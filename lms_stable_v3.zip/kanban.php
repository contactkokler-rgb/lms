<?php
require_once __DIR__ . '/config/auth.php';
$user       = require_permission('leads', 'view');
$account_id = (int)($user['account_id'] ?? 0);
$is_super   = is_super_admin();
$page_title = 'Kanban Board';
$active_nav = 'kanban';
$body_class = 'kanban-page';

$statuses = ['new','contacted','qualified','converted','lost'];
$status_config = [
    'new'       => ['label'=>'New Leads',     'color'=>'#2563eb', 'bg'=>'#eff6ff'],
    'contacted' => ['label'=>'Contacted',     'color'=>'#d97706', 'bg'=>'#fffbeb'],
    'qualified' => ['label'=>'Qualified',     'color'=>'#7c3aed', 'bg'=>'#f5f3ff'],
    'converted' => ['label'=>'Converted',     'color'=>'#16a34a', 'bg'=>'#f0fdf4'],
    'lost'      => ['label'=>'Lost',          'color'=>'#6b7280', 'bg'=>'#f9fafb'],
];

// AJAX: update status via drag
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
    if (!csrf_verify()) { http_response_code(403); exit; }
    header('Content-Type: application/json');
    $lead_id   = (int)($_POST['lead_id'] ?? 0);
    $new_status = $_POST['status'] ?? '';
    if (!in_array($new_status, $statuses) || !$lead_id) {
        echo json_encode(['ok'=>false]); exit;
    }
    $where = $is_super ? 'id = ?' : 'id = ? AND account_id = ?';
    $types = $is_super ? 'si' : 'sii';
    $args  = $is_super ? [$new_status, $lead_id] : [$new_status, $lead_id, $account_id];
    db_query("UPDATE leads SET status = ?, updated_at = NOW() WHERE $where", $types, ...$args);
    audit('lead.kanban_moved', "lead:{$lead_id},status:{$new_status}");
    echo json_encode(['ok'=>true]); exit;
}

// Load all non-spam, non-deleted, non-archived leads
$where_clauses = ["l.status != 'spam'", "l.is_deleted = 0"];
$types = '';
$params = [];
if (!$is_super) { $where_clauses[] = 'l.account_id = ?'; $types .= 'i'; $params[] = $account_id; }
if (!can('leads','view_all')) { $where_clauses[] = 'l.assigned_to = ?'; $types .= 'i'; $params[] = $user['id']; }
$filter_form = (int)($_GET['form_id'] ?? 0);
if ($filter_form) { $where_clauses[] = 'l.form_id = ?'; $types .= 'i'; $params[] = $filter_form; }
$where_sql = 'WHERE ' . implode(' AND ', $where_clauses);

$leads = db_fetch_all(
    "SELECT l.id, l.status, l.score, l.score_category, l.assigned_to, l.submitted_at,
            l.reference_no, l.device_type, l.country,
            f.name AS form_name,
            CONCAT(ua.first_name,' ',ua.last_name) AS assigned_name
     FROM leads l
     LEFT JOIN lead_forms f ON f.id = l.form_id
     LEFT JOIN users ua ON ua.id = l.assigned_to
     $where_sql
     ORDER BY l.submitted_at DESC LIMIT 500",
    $types, ...$params
);

// Get name/email for each lead
$lead_meta = [];
if ($leads) {
    $ids = implode(',', array_map(function($r) { return (int)$r['id']; }, $leads));
    $vals = db_fetch_all("SELECT lead_id, field_key, field_label, value FROM lead_values WHERE lead_id IN ($ids) ORDER BY id ASC");
    foreach ($vals as $v) {
        $lid = (int)$v['lead_id'];
        if (!isset($lead_meta[$lid])) $lead_meta[$lid] = ['name'=>'','email'=>''];
        $lbl = strtolower($v['field_key'].' '.$v['field_label']);
        if (!$lead_meta[$lid]['email'] && (strpos($lbl,'email') !== false)) $lead_meta[$lid]['email'] = $v['value'];
        if (!$lead_meta[$lid]['name']  && (strpos($lbl,'name') !== false) && (strpos($lbl,'email') === false)) $lead_meta[$lid]['name'] = $v['value'];
    }
}

// Bucket leads by status
$buckets = array_fill_keys($statuses, []);
foreach ($leads as $l) {
    if (isset($buckets[$l['status']])) $buckets[$l['status']][] = $l;
}

// Load forms for filter
$forms = $is_super
    ? db_fetch_all('SELECT id, name FROM lead_forms ORDER BY name')
    : db_fetch_all('SELECT id, name FROM lead_forms WHERE account_id = ? ORDER BY name', 'i', $account_id);

include __DIR__ . '/layouts/header.php';
?>

<div class="kanban-header">
  <div>
    <h1 class="page-title" style="margin-bottom:2px;">Kanban Board</h1>
    <p class="page-subtitle"><?= array_sum(array_map('count', $buckets)) ?> leads across <?= count($statuses) ?> stages</p>
  </div>
  <div style="display:flex;gap:8px;align-items:center;">
    <select onchange="window.location='?form_id='+this.value" class="form-control form-control-sm" style="width:180px;">
      <option value="0">All Forms</option>
      <?php foreach ($forms as $f): ?>
      <option value="<?= $f['id'] ?>" <?= $filter_form == $f['id'] ? 'selected' : '' ?>><?= h($f['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <a href="<?= APP_URL ?>/leads.php" class="btn btn-secondary btn-sm">List View</a>
  </div>
</div>

<!-- Kanban board -->
<div class="kanban-board" id="kanbanBoard">
<?php foreach ($statuses as $st):
  $cfg = $status_config[$st];
  $col_leads = $buckets[$st];
?>
<div class="kanban-col" data-status="<?= $st ?>" 
     ondragover="event.preventDefault();this.classList.add('drag-over')"
     ondragleave="this.classList.remove('drag-over')"
     ondrop="handleDrop(event,this)">

  <div class="kanban-col-header" style="color:<?= $cfg['color'] ?>;">
    <?= $cfg['label'] ?>
    <span class="kanban-col-count" style="background:<?= $cfg['bg'] ?>;color:<?= $cfg['color'] ?>;"><?= count($col_leads) ?></span>
  </div>

  <div class="kanban-cards">
    <?php foreach ($col_leads as $lead):
      $meta  = isset($lead_meta[$lead['id']]) ? $lead_meta[$lead['id']] : ['name'=>'','email'=>''];
      $name  = $meta['name'] ?: $meta['email'] ?: $lead['reference_no'];
      $email = $meta['email'];
      $cat   = $lead['score_category'] ?? 'cold';
      $score = (int)($lead['score'] ?? 0);
    ?>
    <div class="kanban-card" 
         draggable="true"
         data-id="<?= $lead['id'] ?>"
         ondragstart="handleDragStart(event,this)"
         ondragend="this.classList.remove('dragging')"
         ondblclick="window.location='<?= APP_URL ?>/lead_view.php?id=<?= $lead['id'] ?>'">
      
      <!-- Score pill top right -->
      <?php if ($score > 0): ?>
      <div style="position:absolute;top:10px;right:10px;">
        <span class="score-pill score-<?= $cat ?>" style="font-size:.65rem;padding:2px 7px 2px 5px;">
          <span class="score-dot"></span><?= $score ?>
        </span>
      </div>
      <?php endif; ?>

      <div class="kanban-card-name" style="padding-right:<?= $score > 0 ? '44px' : '0' ?>;"><?= h($name) ?></div>
      <?php if ($email && $email !== $name): ?>
      <div class="kanban-card-email"><?= h($email) ?></div>
      <?php endif; ?>

      <div class="kanban-card-meta">
        <?php if ($lead['form_name']): ?>
        <span class="kanban-card-form"><?= h($lead['form_name']) ?></span>
        <?php endif; ?>
        <?php if ($lead['country']): ?>
        <span class="kanban-card-form" title="Country"><?= h($lead['country']) ?></span>
        <?php endif; ?>
        <?php if ($lead['device_type'] && $lead['device_type'] !== 'unknown'): ?>
        <span title="<?= $lead['device_type'] ?>" style="font-size:.72rem;">
          <?= $lead['device_type'] === 'mobile' ? '📱' : ($lead['device_type'] === 'tablet' ? '📲' : '🖥') ?>
        </span>
        <?php endif; ?>
        <span class="kanban-card-date"><?= format_dt($lead['submitted_at'], 'd M') ?></span>
      </div>

      <?php if ($lead['assigned_name'] && trim($lead['assigned_name'])): ?>
      <div style="margin-top:7px;padding-top:7px;border-top:1px solid var(--gray-100);display:flex;align-items:center;gap:5px;">
        <?php
        $parts   = explode(' ', trim($lead['assigned_name']));
        $initials = strtoupper(substr($parts[0],0,1) . (isset($parts[1]) ? substr($parts[1],0,1) : ''));
        $colors  = ['#2563eb','#7c3aed','#0891b2','#16a34a'];
        $col     = $colors[$lead['assigned_to'] % count($colors)];
        ?>
        <div style="width:18px;height:18px;border-radius:50%;background:<?= $col ?>;color:#fff;font-size:.58rem;font-weight:700;display:flex;align-items:center;justify-content:center;"><?= $initials ?></div>
        <span style="font-size:.68rem;color:var(--gray-400);"><?= h($lead['assigned_name']) ?></span>
      </div>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>

    <!-- Empty state -->
    <?php if (!$col_leads): ?>
    <div style="text-align:center;padding:24px 12px;color:var(--gray-300);font-size:.76rem;">
      Drop leads here
    </div>
    <?php endif; ?>
  </div>
</div>
<?php endforeach; ?>
</div>

<!-- Toast notification -->
<div id="kanbanToast" style="position:fixed;bottom:24px;right:24px;background:var(--gray-900);color:#fff;padding:10px 18px;border-radius:10px;font-size:.82rem;font-weight:600;opacity:0;transform:translateY(10px);transition:all .25s;pointer-events:none;z-index:9999;"></div>

<script>
var dragging = null;
var csrfToken = '<?= csrf_token() ?>';

function handleDragStart(e, el) {
  dragging = el;
  el.classList.add('dragging');
  e.dataTransfer.effectAllowed = 'move';
  e.dataTransfer.setData('text/plain', el.dataset.id);
}

function handleDrop(e, col) {
  e.preventDefault();
  col.classList.remove('drag-over');
  if (!dragging) return;
  var newStatus = col.dataset.status;
  var leadId    = dragging.dataset.id;
  var cards     = col.querySelector('.kanban-cards');
  cards.appendChild(dragging);
  // Update count badges
  updateCounts();
  // AJAX update
  var fd = new FormData();
  fd.append('lead_id', leadId);
  fd.append('status',  newStatus);
  fd.append('_csrf',   csrfToken);
  fetch(window.location.pathname, {
    method: 'POST',
    headers: {'X-Requested-With': 'XMLHttpRequest'},
    body: fd
  }).then(r => r.json()).then(data => {
    showToast(data.ok ? '✓ Moved to ' + newStatus : '✗ Update failed');
  });
  dragging = null;
}

function updateCounts() {
  document.querySelectorAll('.kanban-col').forEach(function(col) {
    var cards  = col.querySelectorAll('.kanban-card').length;
    var badge  = col.querySelector('.kanban-col-count');
    if (badge) badge.textContent = cards;
  });
}

function showToast(msg) {
  var t = document.getElementById('kanbanToast');
  t.textContent = msg;
  t.style.opacity = '1';
  t.style.transform = 'translateY(0)';
  setTimeout(function() { t.style.opacity='0'; t.style.transform='translateY(10px)'; }, 2500);
}
</script>

<?php include __DIR__ . '/layouts/footer.php'; ?>
