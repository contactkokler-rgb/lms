<?php
require_once __DIR__ . '/config/auth.php';
$user       = require_auth();
$account_id = (int)($user['account_id'] ?? 0);

header('Content-Type: application/json; charset=utf-8');

$_tdb = db();
$_has_is_active   = $_tdb->query("SHOW COLUMNS FROM `campaign_templates` LIKE 'is_active'")->num_rows   > 0;
$_has_is_featured = $_tdb->query("SHOW COLUMNS FROM `campaign_templates` LIKE 'is_featured'")->num_rows > 0;

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $act = $_GET['action'] ?? 'list';

    if ($act === 'list') {
        $cat    = trim($_GET['category'] ?? '');
        $where  = [];
        $types  = '';
        $params = [];

        $where[]  = '(t.is_system = 1 OR t.account_id = ?)';
        $types   .= 'i';
        $params[] = $account_id;

        // Only show active templates if column exists
        if ($_has_is_active) {
            $where[] = '(t.is_system = 0 OR t.is_active = 1)';
        }
        if ($cat && $cat !== 'all') {
            $where[]  = 't.category = ?';
            $types   .= 's';
            $params[] = $cat;
        }

        $wsql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $feat_col = $_has_is_featured ? 't.is_featured' : '0';

        $rows = db_fetch_all(
            "SELECT t.id, t.name, t.category, t.description, t.thumbnail_emoji, t.thumbnail_color,
                    t.is_system, t.sort_order, {$feat_col} AS is_featured, t.page_data,
                    CASE WHEN t.account_id IS NULL THEN 'system' ELSE 'saved' END AS source
             FROM campaign_templates t
             $wsql
             ORDER BY t.is_system DESC, t.sort_order ASC, t.name ASC",
            $types, ...$params
        );

        // Get distinct categories
        $cats = db_fetch_all(
            'SELECT DISTINCT category FROM campaign_templates WHERE is_system=1 OR account_id=? ORDER BY category',
            'i', $account_id
        );

        echo json_encode([
            'ok'        => true,
            'templates' => $rows,
            'categories'=> array_column($cats, 'category'),
        ]);
        exit;
    }

    if ($act === 'get') {
        $id = (int)($_GET['id'] ?? 0);
        $t  = db_fetch(
            'SELECT * FROM campaign_templates WHERE id=? AND (is_system=1 OR account_id=?)',
            'ii', $id, $account_id
        );
        if (!$t) { echo json_encode(['ok'=>false,'error'=>'Not found']); exit; }
        echo json_encode(['ok'=>true, 'page_data'=>$t['page_data'], 'name'=>$t['name']]);
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { echo json_encode(['ok'=>false,'error'=>'CSRF']); exit; }
    $act = $_POST['action'] ?? '';

    if ($act === 'save') {
        $name      = trim($_POST['name']        ?? '');
        $category  = trim($_POST['category']    ?? 'saved');
        $page_data = $_POST['page_data']        ?? '[]';
        $emoji     = trim($_POST['emoji']       ?? 'artboard-tool');
        $color     = preg_match('/^#[0-9a-fA-F]{6}$/', $_POST['color']??'') ? $_POST['color'] : '#2563eb';

        if (!$name) { echo json_encode(['ok'=>false,'error'=>'Name required']); exit; }

        json_decode($page_data);
        if (json_last_error() !== JSON_ERROR_NONE) { echo json_encode(['ok'=>false,'error'=>'Invalid page data']); exit; }

        $id = db_insert(
            'INSERT INTO campaign_templates (account_id, name, category, description, thumbnail_emoji, thumbnail_color, page_data, is_system, created_by)
             VALUES (?,?,?,?,?,?,?,0,?)',
            'issssssi',
            $account_id, $name, $category, '', $emoji, $color, $page_data, (int)$user['id']
        );
        echo json_encode(['ok'=>true,'id'=>$id]);
        exit;
    }

    if ($act === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $t  = db_fetch('SELECT id FROM campaign_templates WHERE id=? AND account_id=? AND is_system=0', 'ii', $id, $account_id);
        if (!$t) { echo json_encode(['ok'=>false,'error'=>'Not found']); exit; }
        db_query('DELETE FROM campaign_templates WHERE id=? AND account_id=?', 'ii', $id, $account_id);
        echo json_encode(['ok'=>true]);
        exit;
    }
}

echo json_encode(['ok'=>false,'error'=>'Unknown action']);
