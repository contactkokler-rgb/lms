<?php
/**
 * LeadPro — Campaign Management
 * campaigns.php — List, create, edit, archive campaigns
 */
require_once __DIR__ . '/config/auth.php';
require_once __DIR__ . '/config/ai.php';
require_once __DIR__ . '/config/BillingService.php';
$user       = require_permission('campaigns', 'view');
$account_id = (int)($user['account_id'] ?? 0);
$is_super   = is_super_admin();
$uid        = (int)$user['id'];

$page_title = 'Campaigns';
$active_nav = 'campaigns';

// ── POST Actions ──────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { http_response_code(403); die('CSRF'); }
    $act = $_POST['action'] ?? '';

    if ($act === 'create' && can('campaigns', 'create')) {
        // Plan enforcement
        if (!$is_super) {
            BillingService::enforce($account_id, 'can_create_campaign', 'create a new campaign');
        }
        $name      = trim($_POST['name'] ?? '');
        $desc      = trim($_POST['description'] ?? '');
        $objective = trim($_POST['objective'] ?? '');
        $status    = in_array($_POST['status'] ?? '', ['draft','active','paused']) ? $_POST['status'] : 'draft';
        $owner_id  = (int)($_POST['owner_id'] ?? $uid);
        $start     = $_POST['start_date'] ?? null;
        $end       = $_POST['end_date']   ?? null;
        $color     = preg_match('/^#[0-9a-fA-F]{6}$/', $_POST['color'] ?? '') ? $_POST['color'] : '#2563eb';

        if ($name) {
            $cid = db_insert(
                'INSERT INTO campaigns (account_id,name,description,objective,status,owner_id,start_date,end_date,color,created_by)
                 VALUES (?,?,?,?,?,?,?,?,?,?)',
                'issssisssi',
                $account_id, $name, $desc, $objective, $status,
                $owner_id ?: null,
                $start ?: null, $end ?: null, $color, $uid
            );
            audit('campaign.created', "campaign:{$cid}");
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Campaign created successfully.'];
            header('Location: ' . APP_URL . '/campaign_view.php?id=' . $cid); exit;
        }
        $_SESSION['flash'] = ['type'=>'error','msg'=>'Campaign name is required.'];
    }

    elseif ($act === 'edit' && can('campaigns', 'edit')) {
        // Plan enforcement
        if (!$is_super) {
            BillingService::enforce($account_id, 'can_edit', 'edit campaigns');
        }
        $cid  = (int)($_POST['campaign_id'] ?? 0);
        $camp = db_fetch('SELECT * FROM campaigns WHERE id=? AND account_id=?', 'ii', $cid, $account_id);
        if ($camp) {
            $name      = trim($_POST['name'] ?? '');
            $desc      = trim($_POST['description'] ?? '');
            $objective = trim($_POST['objective'] ?? '');
            $status    = in_array($_POST['status'] ?? '', ['draft','active','paused','archived']) ? $_POST['status'] : $camp['status'];
            $owner_id  = (int)($_POST['owner_id'] ?? 0);
            $start     = $_POST['start_date'] ?? null;
            $end       = $_POST['end_date']   ?? null;
            $color     = preg_match('/^#[0-9a-fA-F]{6}$/', $_POST['color'] ?? '') ? $_POST['color'] : $camp['color'];
            if ($name) {
                db_query(
                    'UPDATE campaigns SET name=?,description=?,objective=?,status=?,owner_id=?,start_date=?,end_date=?,color=? WHERE id=? AND account_id=?',
                    'ssssisssii',
                    $name, $desc, $objective, $status,
                    $owner_id ?: null,
                    $start ?: null, $end ?: null, $color,
                    $cid, $account_id
                );
                audit('campaign.edited', "campaign:{$cid}");
                $_SESSION['flash'] = ['type'=>'success','msg'=>'Campaign updated.'];
            }
        }
    }

    elseif ($act === 'archive' && can('campaigns', 'edit')) {
        $cid = (int)($_POST['campaign_id'] ?? 0);
        db_query('UPDATE campaigns SET status="archived" WHERE id=? AND account_id=?', 'ii', $cid, $account_id);
        audit('campaign.archived', "campaign:{$cid}");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Campaign archived.'];
    }

    elseif ($act === 'delete' && can('campaigns', 'delete')) {
        $cid = (int)($_POST['campaign_id'] ?? 0);
        db_query('DELETE FROM campaigns WHERE id=? AND account_id=?', 'ii', $cid, $account_id);
        audit('campaign.deleted', "campaign:{$cid}");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Campaign deleted.'];
    }

    header('Location: ' . APP_URL . '/campaigns.php'); exit;
}

// ── GET / Display ─────────────────────────────────────────────
$flash      = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$f_status   = $_GET['status']   ?? '';
$search     = trim($_GET['q']   ?? '');
$show_arch  = ($f_status === 'archived');

$where  = ['c.account_id=?']; $types = 'i'; $params = [$account_id];
if ($f_status) { $where[] = 'c.status=?'; $types .= 's'; $params[] = $f_status; }
else           { $where[] = "c.status != 'archived'"; }
if ($search)   { $where[] = 'c.name LIKE ?'; $types .= 's'; $params[] = "%$search%"; }
$wsql = 'WHERE ' . implode(' AND ', $where);

$campaigns = db_fetch_all(
    "SELECT c.*,
        CONCAT(u.first_name,' ',u.last_name) AS owner_name,
        (SELECT COUNT(*) FROM campaign_pages cp WHERE cp.campaign_id=c.id) AS page_count,
        (SELECT COUNT(*) FROM leads l WHERE l.campaign_id=c.id) AS lead_count
     FROM campaigns c
     LEFT JOIN users u ON u.id=c.owner_id
     {$wsql} ORDER BY c.created_at DESC",
    $types, ...$params
);

// Stats summary
$stats = db_fetch(
    "SELECT
        SUM(status='active')   AS active,
        SUM(status='draft')    AS draft,
        SUM(status='paused')   AS paused,
        SUM(status='archived') AS archived,
        COUNT(*)               AS total
     FROM campaigns WHERE account_id=?", 'i', $account_id
) ?? [];

// Team list for owner selector
$team = $is_super
    ? db_fetch_all("SELECT id,first_name,last_name FROM users WHERE status='active' ORDER BY first_name")
    : db_fetch_all("SELECT id,first_name,last_name FROM users WHERE account_id=? AND status='active' ORDER BY first_name", 'i', $account_id);

$status_cfg = [
    'draft'    => ['bg'=>'#f1f5f9','text'=>'#475569','label'=>'Draft'],
    'active'   => ['bg'=>'#f0fdf4','text'=>'#15803d','label'=>'Active'],
    'paused'   => ['bg'=>'#fffbeb','text'=>'#92400e','label'=>'Paused'],
    'archived' => ['bg'=>'#f8fafc','text'=>'#94a3b8','label'=>'Archived'],
];

include __DIR__ . '/layouts/header.php';
?>

<!-- Flash -->
<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'danger' ?> mb-5">
    <?= h($flash['msg']) ?>
</div>
<?php endif; ?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="hgi hgi-stroke hgi-megaphone-02"></i>Campaigns</h1>
        <p class="page-subtitle">Manage marketing campaigns and landing pages</p>
    </div>
    <div>
        <?php if (can('campaigns','create')): ?>
        <?php if (ai_enabled()): ?>
        <button class="btn btn-sm btn-ai" onclick="openAIWizard()">
            <i class="hgi hgi-stroke hgi-stars"></i>
            Generate with AI
        </button>
        <?php endif; ?>
        <button class="btn btn-sm btn-primary" onclick="openModal('createModal')"><i class="hgi hgi-stroke hgi-plus-sign"></i> New Campaign</button>
        <?php endif; ?>
    </div>
</div>


<div class="flex gap-4 justify-between items-center">
    <div class="tabs-pill">
        <?php
      $kpis = [
        [!$f_status?'on':'',                (int)($stats['total']??0),     '',                     'All',      'dark'],
        [$f_status==='active'  ?'on':'',    (int)($stats['active']??0),    '?status=active',       'Active',   'success'],
        [$f_status==='draft'   ?'on':'',    (int)($stats['draft']??0),     '?status=draft',        'Draft',    'info'],
        [$f_status==='paused'  ?'on':'',    (int)($stats['paused']??0),    '?status=paused',       'Paused',   'warning'],
        [$f_status==='archived'?'on':'',    (int)($stats['archived']??0),  '?status=archived',     'Archived', 'danger'],
      ];
      foreach ($kpis as [$a,$c,$l,$n,$b]): ?>

        <a href="campaigns.php<?= $l ?>" class="tab-pill <?= $a ?>"><?= $n ?><span class="badge badge-<?= $b ?> badge-sm"><?= $c ?></span></a>
        <?php endforeach; ?>
    </div>


    <!-- Filters + Search -->
    <form method="GET" class="flex gap-2">
        <?php if ($f_status): ?><input type="hidden" name="status" value="<?= h($f_status) ?>"><?php endif; ?>
        <input type="text" name="q" value="<?= h($search) ?>" placeholder="Search campaigns…" class="input input-sm" style="width:200px;">
        <button class="btn btn-secondary btn-sm">Search</button>
    </form>
</div>

<!-- Campaign grid -->
<?php if ($campaigns): ?>
<div class="mt-5 grid grid-cols-3 gap-4">
<?php foreach ($campaigns as $c):
    $sc = $status_cfg[$c['status']] ?? $status_cfg['draft'];
    $col = $c['color'] ?? '#2563eb';
    $start = $c['start_date'] ? date('d M Y', strtotime($c['start_date'])) : null;
    $end   = $c['end_date']   ? date('d M Y', strtotime($c['end_date']))   : null;
?>
    <div class="card">
        <div class="card-header flex justify-between">
            <div class="card-title"><?= h($c['name']) ?></div>
            <div>
                <?php if (can('campaigns','edit')): ?>
                <button class="btn btn-secondary btn-xs btn-icon" title="Edit" onclick="openEdit(<?= $c['id'] ?>,<?= htmlspecialchars(json_encode($c), ENT_QUOTES) ?>)"><i class="hgi hgi-stroke hgi-edit-02"></i></button>
                <?php endif; ?>
                <?php if (can('campaigns','delete')): ?>
                <button class="btn btn-danger btn-xs btn-icon" title="Delete" onclick="confirmDelete(<?= $c['id'] ?>, '<?= h(addslashes($c['name'])) ?>')"><i class="hgi hgi-stroke hgi-delete-01"></i></button>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-body" style="padding-top: var(--space-4); background: <?= h($col) ?>;">
            
            <div class="flex justify-between items-center">
                <?php if ($c['owner_name'] && trim($c['owner_name'])): ?>
                <div>                    
                    <div class="text-sm font-semibold"><?= h(trim($c['owner_name'])) ?></div>
                    <div class="caption">Owner</div>
                </div>
                <?php endif; ?>
                <span class="badge" style="background:<?= $sc['bg'] ?>;color:<?= $sc['text'] ?>;"><?= $sc['label'] ?></span>
            </div>
            
            <div class="grid grid-cols-2 gap-4 mt-4">
                <div class="card-stat bg-white">
                    <div class="text-xs font-semibold tracking-widest uppercase text-muted ml-2">Pages</div>
                    <div class="badge badge-lg badge-info"><?= $c['page_count'] ?></div>                    
                </div>
                <div class="card-stat bg-white">
                    <div class="text-xs font-semibold tracking-widest uppercase text-muted ml-2">Leads</div>
                    <div class="badge badge-lg badge-warning"><?= $c['lead_count'] ?></div>
                </div>
            </div>
            
            <?php if ($start || $end): ?>
            <div class="flex items-center my-4">
                <?= $start ? '<i class="hgi hgi-stroke hgi-calendar-03 mr-1"></i>'.$start : '' ?><?= ($start&&$end)?' <i class="hgi hgi-stroke hgi-arrow-right-02 mr-1 ml-1"></i> ':'' ?><?= $end ? $end : '' ?>
            </div>
            <?php endif; ?>

            <?php if ($c['description']): ?>
                <div class="caption mt-4">Description</div>
                <div class="text-xs"><?= h(mb_substr($c['description'], 0, 100)) ?><?= mb_strlen($c['description'])>100?'…':'' ?></div>                
            <?php endif; ?>

            <?php if ($c['objective']): ?>
                <div class="caption mt-4">Objective</div>
                <div class="text-xs"><?= h($c['objective']) ?></div>                
            <?php endif; ?>
            
        </div>
        <div class="card-footer flex justify-between" style="border: none;">
            <?php if ($c['status'] !== 'archived' && can('campaigns','edit')): ?>
            <form method="POST" style="display:inline;" onsubmit="return confirm('Archive this campaign?')">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="archive">
                <input type="hidden" name="campaign_id" value="<?= $c['id'] ?>">
                <button class="btn btn-secondary btn-sm" type="submit"><i class="hgi hgi-stroke hgi-archive"></i>Archive</button>
            </form>
            <?php endif; ?>
            <a href="<?= APP_URL ?>/campaign_view.php?id=<?= $c['id'] ?>" class="btn btn-primary btn-sm">Open Workspace <i class="hgi hgi-stroke hgi-arrow-right-02"></i></a>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php else: ?>
<div class="card mt-10">
    <div class="empty-state">
        <div class="empty-state-icon">
            <i class="hgi hgi-stroke hgi-megaphone-02"></i>
        </div>
        <div class="empty-state-title">No campaigns yet<?= $search ? ' matching "'.$search.'"' : '' ?></div>        
        <div class="empty-state-desc">Create your first campaign to start building landing pages and capturing leads.</div>
        <?php if (can('campaigns','create')): ?>
            <button class="btn btn-primary" onclick="openModal('createModal')"><i class="hgi hgi-stroke hgi-plus-sign"></i> Create First Campaign</button>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>


<!-- ── CREATE MODAL ──────────────────────────────────────────── -->
<div class="modal-overlay" id="createModal">
    <form method="POST" class="modal">
        <div class="modal-header">
            <div>
                <h2 class="modal-title">New Campaign</h2>
            </div>
            <button class="modal-close" onclick="closeModal('createModal')">
                <i class="hi hi-x-mark"></i>
            </button>
        </div>
        <div class="modal-body">
        
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create">
            <div class="form-group">
                <label class="form-label">Campaign Owner</label>
                <select name="owner_id" class="select select-sm">
                    <option value="">— Select owner —</option>
                    <?php foreach ($team as $t): ?>
                    <option value="<?= $t['id'] ?>" <?= $t['id']===$uid?'selected':'' ?>><?= h($t['first_name'].' '.$t['last_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>   

            <div class="form-group">
                <label class="form-label">Campaign Name <span style="color:#ef4444;">*</span></label>
                <input type="text" name="name" class="input input-sm" placeholder="e.g. Spring Product Launch" required>
            </div>
            <div class="form-group">
                <label class="form-label">Description</label>
                <textarea name="description" class="textarea" rows="2" placeholder="What is this campaign about?"></textarea>
            </div>
            <div class="form-group">
                <label class="form-label">Campaign Colour</label>
                <input type="color" name="color" value="#fefae0" class="input input-sm input-color" oninput="this.style.background = this.value">
            </div>

            <div class="grid grid-cols-2 gap-3 mt-2">                
                <div class="form-group">
                    <label class="form-label">Objective</label>
                    <input type="text" name="objective" class="input input-sm" placeholder="e.g. Generate 200 qualified leads">
                </div>
                <div class="form-group">                    
                    <label class="form-label">Status</label>
                    <select name="status" class="select select-sm">
                        <option value="draft">Draft</option>
                        <option value="active">Active</option>
                        <option value="paused">Paused</option>
                    </select>                    
                </div>
                
                <div class="form-group">
                    <label class="form-label">Start Date</label>
                    <input type="date" name="start_date" class="input input-sm">
                </div>
                <div class="form-group">
                    <label class="form-label">End Date</label>
                    <input type="date" name="end_date" class="input input-sm">
                </div>                   
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-sm btn-secondary" onclick="closeModal('createModal')">Cancel</button>
            <button type="submit" class="btn btn-sm btn-primary"><i class="hgi hgi-stroke hgi-tick-02"></i>Create Campaign</button>
        </div>
    </form>
</div>

<!-- ── EDIT MODAL ────────────────────────────────────────────── -->
<div class="modal-overlay" id="editModal">
    <form method="POST" id="editForm" class="modal">
        <div class="modal-header">
            <div>
                <h2 class="modal-title">Edit Campaign</h2>
            </div>
            <button class="modal-close" onclick="closeModal('editModal')">
                <i class="hi hi-x-mark"></i>
            </button>
        </div>
        
        <div class="modal-body">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="campaign_id" id="editId">
            
            <div class="form-group">
                <label class="form-label">Campaign Owner</label>
                <select name="owner_id" id="editOwner" class="select select-sm">
                    <option value="">— Select owner —</option>
                    <?php foreach ($team as $t): ?>
                    <option value="<?= $t['id'] ?>"><?= h($t['first_name'].' '.$t['last_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label class="form-label">Campaign Name <span style="color:#ef4444;">*</span></label>
                <input type="text" name="name" id="editName" class="input input-sm" required>
            </div>
            <div class="form-group">
                <label class="form-label">Description</label>
                <textarea name="description" id="editDesc" class="textarea" rows="2"></textarea>
            </div>
            
            <div class="form-group">
                <label class="form-label">Campaign Colour</label>
                <input type="color" name="color" id="editColor" class="input input-sm">
            </div>
            
            <div class="grid grid-cols-2 gap-3 mt-2"> 
                <div class="form-group">
                    <label class="form-label">Objective</label>
                    <input type="text" name="objective" id="editObjective" class="input input-sm">
                </div>
                <div class="form-group">

                    <label class="form-label">Status</label>
                    <select name="status" id="editStatus" class="select select-sm">
                        <option value="draft">Draft</option>
                        <option value="active">Active</option>
                        <option value="paused">Paused</option>
                        <option value="archived">Archived</option>
                    </select>
                </div>
            </div>
            
            <div class="grid grid-cols-2 gap-3 mt-2"> 
                <div class="form-group">
                    <label class="form-label">Start Date</label>
                    <input type="date" name="start_date" id="editStart" class="input input-sm">
                </div>
                <div class="form-group">
                    <label class="form-label">End Date</label>
                    <input type="date" name="end_date" id="editEnd" class="input input-sm">
                </div>                
            </div>
            
        </div>
        
        <div class="modal-footer">
            <button type="button" class="btn btn-sm btn-secondary" onclick="closeModal('editModal')">Cancel</button>
            <button type="submit" class="btn btn-sm btn-primary"><i class="hgi hgi-stroke hgi-tick-02"></i>Save Changes</button>
        </div>
    </form>
</div>

<!-- ── DELETE CONFIRM MODAL ──────────────────────────────────── -->
<div class="modal-overlay" id="deleteModal">
    <form method="POST" class="modal">
        <div class="modal-header">
            <div>
                <h2 class="modal-title">Delete Campaign</h2>
            </div>
            <button class="modal-close" onclick="closeModal('deleteModal')">
                <i class="hi hi-x-mark"></i>
            </button>
        </div>
        
        <div class="modal-body">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="campaign_id" id="deleteId">
            
            <p>
                Are you sure you want to delete <strong id="deleteName"></strong>?
                This will permanently delete all associated landing pages. Leads will be retained.
            </p>
        </div>
            
        <div class="modal-footer">
            <button type="button" class="btn btn-sm btn-secondary" onclick="closeModal('deleteModal')">Cancel</button>
            <button type="submit" class="btn btn-sm btn-danger"><i class="hgi hgi-stroke hgi-delete-01"></i>Delete</button>
        </div>
        
    </form>
</div>

<script>
    function openModal(id) {
        document.getElementById(id).classList.add('open');
        document.body.style.overflow = 'hidden';
    }

    function closeModal(id) {
        document.getElementById(id).classList.remove('open');
        document.body.style.overflow = '';
    }
    // Close on backdrop click
    document.querySelectorAll('.modal-back').forEach(function(el) {
        el.addEventListener('click', function(e) {
            if (e.target === el) closeModal(el.id);
        });
    });

    function openEdit(id, data) {
        document.getElementById('editId').value = id;
        document.getElementById('editName').value = data.name || '';
        document.getElementById('editDesc').value = data.description || '';
        document.getElementById('editObjective').value = data.objective || '';
        document.getElementById('editStatus').value = data.status || 'draft';
        document.getElementById('editColor').value = data.color || '#2563eb';
        document.getElementById('editStart').value = data.start_date || '';
        document.getElementById('editEnd').value = data.end_date || '';
        document.getElementById('editOwner').value = data.owner_id || '';
        openModal('editModal');
    }

    function confirmDelete(id, name) {
        document.getElementById('deleteId').value = id;
        document.getElementById('deleteName').textContent = name;
        openModal('deleteModal');
    }
</script>

<!-- ═══════════════════════════════════════════════════════════
     AI CAMPAIGN GENERATOR — 3-Step Wizard Modal
════════════════════════════════════════════════════════════ -->
<?php if (ai_enabled()): ?>
<div id="aiModal" class="modal-overlay model-ai">
    <div class="modal">
        <div class="modal-header">
            <div>
                <h2 class="modal-title">Generate Campaign</h2>
            </div>
            
            <div class="flex items-center gap-2">
                <?php foreach ([1=>'Business',2=>'Goal',3=>'Review'] as $n=>$label): ?>
                <div style="display:flex;align-items:center;gap:0;flex:1;">
                    <div class="ai-step-dot" id="aiDot<?= $n ?>" style="<?= $n===1?'background:#2563eb;color:#fff':'background:#f1f5f9;color:#94a3b8' ?>;width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.72rem;font-weight:800;flex-shrink:0;"><?= $n ?></div>
                    <div style="font-size:.7rem;font-weight:600;color:#64748b;margin-left:6px;white-space:nowrap;"><?= $label ?></div>
                    <?php if ($n < 3): ?><div style="flex:1;height:1px;background:#e2e8f0;margin:0 8px;"></div><?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- ── STEP 1 — Business context ── -->
        <div id="aiStep1">
            <div class="modal-body">
                <div class="text-xs text-muted mb-3">Tell us about your business and we'll build a complete campaign.</div>

                <div class="form-group">
                    <label class="form-label">Business Type <span style="color:#ef4444;">*</span></label>
                    <input type="text" id="aiBizType" class="input input-sm" placeholder="e.g. SaaS company, digital marketing agency, fitness coach…">
                </div>
                <div class="form-group">
                    <label class="form-label">Target Audience</label>
                    <input type="text" id="aiAudience" class="input input-sm" placeholder="e.g. small business owners, marketing managers, B2B startups…">
                </div>
                <div class="form-group">
                    <label class="form-label">Tone</label>
                    <select id="aiTone" class="select select-sm">
                        <option value="professional">Professional</option>
                        <option value="friendly">Friendly &amp; Casual</option>
                        <option value="urgent">Urgent &amp; Direct</option>
                        <option value="inspirational">Inspirational</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-secondary" onclick="closeModal('aiModal')">Cancel</button>
                <button type="button" class="btn btn-sm btn-primary" onclick="aiStep1Next()">Next<i class="hgi hgi-stroke hgi-arrow-right-02"></i></button>
            </div>
        </div>

        <!-- ── STEP 2 — Campaign goal & offer ── -->
        <div id="aiStep2" style="display:none;">
            <div class="modal-body">
                <div class="text-xs text-muted mb-3">What are you promoting?</div>

                <div class="form-group">
                    <label class="form-label">Campaign Goal <span style="color:#ef4444;">*</span></label>
                    <select id="aiGoal" class="select select-sm">
                        <option value="generate leads">Generate leads</option>
                        <option value="register webinar attendees">Webinar registration</option>
                        <option value="sell a product or service">Product / service sale</option>
                        <option value="book consultation calls">Book consultation calls</option>
                        <option value="promote a discount or offer">Promote discount / offer</option>
                        <option value="grow email list">Grow email list</option>
                        <option value="announce a product launch">Product launch</option>
                        <option value="drive event registrations">Event registrations</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Offer / Promotion <span style="color:#ef4444;">*</span></label>
                    <textarea id="aiOffer" class="textarea" rows="3" placeholder="e.g. Free 14-day trial of our lead management software. No credit card needed. Cancel anytime."></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Campaign Colour</label>
                    <input type="color" id="aiColor" value="#fefae0" class="input input-sm">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-secondary" onclick="aiGoBack(1)"><i class="hgi hgi-stroke hgi-arrow-left-02"></i> Back</button>
                <button type="button" class="btn btn-sm btn-primary" id="aiGenerateBtn" onclick="aiGenerate()">
                    Generate Campaign<i class="hgi hgi-stroke hgi-arrow-right-02"></i>
                </button>
            </div>
        </div>

        <!-- ── STEP 3 — Preview & confirm ── -->
        <div id="aiStep3" style="display:none;">
            <div class="modal-body">
                <div class="text-xs text-muted mb-3">Review your campaign & edit any field before creating.</div>

                <div class="form-group">
                    <label class="form-label">Campaign Name</label>
                    <input type="text" id="aiResultName" class="input input-sm">
                </div>
                <div class="form-group">
                    <label class="form-label">Campaign Objective</label>
                    <input type="text" id="aiResultObj" class="input input-sm">
                </div>
                <div class="form-group">
                    <label class="form-label">Landing Page Title</label>
                    <input type="text" id="aiResultPageTitle" class="input input-sm">
                </div>

                <!-- Page blocks preview -->
                <div class="ai-page-preview">
                    <div class="preview-header">
                        <div class="text-sm font-semibold tracking-wider uppercase">Landing Page Preview</div>
                        <div id="aiBlockCount" class="text-xs text-muted"></div>
                    </div>
                    <div id="aiBlockPreview" class="preview-block"></div>
                </div>

                <div class="alert alert-success mt-5">
                    Your page will open in the builder so you can customise it further before publishing.
                </div>

                <div id="aiCreateError" class="alert alert-error mt-5"></div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-secondary" onclick="aiGoBack(2)"><i class="hgi hgi-stroke hgi-arrow-left-02"></i> Regenerate</button>
                <button type="button" class="btn btn-sm btn-primary" id="aiCreateBtn" onclick="aiCreate()">
                    Create Campaign &amp; Open Builder<i class="hgi hgi-stroke hgi-arrow-right-02"></i>
                </button>
            </div>
        </div>

        <!-- Loading state (overlay) -->
        <div id="aiLoading" class="modal-body text-center">
            <div class="loading-spinner mt-5"></div>
            <div class="text-lg mt-4 mb-2" id="aiLoadingText">Generating your campaign…</div>
            <div class="text-xs text-muted mb-10">This usually takes 5–15 seconds</div>
        </div>

    </div>
</div>

<style>
    @keyframes spin {
        to {
            transform: rotate(360deg);
        }
    }
</style>

<script>
    const AI_ENDPOINT = '<?= APP_URL ?>/ai_campaign.php';
    const AI_CSRF = '<?= csrf_token() ?>';
    let aiBlocks = [];
    let aiCurrentStep = 1;

    function openAIWizard() {
        aiCurrentStep = 1;
        showAIStep(1);
        // Reset fields
        ['aiBizType', 'aiAudience', 'aiOffer', 'aiResultName', 'aiResultObj', 'aiResultPageTitle'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.value = '';
        });
        document.getElementById('aiTone').value = 'professional';
        document.getElementById('aiGoal').value = 'generate leads';
        document.getElementById('aiColor').value = '#2563eb';
        document.getElementById('aiCreateError').style.display = 'none';
        aiBlocks = [];
        openModal('aiModal');
    }

    function showAIStep(n) {
        [1, 2, 3].forEach(i => {
            document.getElementById('aiStep' + i).style.display = i === n ? '' : 'none';
            const dot = document.getElementById('aiDot' + i);
            if (dot) {
                dot.style.background = i <= n ? '#2563eb' : '#f1f5f9';
                dot.style.color = i <= n ? '#fff' : '#94a3b8';
            }
        });
        document.getElementById('aiLoading').style.display = 'none';
        aiCurrentStep = n;
    }

    function aiGoBack(n) {
        showAIStep(n);
    }

    function aiStep1Next() {
        const biz = document.getElementById('aiBizType').value.trim();
        if (!biz) {
            document.getElementById('aiBizType').focus();
            return;
        }
        showAIStep(2);
    }

    async function aiGenerate() {
        const biz = document.getElementById('aiBizType').value.trim();
        const goal = document.getElementById('aiGoal').value;
        const offer = document.getElementById('aiOffer').value.trim();
        const aud = document.getElementById('aiAudience').value.trim();
        const tone = document.getElementById('aiTone').value;

        if (!biz || !offer) {
            alert('Please fill in the required fields.');
            return;
        }

        // Show loading
        [1, 2, 3].forEach(i => document.getElementById('aiStep' + i).style.display = 'none');
        document.getElementById('aiLoading').style.display = '';
        const loadingText = document.getElementById('aiLoadingText');
        const msgs = ['Generating your campaign…', 'Writing headlines…', 'Building landing page blocks…', 'Almost there…'];
        let mi = 0;
        const ticker = setInterval(() => {
            loadingText.textContent = msgs[++mi % msgs.length];
        }, 3000);

        const fd = new FormData();
        fd.append('action', 'generate');
        fd.append('_csrf', AI_CSRF);
        fd.append('business_type', biz);
        fd.append('goal', goal);
        fd.append('audience', aud);
        fd.append('offer', offer);
        fd.append('tone', tone);

        try {
            const res = await fetch(AI_ENDPOINT, {
                method: 'POST',
                body: fd
            });
            const data = await res.json();
            clearInterval(ticker);

            if (!data.ok) {
                document.getElementById('aiLoading').style.display = 'none';
                document.getElementById('aiStep2').style.display = '';
                alert('AI Error: ' + (data.error || 'Unknown error. Please try again.'));
                return;
            }

            aiBlocks = data.blocks || [];

            // Populate step 3 fields
            document.getElementById('aiResultName').value = data.campaign_name || '';
            document.getElementById('aiResultObj').value = data.campaign_objective || '';
            document.getElementById('aiResultPageTitle').value = data.page_title || data.campaign_name || '';

            // Block preview
            renderAIBlockPreview(aiBlocks);
            document.getElementById('aiBlockCount').textContent = aiBlocks.length + ' blocks generated';

            showAIStep(3);

        } catch (e) {
            clearInterval(ticker);
            document.getElementById('aiLoading').style.display = 'none';
            document.getElementById('aiStep2').style.display = '';
            alert('Network error. Please check your connection and try again.');
        }
    }

    function renderAIBlockPreview(blocks) {
        const container = document.getElementById('aiBlockPreview');
        const colors = {
            headline:       '#fefae0',
            subheadline:    '#ffe5ec',
            paragraph:      '#f1faee',
            bullet_list:    '#f1f2f6',
            lead_form:      '#fffcf2',
            cta_button:     '#d8f3dc',
            trust_badges:   '#edf6f9',
            testimonial:    '#ffedd8',
            offer_banner:   '#daf0ee',
            countdown:      '#eaf4f4',
            pricing:        '#f9e9ec',
            faq:            '#fffae5',
            reviews:        '#f8edeb',
            appointment:    '#f4effa',
            nav_bar:        '#caf0f8',
            hero_section:   '#f5ebe0',
            feature_grid:   '#efe6dd',
            stats_row:      '#e8e8e4',
            footer_block:   '#ffe5d9',
        };
        const icons = {
            headline:       'megaphone-03',
            subheadline:    'text-font',
            paragraph:      'paragraph',
            bullet_list:    'check-list',
            lead_form:      'database-01',
            cta_button:     'rectangle-selection-01',
            trust_badges:   'checkmark-badge-02',
            testimonial:    'comment-03',
            offer_banner:   'coupon-percent',
            countdown:      'clock-04',
            pricing:        'tag-01',
            faq:            'file-question-mark',
            reviews:        'question',
            appointment:    'calendar-03',
            image:          'image-01',
            divider:        'dashed-line-01',
            spacer:         'paragraph-spacing',
            nav_bar:        'menu-09',
            hero_section:   'image-crop',
            feature_grid:   'grid-view',
            stats_row:      'blockchain-05',
            footer_block:   'blocked',
        };
        container.innerHTML = blocks.map(b => {
            const ic = icons[b.type] || 'blockchain-01';
            const bg = colors[b.type] || '#e6e8e6';
            const lbl = b.type.replace(/_/g, ' ');
            let preview = '';
            if (b.text) preview = escHtmlPrev(String(b.text).slice(0, 60));
            else if (b.title) preview = escHtmlPrev(String(b.title).slice(0, 60));
            else if (b.headline) preview = escHtmlPrev(String(b.headline).slice(0, 60));
            else if (b.items) preview = b.items.slice(0, 2).map(i => escHtmlPrev(String(i).slice(0, 40))).join(' · ');
            else if (b.badges) preview = b.badges.slice(0, 3).map(x => escHtmlPrev(x)).join(' · ');
            return `<div class="preview-item ${b.type}" style="background:${bg};">
      <i class="hgi hgi-stroke hgi-${ic} text-lg"></i>
      <div>
        <div class="text-xs uppercase font-bold">${lbl}</div>
        ${preview ? `<div class="text-2xs">${preview}</div>` : ''}
      </div>
    </div>`;
        }).join('');
    }

    async function aiCreate() {
        const name = document.getElementById('aiResultName').value.trim();
        const objective = document.getElementById('aiResultObj').value.trim();
        const pageTitle = document.getElementById('aiResultPageTitle').value.trim();
        const color = document.getElementById('aiColor').value || '#2563eb';
        const errDiv = document.getElementById('aiCreateError');
        errDiv.style.display = 'none';

        if (!name) {
            document.getElementById('aiResultName').focus();
            return;
        }

        const btn = document.getElementById('aiCreateBtn');
        btn.disabled = true;
        btn.textContent = 'Creating…';

        const fd = new FormData();
        fd.append('action', 'create');
        fd.append('_csrf', AI_CSRF);
        fd.append('campaign_name', name);
        fd.append('campaign_objective', objective);
        fd.append('page_title', pageTitle);
        fd.append('page_data', JSON.stringify(aiBlocks));
        fd.append('color', color);
        fd.append('meta_title', document.getElementById('aiResultName').value.trim());
        fd.append('meta_desc', document.getElementById('aiResultObj').value.trim());

        try {
            const res = await fetch(AI_ENDPOINT, {
                method: 'POST',
                body: fd
            });
            const data = await res.json();
            if (data.ok) {
                window.location.href = data.redirect;
            } else {
                errDiv.textContent = 'Error: ' + (data.error || 'Creation failed.');
                errDiv.style.display = '';
                btn.disabled = false;
                btn.textContent = 'Create Campaign & Open Builder';
            }
        } catch (e) {
            errDiv.textContent = 'Network error. Please try again.';
            errDiv.style.display = '';
            btn.disabled = false;
            btn.textContent = 'Create Campaign & Open Builder';
        }
    }

    function escHtmlPrev(s) {
        return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
</script>
<?php endif; ?>

<?php include __DIR__ . '/layouts/footer.php'; ?>