<?php
require_once __DIR__ . '/config/auth.php';
require_once __DIR__ . '/config/ai.php';

$user       = require_permission('campaigns', 'create');
$account_id = (int)($user['account_id'] ?? 0);
$uid        = (int)$user['id'];

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['ok' => false, 'error' => 'POST required']); exit;
}
if (!csrf_verify()) {
    echo json_encode(['ok' => false, 'error' => 'CSRF token invalid']); exit;
}
if (!ai_enabled()) {
    echo json_encode(['ok' => false, 'error' => 'AI is not enabled. Please add an API key in Settings → AI & API.']); exit;
}

$act = $_POST['action'] ?? '';

// ══════════════════════════════════════════════════════════════
// ACTION: generate  — call AI, return structured data for preview
// ══════════════════════════════════════════════════════════════
if ($act === 'generate') {

    $business_type = trim($_POST['business_type'] ?? '');
    $goal          = trim($_POST['goal']          ?? '');
    $audience      = trim($_POST['audience']      ?? '');
    $offer         = trim($_POST['offer']         ?? '');
    $tone          = trim($_POST['tone']          ?? 'professional');

    if (!$business_type || !$goal || !$offer) {
        echo json_encode(['ok' => false, 'error' => 'Business type, goal, and offer are required.']); exit;
    }

    // ── Build the AI prompt ──────────────────────────────────
    $system_prompt = <<<SYS
You are an expert marketing copywriter and landing page strategist.
Your job is to generate complete campaign briefs and landing page content.
You MUST respond with valid JSON only. No prose, no markdown fences, no explanation.
SYS;

    $user_prompt = <<<PROMPT
Generate a complete marketing campaign and landing page for this business.

Business type: {$business_type}
Campaign goal: {$goal}
Target audience: {$audience}
Offer / promotion: {$offer}
Tone: {$tone}

Respond with EXACTLY this JSON structure (no extra fields, no markdown):
{
  "campaign_name": "<compelling campaign name, max 60 chars>",
  "campaign_objective": "<one sentence objective>",
  "page_title": "<landing page title>",
  "blocks": [
    {"type": "nav_bar", "brand": "<business name>", "brandUrl": "#", "links": [{"label": "Features", "url": "#"}, {"label": "Pricing", "url": "#"}], "ctaText": "<CTA>", "ctaUrl": "#", "ctaBg": "#2563eb", "bgColor": "#ffffff", "textColor": "#475569"},
    {"type": "hero_section", "headline": "<powerful H1>", "subheadline": "<supporting sub>", "btnText": "<CTA text>", "btnUrl": "#", "btnBg": "#2563eb", "bgColor": "#1e293b", "overlayColor": "rgba(0,0,0,0.5)", "layout": "split", "showForm": true, "formTitle": "<form headline>", "minHeight": 500},
    {"type": "trust_badges", "badges": ["<badge 1>", "<badge 2>", "<badge 3>", "<badge 4>"]},
    {"type": "feature_grid", "headline": "<section headline>", "subheadline": "<sub>", "cols": 3, "bgColor": "#fff", "items": [{"icon": "🎯", "title": "<feature>", "desc": "<desc>"}, {"icon": "⚡", "title": "<feature>", "desc": "<desc>"}, {"icon": "🛡", "title": "<feature>", "desc": "<desc>"}]},
    {"type": "testimonial", "quote": "<realistic quote>", "author": "<First Last>", "role": "<Title, Company>", "color": "#2563eb"},
    {"type": "stats_row", "bgColor": "#f8fafc", "items": [{"number": "<n>", "label": "<label>"}, {"number": "<n>", "label": "<label>"}, {"number": "<n>", "label": "<label>"}]},
    {"type": "lead_form", "title": "<form headline>", "submitText": "<CTA>", "successMsg": "<thank you>", "bg": "#f8fafc"},
    {"type": "footer_block", "brand": "<name>", "description": "<tagline>", "bgColor": "#0f172a", "textColor": "#94a3b8", "brandColor": "#fff", "columns": [{"title": "Product", "links": [{"label": "Features", "url": "#"}]}, {"title": "Company", "links": [{"label": "About", "url": "#"}]}], "copyright": "© 2024. All rights reserved."}
  ],
  "suggested_form_fields": ["Name", "Email", "Phone", "Company"],
  "meta_title": "<SEO title>",
  "meta_desc": "<SEO description under 155 chars>"
}
PROMPT;

    $result = ai_call([
        ['role' => 'system', 'content' => $system_prompt],
        ['role' => 'user',   'content' => $user_prompt],
    ], 1800);

    if (!$result['ok']) {
        echo json_encode(['ok' => false, 'error' => $result['error']]); exit;
    }

    // Parse JSON
    $raw  = preg_replace('/^```(?:json)?\s*/m', '', $result['text']);
    $raw  = preg_replace('/\s*```\s*$/m', '', $raw);
    $raw  = trim($raw);
    $s = strpos($raw, '{'); $e = strrpos($raw, '}');
    if ($s !== false && $e !== false) $raw = substr($raw, $s, $e - $s + 1);

    $json = json_decode($raw, true);
    if (!$json || json_last_error() !== JSON_ERROR_NONE) {
        error_log('[LeadPro AI Campaign] Bad JSON: ' . substr($raw, 0, 300));
        echo json_encode(['ok'=>false,'error'=>'AI returned invalid data. Please try again.','debug'=>substr($raw,0,200)]); exit;
    }

        // Validate and sanitise blocks — ensure required fields exist — ensure required fields exist
    $allowed_types = ['headline','subheadline','paragraph','section_title','bullet_list',
                      'cta_button','lead_form','trust_badges','testimonial','countdown',
                      'hero_section','two_col','feature_grid','stats_row','nav_bar','footer_block',
                      'progress_bars','contact_info','social_links','announcement_bar','reviews','faq',
                      'offer_banner','pricing','image','divider','spacer','reviews','faq','appointment'];

    $blocks = [];
    foreach ((array)($json['blocks'] ?? []) as $b) {
        if (!isset($b['type']) || !in_array($b['type'], $allowed_types)) continue;
        // Assign unique IDs
        $b['id']      = 'ai' . substr(md5(uniqid()), 0, 8);
        $b['padding'] = $b['padding'] ?? '20';
        $blocks[] = $b;
    }

    if (empty($blocks)) {
        echo json_encode(['ok' => false, 'error' => 'AI generated no page blocks. Please try again.']); exit;
    }

    echo json_encode([
        'ok'                   => true,
        'campaign_name'        => htmlspecialchars($json['campaign_name']        ?? 'AI Campaign', ENT_QUOTES, 'UTF-8'),
        'campaign_objective'   => htmlspecialchars($json['campaign_objective']   ?? '',             ENT_QUOTES, 'UTF-8'),
        'page_title'           => htmlspecialchars($json['page_title']           ?? '',             ENT_QUOTES, 'UTF-8'),
        'blocks'               => $blocks,
        'suggested_form_fields'=> (array)($json['suggested_form_fields'] ?? []),
        'meta_title'           => htmlspecialchars($json['meta_title']           ?? '',             ENT_QUOTES, 'UTF-8'),
        'meta_desc'            => htmlspecialchars($json['meta_desc']            ?? '',             ENT_QUOTES, 'UTF-8'),
        'tokens'               => $result['tokens'] ?? 0,
        'model'                => $result['model']  ?? '',
        'provider'             => $result['provider'] ?? '',
    ]);
    exit;
}

// ══════════════════════════════════════════════════════════════
// ACTION: create  — persist campaign + page from confirmed AI output
// ══════════════════════════════════════════════════════════════
if ($act === 'create') {

    $name       = trim($_POST['campaign_name']      ?? '');
    $objective  = trim($_POST['campaign_objective'] ?? '');
    $page_title = trim($_POST['page_title']         ?? '');
    $page_data  = $_POST['page_data']               ?? '[]';
    $meta_t     = trim($_POST['meta_title']         ?? '');
    $meta_d     = trim($_POST['meta_desc']          ?? '');
    $color      = preg_match('/^#[0-9a-fA-F]{6}$/', $_POST['color'] ?? '') ? $_POST['color'] : '#2563eb';

    if (!$name) {
        echo json_encode(['ok' => false, 'error' => 'Campaign name is required.']); exit;
    }

    // Validate page_data JSON
    json_decode($page_data);
    if (json_last_error() !== JSON_ERROR_NONE) $page_data = '[]';

    // 1. Create campaign
    $campaign_id = db_insert(
        'INSERT INTO campaigns (account_id, name, objective, status, color, created_by)
         VALUES (?,?,?,?,?,?)',
        'issssi',
        $account_id, $name, $objective, 'draft', $color, $uid
    );

    if (!$campaign_id) {
        echo json_encode(['ok' => false, 'error' => 'Failed to create campaign.']); exit;
    }

    audit('campaign.created', "campaign:{$campaign_id}", ['name' => $name, 'source' => 'ai_generator']);

    // 2. Create landing page (if we have a title and blocks)
    $page_id   = null;
    $page_slug = null;

    if ($page_title) {
        // Generate unique slug
        $base = strtolower(trim(preg_replace('/[^a-zA-Z0-9]+/', '-', $page_title), '-')) ?: 'page';
        $slug = $base; $i = 1;
        while (db_fetch('SELECT id FROM campaign_pages WHERE account_id=? AND slug=?', 'is', $account_id, $slug)) {
            $slug = $base . '-' . (++$i);
        }

        $page_id = db_insert(
            'INSERT INTO campaign_pages (campaign_id, account_id, title, slug, page_data, meta_title, meta_desc, status)
             VALUES (?,?,?,?,?,?,?,?)',
            'iissssss',
            $campaign_id, $account_id, $page_title, $slug,
            $page_data, $meta_t, $meta_d, 'draft'
        );
        $page_slug = $slug;
    }

    echo json_encode([
        'ok'          => true,
        'campaign_id' => $campaign_id,
        'page_id'     => $page_id,
        'page_slug'   => $page_slug,
        'redirect'    => $page_id
            ? APP_URL . '/page_builder.php?id=' . $page_id
            : APP_URL . '/campaign_view.php?id=' . $campaign_id,
    ]);
    exit;
}

echo json_encode(['ok' => false, 'error' => 'Unknown action']);
