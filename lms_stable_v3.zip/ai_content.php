<?php
require_once __DIR__ . '/config/auth.php';
require_once __DIR__ . '/config/ai.php';

$user       = require_auth();
$account_id = (int)($user['account_id'] ?? 0);

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['ok'=>false,'error'=>'POST required']); exit;
}
if (!csrf_verify()) {
    echo json_encode(['ok'=>false,'error'=>'CSRF']); exit;
}
if (!ai_enabled()) {
    echo json_encode(['ok'=>false,'error'=>'AI not enabled. Add an API key in Settings → AI & API.']); exit;
}

$act = $_POST['action'] ?? '';
if ($act !== 'generate') {
    echo json_encode(['ok'=>false,'error'=>'Unknown action']); exit;
}

// ── Inputs ────────────────────────────────────────────────────
$widget_type   = trim($_POST['widget_type']   ?? '');
$field         = trim($_POST['field']         ?? 'text');
$current_value = trim($_POST['current_value'] ?? '');
$campaign_name = trim($_POST['campaign_name'] ?? '');
$page_title    = trim($_POST['page_title']    ?? '');
$block_index   = (int)($_POST['block_index']  ?? 0);
$page_context  = trim($_POST['page_context']  ?? '');  // JSON summary

// ── Build a compact page context string ──────────────────────
$ctx_str = '';
if ($page_context) {
    $ctx_arr = json_decode($page_context, true);
    if (is_array($ctx_arr)) {
        $ctx_lines = [];
        foreach (array_slice($ctx_arr, 0, 6) as $c) {
            if (!empty($c['type']) && !empty($c['preview'])) {
                $ctx_lines[] = strtoupper($c['type']) . ': ' . $c['preview'];
            }
        }
        if ($ctx_lines) $ctx_str = "\nExisting page content:\n" . implode("\n", $ctx_lines);
    }
}

$campaign_ctx = $campaign_name ? "Campaign: {$campaign_name}" : '';
$page_ctx     = $page_title    ? "Page title: {$page_title}"  : '';
$context_block = implode("\n", array_filter([$campaign_ctx, $page_ctx, $ctx_str]));

// ── System prompt ─────────────────────────────────────────────
$system = 'You are an expert marketing copywriter specialising in high-converting landing pages. '
        . 'Respond with valid JSON only. No prose, no markdown fences, no explanation.';

// ── Per widget/field prompts ──────────────────────────────────
$prompt = '';
$max_tokens = 400;

switch ("{$widget_type}:{$field}") {

    case 'headline:text':
    case 'subheadline:text':
        $type_label = $widget_type === 'headline' ? 'main headline (H1)' : 'supporting subheadline (H2)';
        $prompt = <<<PROMPT
Write 3 compelling {$type_label} options for a landing page.

{$context_block}

Rules:
- Outcome-focused, not feature-focused
- Clear and specific, not vague
- Under 12 words each
- Varies in style (direct, question, benefit-led)

Respond with JSON: {"options": ["<option1>", "<option2>", "<option3>"]}
PROMPT;
        break;

    case 'paragraph:text':
        $prompt = <<<PROMPT
Write a persuasive landing page paragraph (2–3 sentences, max 60 words).

{$context_block}
Current text: {$current_value}

Rules:
- Clear benefits, not features
- Conversational, not corporate
- Drive the reader toward the CTA

Respond with JSON: {"text": "<paragraph text>"}
PROMPT;
        $max_tokens = 200;
        break;

    case 'section_title:text':
        $prompt = <<<PROMPT
Write 3 short section title label options (ALL CAPS, 2–5 words each) for a landing page section.

{$context_block}

Examples of good section titles: "WHY IT WORKS", "WHAT YOU GET", "HOW IT WORKS", "LOVED BY THOUSANDS"

Respond with JSON: {"options": ["<OPTION1>", "<OPTION2>", "<OPTION3>"]}
PROMPT;
        $max_tokens = 150;
        break;

    case 'bullet_list:items':
        $prompt = <<<PROMPT
Write 5 benefit-focused bullet points for a landing page.

{$context_block}

Rules:
- Start each with a strong action verb or outcome
- Focus on what the user gains, not features
- Concise — max 12 words each
- No generic fluff like "Easy to use"

Respond with JSON: {"items": ["<item1>", "<item2>", "<item3>", "<item4>", "<item5>"]}
PROMPT;
        $max_tokens = 300;
        break;

    case 'cta_button:text':
        $prompt = <<<PROMPT
Write 3 high-converting CTA button text options.

{$context_block}

Rules:
- Action-verb first (Get, Start, Book, Claim, Join, Try, Download)
- Specific, not generic ("Get My Free Trial" not "Submit")
- 3–6 words each
- Create urgency or value

Respond with JSON: {"options": ["<option1>", "<option2>", "<option3>"]}
PROMPT;
        $max_tokens = 150;
        break;

    case 'offer_banner:headline':
        $prompt = <<<PROMPT
Write 3 urgency-driven offer banner headlines.

{$context_block}

Rules:
- Create FOMO or urgency
- Include the offer benefit
- Under 10 words
- Bold and direct

Respond with JSON: {"options": ["<option1>", "<option2>", "<option3>"]}
PROMPT;
        $max_tokens = 150;
        break;

    case 'offer_banner:text':
        $prompt = <<<PROMPT
Write a short offer banner body text (1 sentence, max 20 words).

{$context_block}

Rules:
- Reinforce the headline urgency
- Add a specific detail (deadline, percentage off, seats left, etc.)

Respond with JSON: {"text": "<banner body text>"}
PROMPT;
        $max_tokens = 120;
        break;

    case 'testimonial:quote':
        $prompt = <<<PROMPT
Write a realistic, specific customer testimonial quote (2–3 sentences, max 50 words).

{$context_block}

Rules:
- Sounds like a real person, not a marketing brochure
- Mentions a specific result or outcome
- Includes a before/after or problem/solution arc
- Avoid generic superlatives like "amazing" or "fantastic" alone

Respond with JSON: {"quote": "<testimonial text>", "suggested_author": "<First Last>", "suggested_role": "<Job Title, Company>"}
PROMPT;
        $max_tokens = 200;
        break;

    case 'lead_form:title':
        $prompt = <<<PROMPT
Write 3 lead capture form headline options.

{$context_block}

Rules:
- Value-focused (what they GET, not what they DO)
- Under 8 words
- Encourage form completion
- Varies in style

Respond with JSON: {"options": ["<option1>", "<option2>", "<option3>"]}
PROMPT;
        $max_tokens = 150;
        break;

    case 'pricing:features':
        $prompt = <<<PROMPT
Write 5 pricing plan feature bullet points.

{$context_block}

Rules:
- Each under 8 words
- Mix of features and benefits
- Most valuable first
- Specific and concrete

Respond with JSON: {"items": ["<feature1>", "<feature2>", "<feature3>", "<feature4>", "<feature5>"]}
PROMPT;
        $max_tokens = 200;
        break;

    case 'faq:items':
        $prompt = <<<PROMPT
Write 4 FAQ question-and-answer pairs for a landing page.

{$context_block}

Rules:
- Questions address real buying objections (pricing, trust, results, cancellation)
- Answers are direct and reassuring (2–3 sentences each)
- Conversational tone

Respond with JSON: {"items": [{"q": "<question>", "a": "<answer>"}, ...]}
PROMPT;
        $max_tokens = 500;
        break;

    case 'reviews:items':
        $prompt = <<<PROMPT
Write 3 customer reviews with star ratings for a landing page.

{$context_block}

Rules:
- Each review 1–2 sentences, max 30 words
- Specific outcomes mentioned
- Mix of 5-star and 4-star ratings
- Different reviewer name styles (first name only, First L., full name)

Respond with JSON: {"items": [{"stars": 5, "text": "<review>", "name": "<reviewer>"}, ...]}
PROMPT;
        $max_tokens = 300;
        break;

    default:
        echo json_encode(['ok'=>false,'error'=>"No AI generator for widget '{$widget_type}' field '{$field}'"]); exit;
}

// ── Call AI ───────────────────────────────────────────────────
$result = ai_call([
    ['role' => 'system', 'content' => $system],
    ['role' => 'user',   'content' => $prompt],
], $max_tokens);

if (!$result['ok']) {
    echo json_encode(['ok'=>false,'error'=>$result['error']]); exit;
}

// ── Parse response ────────────────────────────────────────────
$raw = preg_replace('/^```(?:json)?\s*/m', '', $result['text']);
$raw = preg_replace('/\s*```\s*$/m', '', $raw);
$raw = trim($raw);

// Find JSON boundaries
$start = strpos($raw, '{');
$end   = strrpos($raw, '}');
if ($start !== false && $end !== false) {
    $raw = substr($raw, $start, $end - $start + 1);
}

$json = json_decode($raw, true);
if (!$json || json_last_error() !== JSON_ERROR_NONE) {
    error_log('[LeadPro AI Content] Bad JSON for '.$widget_type.':'.$field.' — '.substr($raw,0,200));
    echo json_encode(['ok'=>false,'error'=>'AI returned invalid data. Please try again.']); exit;
}

echo json_encode([
    'ok'       => true,
    'data'     => $json,
    'tokens'   => $result['tokens']   ?? 0,
    'provider' => $result['provider'] ?? '',
]);
