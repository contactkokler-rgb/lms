<?php
require_once __DIR__ . '/config/auth.php';
$user       = require_auth();
$account_id = (int)($user['account_id'] ?? 0);

header('Content-Type: application/json; charset=utf-8');

$act = $_REQUEST['action'] ?? '';

// ── Upload directory ──────────────────────────────────────────
$upload_base = __DIR__ . '/assets/uploads';
$upload_dir  = $upload_base . '/' . $account_id;

if (!is_dir($upload_base)) @mkdir($upload_base, 0755, true);
if (!is_dir($upload_dir))  @mkdir($upload_dir,  0755, true);

// ── Upload image ──────────────────────────────────────────────
if ($act === 'image' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { echo json_encode(['ok'=>false,'error'=>'CSRF']); exit; }

    $file = $_FILES['file'] ?? null;
    if (!$file || $file['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['ok'=>false,'error'=>'Upload failed (code '.($file['error']??'?').')']); exit;
    }

    // Validate type
    $allowed_mime = ['image/jpeg','image/png','image/gif','image/webp','image/svg+xml'];
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime  = $finfo->file($file['tmp_name']);
    if (!in_array($mime, $allowed_mime)) {
        echo json_encode(['ok'=>false,'error'=>'Only JPG, PNG, GIF, WebP, SVG allowed.']); exit;
    }

    // Size limit: 5MB
    if ($file['size'] > 5 * 1024 * 1024) {
        echo json_encode(['ok'=>false,'error'=>'File too large. Max 5MB.']); exit;
    }

    // Generate unique filename
    $ext      = pathinfo($file['name'], PATHINFO_EXTENSION) ?: 'jpg';
    $ext      = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $ext));
    $filename = uniqid('img_', true) . '.' . $ext;
    $dest     = $upload_dir . '/' . $filename;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        echo json_encode(['ok'=>false,'error'=>'Could not save file.']); exit;
    }

    $url = APP_URL . '/assets/uploads/' . $account_id . '/' . $filename;

    // Log to DB if page_assets table exists
    try {
        db_insert(
            'INSERT INTO page_assets (account_id, filename, path, size, mime_type, uploaded_by) VALUES (?,?,?,?,?,?)',
            'issiisi',
            $account_id, $filename,
            'assets/uploads/' . $account_id . '/' . $filename,
            (int)$file['size'], $mime, (int)$user['id']
        );
    } catch (\Throwable $e) {
        // Table may not exist yet — that's fine, file is still saved
    }

    echo json_encode(['ok'=>true, 'url'=>$url, 'filename'=>$filename]);
    exit;
}

// ── List assets ───────────────────────────────────────────────
if ($act === 'list') {
    $assets = [];

    // Try DB first
    try {
        $rows = db_fetch_all(
            'SELECT filename, path, size, mime_type, created_at FROM page_assets WHERE account_id=? ORDER BY created_at DESC LIMIT 60',
            'i', $account_id
        );
        foreach ($rows as $r) {
            $assets[] = [
                'url'      => APP_URL . '/' . $r['path'],
                'filename' => $r['filename'],
                'size'     => $r['size'],
                'created'  => $r['created_at'],
            ];
        }
    } catch (\Throwable $e) {
        // Fall back to scanning directory
        if (is_dir($upload_dir)) {
            foreach (glob($upload_dir . '/*.{jpg,jpeg,png,gif,webp,svg}', GLOB_BRACE) as $f) {
                $assets[] = [
                    'url'      => APP_URL . '/assets/uploads/' . $account_id . '/' . basename($f),
                    'filename' => basename($f),
                    'size'     => filesize($f),
                    'created'  => date('Y-m-d H:i:s', filemtime($f)),
                ];
            }
        }
    }

    echo json_encode(['ok'=>true, 'assets'=>$assets]);
    exit;
}

// ── Delete asset ──────────────────────────────────────────────
if ($act === 'delete' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { echo json_encode(['ok'=>false,'error'=>'CSRF']); exit; }

    $filename = preg_replace('/[^a-zA-Z0-9_.\-]/', '', $_POST['filename'] ?? '');
    if (!$filename) { echo json_encode(['ok'=>false,'error'=>'Invalid filename']); exit; }

    $path = $upload_dir . '/' . $filename;
    if (file_exists($path) && strpos(realpath($path), realpath($upload_dir)) === 0) {
        @unlink($path);
        try {
            db_query('DELETE FROM page_assets WHERE account_id=? AND filename=?', 'is', $account_id, $filename);
        } catch (\Throwable $e) {}
    }

    echo json_encode(['ok'=>true]);
    exit;
}

// ── Unsplash/Pexels/Pixabay search proxy ─────────────────────
if ($act === 'unsplash') {
    $q      = trim($_GET['q'] ?? '');
    $page   = max(1, (int)($_GET['p'] ?? 1));
    $source = trim($_GET['source'] ?? 'auto'); // auto|unsplash|pexels|pixabay
    if (!$q) { echo json_encode(['ok'=>false,'error'=>'Query required']); exit; }

    $unsplash_key = ps('unsplash_api_key', '');
    $pexels_key   = ps('pexels_api_key', '');
    $pixabay_key  = ps('pixabay_api_key', '');

    // Auto-select best available source
    if ($source === 'auto') {
        if ($unsplash_key) $source = 'unsplash';
        elseif ($pexels_key) $source = 'pexels';
        elseif ($pixabay_key) $source = 'pixabay';
        else $source = 'picsum';
    }

    $photos = [];

    if ($source === 'unsplash' && $unsplash_key) {
        $url = "https://api.unsplash.com/search/photos?query=" . urlencode($q) . "&per_page=20&page={$page}&orientation=landscape";
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_HTTPHEADER=>["Authorization: Client-ID {$unsplash_key}"], CURLOPT_TIMEOUT=>10]);
        $resp = json_decode(curl_exec($ch), true); curl_close($ch);
        foreach (($resp['results'] ?? []) as $p) {
            $photos[] = ['thumb'=>$p['urls']['small']??'','url'=>$p['urls']['regular']??'','desc'=>$p['alt_description']??$q,'user'=>$p['user']['name']??''];
        }
        $source_label = 'Unsplash';
    } elseif ($source === 'pexels' && $pexels_key) {
        $url = "https://api.pexels.com/v1/search?query=" . urlencode($q) . "&per_page=20&page={$page}";
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_HTTPHEADER=>["Authorization: {$pexels_key}"], CURLOPT_TIMEOUT=>10]);
        $resp = json_decode(curl_exec($ch), true); curl_close($ch);
        foreach (($resp['photos'] ?? []) as $p) {
            $photos[] = ['thumb'=>$p['src']['medium']??'','url'=>$p['src']['large']??'','desc'=>$p['alt']??$q,'user'=>$p['photographer']??''];
        }
        $source_label = 'Pexels';
    } elseif ($source === 'pixabay' && $pixabay_key) {
        $url = "https://pixabay.com/api/?key={$pixabay_key}&q=" . urlencode($q) . "&image_type=photo&orientation=horizontal&per_page=20&page={$page}";
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>10]);
        $resp = json_decode(curl_exec($ch), true); curl_close($ch);
        foreach (($resp['hits'] ?? []) as $p) {
            $photos[] = ['thumb'=>$p['previewURL']??'','url'=>$p['webformatURL']??'','desc'=>implode(', ', array_slice(explode(' ', $p['tags']??''),0,3)),'user'=>$p['user']??''];
        }
        $source_label = 'Pixabay';
    } else {
        // Picsum fallback
        $seeds = range(10, 200, 10);
        foreach (array_slice($seeds, 0, 16) as $seed) {
            $photos[] = ['thumb'=>"https://picsum.photos/seed/{$seed}/400/300",'url'=>"https://picsum.photos/seed/{$seed}/1200/800",'desc'=>"Stock photo #{$seed}",'user'=>'Picsum'];
        }
        $source_label = 'Picsum (demo)';
    }

    echo json_encode(['ok'=>true,'photos'=>$photos,'source'=>$source_label]);
    exit;
}

echo json_encode(['ok'=>false,'error'=>'Unknown action']);
