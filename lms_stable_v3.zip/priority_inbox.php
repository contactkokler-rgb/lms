<?php
/**
 * LeadPro — Priority Inbox
 * Step 10: Ranked lead view combining all signals into a single action list.
 *
 * Priority score (0–100) computed from:
 *   - Pending reminder due/overdue      → up to +40 pts
 *   - Engagement heat level             → up to +25 pts
 *   - Lead score (rule-based)           → up to +20 pts
 *   - Response time urgency (new leads) → up to +15 pts
 */
require_once __DIR__ . '/config/auth.php';
$user       = require_permission('leads', 'view');
$account_id = (int)($user['account_id'] ?? 0);
$is_super   = is_super_admin();
$uid        = (int)$user['id'];
$role       = $user['role_name'] ?? 'agent';
$can_see_all = ($is_super || in_array($role, ['account_owner','manager']));

$page_title = 'Priority Inbox';
$active_nav = 'priority_inbox';

// ── Filters ───────────────────────────────────────────────────
$f_mine   = !$can_see_all || (($_GET['filter'] ?? '') === 'mine');
$f_status = $_GET['status'] ?? '';           // '' = open (non-terminal)
$limit    = 50;

// ── WHERE base ────────────────────────────────────────────────
$where = []; $types = ''; $params = [];
if (!$is_super)    { $where[] = 'l.account_id=?'; $types .= 'i'; $params[] = $account_id; }
$where[] = 'l.is_deleted=0';
$where[] = "l.status NOT IN ('spam','converted','lost')";  // only actionable leads
if ($f_mine)       { $where[] = 'l.assigned_to=?'; $types .= 'i'; $params[] = $uid; }
if ($f_status)     { $where[] = 'l.status=?';      $types .= 's'; $params[] = $f_status; }
// Only leads snoozed until past now (or not snoozed)
$where[] = "(l.snoozed_until IS NULL OR l.snoozed_until < NOW())";
$wsql = 'WHERE ' . implode(' AND ', $where);

// ── Main priority query ───────────────────────────────────────
// Priority score components computed in SQL for efficiency
$leads = db_fetch_all(
    "SELECT
        l.id, l.reference_no, l.status, l.submitted_at, l.assigned_to,
        l.score, l.score_category,
        l.engagement_score, l.engagement_level,
        l.first_contacted_at, l.last_activity_at, l.snoozed_until,
        l.ai_score, l.ai_qualification,
        f.name  AS form_name,
        d.domain,
        CONCAT(ua.first_name,' ',ua.last_name) AS assigned_name,
        ua.id AS assigned_id,

        /* Pending reminder signal */
        COUNT(DISTINCT r.id) AS pending_reminders,
        MIN(r.remind_at)     AS next_reminder,
        SUM(r.remind_at < NOW() AND r.is_done=0 ) AS overdue_reminders,

        /* Hours since submitted with no contact */
        ROUND(TIMESTAMPDIFF(MINUTE, l.submitted_at, NOW())/60, 1) AS hrs_since_submit,

        /* Priority score formula */
        LEAST(100,
          /* Overdue reminders: up to 40 */
          LEAST(40, COALESCE(SUM(r.remind_at < NOW() AND r.is_done=0 ),0) * 20)
          +
          /* Upcoming reminder in next 2h: +15 */
          IF(MIN(r.remind_at) IS NOT NULL AND MIN(r.remind_at) BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 2 HOUR), 15, 0)
          +
          /* Engagement level: hot=25, warm=15, cold=0 */
          IF(l.engagement_level='hot', 25, IF(l.engagement_level='warm', 15, 0))
          +
          /* Lead score: up to 20 */
          LEAST(20, ROUND(COALESCE(l.score,0) * 0.2))
          +
          /* New lead no contact >4h: +15 */
          IF(l.status='new' AND l.first_contacted_at IS NULL AND TIMESTAMPDIFF(HOUR, l.submitted_at, NOW()) >= 4, 15, 0)
          +
          /* New lead no contact 1-4h: +8 */
          IF(l.status='new' AND l.first_contacted_at IS NULL AND TIMESTAMPDIFF(HOUR, l.submitted_at, NOW()) BETWEEN 1 AND 3, 8, 0)
        ) AS priority_score

     FROM leads l
     LEFT JOIN lead_forms f         ON f.id = l.form_id
     LEFT JOIN domains d            ON d.id = l.domain_id
     LEFT JOIN users ua             ON ua.id = l.assigned_to
     LEFT JOIN lead_reminders r     ON r.lead_id = l.id AND r.is_done=0
                                    
     LEFT JOIN lead_values lv       ON lv.lead_id = l.id
     $wsql
     GROUP BY l.id
     ORDER BY priority_score DESC, l.submitted_at DESC
     LIMIT ?",
    $types . 'i', ...array_merge($params, [$limit])
);

// ── Fetch preview values (name/email) ─────────────────────────
$lead_ids   = array_column($leads, 'id');
$lead_vals  = [];
if ($lead_ids) {
    $ph   = implode(',', array_fill(0, count($lead_ids), '?'));
    $rows = db_fetch_all(
        "SELECT lv.lead_id, lv.field_key, lv.field_label, lv.value
         FROM lead_values lv
         JOIN form_fields ff ON ff.id = lv.field_id
         WHERE lv.lead_id IN ($ph) AND ff.field_type IN ('text','email','tel','name')
         ORDER BY ff.sort_order",
        str_repeat('i', count($lead_ids)), ...$lead_ids
    );
    foreach ($rows as $r) $lead_vals[$r['lead_id']][] = $r;
}

function inbox_preview(array $vals): array {
    $name = ''; $email = '';
    foreach ($vals as $v) {
        $key = strtolower((string)$v['field_key'] . ' ' . (string)$v['field_label']);
        if (!$name  && (strpos($key,'name') !== false))  $name  = $v['value'];
        if (!$email && (strpos($key,'email') !== false)) $email = $v['value'];
    }
    return [$name, $email];
}

// ── Priority label ────────────────────────────────────────────
function priority_badge(int $score): string {
    if ($score >= 70) return '<span style="display:inline-flex;align-items:center;gap:3px;font-size:.68rem;font-weight:700;padding:2px 8px;background:#fef2f2;border:1px solid #fca5a5;color:#991b1b;border-radius:10px;">🔴 Urgent</span>';
    if ($score >= 40) return '<span style="display:inline-flex;align-items:center;gap:3px;font-size:.68rem;font-weight:700;padding:2px 8px;background:#fffbeb;border:1px solid #fde68a;color:#92400e;border-radius:10px;">🟡 High</span>';
    if ($score >= 15) return '<span style="display:inline-flex;align-items:center;gap:3px;font-size:.68rem;font-weight:700;padding:2px 8px;background:#f0f9ff;border:1px solid #bae6fd;color:#0c4a6e;border-radius:10px;">🔵 Normal</span>';
    return '<span style="font-size:.68rem;font-weight:600;color:var(--gray-300);padding:2px 8px;">Low</span>';
}

$status_colors = [
    'new'       => 'badge-blue',
    'contacted' => 'badge-yellow',
    'qualified' => 'badge-purple',
    'converted' => 'badge-green',
    'lost'      => 'badge-gray',
    'spam'      => 'badge-red',
];

include __DIR__ . '/layouts/header.php';
?>
<style>
.pi-header { display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px; margin-bottom:20px; }
.pi-title  { font-size:1.25rem; font-weight:800; color:var(--gray-900); letter-spacing:-.025em; }
.pi-filters{ display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.pi-card   { background:#fff; border:1.5px solid var(--gray-100); border-radius:13px; margin-bottom:10px; padding:14px 18px; display:flex; align-items:flex-start; gap:16px; transition:.12s; }
.pi-card:hover { border-color:var(--brand-300); box-shadow:0 2px 10px rgba(99,102,241,.08); }
.pi-score  { display:flex; flex-direction:column; align-items:center; justify-content:center; min-width:48px; }
.pi-score-n{ font-size:1.2rem; font-weight:900; line-height:1; }
.pi-score-l{ font-size:.6rem; font-weight:600; color:var(--gray-400); text-transform:uppercase; letter-spacing:.05em; margin-top:2px; }
.pi-body   { flex:1; min-width:0; }
.pi-name   { font-size:.88rem; font-weight:700; color:var(--gray-800); }
.pi-meta   { font-size:.73rem; color:var(--gray-400); margin-top:2px; display:flex; flex-wrap:wrap; gap:8px; align-items:center; }
.pi-signals{ display:flex; flex-wrap:wrap; gap:5px; margin-top:7px; }
.pi-sig    { display:inline-flex; align-items:center; gap:3px; font-size:.67rem; font-weight:600; padding:2px 7px; border-radius:8px; }
.pi-actions{ display:flex; flex-direction:column; align-items:flex-end; gap:6px; }
.pi-empty  { text-align:center; padding:60px 20px; color:var(--gray-400); }
.pi-section-title { font-size:.72rem; font-weight:700; text-transform:uppercase; letter-spacing:.07em; color:var(--gray-400); padding:10px 4px 6px; }
@media(max-width:600px){ .pi-card{flex-wrap:wrap;} .pi-actions{flex-direction:row;} }
</style>

<div class="pi-header">
  <div>
    <div class="pi-title">🎯 Priority Inbox</div>
    <div style="font-size:.74rem;color:var(--gray-400);margin-top:2px;">Showing up to <?= $limit ?> highest-priority open leads</div>
  </div>
  <div class="pi-filters">
    <?php if ($can_see_all): ?>
    <a href="?<?= http_build_query(['filter'=>'mine','status'=>$f_status]) ?>"
       class="btn btn-sm <?= $f_mine ? 'btn-primary' : 'btn-secondary' ?>">My Leads</a>
    <a href="?<?= http_build_query(['status'=>$f_status]) ?>"
       class="btn btn-sm <?= !$f_mine ? 'btn-primary' : 'btn-secondary' ?>">All Leads</a>
    <?php endif; ?>
    <select class="form-control form-control-sm" style="width:130px;"
            onchange="location.href='?<?= $f_mine?'filter=mine&':'' ?>status='+this.value">
      <option value="" <?= !$f_status?'selected':'' ?>>All statuses</option>
      <?php foreach (['new','contacted','qualified'] as $s): ?>
      <option value="<?=$s?>" <?= $f_status===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
      <?php endforeach; ?>
    </select>
    <a href="<?= APP_URL ?>/leads.php" class="btn btn-secondary btn-sm">Full List →</a>
  </div>
</div>

<?php if (!$leads): ?>
<div class="pi-empty">
  <div style="font-size:2.5rem;margin-bottom:12px;">✅</div>
  <div style="font-weight:700;color:var(--gray-600);font-size:1rem;margin-bottom:6px;">All clear!</div>
  <div style="font-size:.82rem;">No actionable leads match your current filters.</div>
</div>
<?php else: ?>

<?php
// Group into Urgent / High / Normal / Low
$groups = ['Urgent (70–100)'=>[],'High (40–69)'=>[],'Normal (15–39)'=>[],'Low (0–14)'=>[]];
foreach ($leads as $lead) {
    $ps = (int)$lead['priority_score'];
    if ($ps >= 70)     $groups['Urgent (70–100)'][] = $lead;
    elseif ($ps >= 40) $groups['High (40–69)'][]    = $lead;
    elseif ($ps >= 15) $groups['Normal (15–39)'][]  = $lead;
    else               $groups['Low (0–14)'][]       = $lead;
}
?>

<?php foreach ($groups as $group_label => $group_leads): ?>
<?php if (!$group_leads) continue; ?>
<div class="pi-section-title"><?= $group_label ?> · <?= count($group_leads) ?> lead<?= count($group_leads)!==1?'s':'' ?></div>

<?php foreach ($group_leads as $lead):
  $ps    = (int)$lead['priority_score'];
  $vals  = $lead_vals[$lead['id']] ?? [];
  [$pname, $pemail] = inbox_preview($vals);
  $pname = $pname ?: 'Unknown';

  // Priority colour
  if ($ps >= 70)     { $pcol = '#dc2626'; $pbg = '#fef2f2'; }
  elseif ($ps >= 40) { $pcol = '#d97706'; $pbg = '#fffbeb'; }
  elseif ($ps >= 15) { $pcol = '#2563eb'; $pbg = '#eff6ff'; }
  else               { $pcol = '#94a3b8'; $pbg = '#f8fafc'; }

  // Signal pills
  $signals = [];
  if ((int)$lead['overdue_reminders'] > 0)
      $signals[] = ['#fef2f2','#fca5a5','#991b1b', '⏰ ' . $lead['overdue_reminders'] . ' overdue reminder' . ((int)$lead['overdue_reminders']>1?'s':'')];
  elseif ($lead['next_reminder'] && strtotime($lead['next_reminder']) <= strtotime('+2 hours'))
      $signals[] = ['#fffbeb','#fde68a','#92400e', '🔔 Reminder soon'];

  $eng = $lead['engagement_level'] ?? 'cold';
  if ($eng === 'hot')       $signals[] = ['#fef2f2','#fca5a5','#991b1b','🔥 Hot'];
  elseif ($eng === 'warm')  $signals[] = ['#fffbeb','#fde68a','#92400e','🟡 Warm'];

  if ($lead['status']==='new' && !$lead['first_contacted_at']) {
      $hrs = (float)$lead['hrs_since_submit'];
      if ($hrs >= 4)       $signals[] = ['#fef2f2','#fca5a5','#991b1b', '📵 No contact ' . round($hrs) . 'h'];
      elseif ($hrs >= 1)   $signals[] = ['#fffbeb','#fde68a','#92400e', '📵 New – ' . round($hrs) . 'h old'];
  }

  if ((int)($lead['score']??0) >= 70)
      $signals[] = ['#f0fdf4','#86efac','#15803d','⭐ Score '.$lead['score']];
?>
<div class="pi-card">

  <!-- Priority score -->
  <div class="pi-score" style="background:<?= $pbg ?>;border-radius:10px;padding:8px 6px;min-width:52px;">
    <div class="pi-score-n" style="color:<?= $pcol ?>;"><?= $ps ?></div>
    <div class="pi-score-l" style="color:<?= $pcol ?>aa;">priority</div>
  </div>

  <!-- Main body -->
  <div class="pi-body">
    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
      <a href="<?= APP_URL ?>/lead_view.php?id=<?= $lead['id'] ?>"
         style="font-size:.88rem;font-weight:700;color:var(--gray-800);text-decoration:none;"><?= h($pname) ?></a>
      <?= priority_badge($ps) ?>
      <span class="badge <?= $status_colors[$lead['status']] ?? 'badge-gray' ?>">
        <span class="badge-dot"></span><?= ucfirst($lead['status']) ?>
      </span>
    </div>

    <div class="pi-meta">
      <?php if ($pemail): ?><span><?= h($pemail) ?></span><?php endif; ?>
      <?php if ($lead['form_name']): ?><span>📋 <?= h($lead['form_name']) ?></span><?php endif; ?>
      <span>🕐 <?= format_dt($lead['submitted_at'], 'd M g:ia') ?></span>
      <?php if ($lead['assigned_name'] && trim($lead['assigned_name'])): ?>
      <span>👤 <?= h(trim($lead['assigned_name'])) ?></span>
      <?php else: ?>
      <span style="color:#f59e0b;">⚠ Unassigned</span>
      <?php endif; ?>
      <span style="font-family:var(--font-mono);font-size:.68rem;color:var(--gray-300);"><?= h($lead['reference_no']) ?></span>
    </div>

    <?php if ($signals): ?>
    <div class="pi-signals">
      <?php foreach ($signals as [$sbg,$sbr,$stx,$slbl]): ?>
      <span class="pi-sig" style="background:<?=$sbg?>;border:1px solid <?=$sbr?>;color:<?=$stx?>;"><?= $slbl ?></span>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if (!empty($lead['next_reminder']) && !(int)$lead['overdue_reminders']): ?>
    <div style="font-size:.7rem;color:var(--gray-400);margin-top:5px;">
      Next reminder: <?= format_dt($lead['next_reminder'], 'd M g:ia') ?>
    </div>
    <?php endif; ?>
  </div>

  <!-- Actions -->
  <div class="pi-actions">
    <a href="<?= APP_URL ?>/lead_view.php?id=<?= $lead['id'] ?>" class="btn btn-primary btn-sm">View →</a>
    <?php if ((int)$lead['pending_reminders'] > 0): ?>
    <span style="font-size:.68rem;color:var(--gray-400);"><?= $lead['pending_reminders'] ?> reminder<?= $lead['pending_reminders']>1?'s':'' ?></span>
    <?php endif; ?>
  </div>

</div>
<?php endforeach; ?>
<?php endforeach; ?>

<?php if (count($leads) === $limit): ?>
<div style="text-align:center;padding:18px;font-size:.78rem;color:var(--gray-400);">
  Showing top <?= $limit ?> leads by priority. <a href="<?= APP_URL ?>/leads.php" style="color:var(--brand-500);">View all leads →</a>
</div>
<?php endif; ?>

<?php endif; ?>

<?php include __DIR__ . '/layouts/footer.php'; ?>
