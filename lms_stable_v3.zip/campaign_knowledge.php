<?php
/**
 * LeadPro — Campaign AI Knowledge Base Manager
 * campaign_knowledge.php
 * Phases 1-5, 7, 11, 12
 */
 
ini_set('display_startup_errors', 1);
ini_set('display_errors', 1);
error_reporting(E_ALL);


require_once __DIR__ . '/config/auth.php';
$user       = require_permission('campaigns', 'edit');
$account_id = (int)($user['account_id'] ?? 0);
$is_super   = is_super_admin();

require_once __DIR__ . '/config/knowledge.php';

$cid = (int)($_GET['id'] ?? 0);
if (!$cid) { header('Location: ' . APP_URL . '/campaigns.php'); exit; }

$campaign = db_fetch(
    'SELECT * FROM campaigns WHERE id = ? AND account_id = ?',
    'ii', $cid, $account_id
);
if (!$campaign) { header('Location: ' . APP_URL . '/campaigns.php'); exit; }

$flash = null;
$tab   = $_GET['tab'] ?? 'profile';

// ── POST handlers ─────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { http_response_code(403); die('CSRF'); }
    $act = $_POST['action'] ?? '';

    // Profile save
    if ($act === 'save_profile') {
        $data = [
            'business_name'        => mb_substr(trim($_POST['business_name']        ?? ''), 0, 200),
            'business_description' => trim($_POST['business_description'] ?? ''),
            'industry'             => mb_substr(trim($_POST['industry']             ?? ''), 0, 100),
            'service_locations'    => trim($_POST['service_locations']    ?? ''),
            'working_hours'        => mb_substr(trim($_POST['working_hours']        ?? ''), 0, 500),
            'phone'                => mb_substr(trim($_POST['phone']                ?? ''), 0, 50),
            'email'                => mb_substr(trim($_POST['email']                ?? ''), 0, 200),
            'website'              => mb_substr(trim($_POST['website']              ?? ''), 0, 500),
            'address'              => trim($_POST['address']              ?? ''),
            'tone_of_voice'        => in_array($_POST['tone_of_voice'] ?? '', ['professional','friendly','formal','casual'])
                                       ? $_POST['tone_of_voice'] : 'professional',
            'extra_context'        => trim($_POST['extra_context'] ?? ''),
        ];
        $existing = db_fetch('SELECT id FROM campaign_knowledge_profile WHERE campaign_id = ?', 'i', $cid);
        // Explicit columns — no dynamic spreads
        $p = $data;
        if ($existing) {
            db_query(
                'UPDATE campaign_knowledge_profile SET
                 business_name=?,business_description=?,industry=?,service_locations=?,
                 working_hours=?,phone=?,email=?,website=?,address=?,tone_of_voice=?,extra_context=?
                 WHERE campaign_id=?',
                'sssssssssss' . 'i',
                $p['business_name'], $p['business_description'], $p['industry'],
                $p['service_locations'], $p['working_hours'], $p['phone'],
                $p['email'], $p['website'], $p['address'], $p['tone_of_voice'],
                $p['extra_context'], $cid
            );
        } else {
            db_insert(
                'INSERT INTO campaign_knowledge_profile
                 (campaign_id,account_id,business_name,business_description,industry,
                  service_locations,working_hours,phone,email,website,address,tone_of_voice,extra_context)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
                'iisssssssssss',
                $cid, $account_id,
                $p['business_name'], $p['business_description'], $p['industry'],
                $p['service_locations'], $p['working_hours'], $p['phone'],
                $p['email'], $p['website'], $p['address'], $p['tone_of_voice'],
                $p['extra_context']
            );
        }
        // Also sync quick fields back to campaigns table
        db_query('UPDATE campaigns SET ai_location=?, ai_booking_url=? WHERE id=?',
            'ssi',
            $data['service_locations'],
            trim($_POST['booking_url'] ?? ''),
            $cid
        );
        $flash = ['type'=>'success','msg'=>'Business profile saved.'];
        $tab   = 'profile';
    }

    // Service add/edit
    if ($act === 'save_service') {
        $sid  = (int)($_POST['service_id'] ?? 0);
        $name = mb_substr(trim($_POST['name'] ?? ''), 0, 200);
        if (!$name) { $flash = ['type'=>'error','msg'=>'Service name required.']; }
        else {
            $d = [
                mb_substr(trim($_POST['name']        ?? ''), 0, 200),
                trim($_POST['description'] ?? ''),
                trim($_POST['benefits']    ?? ''),
                mb_substr(trim($_POST['duration']    ?? ''), 0, 100),
                mb_substr(trim($_POST['category']    ?? ''), 0, 100),
                (int)($_POST['sort_order'] ?? 0),
            ];
            if ($sid) {
                db_query('UPDATE campaign_knowledge_services SET name=?,description=?,benefits=?,duration=?,category=?,sort_order=? WHERE id=? AND campaign_id=?',
                    'sssssiii', $d[0],$d[1],$d[2],$d[3],$d[4],$d[5], $sid, $cid);
                $flash = ['type'=>'success','msg'=>'Service updated.'];
            } else {
                db_insert('INSERT INTO campaign_knowledge_services (campaign_id,account_id,name,description,benefits,duration,category,sort_order) VALUES (?,?,?,?,?,?,?,?)',
                    'iisssssi', $cid, $account_id, $d[0],$d[1],$d[2],$d[3],$d[4],$d[5]);
                $flash = ['type'=>'success','msg'=>'Service added.'];
            }
        }
        $tab = 'services';
    }

    // Delete service
    if ($act === 'delete_service') {
        db_query('DELETE FROM campaign_knowledge_services WHERE id=? AND campaign_id=?', 'ii', (int)$_POST['id'], $cid);
        $flash = ['type'=>'success','msg'=>'Service removed.']; $tab = 'services';
    }

    // Pricing add/edit
    if ($act === 'save_pricing') {
        $pid  = (int)($_POST['pricing_id'] ?? 0);
        $name = mb_substr(trim($_POST['service_name'] ?? ''), 0, 200);
        if (!$name) { $flash = ['type'=>'error','msg'=>'Service name required.']; }
        else {
            $d = [
                $name,
                mb_substr(trim($_POST['price']         ?? ''), 0, 100),
                trim($_POST['price_notes']    ?? ''),
                mb_substr(trim($_POST['special_offer'] ?? ''), 0, 300),
                (int)($_POST['sort_order'] ?? 0),
            ];
            if ($pid) {
                db_query('UPDATE campaign_knowledge_pricing SET service_name=?,price=?,price_notes=?,special_offer=?,sort_order=? WHERE id=? AND campaign_id=?',
                    'sssssii', $d[0],$d[1],$d[2],$d[3],$d[4], $pid, $cid);
                $flash = ['type'=>'success','msg'=>'Pricing updated.'];
            } else {
                db_insert('INSERT INTO campaign_knowledge_pricing (campaign_id,account_id,service_name,price,price_notes,special_offer,sort_order) VALUES (?,?,?,?,?,?,?)',
                    'iissssi', $cid, $account_id, $d[0],$d[1],$d[2],$d[3],$d[4]);
                $flash = ['type'=>'success','msg'=>'Pricing added.'];
            }
        }
        $tab = 'pricing';
    }

    if ($act === 'delete_pricing') {
        db_query('DELETE FROM campaign_knowledge_pricing WHERE id=? AND campaign_id=?', 'ii', (int)$_POST['id'], $cid);
        $flash = ['type'=>'success','msg'=>'Pricing removed.']; $tab = 'pricing';
    }

    // FAQ add/edit
    if ($act === 'save_faq') {
        $fid = (int)($_POST['faq_id'] ?? 0);
        $q   = trim($_POST['question'] ?? '');
        $a   = trim($_POST['answer']   ?? '');
        if (!$q || !$a) { $flash = ['type'=>'error','msg'=>'Question and answer required.']; }
        else {
            $d = [$q, $a, mb_substr(trim($_POST['category']??''),0,100), (int)($_POST['sort_order']??0)];
            if ($fid) {
                db_query('UPDATE campaign_knowledge_faqs SET question=?,answer=?,category=?,sort_order=? WHERE id=? AND campaign_id=?',
                    'sssiii', $d[0],$d[1],$d[2],(int)$d[3], $fid, $cid);
                $flash = ['type'=>'success','msg'=>'FAQ updated.'];
            } else {
                db_insert('INSERT INTO campaign_knowledge_faqs (campaign_id,account_id,question,answer,category,sort_order) VALUES (?,?,?,?,?,?)',
                    'iisssi', $cid, $account_id, $d[0],$d[1],$d[2],(int)$d[3]);
                $flash = ['type'=>'success','msg'=>'FAQ added.'];
            }
        }
        $tab = 'faqs';
    }

    if ($act === 'delete_faq') {
        db_query('DELETE FROM campaign_knowledge_faqs WHERE id=? AND campaign_id=?', 'ii', (int)$_POST['id'], $cid);
        $flash = ['type'=>'success','msg'=>'FAQ removed.']; $tab = 'faqs';
    }

    // Policy add/edit
    if ($act === 'save_policy') {
        $polid   = (int)($_POST['policy_id'] ?? 0);
        $title   = mb_substr(trim($_POST['title']   ?? ''), 0, 200);
        $content = trim($_POST['content'] ?? '');
        $ptype   = in_array($_POST['policy_type']??'', ['cancellation','appointment','refund','consultation','other'])
                    ? $_POST['policy_type'] : 'other';
        if (!$title || !$content) { $flash = ['type'=>'error','msg'=>'Title and content required.']; }
        else {
            $d = [$ptype, $title, $content, (int)($_POST['sort_order']??0)];
            if ($polid) {
                db_query('UPDATE campaign_knowledge_policies SET policy_type=?,title=?,content=?,sort_order=? WHERE id=? AND campaign_id=?',
                    'sssiii', $d[0],$d[1],$d[2],(int)$d[3], $polid, $cid);
                $flash = ['type'=>'success','msg'=>'Policy updated.'];
            } else {
                db_insert('INSERT INTO campaign_knowledge_policies (campaign_id,account_id,policy_type,title,content,sort_order) VALUES (?,?,?,?,?,?)',
                    'iisssi', $cid, $account_id, $d[0],$d[1],$d[2],(int)$d[3]);
                $flash = ['type'=>'success','msg'=>'Policy added.'];
            }
        }
        $tab = 'policies';
    }

    if ($act === 'delete_policy') {
        db_query('DELETE FROM campaign_knowledge_policies WHERE id=? AND campaign_id=?', 'ii', (int)$_POST['id'], $cid);
        $flash = ['type'=>'success','msg'=>'Policy removed.']; $tab = 'policies';
    }

    // Phase 7: Add URL to crawl queue
    if ($act === 'add_url') {
        $url = trim($_POST['url'] ?? '');
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            $flash = ['type'=>'error','msg'=>'Invalid URL.']; $tab = 'website';
        } else {
            $existing = db_fetch('SELECT id FROM campaign_knowledge_pages WHERE campaign_id=? AND url=?', 'is', $cid, $url);
            if ($existing) {
                $flash = ['type'=>'error','msg'=>'URL already added.']; $tab = 'website';
            } else {
                db_insert('INSERT INTO campaign_knowledge_pages (campaign_id,account_id,url,status) VALUES (?,?,?,?)',
                    'iiss', $cid, $account_id, $url, 'pending');
                $flash = ['type'=>'success','msg'=>'URL added. Click Crawl to fetch content.']; $tab = 'website';
            }
        }
    }

    if ($act === 'delete_page') {
        db_query('DELETE FROM campaign_knowledge_pages WHERE id=? AND campaign_id=?', 'ii', (int)$_POST['id'], $cid);
        $flash = ['type'=>'success','msg'=>'Page removed.']; $tab = 'website';
    }

    if ($act === 'crawl_url') {
        $pid    = (int)($_POST['page_id'] ?? 0);
        $pg_row = db_fetch('SELECT * FROM campaign_knowledge_pages WHERE id=? AND campaign_id=?', 'ii', $pid, $cid);
        if ($pg_row) {
            $result = kb_crawl_url($pg_row['url']);
            if ($result['ok']) {
                db_query('UPDATE campaign_knowledge_pages SET page_title=?,content=?,word_count=?,status=?,error_message=NULL,crawled_at=NOW() WHERE id=?',
                    'ssssi', $result['title'], $result['content'], $result['word_count'], 'crawled', $pid);
                $flash = ['type'=>'success','msg'=>'Page crawled: ' . $result['word_count'] . ' words extracted.'];
            } else {
                db_query("UPDATE campaign_knowledge_pages SET status='failed',error_message=?,crawled_at=NOW() WHERE id=?",
                    'si', mb_substr($result['error'], 0, 500), $pid);
                $flash = ['type'=>'error','msg'=>'Crawl failed: ' . $result['error']];
            }
        }
        $tab = 'website';
    }
}

// ── Load data for current tab ─────────────────────────────────
$profile  = db_fetch('SELECT * FROM campaign_knowledge_profile WHERE campaign_id = ?', 'i', $cid);
$services = db_fetch_all('SELECT * FROM campaign_knowledge_services WHERE campaign_id=? ORDER BY sort_order,id', 'i', $cid);
$pricing  = db_fetch_all('SELECT * FROM campaign_knowledge_pricing  WHERE campaign_id=? ORDER BY sort_order,id', 'i', $cid);
$faqs     = db_fetch_all('SELECT * FROM campaign_knowledge_faqs     WHERE campaign_id=? ORDER BY sort_order,id', 'i', $cid);
$policies = db_fetch_all('SELECT * FROM campaign_knowledge_policies WHERE campaign_id=? ORDER BY sort_order,id', 'i', $cid);
$pages    = db_fetch_all("SELECT * FROM campaign_knowledge_pages    WHERE campaign_id=? ORDER BY id", 'i', $cid);
$analytics= kb_analytics($cid);

// KB completeness score
$kb_score = 0;
if ($profile && $profile['business_name']) $kb_score += 20;
if (count($services) > 0) $kb_score += 20;
if (count($pricing)  > 0) $kb_score += 20;
if (count($faqs)     > 0) $kb_score += 20;
if (count($pages)    > 0) $kb_score += 20;

$page_title = 'AI Knowledge Base — ' . h($campaign['name']);
$active_nav = 'campaigns';

include __DIR__ . '/layouts/header.php';
?>

<div class="page-header">
    <div>
        <h1 class="page-title">
            <i class="hgi hgi-stroke hgi-ai-brain-05"></i>
            AI Knowledge Base
        </h1>
        <p class="page-subtitle">
            <a href="<?= APP_URL ?>/campaign_view.php?id=<?= $cid ?>" class="text-muted">
                <?= h($campaign['name']) ?>
            </a>
            — teach the AI everything about this campaign
        </p>
    </div>
    <div class="flex gap-2">
        <a href="<?= APP_URL ?>/campaign_view.php?id=<?= $cid ?>" class="btn btn-secondary btn-sm">
            <i class="hgi hgi-stroke hgi-arrow-left-02"></i> Back to Campaign
        </a>
    </div>
</div>

<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type']==='success'?'success':'danger' ?> mb-5">
    <?= h($flash['msg']) ?>
</div>
<?php endif; ?>

<!-- KB Completeness -->
<div class="card mb-5">
    <div class="card-body" style="padding:16px 20px;">
        <div class="flex items-center gap-4">
            <div style="flex:1;">
                <div class="flex flex-between mb-1">
                    <span class="text-sm font-semibold">Knowledge Base Completeness</span>
                    <span class="text-sm font-bold text-brand"><?= $kb_score ?>%</span>
                </div>
                <div style="height:8px;background:var(--neutral-100);border-radius:99px;overflow:hidden;">
                    <div style="height:100%;width:<?= $kb_score ?>%;background:var(--brand-500);border-radius:99px;transition:.5s;"></div>
                </div>
            </div>
            <div class="text-xs text-muted" style="white-space:nowrap;">
                <?= count($services) ?> services · <?= count($faqs) ?> FAQs · <?= count($pages) ?> pages
            </div>
        </div>
    </div>
</div>

<!-- Tab nav -->
<div class="flex gap-1 mb-5" style="border-bottom:1px solid var(--border-subtle);padding-bottom:0;">
    <?php
    $tabs = [
        'profile'  => ['hgi-user-circle-02',       'Business Profile'],
        'services' => ['hgi-service',               'Services (' . count($services) . ')'],
        'pricing'  => ['hgi-tag-01',                'Pricing ('  . count($pricing)  . ')'],
        'faqs'     => ['hgi-help-circle',           'FAQs ('     . count($faqs)     . ')'],
        'policies' => ['hgi-file-security',         'Policies ('  . count($policies) . ')'],
        'website'  => ['hgi-browser',               'Website ('  . count($pages)    . ')'],
        'analytics'=> ['hgi-chart-bar-line-01',     'Analytics'],
    ];
    foreach ($tabs as $key => [$icon, $label]): ?>
    <a href="?id=<?= $cid ?>&tab=<?= $key ?>"
       style="display:inline-flex;align-items:center;gap:6px;padding:9px 14px;font-size:.82rem;font-weight:600;text-decoration:none;border-bottom:2px solid <?= $tab===$key?'var(--brand-500)':'transparent' ?>;color:<?= $tab===$key?'var(--brand-500)':'var(--text-muted)' ?>;margin-bottom:-1px;white-space:nowrap;">
        <i class="hgi hgi-stroke <?= $icon ?>"></i><?= $label ?>
    </a>
    <?php endforeach; ?>
</div>

<!-- ── PROFILE TAB ─────────────────────────────────────────── -->
<?php if ($tab === 'profile'): ?>
<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title">Business Profile</div>
            <div class="card-subtitle">Core information the AI uses in all conversations for this campaign</div>
        </div>
    </div>
    <div class="card-body">
        <form method="POST">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save_profile">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                <div class="form-group">
                    <label class="form-label">Business Name</label>
                    <input type="text" name="business_name" class="input"
                        value="<?= h($profile['business_name'] ?? $campaign['name']) ?>"
                        placeholder="e.g. Smith Dental Clinic">
                </div>
                <div class="form-group">
                    <label class="form-label">Industry</label>
                    <input type="text" name="industry" class="input"
                        value="<?= h($profile['industry'] ?? '') ?>"
                        placeholder="e.g. Dental, Real Estate, Legal">
                </div>
                <div class="form-group" style="grid-column:1/-1;">
                    <label class="form-label">Business Description</label>
                    <textarea name="business_description" class="textarea" rows="3"
                        placeholder="Brief description of what this business does and who it serves..."><?= h($profile['business_description'] ?? '') ?></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Service Locations</label>
                    <input type="text" name="service_locations" class="input"
                        value="<?= h($profile['service_locations'] ?? $campaign['ai_location'] ?? '') ?>"
                        placeholder="e.g. London, Manchester, Online">
                </div>
                <div class="form-group">
                    <label class="form-label">Working Hours</label>
                    <input type="text" name="working_hours" class="input"
                        value="<?= h($profile['working_hours'] ?? '') ?>"
                        placeholder="e.g. Mon-Fri 9am-6pm, Sat 10am-2pm">
                </div>
                <div class="form-group">
                    <label class="form-label">Phone</label>
                    <input type="text" name="phone" class="input"
                        value="<?= h($profile['phone'] ?? '') ?>" placeholder="+44 20 1234 5678">
                </div>
                <div class="form-group">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="input"
                        value="<?= h($profile['email'] ?? '') ?>" placeholder="hello@business.com">
                </div>
                <div class="form-group">
                    <label class="form-label">Website</label>
                    <input type="url" name="website" class="input"
                        value="<?= h($profile['website'] ?? '') ?>" placeholder="https://www.business.com">
                </div>
                <div class="form-group">
                    <label class="form-label">Booking / Appointment URL</label>
                    <input type="url" name="booking_url" class="input"
                        value="<?= h($campaign['ai_booking_url'] ?? '') ?>"
                        placeholder="https://calendly.com/...">
                    <div class="form-hint">Shared with leads who ask to book</div>
                </div>
                <div class="form-group" style="grid-column:1/-1;">
                    <label class="form-label">Address</label>
                    <input type="text" name="address" class="input"
                        value="<?= h($profile['address'] ?? '') ?>"
                        placeholder="123 High Street, London, UK">
                </div>
                <div class="form-group">
                    <label class="form-label">AI Tone of Voice</label>
                    <select name="tone_of_voice" class="select">
                        <?php foreach(['professional'=>'Professional','friendly'=>'Friendly','formal'=>'Formal','casual'=>'Casual'] as $v=>$l): ?>
                        <option value="<?= $v ?>" <?= ($profile['tone_of_voice']??'professional')===$v?'selected':''?>><?= $l ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group" style="grid-column:1/-1;">
                    <label class="form-label">Additional Context <span class="text-muted text-xs">(optional)</span></label>
                    <textarea name="extra_context" class="textarea" rows="4"
                        placeholder="Anything else AI should know: unique selling points, certifications, awards, parking info, special instructions for staff..."><?= h($profile['extra_context'] ?? '') ?></textarea>
                </div>
            </div>
            <div class="flex gap-2 mt-4">
                <button type="submit" class="btn btn-primary">
                    <i class="hgi hgi-stroke hgi-floppy-disk"></i> Save Profile
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ── SERVICES TAB ────────────────────────────────────────── -->
<?php elseif ($tab === 'services'): ?>
<div class="flex gap-4" style="align-items:flex-start;">
    <!-- Form -->
    <div class="card" style="width:340px;flex-shrink:0;">
        <div class="card-header">
            <div class="card-title" id="svcFormTitle">Add Service</div>
        </div>
        <div class="card-body">
            <form method="POST" id="svcForm">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="save_service">
                <input type="hidden" name="service_id" id="svcId" value="0">
                <div class="form-group">
                    <label class="form-label">Service Name *</label>
                    <input type="text" name="name" id="svcName" class="input" required placeholder="e.g. Teeth Whitening">
                </div>
                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea name="description" id="svcDesc" class="textarea" rows="3"
                        placeholder="What does this service involve?"></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Key Benefits <span class="text-muted text-xs">(one per line)</span></label>
                    <textarea name="benefits" id="svcBenefits" class="textarea" rows="3"
                        placeholder="Instant results&#10;Pain-free procedure&#10;Lasts 12+ months"></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Typical Duration</label>
                    <input type="text" name="duration" id="svcDuration" class="input"
                        placeholder="e.g. 60 minutes, 2-3 sessions">
                </div>
                <div class="form-group">
                    <label class="form-label">Category</label>
                    <input type="text" name="category" id="svcCat" class="input"
                        placeholder="e.g. cosmetic, clinical, consultation">
                </div>
                <div class="form-group">
                    <label class="form-label">Sort Order</label>
                    <input type="number" name="sort_order" id="svcSort" class="input" value="0" min="0">
                </div>
                <div class="flex gap-2">
                    <button type="submit" class="btn btn-primary btn-sm">
                        <i class="hgi hgi-stroke hgi-floppy-disk"></i> Save
                    </button>
                    <button type="button" class="btn btn-secondary btn-sm" onclick="resetSvcForm()">Clear</button>
                </div>
            </form>
        </div>
    </div>
    <!-- List -->
    <div style="flex:1;min-width:0;">
        <?php if (!$services): ?>
        <div class="card">
            <div class="empty-state" style="padding:40px;">
                <i class="hgi hgi-stroke hgi-service empty-state-icon"></i>
                <div class="empty-state-title">No services yet</div>
                <div class="empty-state-desc">Add the services this campaign promotes so AI can explain them to leads.</div>
            </div>
        </div>
        <?php else: ?>
        <div style="display:flex;flex-direction:column;gap:10px;">
            <?php foreach ($services as $s): ?>
            <div class="card">
                <div class="card-body" style="padding:14px 16px;">
                    <div class="flex flex-between">
                        <div>
                            <div class="font-semibold text-sm"><?= h($s['name']) ?></div>
                            <?php if ($s['category']): ?>
                            <span class="badge badge-default badge-sm mt-1"><?= h($s['category']) ?></span>
                            <?php endif; ?>
                            <?php if ($s['description']): ?>
                            <div class="text-xs text-muted mt-1"><?= h(mb_substr($s['description'],0,120)) ?><?= mb_strlen($s['description'])>120?'…':''?></div>
                            <?php endif; ?>
                            <?php if ($s['duration']): ?>
                            <div class="text-xs text-muted mt-1"><i class="hgi hgi-stroke hgi-clock-01"></i> <?= h($s['duration']) ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="flex gap-1">
                            <button type="button" class="btn btn-secondary btn-xs btn-icon"
                                onclick="editService(<?= htmlspecialchars(json_encode($s), ENT_QUOTES) ?>)"
                                title="Edit"><i class="hgi hgi-stroke hgi-edit-02"></i></button>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this service?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete_service">
                                <input type="hidden" name="id" value="<?= $s['id'] ?>">
                                <button type="submit" class="btn btn-danger btn-xs btn-icon" title="Delete">
                                    <i class="hgi hgi-stroke hgi-delete-02"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</div>
<script>
function editService(s) {
    document.getElementById('svcFormTitle').textContent = 'Edit Service';
    document.getElementById('svcId').value       = s.id;
    document.getElementById('svcName').value     = s.name || '';
    document.getElementById('svcDesc').value     = s.description || '';
    document.getElementById('svcBenefits').value = s.benefits || '';
    document.getElementById('svcDuration').value = s.duration || '';
    document.getElementById('svcCat').value      = s.category || '';
    document.getElementById('svcSort').value     = s.sort_order || 0;
    document.getElementById('svcForm').scrollIntoView({behavior:'smooth'});
}
function resetSvcForm() {
    document.getElementById('svcFormTitle').textContent = 'Add Service';
    document.getElementById('svcForm').reset();
    document.getElementById('svcId').value = 0;
}
</script>

<!-- ── PRICING TAB ─────────────────────────────────────────── -->
<?php elseif ($tab === 'pricing'): ?>
<div class="flex gap-4" style="align-items:flex-start;">
    <div class="card" style="width:340px;flex-shrink:0;">
        <div class="card-header"><div class="card-title" id="priceFormTitle">Add Pricing</div></div>
        <div class="card-body">
            <form method="POST" id="priceForm">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="save_pricing">
                <input type="hidden" name="pricing_id" id="priceId" value="0">
                <div class="form-group">
                    <label class="form-label">Service Name *</label>
                    <input type="text" name="service_name" id="pSvcName" class="input" required
                        placeholder="e.g. Teeth Whitening">
                </div>
                <div class="form-group">
                    <label class="form-label">Price / Range</label>
                    <input type="text" name="price" id="pPrice" class="input"
                        placeholder="e.g. £299, From £99, £99-£299">
                </div>
                <div class="form-group">
                    <label class="form-label">Pricing Notes</label>
                    <textarea name="price_notes" id="pNotes" class="textarea" rows="2"
                        placeholder="What's included, payment options..."></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Special Offer <span class="text-muted text-xs">(optional)</span></label>
                    <input type="text" name="special_offer" id="pOffer" class="input"
                        placeholder="e.g. 20% off this month only">
                </div>
                <div class="flex gap-2">
                    <button type="submit" class="btn btn-primary btn-sm">
                        <i class="hgi hgi-stroke hgi-floppy-disk"></i> Save
                    </button>
                    <button type="button" class="btn btn-secondary btn-sm" onclick="resetPriceForm()">Clear</button>
                </div>
            </form>
        </div>
    </div>
    <div style="flex:1;min-width:0;">
        <?php if (!$pricing): ?>
        <div class="card">
            <div class="empty-state" style="padding:40px;">
                <i class="hgi hgi-stroke hgi-tag-01 empty-state-icon"></i>
                <div class="empty-state-title">No pricing yet</div>
                <div class="empty-state-desc">Add pricing so the AI can answer "how much does X cost?" questions accurately.</div>
            </div>
        </div>
        <?php else: ?>
        <div style="display:flex;flex-direction:column;gap:10px;">
            <?php foreach ($pricing as $p): ?>
            <div class="card">
                <div class="card-body" style="padding:14px 16px;">
                    <div class="flex flex-between">
                        <div>
                            <div class="font-semibold text-sm"><?= h($p['service_name']) ?></div>
                            <?php if ($p['price']): ?>
                            <div class="text-brand font-bold text-sm mt-1"><?= h($p['price']) ?></div>
                            <?php endif; ?>
                            <?php if ($p['special_offer']): ?>
                            <span class="badge badge-warning badge-sm mt-1">🎯 <?= h($p['special_offer']) ?></span>
                            <?php endif; ?>
                            <?php if ($p['price_notes']): ?>
                            <div class="text-xs text-muted mt-1"><?= h(mb_substr($p['price_notes'],0,100)) ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="flex gap-1">
                            <button type="button" class="btn btn-secondary btn-xs btn-icon"
                                onclick="editPrice(<?= htmlspecialchars(json_encode($p), ENT_QUOTES) ?>)">
                                <i class="hgi hgi-stroke hgi-edit-02"></i></button>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Delete?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete_pricing">
                                <input type="hidden" name="id" value="<?= $p['id'] ?>">
                                <button type="submit" class="btn btn-danger btn-xs btn-icon">
                                    <i class="hgi hgi-stroke hgi-delete-02"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</div>
<script>
function editPrice(p) {
    document.getElementById('priceFormTitle').textContent = 'Edit Pricing';
    document.getElementById('priceId').value   = p.id;
    document.getElementById('pSvcName').value  = p.service_name || '';
    document.getElementById('pPrice').value    = p.price || '';
    document.getElementById('pNotes').value    = p.price_notes || '';
    document.getElementById('pOffer').value    = p.special_offer || '';
    document.getElementById('priceForm').scrollIntoView({behavior:'smooth'});
}
function resetPriceForm() {
    document.getElementById('priceFormTitle').textContent = 'Add Pricing';
    document.getElementById('priceForm').reset();
    document.getElementById('priceId').value = 0;
}
</script>

<!-- ── FAQs TAB ────────────────────────────────────────────── -->
<?php elseif ($tab === 'faqs'): ?>
<div class="flex gap-4" style="align-items:flex-start;">
    <div class="card" style="width:360px;flex-shrink:0;">
        <div class="card-header"><div class="card-title" id="faqFormTitle">Add FAQ</div></div>
        <div class="card-body">
            <form method="POST" id="faqForm">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="save_faq">
                <input type="hidden" name="faq_id" id="faqId" value="0">
                <div class="form-group">
                    <label class="form-label">Question *</label>
                    <textarea name="question" id="faqQ" class="textarea" rows="2" required
                        placeholder="e.g. How long does the procedure take?"></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Answer *</label>
                    <textarea name="answer" id="faqA" class="textarea" rows="4" required
                        placeholder="The complete answer the AI will give when this question is asked..."></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Category <span class="text-muted text-xs">(optional)</span></label>
                    <input type="text" name="category" id="faqCat" class="input"
                        placeholder="e.g. pricing, process, eligibility">
                </div>
                <div class="flex gap-2">
                    <button type="submit" class="btn btn-primary btn-sm">
                        <i class="hgi hgi-stroke hgi-floppy-disk"></i> Save FAQ
                    </button>
                    <button type="button" class="btn btn-secondary btn-sm" onclick="resetFaqForm()">Clear</button>
                </div>
            </form>
        </div>
    </div>
    <div style="flex:1;min-width:0;">
        <?php if (!$faqs): ?>
        <div class="card">
            <div class="empty-state" style="padding:40px;">
                <i class="hgi hgi-stroke hgi-help-circle empty-state-icon"></i>
                <div class="empty-state-title">No FAQs yet</div>
                <div class="empty-state-desc">Add common customer questions. The AI searches these first when a lead asks anything.</div>
            </div>
        </div>
        <?php else: ?>
        <div style="display:flex;flex-direction:column;gap:10px;">
            <?php foreach ($faqs as $f): ?>
            <div class="card">
                <div class="card-body" style="padding:14px 16px;">
                    <div class="flex flex-between" style="align-items:flex-start;">
                        <div style="flex:1;min-width:0;">
                            <div class="font-semibold text-sm">Q: <?= h($f['question']) ?></div>
                            <div class="text-xs text-muted mt-1 mb-1">A: <?= h(mb_substr($f['answer'],0,140)) ?><?= mb_strlen($f['answer'])>140?'…':''?></div>
                            <div class="flex gap-2" style="align-items:center;">
                                <?php if ($f['category']): ?>
                                <span class="badge badge-default badge-sm"><?= h($f['category']) ?></span>
                                <?php endif; ?>
                                <?php if ($f['times_used'] > 0): ?>
                                <span class="text-xs text-muted">Used <?= $f['times_used'] ?>×</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="flex gap-1" style="flex-shrink:0;margin-left:12px;">
                            <button type="button" class="btn btn-secondary btn-xs btn-icon"
                                onclick="editFaq(<?= htmlspecialchars(json_encode($f), ENT_QUOTES) ?>)">
                                <i class="hgi hgi-stroke hgi-edit-02"></i></button>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Delete?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete_faq">
                                <input type="hidden" name="id" value="<?= $f['id'] ?>">
                                <button type="submit" class="btn btn-danger btn-xs btn-icon">
                                    <i class="hgi hgi-stroke hgi-delete-02"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</div>
<script>
function editFaq(f) {
    document.getElementById('faqFormTitle').textContent = 'Edit FAQ';
    document.getElementById('faqId').value  = f.id;
    document.getElementById('faqQ').value   = f.question || '';
    document.getElementById('faqA').value   = f.answer || '';
    document.getElementById('faqCat').value = f.category || '';
    document.getElementById('faqForm').scrollIntoView({behavior:'smooth'});
}
function resetFaqForm() {
    document.getElementById('faqFormTitle').textContent = 'Add FAQ';
    document.getElementById('faqForm').reset();
    document.getElementById('faqId').value = 0;
}
</script>

<!-- ── POLICIES TAB ────────────────────────────────────────── -->
<?php elseif ($tab === 'policies'): ?>
<div class="flex gap-4" style="align-items:flex-start;">
    <div class="card" style="width:360px;flex-shrink:0;">
        <div class="card-header"><div class="card-title" id="polFormTitle">Add Policy</div></div>
        <div class="card-body">
            <form method="POST" id="polForm">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="save_policy">
                <input type="hidden" name="policy_id" id="polId" value="0">
                <div class="form-group">
                    <label class="form-label">Policy Type</label>
                    <select name="policy_type" id="polType" class="select">
                        <option value="cancellation">Cancellation Policy</option>
                        <option value="appointment">Appointment Policy</option>
                        <option value="refund">Refund Policy</option>
                        <option value="consultation">Consultation Policy</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Title *</label>
                    <input type="text" name="title" id="polTitle" class="input" required
                        placeholder="e.g. Free Cancellation Policy">
                </div>
                <div class="form-group">
                    <label class="form-label">Policy Content *</label>
                    <textarea name="content" id="polContent" class="textarea" rows="5" required
                        placeholder="Full policy text that AI will reference when customers ask..."></textarea>
                </div>
                <div class="flex gap-2">
                    <button type="submit" class="btn btn-primary btn-sm">
                        <i class="hgi hgi-stroke hgi-floppy-disk"></i> Save Policy
                    </button>
                    <button type="button" class="btn btn-secondary btn-sm" onclick="resetPolForm()">Clear</button>
                </div>
            </form>
        </div>
    </div>
    <div style="flex:1;min-width:0;">
        <?php if (!$policies): ?>
        <div class="card">
            <div class="empty-state" style="padding:40px;">
                <i class="hgi hgi-stroke hgi-file-security empty-state-icon"></i>
                <div class="empty-state-title">No policies yet</div>
                <div class="empty-state-desc">Add cancellation, refund and appointment policies so the AI answers policy questions accurately.</div>
            </div>
        </div>
        <?php else: ?>
        <?php
        $pol_types = ['cancellation'=>['badge-danger','Cancellation'],'appointment'=>['badge-info','Appointment'],
                      'refund'=>['badge-warning','Refund'],'consultation'=>['badge-brand','Consultation'],'other'=>['badge-default','Other']];
        ?>
        <div style="display:flex;flex-direction:column;gap:10px;">
            <?php foreach ($policies as $pol): ?>
            <div class="card">
                <div class="card-body" style="padding:14px 16px;">
                    <div class="flex flex-between" style="align-items:flex-start;">
                        <div style="flex:1;min-width:0;">
                            <?php $pc = $pol_types[$pol['policy_type']] ?? $pol_types['other']; ?>
                            <span class="badge <?= $pc[0] ?> badge-sm mb-1"><?= $pc[1] ?></span>
                            <div class="font-semibold text-sm"><?= h($pol['title']) ?></div>
                            <div class="text-xs text-muted mt-1"><?= h(mb_substr($pol['content'],0,140)) ?><?= mb_strlen($pol['content'])>140?'…':''?></div>
                        </div>
                        <div class="flex gap-1" style="flex-shrink:0;margin-left:12px;">
                            <button type="button" class="btn btn-secondary btn-xs btn-icon"
                                onclick="editPol(<?= htmlspecialchars(json_encode($pol), ENT_QUOTES) ?>)">
                                <i class="hgi hgi-stroke hgi-edit-02"></i></button>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Delete?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete_policy">
                                <input type="hidden" name="id" value="<?= $pol['id'] ?>">
                                <button type="submit" class="btn btn-danger btn-xs btn-icon">
                                    <i class="hgi hgi-stroke hgi-delete-02"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</div>
<script>
function editPol(p) {
    document.getElementById('polFormTitle').textContent = 'Edit Policy';
    document.getElementById('polId').value      = p.id;
    document.getElementById('polType').value    = p.policy_type || 'other';
    document.getElementById('polTitle').value   = p.title || '';
    document.getElementById('polContent').value = p.content || '';
    document.getElementById('polForm').scrollIntoView({behavior:'smooth'});
}
function resetPolForm() {
    document.getElementById('polFormTitle').textContent = 'Add Policy';
    document.getElementById('polForm').reset();
    document.getElementById('polId').value = 0;
}
</script>

<!-- ── WEBSITE TAB ─────────────────────────────────────────── -->
<?php elseif ($tab === 'website'): ?>
<div class="card mb-4">
    <div class="card-header">
        <div>
            <div class="card-title">Import from Website</div>
            <div class="card-subtitle">Add URLs to crawl — the AI reads the text content from each page</div>
        </div>
    </div>
    <div class="card-body">
        <form method="POST" class="flex gap-2">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add_url">
            <input type="url" name="url" class="input" required
                placeholder="https://www.yourbusiness.com/services"
                style="flex:1;">
            <button type="submit" class="btn btn-primary btn-sm">
                <i class="hgi hgi-stroke hgi-add-circle"></i> Add URL
            </button>
        </form>
        <div class="form-hint mt-2">Add your about page, services page, pricing page etc. Then click Crawl on each one.</div>
    </div>
</div>

<?php if ($pages): ?>
<div style="display:flex;flex-direction:column;gap:10px;">
    <?php foreach ($pages as $pg): ?>
    <div class="card">
        <div class="card-body" style="padding:14px 16px;">
            <div class="flex flex-between" style="align-items:flex-start;gap:12px;">
                <div style="flex:1;min-width:0;">
                    <div class="flex gap-2" style="align-items:center;margin-bottom:4px;">
                        <?php if ($pg['status']==='crawled'): ?>
                        <span class="badge badge-success badge-sm">✓ Crawled</span>
                        <?php elseif ($pg['status']==='failed'): ?>
                        <span class="badge badge-danger badge-sm">✗ Failed</span>
                        <?php else: ?>
                        <span class="badge badge-warning badge-sm">⏳ Pending</span>
                        <?php endif; ?>
                        <?php if ($pg['word_count'] > 0): ?>
                        <span class="text-xs text-muted"><?= number_format($pg['word_count']) ?> words</span>
                        <?php endif; ?>
                    </div>
                    <?php if ($pg['page_title']): ?>
                    <div class="font-semibold text-sm"><?= h($pg['page_title']) ?></div>
                    <?php endif; ?>
                    <div class="text-xs text-muted" style="word-break:break-all;">
                        <a href="<?= h($pg['url']) ?>" target="_blank" class="text-brand"><?= h($pg['url']) ?></a>
                    </div>
                    <?php if ($pg['error_message']): ?>
                    <div class="text-xs" style="color:var(--color-danger-text);margin-top:4px;">
                        <?= h($pg['error_message']) ?>
                    </div>
                    <?php endif; ?>
                    <?php if ($pg['crawled_at']): ?>
                    <div class="text-xs text-muted mt-1">Last crawled: <?= format_dt($pg['crawled_at'], 'd M Y H:i') ?></div>
                    <?php endif; ?>
                </div>
                <div class="flex gap-1" style="flex-shrink:0;">
                    <form method="POST" style="display:inline;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="crawl_url">
                        <input type="hidden" name="page_id" value="<?= $pg['id'] ?>">
                        <button type="submit" class="btn btn-secondary btn-xs"
                            onclick="return confirm('Crawl this URL now? This may take a few seconds.')"
                            title="<?= $pg['status']==='crawled'?'Re-crawl':'Crawl' ?> this page">
                            <i class="hgi hgi-stroke hgi-refresh"></i>
                            <?= $pg['status']==='crawled'?'Re-crawl':'Crawl' ?>
                        </button>
                    </form>
                    <form method="POST" style="display:inline;" onsubmit="return confirm('Remove this page?')">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="delete_page">
                        <input type="hidden" name="id" value="<?= $pg['id'] ?>">
                        <button type="submit" class="btn btn-danger btn-xs btn-icon">
                            <i class="hgi hgi-stroke hgi-delete-02"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php else: ?>
<div class="card">
    <div class="empty-state" style="padding:40px;">
        <i class="hgi hgi-stroke hgi-browser empty-state-icon"></i>
        <div class="empty-state-title">No pages added yet</div>
        <div class="empty-state-desc">Add URLs from your website above and click Crawl to import content.</div>
    </div>
</div>
<?php endif; ?>

<!-- ── ANALYTICS TAB ───────────────────────────────────────── -->
<?php elseif ($tab === 'analytics'): ?>
<?php if (empty($analytics) || !isset($analytics['total_uses'])): ?>
<div class="card">
    <div class="empty-state" style="padding:40px;">
        <i class="hgi hgi-stroke hgi-chart-bar-line-01 empty-state-icon"></i>
        <div class="empty-state-title">No usage data yet</div>
        <div class="empty-state-desc">Analytics will appear here once the AI starts using this knowledge base in smart replies.</div>
    </div>
</div>
<?php else: ?>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px;">
    <div class="card">
        <div class="card-body" style="text-align:center;padding:24px;">
            <div style="font-size:2.5rem;font-weight:800;color:var(--brand-500);"><?= number_format($analytics['total_uses']) ?></div>
            <div class="text-xs text-muted mt-1 uppercase tracking-wide">Total KB Uses</div>
        </div>
    </div>
    <div class="card">
        <div class="card-header"><div class="card-title">Usage by Type</div></div>
        <div class="card-body">
            <?php foreach ($analytics['by_type'] ?? [] as $t): ?>
            <div class="info-row">
                <span class="info-lbl"><?= ucfirst(str_replace('_',' ',$t['source_type'])) ?></span>
                <span class="info-val font-bold"><?= $t['n'] ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php if ($analytics['top_faqs']): ?>
<div class="card mb-4">
    <div class="card-header"><div class="card-title">Most Used FAQs</div></div>
    <div class="card-body">
        <?php foreach ($analytics['top_faqs'] as $f): ?>
        <div class="detail-row">
            <div class="detail-lbl">Q: <?= h($f['question']) ?></div>
            <div class="detail-val flex flex-between">
                <span class="text-xs text-muted"><?= h(mb_substr($f['answer'],0,100)) ?>…</span>
                <span class="badge badge-brand badge-sm">Used <?= $f['times_used'] ?>×</span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<?php if ($analytics['recent_queries']): ?>
<div class="card">
    <div class="card-header"><div class="card-title">Recent Queries</div></div>
    <div class="card-body">
        <?php foreach ($analytics['recent_queries'] as $q): ?>
        <div class="detail-row">
            <div class="detail-lbl"><?= h(mb_substr($q['query_text'],0,120)) ?></div>
            <div class="detail-val flex flex-between">
                <span class="badge badge-default badge-sm"><?= h($q['source_type']) ?></span>
                <span class="text-xs text-muted"><?= format_dt($q['created_at'],'d M H:i') ?></span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>
<?php endif; ?>
<?php endif; ?>

<?php include __DIR__ . '/layouts/footer.php'; ?>
