<?php
/**
 * LeadPro — Public SEO Audit Report
 * /seo_report.php?token=<public_token>
 *
 * No authentication required. Accessed via secure 48-char random token.
 * Safe: read-only, scoped to token, no account data exposed.
 */
define('NO_SESSION', 1); // Skip session init — public page
require_once __DIR__ . '/config/config.local.php';

$token = trim((string)($_GET['token'] ?? ''));

// Validate token format — 48 hex chars
if (!preg_match('/^[a-f0-9]{48}$/', $token)) {
    http_response_code(404);
    include __DIR__ . '/layouts/403.php';
    exit;
}

// Look up audit by token — check column exists first (resilient to old schema)
$_pt_exists = false;
try {
    $res = db()->query("SHOW COLUMNS FROM seo_audits LIKE 'public_token'");
    $_pt_exists = ($res && $res->num_rows > 0);
} catch (Throwable $e) { }

if (!$_pt_exists) {
    // Schema not yet updated — show friendly message
    http_response_code(503);
    $__app_name = function_exists('ps') ? ps('app_name', 'LeadPro') : 'LeadPro';
    include __DIR__ . '/layouts/seo_report_notfound.php';
    exit;
}

$audit = db_fetch(
    'SELECT a.id, a.url, a.score_overall, a.result_json, a.created_at
     FROM seo_audits a
     WHERE a.public_token = ?
     LIMIT 1',
    's', $token
);

if (!$audit) {
    http_response_code(404);
    $__app_name = function_exists('ps') ? ps('app_name', 'LeadPro') : 'LeadPro';
    include __DIR__ . '/layouts/seo_report_notfound.php';
    exit;
}

// Audit found but result_json not yet saved (schema updated, audit needs re-run)
if (empty($audit['result_json'])) {
    http_response_code(200);
    $__app_name = function_exists('ps') ? ps('app_name', 'LeadPro') : 'LeadPro';
    $__audit_url = $audit['url'] ?? '';
    include __DIR__ . '/layouts/seo_report_pending.php';
    exit;
}

$data    = json_decode($audit['result_json'], true) ?: [];
$scores  = $data['scores']  ?? [];
$overall = (int)($scores['overall'] ?? $audit['score_overall']);
$ai      = $data['ai_summary']  ?? [];
$issues  = $data['issues']      ?? [];
$hl      = $data['highlights']  ?? [];
$modules = $data['modules']     ?? [];

$col       = $overall >= 70 ? '#16a34a' : ($overall >= 40 ? '#f59e0b' : '#ef4444');
$col_bg    = $overall >= 70 ? '#dcfce7' : ($overall >= 40 ? '#fef9c3' : '#fee2e2');
$col_label = $overall >= 70 ? 'Good'    : ($overall >= 40 ? 'Needs Improvement' : 'Poor');

$app_name   = ps('app_name', 'LeadPro');
$audit_host = parse_url($audit['url'], PHP_URL_HOST) ?: $audit['url'];
$audit_date = date('d M Y, g:ia', strtotime($audit['created_at']));

$crits = array_filter($issues, fn($i) => ($i['severity']??'') === 'critical');
$warns = array_filter($issues, fn($i) => ($i['severity']??'') === 'warning');
$infos = array_filter($issues, fn($i) => !in_array($i['severity']??'',['critical','warning']));

//function h(mixed $v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>SEO Audit Report — <?= h($audit_host) ?></title>
<meta name="robots" content="noindex,nofollow">
<style>
/* ── Reset + Base ────────────────────────────────── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #f1f5f9;
  color: #1e293b;
  font-size: 14px;
  line-height: 1.6;
  min-height: 100vh;
}

/* ── Layout ──────────────────────────────────────── */
.page-wrap { max-width: 860px; margin: 0 auto; padding: 24px 16px 64px; }

/* ── Top bar ─────────────────────────────────────── */
.topbar {
  background: #0f172a;
  padding: 14px 24px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
.topbar-brand { color: #fff; font-weight: 800; font-size: 16px; letter-spacing: -.3px; }
.topbar-meta  { color: #94a3b8; font-size: 12px; }

/* ── Cards ───────────────────────────────────────── */
.card {
  background: #fff;
  border: 1.5px solid #e2e8f0;
  border-radius: 12px;
  margin-bottom: 16px;
  overflow: hidden;
}
.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 18px;
  border-bottom: 1px solid #f1f5f9;
  font-weight: 700;
  font-size: 13px;
  color: #334155;
}
.card-body { padding: 18px; }

/* ── Hero score ──────────────────────────────────── */
.score-hero {
  background: #fff;
  border: 1.5px solid #e2e8f0;
  border-radius: 12px;
  padding: 24px;
  margin-bottom: 16px;
  display: flex;
  gap: 24px;
  align-items: center;
  flex-wrap: wrap;
}
.score-main { text-align: center; }
.score-big {
  font-size: 68px;
  font-weight: 900;
  line-height: 1;
  color: <?= $col ?>;
}
.score-label {
  display: inline-block;
  padding: 3px 12px;
  background: <?= $col_bg ?>;
  color: <?= $col ?>;
  border-radius: 20px;
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: .04em;
  margin-top: 6px;
}
.score-meta { flex: 1; min-width: 180px; }
.score-url  { font-size: 15px; font-weight: 700; color: #0f172a; word-break: break-all; margin-bottom: 4px; }
.score-date { font-size: 12px; color: #94a3b8; margin-bottom: 16px; }
.sub-scores { display: flex; flex-wrap: wrap; gap: 12px; }
.sub-score  { text-align: center; }
.sub-score .num   { font-size: 22px; font-weight: 800; }
.sub-score .name  { font-size: 10px; color: #94a3b8; text-transform: uppercase; letter-spacing: .04em; margin-top: 2px; }

/* ── Badges ──────────────────────────────────────── */
.badge { display: inline-block; padding: 2px 8px; border-radius: 20px; font-size: 11px; font-weight: 700; }
.badge-danger  { background: #fee2e2; color: #dc2626; }
.badge-warning { background: #fef9c3; color: #b45309; }
.badge-info    { background: #dbeafe; color: #2563eb; }

/* ── Issues ──────────────────────────────────────── */
.issue-item {
  padding: 10px 12px;
  border-radius: 8px;
  margin-bottom: 8px;
  border: 1px solid;
}
.issue-item.critical { background: #fef2f2; border-color: #fca5a5; }
.issue-item.warning  { background: #fffbeb; border-color: #fcd34d; }
.issue-item.info     { background: #eff6ff; border-color: #93c5fd; }
.issue-title  { font-weight: 600; font-size: 13px; margin-bottom: 3px; }
.issue-detail { font-size: 12px; color: #64748b; margin-bottom: 2px; }
.issue-fix    { font-size: 12px; color: #16a34a; }

/* ── AI section ──────────────────────────────────── */
.ai-summary { font-size: 14px; line-height: 1.75; color: #475569; margin-bottom: 16px; }
.section-label {
  font-size: 10px; font-weight: 700; text-transform: uppercase;
  letter-spacing: .06em; color: #94a3b8; margin: 14px 0 6px;
}
.opportunity-item, .quickwin-item {
  padding: 7px 10px;
  border-bottom: 1px solid #f1f5f9;
  font-size: 13px;
  color: #475569;
}
.opportunity-item::before { content: '→ '; color: #6366f1; font-weight: 700; }
.quickwin-item::before    { content: '✓ '; color: #16a34a; font-weight: 700; }

/* ── Highlights table ────────────────────────────── */
.hl-row {
  display: flex;
  justify-content: space-between;
  padding: 7px 0;
  border-bottom: 1px solid #f1f5f9;
  font-size: 13px;
  gap: 10px;
}
.hl-key { color: #94a3b8; flex-shrink: 0; }
.hl-val { font-weight: 500; text-align: right; word-break: break-word; color: #334155; }

/* ── Module cards ────────────────────────────────── */
.modules-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
@media (max-width: 540px) { .modules-grid { grid-template-columns: 1fr; } }
.mod-score-badge {
  font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 20px;
}

/* ── Footer ──────────────────────────────────────── */
.pub-footer {
  text-align: center;
  padding: 32px 16px;
  font-size: 12px;
  color: #94a3b8;
}
.pub-footer a { color: #94a3b8; }

/* ── Print ───────────────────────────────────────── */
@media print {
  body      { background: #fff; }
  .topbar   { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
  .no-print { display: none !important; }
}
</style>
</head>
<body>

<div class="topbar">
  <div class="topbar-brand"><?= h($app_name) ?></div>
  <div class="topbar-meta">SEO Audit Report — <?= h($audit_host) ?></div>
</div>

<div class="page-wrap">

  <!-- ── Score Hero ──────────────────────────────── -->
  <div class="score-hero">
    <div class="score-main">
      <div class="score-big"><?= $overall ?></div>
      <div style="font-size:11px;color:#94a3b8;text-transform:uppercase;letter-spacing:.04em;margin-top:4px;">Overall</div>
      <div class="score-label"><?= h($col_label) ?></div>
    </div>
    <div class="score-meta">
      <div class="score-url"><?= h($audit['url']) ?></div>
      <div class="score-date">Audited <?= h($audit_date) ?></div>
      <?php if (count($scores) > 1): ?>
      <div class="sub-scores">
        <?php foreach ($scores as $k => $v):
          if ($k === 'overall') continue;
          $sc = (int)$v;
          $c2 = $sc>=70?'#16a34a':($sc>=40?'#f59e0b':'#ef4444');
        ?>
        <div class="sub-score">
          <div class="num" style="color:<?= $c2 ?>"><?= $sc ?></div>
          <div class="name"><?= h(str_replace('_',' ',$k)) ?></div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- ── AI Strategic Analysis ───────────────────── -->
  <?php if (!empty($ai['strategic_summary'])): ?>
  <div class="card">
    <div class="card-header">🧠 AI Strategic Analysis</div>
    <div class="card-body">
      <div class="ai-summary"><?= h($ai['strategic_summary']) ?></div>

      <?php if (!empty($ai['top_opportunities'])): ?>
      <div class="section-label">Top Opportunities</div>
      <?php foreach ($ai['top_opportunities'] as $op): ?>
      <div class="opportunity-item"><?= h($op) ?></div>
      <?php endforeach; ?>
      <?php endif; ?>

      <?php if (!empty($ai['quick_wins'])): ?>
      <div class="section-label">Quick Wins</div>
      <?php foreach ($ai['quick_wins'] as $qw): ?>
      <div class="quickwin-item"><?= h($qw) ?></div>
      <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- ── Issues ──────────────────────────────────── -->
  <?php if ($issues): ?>
  <div class="card">
    <div class="card-header">
      Issues (<?= count($issues) ?>)
      <div style="display:flex;gap:6px;">
        <?php if ($crits): ?><span class="badge badge-danger"><?= count($crits) ?> critical</span><?php endif; ?>
        <?php if ($warns): ?><span class="badge badge-warning"><?= count($warns) ?> warning</span><?php endif; ?>
        <?php if ($infos): ?><span class="badge badge-info"><?= count($infos) ?> info</span><?php endif; ?>
      </div>
    </div>
    <div class="card-body">
      <?php foreach ([['critical','#ef4444',$crits],['warning','#f59e0b',$warns],['info','#3b82f6',$infos]] as [$sev,$ic,$grp]):
        if (!$grp) continue; ?>
      <div class="section-label" style="color:<?= $ic ?>"><?= $sev ?> (<?= count($grp) ?>)</div>
      <?php foreach ($grp as $issue): ?>
      <div class="issue-item <?= $sev ?>">
        <div class="issue-title"><?= h($issue['title'] ?? $issue['check'] ?? '') ?></div>
        <?php if ($issue['detail'] ?? ''): ?><div class="issue-detail"><?= h($issue['detail']) ?></div><?php endif; ?>
        <?php if ($issue['fix_guidance'] ?? ''): ?><div class="issue-fix">💡 <?= h($issue['fix_guidance']) ?></div><?php endif; ?>
      </div>
      <?php endforeach; ?>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- ── Page Highlights + Module Grid ──────────── -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px;">

    <?php if ($hl): ?>
    <div class="card" style="margin-bottom:0;">
      <div class="card-header">Page Highlights</div>
      <div class="card-body" style="padding:0 18px;">
        <?php foreach ($hl as $k => $v):
          if (!$v) continue;
          $disp = is_array($v) ? implode(', ', $v) : (string)$v;
          $disp = mb_substr($disp, 0, 200);
        ?>
        <div class="hl-row">
          <span class="hl-key"><?= h(str_replace('_',' ',$k)) ?></span>
          <span class="hl-val"><?= h($disp) ?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

  </div>

  <!-- ── Module Cards Grid ───────────────────────── -->
  <?php
  $visible_modules = array_filter(
    ['analytics'=>'Analytics','competitor'=>'Competitor','ecommerce'=>'Ecommerce','chatbot'=>'Chatbot & Lead Capture'],
    fn($mk) => !empty($modules[$mk]),
    ARRAY_FILTER_USE_KEY
  );
  if ($visible_modules): ?>
  <div class="modules-grid">
    <?php foreach ($visible_modules as $mk => $ml):
      $mod       = $modules[$mk];
      $mod_score = (int)($mod['score'] ?? 0);
      $mc        = $mod_score>=70?'#16a34a':($mod_score>=40?'#f59e0b':'#ef4444');
    ?>
    <div class="card" style="margin-bottom:0;">
      <div class="card-header">
        <?= h($ml) ?>
        <?php if ($mod_score): ?>
        <span class="mod-score-badge" style="background:<?= $mc ?>22;color:<?= $mc ?>;border:1px solid <?= $mc ?>44;">
          <?= $mod_score ?>/100
        </span>
        <?php endif; ?>
      </div>
      <div class="card-body" style="font-size:13px;color:#475569;">
        <?php if ($mod['summary'] ?? ''): ?>
        <p style="line-height:1.6;margin-bottom:8px;"><?= h($mod['summary']) ?></p>
        <?php endif; ?>
        <?php
          $lists = ['recommendations'=>'→','gaps'=>'!','strengths'=>'✓'];
          foreach ($lists as $listKey => $prefix):
            if (empty($mod[$listKey])) continue;
        ?>
        <div style="margin-top:6px;">
          <?php foreach (array_slice((array)$mod[$listKey], 0, 4) as $item): ?>
          <div style="padding:3px 0;border-bottom:1px solid #f1f5f9;">
            <?= $prefix ?> <?= h(is_array($item) ? ($item['text']??json_encode($item)) : $item) ?>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

</div><!-- /page-wrap -->

<div class="pub-footer">
  Report generated by <strong><?= h($app_name) ?></strong> · <?= h($audit_date) ?><br>
  <a href="<?= h($audit['url']) ?>" target="_blank" rel="noopener"><?= h($audit['url']) ?></a>
</div>

</body>
</html>