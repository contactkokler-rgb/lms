<?php
require_once __DIR__ . '/config/auth.php';
require_once __DIR__ . '/config/mailer.php';
require_once __DIR__ . '/config/BillingService.php';

/**
 * Save email templates submitted from form builder.
 * Types: auto_reply, notify, follow_up_1, follow_up_2, follow_up_3
 */
function save_form_templates(int $form_id, int $account_id, array $post): void {
    $db = db();
    if ($db->query("SHOW TABLES LIKE 'lead_form_email_templates'")->num_rows === 0) return;
    $types = ['auto_reply', 'notify', 'follow_up_1', 'follow_up_2', 'follow_up_3'];
    foreach ($types as $type) {
        $subject   = trim($post["tpl_{$type}_subject"] ?? '');
        $body      = trim($post["tpl_{$type}_body"]    ?? '');
        $is_active = isset($post["tpl_{$type}_active"]) ? 1 : 0;
        $delay     = (int)($post["tpl_{$type}_delay"] ?? 0);
        if (!$subject && !$body) continue; // skip empty templates
        $existing = db_fetch('SELECT id FROM lead_form_email_templates WHERE form_id=? AND type=?', 'is', $form_id, $type);
        if ($existing) {
            db_query('UPDATE lead_form_email_templates SET subject=?,body=?,is_active=?,delay_hours=?,updated_at=NOW() WHERE id=?',
                'ssiii', $subject, $body, $is_active, $delay, $existing['id']);
        } else {
            db_insert('INSERT INTO lead_form_email_templates (form_id,account_id,type,subject,body,is_active,delay_hours) VALUES (?,?,?,?,?,?,?)',
                'iisssis', $form_id, $account_id, $type, $subject, $body, $is_active, $delay);
        }
    }
}
$user       = require_permission('forms', 'create');
$account_id = (int)($user['account_id'] ?? 0);

$edit_id   = (int)($_GET['id'] ?? 0);
$edit_form = null;
$edit_fields = [];

if ($edit_id) {
    if (!can('forms', 'edit')) { http_response_code(403); include __DIR__ . '/layouts/403.php'; exit; }
    $edit_form = db_fetch('SELECT * FROM lead_forms WHERE id = ? AND account_id = ?', 'ii', $edit_id, $account_id);
    if (!$edit_form) {
        $_SESSION['flash'] = ['type'=>'error','msg'=>'Form not found.'];
        header('Location: ' . APP_URL . '/forms.php'); exit;
    }
    $edit_fields = db_fetch_all('SELECT * FROM form_fields WHERE form_id = ? ORDER BY sort_order, id', 'i', $edit_id);
}

$domains = db_fetch_all('SELECT id, domain, label FROM domains WHERE account_id = ? AND is_active = 1 ORDER BY domain', 'i', $account_id);

// ── Save ────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { http_response_code(403); die('CSRF'); }

    $name        = trim($_POST['form_name'] ?? '');
    $domain_id   = (int)($_POST['domain_id'] ?? 0);
    $desc        = trim($_POST['description'] ?? '');
    $redirect    = trim($_POST['redirect_url'] ?? '');
    $success_msg = trim($_POST['success_msg'] ?? 'Thank you! We will be in touch soon.');
    $notify      = trim($_POST['notify_email'] ?? '');
    $is_active   = isset($_POST['is_active']) ? 1 : 0;
    $fields_json = $_POST['fields_json'] ?? '[]';

    if (!$name)      { $_SESSION['flash'] = ['type'=>'error','msg'=>'Form name is required.']; header('Location: ' . $_SERVER['REQUEST_URI']); exit; }
    if (!$domain_id) { $_SESSION['flash'] = ['type'=>'error','msg'=>'Please select a domain.']; header('Location: ' . $_SERVER['REQUEST_URI']); exit; }

    // Verify domain belongs to account
    $domain_ok = db_fetch('SELECT id FROM domains WHERE id = ? AND account_id = ?', 'ii', $domain_id, $account_id);
    if (!$domain_ok) { $_SESSION['flash'] = ['type'=>'error','msg'=>'Invalid domain.']; header('Location: ' . $_SERVER['REQUEST_URI']); exit; }

    $ai_limit = (int)($_POST['ai_auto_limit'] ?? 3);
    $settings = json_encode(['redirect_url' => $redirect, 'success_msg' => $success_msg, 'notify_email' => $notify]);
    $fields   = json_decode($fields_json, true) ?: [];

    // Helper to insert a field row
    $insert_field = function(int $form_id, int $i, array $f): bool {
        $key   = trim($f['key']   ?? '');
        $label = trim($f['label'] ?? '');
        $type  = trim($f['type']  ?? 'text');
        if (!$key || !$label) return false;
        db_query(
            'INSERT INTO form_fields (form_id, field_key, field_label, field_type, placeholder, default_value, options, validation, sort_order, is_required, is_visible)
             VALUES (?,?,?,?,?,?,?,?,?,?,1)',
            'isssssssii',
            $form_id, $key, $label, $type,
            $f['placeholder'] ?? '', $f['default'] ?? '',
            json_encode($f['options'] ?? []),
            json_encode(['required' => (bool)($f['required'] ?? false)]),
            $i, (int)($f['required'] ?? 0)
        );
        return true;
    };

    $db = db();

    if ($edit_id && $edit_form) {
        // Use transaction so DELETE + INSERT are atomic — fields never lost on error
        $db->begin_transaction();
        try {
            db_query(
                'UPDATE lead_forms SET domain_id=?, name=?, description=?, settings=?, is_active=?, ai_auto_limit=?, updated_at=NOW() WHERE id=?',
                'isssiii', $domain_id, $name, $desc, $settings, $is_active, $ai_limit, $edit_id
            );
            db_query('DELETE FROM form_fields WHERE form_id = ?', 'i', $edit_id);
            foreach ($fields as $i => $f) {
                $insert_field($edit_id, $i, $f);
            }
            $db->commit();
            // Save email templates
            save_form_templates($edit_id, $account_id, $_POST);
            audit('form.updated', "form:{$edit_id}");
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Form updated successfully.'];
        } catch (Throwable $e) {
            $db->rollback();
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Save failed — your fields have been preserved. Error: ' . $e->getMessage()];
        }
        header('Location: ' . APP_URL . '/forms.php'); exit;
    } else {
        // Create — enforce plan limits
        if (!is_super_admin()) {
            BillingService::enforce($account_id, 'can_add_form', 'create a new form');
            if ($err = BillingService::enforceLimit($account_id, 'form')) {
                $_SESSION['flash'] = ['type'=>'error','msg'=>$err];
                header('Location: ' . APP_URL . '/forms.php'); exit;
            }
        }
        // Create
        $slug  = generate_form_slug($name, $account_id);
        $token = bin2hex(random_bytes(32));
        $db->begin_transaction();
        try {
            $form_id = db_insert(
                'INSERT INTO lead_forms (account_id, domain_id, created_by, name, slug, description, form_token, settings, is_active, ai_auto_limit) VALUES (?,?,?,?,?,?,?,?,?,?)',
                'iiisssssii', $account_id, $domain_id, $user['id'], $name, $slug, $desc, $token, $settings, $is_active, $ai_limit
            );
            if (!$form_id) throw new \RuntimeException('Failed to create form record.');
            foreach ($fields as $i => $f) {
                $insert_field($form_id, $i, $f);
            }
            $db->commit();
            // Save email templates
            save_form_templates($form_id, $account_id, $_POST);
            if (!is_super_admin()) BillingService::trackUsage($account_id, 'form');
            audit('form.created', "form:{$form_id}");
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Form created! Get your embed code from the Forms page.'];
        } catch (Throwable $e) {
            $db->rollback();
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Failed to create form. Error: ' . $e->getMessage()];
        }
        header('Location: ' . APP_URL . '/forms.php'); exit;
    }
}

$edit_settings = $edit_form ? (json_decode($edit_form['settings'] ?? '{}', true) ?: []) : [];

// Load existing email templates for edit mode
$edit_templates = [];
if ($edit_id) {
    $db_tpl = db();
    if ($db_tpl->query("SHOW TABLES LIKE 'lead_form_email_templates'")->num_rows > 0) {
        $tpl_rows = db_fetch_all('SELECT * FROM lead_form_email_templates WHERE form_id=?', 'i', $edit_id);
        foreach ($tpl_rows as $tr) { $edit_templates[$tr['type']] = $tr; }
    }
}

$page_title  = $edit_form ? 'Edit Form' : 'Form Builder';
$active_nav  = 'forms';

$field_types = [
    'text'     => ['icon' => 'Aa',  'label' => 'Text',        'color' => '#3b82f6'],
    'email'    => ['icon' => '@',   'label' => 'Email',       'color' => '#8b5cf6'],
    'phone'    => ['icon' => '☎',   'label' => 'Phone',       'color' => '#06b6d4'],
    'number'   => ['icon' => '#',   'label' => 'Number',      'color' => '#f59e0b'],
    'textarea' => ['icon' => '¶',   'label' => 'Long Text',   'color' => '#64748b'],
    'select'   => ['icon' => '▾',   'label' => 'Dropdown',    'color' => '#10b981'],
    'radio'    => ['icon' => '◉',   'label' => 'Radio',       'color' => '#f97316'],
    'checkbox' => ['icon' => '☑',   'label' => 'Checkbox',    'color' => '#ec4899'],
    'date'     => ['icon' => '📅',  'label' => 'Date',        'color' => '#6366f1'],
    'url'      => ['icon' => '🔗',  'label' => 'URL',         'color' => '#14b8a6'],
    'hidden'   => ['icon' => '·',   'label' => 'Hidden',      'color' => '#94a3b8'],
];

include __DIR__ . '/layouts/header.php';
?>

<style>
/* ── Form Builder Layout ── */
.fb-layout { display: grid; grid-template-columns: 210px 1fr 280px; gap: 20px; align-items: start; }
@media (max-width: 900px) { .fb-layout { grid-template-columns: 1fr; } }

/* Palette */
.fb-palette { background: #fff; border: 1.5px solid var(--gray-150); border-radius: var(--radius-lg); overflow: hidden; }
.fb-palette-head { padding: 12px 16px; border-bottom: 1.5px solid var(--gray-150); font-size: .7rem; font-weight: 700; color: var(--gray-400); letter-spacing: .08em; text-transform: uppercase; }
.fb-palette-body { padding: 8px; }
.fb-type-btn { display: flex; align-items: center; gap: 10px; width: 100%; padding: 8px 10px; background: none; border: 1.5px solid transparent; border-radius: 8px; cursor: pointer; text-align: left; transition: all .12s; margin-bottom: 2px; }
.fb-type-btn:hover { background: var(--gray-50); border-color: var(--gray-200); }
.fb-type-btn:active { transform: scale(.97); }
.fb-type-icon { width: 26px; height: 26px; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: .72rem; font-weight: 700; flex-shrink: 0; }
.fb-type-label { font-size: .8rem; font-weight: 500; color: var(--gray-700); }

/* Canvas */
.fb-canvas-wrap { background: #fff; border: 1.5px solid var(--gray-150); border-radius: var(--radius-lg); overflow: hidden; }
.fb-canvas-head { padding: 14px 20px; border-bottom: 1.5px solid var(--gray-150); display: flex; align-items: center; justify-content: space-between; }
.fb-canvas { padding: 16px; min-height: 420px; }
.fb-empty { display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 360px; text-align: center; color: var(--gray-400); }
.fb-empty svg { margin-bottom: 16px; }
.fb-empty-title { font-size: .9rem; font-weight: 600; margin-bottom: 4px; color: var(--gray-500); }

/* Field row */
.fb-field { display: flex; align-items: center; gap: 10px; padding: 12px 14px; background: #fff; border: 1.5px solid var(--gray-200); border-radius: 10px; margin-bottom: 8px; cursor: pointer; transition: all .12s; user-select: none; }
.fb-field:hover { border-color: var(--brand-300); box-shadow: 0 2px 8px rgba(37,99,235,.07); }
.fb-field.selected { border-color: var(--brand-500); background: #eff6ff; box-shadow: 0 0 0 3px rgba(37,99,235,.1); }
.fb-field.dragging { opacity: .4; }
.fb-drag-handle { color: var(--gray-300); cursor: grab; flex-shrink: 0; }
.fb-drag-handle:active { cursor: grabbing; }
.fb-field-info { flex: 1; min-width: 0; }
.fb-field-label { font-size: .83rem; font-weight: 600; color: var(--gray-800); }
.fb-field-meta { font-size: .73rem; color: var(--gray-400); margin-top: 1px; }
.fb-field-required { color: #ef4444; margin-left: 3px; }
.fb-field-actions { display: flex; gap: 4px; opacity: 0; transition: opacity .12s; }
.fb-field:hover .fb-field-actions { opacity: 1; }
.fb-field.selected .fb-field-actions { opacity: 1; }
.fb-act-btn { width: 26px; height: 26px; border: none; background: none; border-radius: 6px; cursor: pointer; display: flex; align-items: center; justify-content: center; color: var(--gray-400); transition: all .12s; }
.fb-act-btn:hover { background: var(--gray-100); color: var(--gray-700); }
.fb-act-btn.del:hover { background: #fee2e2; color: #ef4444; }

/* Editor panel */
.fb-editor { background: #fff; border: 1.5px solid var(--gray-150); border-radius: var(--radius-lg); overflow: hidden; margin-bottom: 16px; }
.fb-editor-head { padding: 12px 16px; border-bottom: 1.5px solid var(--gray-150); display: flex; align-items: center; justify-content: space-between; }
.fb-editor-title { font-size: .82rem; font-weight: 700; color: var(--gray-700); }
.fb-editor-body { padding: 14px 16px; }

/* Settings panel */
.fb-settings { background: #fff; border: 1.5px solid var(--gray-150); border-radius: var(--radius-lg); overflow: hidden; }
.fb-settings-head { padding: 12px 16px; border-bottom: 1.5px solid var(--gray-150); font-size: .82rem; font-weight: 700; color: var(--gray-700); }
.fb-settings-body { padding: 14px 16px; }

/* Preview panel in canvas */
.fb-preview { background: var(--gray-50); border-radius: 10px; padding: 20px; margin-top: 12px; border: 1.5px dashed var(--gray-200); }
.fb-preview-label { font-size: .7rem; font-weight: 700; color: var(--gray-400); letter-spacing: .06em; text-transform: uppercase; margin-bottom: 14px; }
.fp-field { margin-bottom: 14px; }
.fp-label { font-size: .78rem; font-weight: 600; color: var(--gray-700); margin-bottom: 5px; display: block; }
.fp-input { width: 100%; padding: 8px 10px; border: 1.5px solid var(--gray-200); border-radius: 8px; font-size: .8rem; background: #fff; color: var(--gray-500); }
textarea.fp-input { resize: vertical; min-height: 72px; }

/* Toggle switch (reuse from app.css if present) */
.fb-toggle { display: flex; align-items: center; gap: 8px; font-size: .82rem; color: var(--gray-700); cursor: pointer; margin-bottom: 10px; }
.fb-toggle input { width: 34px; height: 18px; appearance: none; background: var(--gray-300); border-radius: 9px; cursor: pointer; position: relative; transition: background .15s; outline: none; }
.fb-toggle input:checked { background: var(--brand-500); }
.fb-toggle input::after { content: ''; position: absolute; width: 14px; height: 14px; background: #fff; border-radius: 50%; top: 2px; left: 2px; transition: left .15s; }
.fb-toggle input:checked::after { left: 18px; }
</style>

<?php if (!$domains): ?>
<div class="alert alert-error" style="margin-bottom:20px;">
  ⚠ You need to <a href="domains.php">add a domain</a> before you can create forms.
</div>
<?php endif; ?>

<div class="page-header" style="margin-bottom:20px;">
  <div>
    <h1 class="page-title"><?= $edit_form ? h('Edit: ' . $edit_form['name']) : 'Form Builder' ?></h1>
    <p class="page-subtitle">Drag fields to build your lead capture form</p>
  </div>
  <a href="<?= APP_URL ?>/forms.php" class="btn btn-secondary">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 5l-7 7 7 7"/></svg>
    Back to Forms
  </a>
</div>

<form method="POST" id="builderForm">
  <?= csrf_field() ?>
  <input type="hidden" name="fields_json" id="fieldsJson" value="">

  <div class="fb-layout">

    <!-- ── Palette ── -->
    <div>
      <div class="fb-palette">
        <div class="fb-palette-head">Field Types</div>
        <div class="fb-palette-body">
          <?php foreach ($field_types as $type => $info): ?>
          <button type="button" class="fb-type-btn" onclick="addField('<?= $type ?>')" data-type="<?= $type ?>">
            <span class="fb-type-icon" style="background:<?= $info['color'] ?>22;color:<?= $info['color'] ?>;">
              <?= $info['icon'] ?>
            </span>
            <span class="fb-type-label"><?= $info['label'] ?></span>
          </button>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <!-- ── Canvas ── -->
    <div>
      <div class="fb-canvas-wrap">
        <div class="fb-canvas-head">
          <div style="display:flex;align-items:center;gap:8px;">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--gray-400)" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg>
            <span style="font-size:.82rem;font-weight:700;color:var(--gray-700);">Form Canvas</span>
          </div>
          <span id="fieldCount" style="font-size:.75rem;color:var(--gray-400);">0 fields</span>
        </div>

        <div class="fb-canvas" id="canvas">
          <div id="emptyCanvas" class="fb-empty">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--gray-300)" stroke-width="1.2">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
              <path d="M14 2v6h6"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>
            </svg>
            <div class="fb-empty-title">No fields yet</div>
            <div style="font-size:.78rem;">Click a field type on the left to add it</div>
          </div>
        </div>

        <!-- Live preview -->
        <div id="formPreview" style="display:none;padding:0 16px 16px;">
          <div class="fb-preview">
            <div class="fb-preview-label">Live Preview</div>
            <div id="previewFields"></div>
            <button type="button" style="width:100%;padding:9px;background:var(--brand-500);color:#fff;border:none;border-radius:8px;font-size:.82rem;font-weight:600;cursor:default;">Submit</button>
          </div>
        </div>
      </div>
    </div>

    <!-- ── Right panel: editor + settings ── -->
    <div>
      <!-- Field editor -->
      <div class="fb-editor" id="fieldEditor" style="display:none;">
        <div class="fb-editor-head">
          <span class="fb-editor-title">Edit Field</span>
          <button type="button" class="fb-act-btn" onclick="closeEditor()" title="Close">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>
        <div class="fb-editor-body">
          <div class="form-group">
            <label class="form-label" style="font-size:.75rem;">Label</label>
            <input id="ef-label" class="form-control form-control-sm" placeholder="Field label" oninput="syncField()">
          </div>
          <div class="form-group">
            <label class="form-label" style="font-size:.75rem;">Key <span style="font-weight:400;color:var(--gray-400);">(auto-generated)</span></label>
            <input id="ef-key" class="form-control form-control-sm" placeholder="field_key" style="font-family:var(--font-mono);font-size:.75rem;" oninput="syncField()">
          </div>
          <div class="form-group">
            <label class="form-label" style="font-size:.75rem;">Placeholder</label>
            <input id="ef-placeholder" class="form-control form-control-sm" oninput="syncField()">
          </div>
          <div class="form-group" id="ef-options-group" style="display:none;">
            <label class="form-label" style="font-size:.75rem;">Options <span style="font-weight:400;color:var(--gray-400);">(one per line)</span></label>
            <textarea id="ef-options" class="form-control form-control-sm" rows="4" placeholder="Option A&#10;Option B&#10;Option C" oninput="syncField()"></textarea>
          </div>
          <label class="fb-toggle">
            <input type="checkbox" id="ef-required" onchange="syncField()">
            Required field
          </label>
          <button type="button" class="btn btn-danger btn-sm" style="width:100%;margin-top:4px;" onclick="deleteSelectedField()">Remove field</button>
        </div>
      </div>

      <!-- Form settings -->
      <div class="fb-settings">
        <div class="fb-settings-head">Form Settings</div>
        <div class="fb-settings-body">
          <div class="form-group">
            <label class="form-label" style="font-size:.75rem;">Form name <span style="color:#ef4444">*</span></label>
            <input name="form_name" id="formName" class="form-control form-control-sm" placeholder="e.g. Contact Form" value="<?= h($edit_form['name'] ?? '') ?>" required>
          </div>
          <div class="form-group">
            <label class="form-label" style="font-size:.75rem;">Domain <span style="color:#ef4444">*</span></label>
            <select name="domain_id" class="form-control form-control-sm" required>
              <option value="">— Select domain —</option>
              <?php foreach ($domains as $d): ?>
              <option value="<?= $d['id'] ?>" <?= ($edit_form['domain_id'] ?? 0) == $d['id'] ? 'selected' : '' ?>>
                <?= h($d['label'] ?: $d['domain']) ?>
              </option>
              <?php endforeach; ?>
            </select>
            <?php if (!$domains): ?>
            <div class="form-help" style="color:#f59e0b;">⚠ Add a domain first</div>
            <?php endif; ?>
          </div>
          <div class="form-group">
            <label class="form-label" style="font-size:.75rem;">Description</label>
            <textarea name="description" class="form-control form-control-sm" rows="2" placeholder="Internal notes…"><?= h($edit_form['description'] ?? '') ?></textarea>
          </div>
          <div class="form-group">
            <label class="form-label" style="font-size:.75rem;">Redirect URL after submit</label>
            <input name="redirect_url" class="form-control form-control-sm" type="url" placeholder="https://…" value="<?= h($edit_settings['redirect_url'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label class="form-label" style="font-size:.75rem;">Success message</label>
            <input name="success_msg" class="form-control form-control-sm" placeholder="Thank you! We will be in touch soon." value="<?= h($edit_settings['success_msg'] ?? 'Thank you! We will be in touch soon.') ?>">
          </div>
          <div class="form-group">
            <label class="form-label" style="font-size:.75rem;">Notification email</label>
            <input name="notify_email" type="email" class="form-control form-control-sm" placeholder="you@example.com" value="<?= h($edit_settings['notify_email'] ?? '') ?>">
          </div>
          <label class="fb-toggle" style="margin-bottom:16px;">
            <input type="checkbox" name="is_active" value="1" <?= ($edit_form['is_active'] ?? 1) ? 'checked' : '' ?>>
            Form is active
          </label>

          <!-- ── AI Automation Limit ───────────────────── -->
          <div class="form-group" style="border-top:1px solid var(--gray-100);padding-top:14px;margin-top:4px;">
            <label class="form-label" style="font-size:.75rem;font-weight:700;">
              <i class="hgi hgi-stroke hgi-ai-brain-05" style="font-size:.85rem;"></i> AI Auto-Reply Limit
            </label>
            <select name="ai_auto_limit" class="form-control form-control-sm">
              <?php
              $cur_limit = (int)($edit_form['ai_auto_limit'] ?? 3);
              $opts = [0=>'Disabled (no AI auto-replies)',1=>'1 reply then human',2=>'2 replies then human',3=>'3 replies then human (recommended)',5=>'5 replies then human',-1=>'Unlimited (fully autonomous)'];
              foreach ($opts as $v=>$l): ?>
              <option value="<?= $v ?>" <?= $cur_limit===$v?'selected':'' ?>><?= $l ?></option>
              <?php endforeach; ?>
            </select>
            <div class="form-help">How many AI-generated email replies to send before pausing for human review.</div>
          </div>

          <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;margin-top:8px;">
            <?= $edit_form ? 'Update Form' : 'Save & Create Form' ?>
          </button>
        </div>
      </div>
    </div>

    <!-- ── Email Templates ──────────────────────────────── -->
    <div style="background:#fff;border:1.5px solid var(--gray-100);border-radius:14px;padding:0;margin-bottom:20px;overflow:hidden;">
      <div style="background:linear-gradient(135deg,var(--brand-500),var(--brand-600));padding:14px 18px;color:#fff;">
        <div style="font-size:.82rem;font-weight:700;margin-bottom:2px;"><i class="hgi hgi-stroke hgi-mail-01"></i> Email Templates</div>
        <div style="font-size:.72rem;opacity:.85;">Configure automated emails sent to leads and staff. Use variables like <code style="background:rgba(255,255,255,.2);padding:1px 4px;border-radius:3px;">{{name}}</code> <code style="background:rgba(255,255,255,.2);padding:1px 4px;border-radius:3px;">{{email}}</code> <code style="background:rgba(255,255,255,.2);padding:1px 4px;border-radius:3px;">{{booking_url}}</code></div>
      </div>
      <div style="padding:16px 18px;">
        <!-- Variable reference -->
        <div style="background:var(--gray-50);border-radius:8px;padding:10px 12px;margin-bottom:16px;font-size:.72rem;color:var(--gray-500);line-height:1.8;">
          <strong>Available variables:</strong><br>
          <code>{{name}}</code> <code>{{email}}</code> <code>{{phone}}</code> <code>{{message}}</code>
          <code>{{form_name}}</code> <code>{{campaign_name}}</code> <code>{{booking_url}}</code>
          <code>{{lead_ref}}</code> <code>{{submitted_date}}</code> <code>{{service}}</code>
        </div>

        <?php
        $tpl_defs = [
          'auto_reply'  => ['Auto-Reply to Lead',       'Sent automatically to the lead when they submit this form.',          'hgi-user-circle-02', 'badge-success'],
          'notify'      => ['Staff Notification',        'Sent to your team when a new lead is submitted.',                     'hgi-user-multiple-02','badge-info'],
          'follow_up_1' => ['Follow-Up #1',              'First follow-up email (sent to lead automatically).',                 'hgi-mail-send-01',   'badge-warning'],
          'follow_up_2' => ['Follow-Up #2',              'Second follow-up email.',                                             'hgi-mail-send-01',   'badge-warning'],
          'follow_up_3' => ['Follow-Up #3 (Final)',      'Final follow-up email.',                                              'hgi-mail-send-01',   'badge-danger'],
        ];
        $tpl_defaults = [
          'auto_reply'  => [
            'subject' => 'Thanks for reaching out, {{name}}!',
            'body'    => "Hi {{name}},

Thank you for getting in touch with us via {{form_name}}.

We've received your enquiry and a member of our team will be in touch with you shortly.

{{booking_url}}

Best regards,
{{app_name}}",
          ],
          'notify' => [
            'subject' => '[New Lead] {{lead_ref}} — {{form_name}}',
            'body'    => "New lead submitted via {{form_name}}.

Name: {{name}}
Email: {{email}}
Phone: {{phone}}
Message: {{message}}

Submitted: {{submitted_date}}
Ref: {{lead_ref}}",
          ],
          'follow_up_1' => [
            'subject' => 'Following up on your enquiry, {{name}}',
            'body'    => "Hi {{name}},

I wanted to follow up on your recent enquiry about {{service}}.

We'd love to help you — would you be free for a quick call?

{{booking_url}}

Best regards,
{{app_name}}",
          ],
          'follow_up_2' => [
            'subject' => 'Still interested, {{name}}?',
            'body'    => "Hi {{name}},

Just checking in — we haven't heard back from you yet.

If you're still interested in {{service}}, we'd be happy to answer any questions.

{{booking_url}}

Best regards,
{{app_name}}",
          ],
          'follow_up_3' => [
            'subject' => 'Last chance to connect, {{name}}',
            'body'    => "Hi {{name}},

This is our final follow-up regarding your enquiry.

If now isn't the right time, no problem at all — feel free to reach back out whenever you're ready.

{{booking_url}}

Best wishes,
{{app_name}}",
          ],
        ];
        foreach ($tpl_defs as $type => [$tpl_label, $tpl_desc, $tpl_icon, $tpl_badge]):
          $t = $edit_templates[$type] ?? null;
          $def = $tpl_defaults[$type];
          $is_follow = str_starts_with($type, 'follow_up');
        ?>
        <div style="border:1.5px solid var(--gray-100);border-radius:10px;margin-bottom:14px;overflow:hidden;">
          <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:var(--gray-50);cursor:pointer;user-select:none;"
               onclick="toggleTpl('<?= $type ?>')">
            <div style="display:flex;align-items:center;gap:8px;">
              <i class="hgi hgi-stroke <?= $tpl_icon ?>" style="font-size:1rem;color:var(--brand-500);"></i>
              <div>
                <div style="font-size:.8rem;font-weight:700;color:var(--gray-800);"><?= $tpl_label ?></div>
                <div style="font-size:.7rem;color:var(--gray-400);"><?= $tpl_desc ?></div>
              </div>
            </div>
            <div style="display:flex;align-items:center;gap:8px;">
              <?php if ($t && $t['is_active']): ?>
              <span class="badge <?= $tpl_badge ?> badge-sm">Active</span>
              <?php else: ?>
              <span class="badge badge-default badge-sm">Inactive</span>
              <?php endif; ?>
              <span id="tpl_arrow_<?= $type ?>" style="font-size:.7rem;color:var(--gray-300);">▼</span>
            </div>
          </div>
          <div id="tpl_panel_<?= $type ?>" style="display:none;padding:14px;">
            <label class="fb-toggle" style="margin-bottom:12px;">
              <input type="checkbox" name="tpl_<?= $type ?>_active" value="1" <?= ($t['is_active'] ?? 0) ? 'checked' : '' ?>>
              Enable this template
            </label>
            <?php if ($is_follow): ?>
            <div class="form-group">
              <label class="form-label" style="font-size:.75rem;">Send after (hours from submission)</label>
              <input type="number" name="tpl_<?= $type ?>_delay" class="form-control form-control-sm"
                value="<?= (int)($t['delay_hours'] ?? ($type==='follow_up_1'?24:($type==='follow_up_2'?72:168))) ?>"
                min="1" max="8760" placeholder="e.g. 24">
              <div class="form-help">24 = 1 day, 72 = 3 days, 168 = 7 days</div>
            </div>
            <?php endif; ?>
            <div class="form-group">
              <label class="form-label" style="font-size:.75rem;">Subject line</label>
              <input type="text" name="tpl_<?= $type ?>_subject" class="form-control form-control-sm"
                value="<?= h($t['subject'] ?? $def['subject']) ?>"
                placeholder="<?= h($def['subject']) ?>">
            </div>
            <div class="form-group">
              <label class="form-label" style="font-size:.75rem;">Email body</label>
              <textarea name="tpl_<?= $type ?>_body" class="form-control form-control-sm" rows="8"
                style="font-family:monospace;font-size:.78rem;"
                placeholder="<?= h($def['body']) ?>"><?= h($t['body'] ?? $def['body']) ?></textarea>
            </div>
            <div style="background:var(--gray-50);border-radius:6px;padding:8px 10px;font-size:.7rem;color:var(--gray-400);">
              💡 Preview: uses lead data when sent. Variables in <code>{{curly braces}}</code> are replaced automatically.
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

  </div>
</form>

<script>
// ── State ────────────────────────────────────────────────────
let fields     = <?= json_encode(array_map(function($f) {
    $opts = json_decode($f['options'], true) ?? [];
    $val  = json_decode($f['validation'], true) ?? [];
    return [
        'id'          => 'f_' . $f['id'],
        'type'        => $f['field_type'],
        'label'       => $f['field_label'],
        'key'         => $f['field_key'],
        'placeholder' => $f['placeholder'] ?? '',
        'default'     => $f['default_value'] ?? '',
        'options'     => $opts,
        'required'    => (bool)($val['required'] ?? false),
    ];
}, $edit_fields)) ?>;

let selectedId  = null;
let dragSrcIdx  = null;

const fieldTypes = <?= json_encode($field_types) ?>;
const canvas     = document.getElementById('canvas');
const emptyEl    = document.getElementById('emptyCanvas');
const editorEl   = document.getElementById('fieldEditor');
const previewEl  = document.getElementById('formPreview');

// ── Helpers ──────────────────────────────────────────────────
function uid()     { return 'f_' + Date.now() + '_' + Math.random().toString(36).slice(2,6); }
function slugify(s){ return s.toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,''); }

// ── Add field ────────────────────────────────────────────────
function addField(type) {
  const existing = fields.map(x => x.key);
  let base = slugify(fieldTypes[type].label), i = 1, k = base;
  while (existing.includes(k)) k = base + '_' + (i++);
  const f = {
    id: uid(), type, label: fieldTypes[type].label, key: k,
    placeholder: '', default: '', options: [],
    required: type === 'email'
  };
  fields.push(f);
  renderCanvas();
  selectField(f.id);
}

// ── Render canvas ────────────────────────────────────────────
function renderCanvas() {
  emptyEl.style.display    = fields.length ? 'none' : '';
  previewEl.style.display  = fields.length ? ''     : 'none';
  document.getElementById('fieldCount').textContent = fields.length + ' field' + (fields.length !== 1 ? 's' : '');

  canvas.querySelectorAll('.fb-field').forEach(e => e.remove());

  fields.forEach((f, i) => {
    const info = fieldTypes[f.type] || {icon:'?', label:f.type, color:'#888'};
    const div  = document.createElement('div');
    div.className = 'fb-field' + (f.id === selectedId ? ' selected' : '');
    div.dataset.id  = f.id;
    div.dataset.idx = i;
    div.draggable   = true;

    div.innerHTML = `
      <div class="fb-drag-handle">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
          <circle cx="9"  cy="5"  r="1.2"/><circle cx="15" cy="5"  r="1.2"/>
          <circle cx="9"  cy="12" r="1.2"/><circle cx="15" cy="12" r="1.2"/>
          <circle cx="9"  cy="19" r="1.2"/><circle cx="15" cy="19" r="1.2"/>
        </svg>
      </div>
      <span style="width:28px;height:28px;border-radius:7px;background:${info.color}22;color:${info.color};display:flex;align-items:center;justify-content:center;font-size:.72rem;font-weight:700;flex-shrink:0;">${info.icon}</span>
      <div class="fb-field-info">
        <div class="fb-field-label">${escHtml(f.label)}${f.required ? '<span class="fb-field-required">*</span>' : ''}</div>
        <div class="fb-field-meta">${f.type} · ${f.key}</div>
      </div>
      <div class="fb-field-actions">
        ${i > 0 ? `<button type="button" class="fb-act-btn" onclick="event.stopPropagation();moveField('${f.id}',-1)" title="Move up"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 15l-6-6-6 6"/></svg></button>` : ''}
        ${i < fields.length-1 ? `<button type="button" class="fb-act-btn" onclick="event.stopPropagation();moveField('${f.id}',1)" title="Move down"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg></button>` : ''}
        <button type="button" class="fb-act-btn del" onclick="event.stopPropagation();deleteField('${f.id}')" title="Remove">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>
        </button>
      </div>`;

    div.addEventListener('click', () => selectField(f.id));

    // Drag events
    div.addEventListener('dragstart', e => { dragSrcIdx = i; div.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move'; });
    div.addEventListener('dragend',   () => { div.classList.remove('dragging'); });
    div.addEventListener('dragover',  e => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; div.style.borderColor = 'var(--brand-400)'; });
    div.addEventListener('dragleave', () => { div.style.borderColor = ''; });
    div.addEventListener('drop', e => {
      e.preventDefault(); div.style.borderColor = '';
      if (dragSrcIdx !== null && dragSrcIdx !== i) {
        const moved = fields.splice(dragSrcIdx, 1)[0];
        fields.splice(i, 0, moved);
        dragSrcIdx = null;
        renderCanvas();
      }
    });

    canvas.appendChild(div);
  });

  renderPreview();
  saveJson();
}

// ── Select field ─────────────────────────────────────────────
function selectField(id) {
  selectedId = id;
  const f = fields.find(x => x.id === id);
  if (!f) return;
  editorEl.style.display = '';
  document.getElementById('ef-label').value       = f.label;
  document.getElementById('ef-key').value         = f.key;
  document.getElementById('ef-placeholder').value = f.placeholder || '';
  document.getElementById('ef-required').checked  = !!f.required;
  const needsOpts = ['select','radio','checkbox'].includes(f.type);
  document.getElementById('ef-options-group').style.display = needsOpts ? '' : 'none';
  document.getElementById('ef-options').value = (f.options || []).join('\n');
  renderCanvas();
}

function closeEditor() { editorEl.style.display = 'none'; selectedId = null; renderCanvas(); }

// ── Sync editor → field ──────────────────────────────────────
function syncField() {
  const f = fields.find(x => x.id === selectedId); if (!f) return;
  f.label       = document.getElementById('ef-label').value;
  f.key         = document.getElementById('ef-key').value || slugify(f.label);
  f.placeholder = document.getElementById('ef-placeholder').value;
  f.required    = document.getElementById('ef-required').checked;
  f.options     = document.getElementById('ef-options').value.split('\n').map(s => s.trim()).filter(Boolean);
  renderCanvas();
}

// ── Move / delete ────────────────────────────────────────────
function moveField(id, dir) {
  const i = fields.findIndex(x => x.id === id);
  if (i + dir < 0 || i + dir >= fields.length) return;
  [fields[i], fields[i+dir]] = [fields[i+dir], fields[i]];
  renderCanvas();
}
function deleteField(id) {
  fields = fields.filter(x => x.id !== id);
  if (selectedId === id) { selectedId = null; editorEl.style.display = 'none'; }
  renderCanvas();
}
function deleteSelectedField() { if (selectedId) deleteField(selectedId); }

// ── Live preview ─────────────────────────────────────────────
function renderPreview() {
  const container = document.getElementById('previewFields');
  container.innerHTML = '';
  fields.forEach(f => {
    if (f.type === 'hidden') return;
    const wrap  = document.createElement('div');
    wrap.className = 'fp-field';
    const label = document.createElement('label');
    label.className = 'fp-label';
    label.textContent = f.label + (f.required ? ' *' : '');
    wrap.appendChild(label);
    let input;
    if (f.type === 'textarea') {
      input = document.createElement('textarea');
      input.className = 'fp-input';
      input.placeholder = f.placeholder || '';
      input.disabled = true;
    } else if (['select','radio','checkbox'].includes(f.type)) {
      input = document.createElement('select');
      input.className = 'fp-input';
      input.disabled = true;
      (f.options || []).forEach(o => {
        const opt = document.createElement('option');
        opt.textContent = o;
        input.appendChild(opt);
      });
    } else {
      input = document.createElement('input');
      input.className = 'fp-input';
      input.type = f.type === 'email' ? 'email' : f.type === 'phone' ? 'tel' : f.type === 'number' ? 'number' : 'text';
      input.placeholder = f.placeholder || '';
      input.disabled = true;
    }
    wrap.appendChild(input);
    container.appendChild(wrap);
  });
}

// ── Save JSON ────────────────────────────────────────────────
function saveJson() { document.getElementById('fieldsJson').value = JSON.stringify(fields); }
document.getElementById('builderForm').addEventListener('submit', saveJson);

// ── HTML escape ──────────────────────────────────────────────
function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ── Init ─────────────────────────────────────────────────────
renderCanvas();
if (fields.length) selectField(fields[0].id);

// ── Email template accordion ────────────────────────────────
function toggleTpl(type) {
  var panel = document.getElementById('tpl_panel_' + type);
  var arrow = document.getElementById('tpl_arrow_' + type);
  if (!panel) return;
  var open = panel.style.display !== 'none';
  panel.style.display = open ? 'none'  : 'block';
  arrow.textContent   = open ? '\u25bc' : '\u25b2';
}
</script>

<?php include __DIR__ . '/layouts/footer.php'; ?>
