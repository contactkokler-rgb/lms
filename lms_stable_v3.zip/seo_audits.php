<?php
require_once __DIR__ . '/config/auth.php';
$user = require_permission('auditor', 'run');
if (!is_super_admin() && ($user['role_id'] ?? 0) > 2) {
    header('Location: ' . APP_URL . '/index.php'); exit;
}

$account_id = (int)($user['account_id'] ?? 0);
$page_title = 'SEO Audit History';
$active_nav = 'seo_auditor';

// ── Handle delete ──────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    if (!csrf_verify()) { http_response_code(403); die('CSRF'); }
    $del_id = (int)($_POST['id'] ?? 0);
    db_query('DELETE FROM seo_audits WHERE id=? AND account_id=?', 'ii', $del_id, $account_id);
    $_SESSION['flash'] = ['type'=>'success','msg'=>'Audit deleted.'];
    header('Location: ' . APP_URL . '/seo_audits.php'); exit;
}

// ── Check table exists ─────────────────────────────────────────
$db_sa = db();
if ($db_sa->query("SHOW TABLES LIKE 'seo_audits'")->num_rows === 0) {
    $_SESSION['flash'] = ['type'=>'error','msg'=>'Run install_auditor.sql first.'];
    header('Location: ' . APP_URL . '/seo_auditor.php'); exit;
}

// ── Single audit view ──────────────────────────────────────────
$view_id    = (int)($_GET['id'] ?? 0);
$view_audit = null;
$view_data  = [];

if ($view_id) {
    // Detect which optional columns exist (safe against old schema missing public_token/emailed_at)
    $_cols      = db_fetch_all("SHOW COLUMNS FROM seo_audits");
    $_col_names = array_column($_cols, 'Field');
    $_has_token = in_array('public_token', $_col_names, true);
    $_has_email = in_array('emailed_at',   $_col_names, true);

    $_select = 'SELECT id, url, score_overall, result_json, created_at'
        . ($_has_token ? ', public_token' : ", '' AS public_token")
        . ($_has_email ? ', emailed_at'   : ', NULL AS emailed_at');

    $view_audit = db_fetch(
        "$_select FROM seo_audits WHERE id=? AND account_id=?",
        'ii', $view_id, $account_id
    );
    if ($view_audit) {
        $view_data = json_decode($view_audit['result_json'] ?? '{}', true);
        if (!is_array($view_data)) $view_data = [];
    }
}

// ── List with pagination ───────────────────────────────────────
$page   = max(1, (int)($_GET['p'] ?? 1));
$per    = 20;
$offset = ($page - 1) * $per;
$total  = (int)(db_fetch('SELECT COUNT(*) AS n FROM seo_audits WHERE account_id=?', 'i', $account_id)['n'] ?? 0);
$audits = db_fetch_all(
    'SELECT id, url, score_overall, created_at FROM seo_audits
     WHERE account_id=? ORDER BY id DESC LIMIT ? OFFSET ?',
    'iii', $account_id, $per, $offset
);

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
include __DIR__ . '/layouts/header.php';
?>

<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type']==='success'?'success':'danger' ?>" style="margin-bottom:16px;"><?= h($flash['msg']) ?></div>
<?php endif; ?>

<?php if ($view_audit): ?>
<!-- ════════════════════════════════════════════════
     SINGLE AUDIT VIEW
     ════════════════════════════════════════════════ -->
<?php
$scores  = $view_data['scores']     ?? [];
$overall = (int)($scores['overall'] ?? $view_audit['score_overall'] ?? 0);
$col     = $overall >= 70 ? '#16a34a' : ($overall >= 40 ? '#f59e0b' : '#ef4444');
$ai      = $view_data['ai_summary'] ?? [];
$issues  = $view_data['issues']     ?? [];
$hl      = $view_data['highlights'] ?? [];
$modules = $view_data['modules']    ?? [];
$has_data = !empty($view_data);
?>

<div class="page-header" style="margin-bottom:20px;">
    <div>
        <div class="page-title"><i class="hgi hgi-stroke hgi-search-visual"></i> Audit Report</div>
        <div class="page-subtitle" style="word-break:break-all;"><?= h($view_audit['url']) ?></div>
    </div>
    <div class="flex gap-2">
        <a href="<?= APP_URL ?>/seo_audits.php" class="btn btn-outline btn-sm">← History</a>
        <a href="<?= APP_URL ?>/seo_auditor.php" class="btn btn-outline btn-sm">New Audit</a>
        <?php if (!empty($view_audit['public_token'])): ?>
        <button type="button" class="btn btn-outline btn-sm" id="btn-copy-link"
                data-url="<?= h(APP_URL . '/seo_report.php?token=' . urlencode($view_audit['public_token'])) ?>">
            <i class="hgi hgi-stroke hgi-link-01"></i> Copy Link
        </button>
        <button type="button" class="btn btn-primary btn-sm" id="btn-email-report">
            <i class="hgi hgi-stroke hgi-mail-01"></i> Email Report
        </button>
        <?php endif; ?>
        <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this audit?')">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int)$view_audit['id'] ?>">
            <button class="btn btn-danger btn-sm btn-icon"><i class="hgi hgi-stroke hgi-delete-02"></i></button>
        </form>
    </div>
</div>

<?php if (!$has_data): ?>
<!-- result_json missing — schema was updated, re-run needed -->
<div class="alert alert-warning" style="margin-bottom:16px;">
    <i class="hgi hgi-stroke hgi-alert-02"></i>
    Full report data is not available for this audit (it was run before the schema was updated).
    <a href="<?= APP_URL ?>/seo_auditor.php?prefill=<?= urlencode($view_audit['url'] ?? '') ?>" style="font-weight:600;margin-left:8px;">Re-run this URL →</a>
</div>
<?php endif; ?>

<!-- Score row — always shown if we have the audit record -->
<div class="card" style="margin-bottom:16px;">
    <div class="card-body" style="padding:20px;">
        <div style="display:flex;gap:28px;flex-wrap:wrap;align-items:center;">
            <div style="text-align:center;">
                <div style="font-size:3.2rem;font-weight:900;color:<?= $col ?>;"><?= $overall ?></div>
                <div style="font-size:.68rem;color:#94a3b8;text-transform:uppercase;letter-spacing:.06em;">Overall</div>
            </div>
            <?php foreach ($scores as $k => $v): if ($k === 'overall') continue;
              $sc2 = (int)$v; $c2 = $sc2>=70?'#16a34a':($sc2>=40?'#f59e0b':'#ef4444'); ?>
            <div style="text-align:center;">
                <div style="font-size:1.8rem;font-weight:800;color:<?= $c2 ?>;"><?= $sc2 ?></div>
                <div style="font-size:.65rem;color:#94a3b8;text-transform:uppercase;letter-spacing:.04em;"><?= h(str_replace('_',' ',$k)) ?></div>
            </div>
            <?php endforeach; ?>
            <div style="margin-left:auto;text-align:right;">
                <div style="font-size:.72rem;color:var(--gray-400);">Audited</div>
                <div style="font-size:.8rem;font-weight:600;"><?= format_dt($view_audit['created_at'],'d M Y, g:ia') ?></div>
            </div>
        </div>
    </div>
</div>

<?php if ($has_data): ?>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">

    <!-- AI Summary -->
    <?php if (!empty($ai['strategic_summary'])): ?>
    <div class="card" style="grid-column:1/-1;">
        <div class="card-header">
            <div class="card-title"><i class="hgi hgi-stroke hgi-ai-brain-05"></i> AI Strategic Analysis</div>
        </div>
        <div class="card-body">
            <p style="font-size:.84rem;line-height:1.75;color:var(--gray-600);margin-bottom:12px;"><?= h($ai['strategic_summary']) ?></p>
            <?php if (!empty($ai['top_opportunities'])): ?>
            <div style="font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--gray-400);margin-bottom:8px;">Top Opportunities</div>
            <?php foreach ($ai['top_opportunities'] as $op): ?>
            <div style="padding:6px 0;border-bottom:1px solid var(--gray-100);font-size:.81rem;color:var(--gray-600);">→ <?= h($op) ?></div>
            <?php endforeach; ?>
            <?php endif; ?>
            <?php if (!empty($ai['quick_wins'])): ?>
            <div style="font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--gray-400);margin:12px 0 8px;">Quick Wins</div>
            <?php foreach ($ai['quick_wins'] as $qw): ?>
            <div style="padding:5px 0;border-bottom:1px solid var(--gray-100);font-size:.8rem;color:var(--gray-600);">✓ <?= h($qw) ?></div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Issues -->
    <?php if ($issues):
      $crits = array_filter($issues, fn($i) => ($i['severity']??'') === 'critical');
      $warns = array_filter($issues, fn($i) => ($i['severity']??'') === 'warning');
      $infos = array_filter($issues, fn($i) => !in_array($i['severity']??'',['critical','warning']));
    ?>
    <div class="card" style="grid-column:1/-1;">
        <div class="card-header">
            <div class="card-title">Issues (<?= count($issues) ?>)</div>
            <div class="flex gap-2">
                <?php if ($crits): ?><span class="badge badge-danger badge-sm"><?= count($crits) ?> critical</span><?php endif; ?>
                <?php if ($warns): ?><span class="badge badge-warning badge-sm"><?= count($warns) ?> warning</span><?php endif; ?>
                <?php if ($infos): ?><span class="badge badge-default badge-sm"><?= count($infos) ?> info</span><?php endif; ?>
            </div>
        </div>
        <div class="card-body">
            <?php foreach ([['critical','#ef4444',$crits],['warning','#f59e0b',$warns],['info','#3b82f6',$infos]] as [$sev,$ic,$grp]):
              if (!$grp) continue; ?>
            <div style="font-size:.68rem;font-weight:700;color:<?= $ic ?>;text-transform:uppercase;letter-spacing:.06em;margin:10px 0 6px;"><?= $sev ?> (<?= count($grp) ?>)</div>
            <?php foreach ($grp as $issue): ?>
            <div style="padding:8px 10px;background:<?= $ic ?>11;border:1px solid <?= $ic ?>33;border-radius:7px;margin-bottom:6px;">
                <div style="font-size:.8rem;font-weight:600;"><?= h($issue['title'] ?? $issue['check'] ?? '') ?></div>
                <?php if ($issue['detail'] ?? ''): ?><div style="font-size:.75rem;color:var(--gray-500);margin-top:3px;"><?= h($issue['detail']) ?></div><?php endif; ?>
                <?php if ($issue['fix_guidance'] ?? ''): ?><div style="font-size:.73rem;color:#16a34a;margin-top:4px;">💡 <?= h($issue['fix_guidance']) ?></div><?php endif; ?>
            </div>
            <?php endforeach; ?>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Highlights -->
    <?php if ($hl): ?>
    <div class="card">
        <div class="card-header"><div class="card-title">Page Highlights</div></div>
        <div class="card-body" style="padding:0 16px;">
            <?php foreach ($hl as $k => $v):
              if (!$v) continue;
              $disp = is_array($v) ? implode(', ', $v) : (string)$v;
              $disp = mb_substr($disp, 0, 200);
            ?>
            <div style="display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--gray-100);font-size:.78rem;gap:10px;">
                <span style="color:var(--gray-400);flex-shrink:0;"><?= h(str_replace('_',' ',$k)) ?></span>
                <span style="color:var(--gray-700);font-weight:500;text-align:right;word-break:break-word;"><?= h($disp) ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Module summaries -->
    <?php foreach (['analytics'=>'Analytics','competitor'=>'Competitor','ecommerce'=>'Ecommerce','chatbot'=>'Chatbot & Lead Capture'] as $mk => $ml):
      $mod = $modules[$mk] ?? null;
      if (!$mod) continue;
      $mod_score = (int)($mod['score'] ?? 0);
      $mc = $mod_score>=70?'#16a34a':($mod_score>=40?'#f59e0b':'#ef4444');
    ?>
    <div class="card">
        <div class="card-header">
            <div class="card-title"><?= $ml ?></div>
            <?php if ($mod_score): ?>
            <span class="badge badge-sm" style="background:<?= $mc ?>22;color:<?= $mc ?>;border:1px solid <?= $mc ?>44;"><?= $mod_score ?>/100</span>
            <?php endif; ?>
        </div>
        <div class="card-body" style="font-size:.78rem;color:var(--gray-600);">
            <?php if ($mod['summary'] ?? ''): ?><p style="margin-bottom:8px;line-height:1.6;"><?= h($mod['summary']) ?></p><?php endif; ?>
            <?php foreach (['recommendations'=>'→','gaps'=>'!','strengths'=>'✓'] as $listKey => $prefix):
              if (empty($mod[$listKey])) continue; ?>
            <div style="margin-top:6px;">
                <?php foreach (array_slice((array)$mod[$listKey], 0, 4) as $item): ?>
                <div style="padding:3px 0;border-bottom:1px solid var(--gray-100);"><?= $prefix ?> <?= h(is_array($item) ? ($item['text']??json_encode($item)) : $item) ?></div>
                <?php endforeach; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endforeach; ?>

</div>
<?php endif; // $has_data ?>

<?php else: ?>
<!-- ════════════════════════════════════════════════
     AUDIT LIST
     ════════════════════════════════════════════════ -->
<div class="page-header" style="margin-bottom:20px;">
    <div>
        <div class="page-title"><i class="hgi hgi-stroke hgi-clock-01"></i> Audit History</div>
        <div class="page-subtitle"><?= $total ?> audit<?= $total !== 1 ? 's' : '' ?> saved</div>
    </div>
    <a href="<?= APP_URL ?>/seo_auditor.php" class="btn btn-primary btn-sm">
        <i class="hgi hgi-stroke hgi-plus-sign"></i> New Audit
    </a>
</div>

<?php if ($audits): ?>
<div class="card">
    <table class="table">
        <thead>
            <tr>
                <th>URL</th>
                <th style="width:80px;text-align:center;">Score</th>
                <th style="width:140px;">Date</th>
                <th style="width:80px;"></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($audits as $a):
              $s   = (int)$a['score_overall'];
              $sc  = $s >= 70 ? 'badge-success' : ($s >= 40 ? 'badge-warning' : 'badge-danger');
              $url = $a['url'] ?? '';
              $host = $url ? (parse_url($url, PHP_URL_HOST) ?: $url) : '(unknown)';
            ?>
            <tr>
                <td>
                    <div style="font-size:.82rem;font-weight:600;word-break:break-all;"><?= h($url ?: '(no URL — re-run audit)') ?></div>
                    <div style="font-size:.7rem;color:var(--gray-400);"><?= h($host) ?></div>
                </td>
                <td style="text-align:center;">
                    <span class="badge <?= $sc ?>"><?= $s ?>/100</span>
                </td>
                <td style="font-size:.78rem;color:var(--gray-500);"><?= format_dt($a['created_at'],'d M Y, H:i') ?></td>
                <td>
                    <div class="flex gap-1" style="justify-content:flex-end;">
                        <a href="<?= APP_URL ?>/seo_audits.php?id=<?= (int)$a['id'] ?>" class="btn btn-outline btn-sm btn-icon" title="View">
                            <i class="hgi hgi-stroke hgi-eye"></i>
                        </a>
                        <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this audit?')">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                            <button class="btn btn-danger btn-sm btn-icon"><i class="hgi hgi-stroke hgi-delete-02"></i></button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php if ($total > $per): ?>
<div style="display:flex;gap:8px;justify-content:center;margin-top:16px;">
    <?php for ($i=1; $i<=ceil($total/$per); $i++): ?>
    <a href="<?= APP_URL ?>/seo_audits.php?p=<?= $i ?>" class="btn btn-sm <?= $i===$page?'btn-primary':'btn-outline' ?>"><?= $i ?></a>
    <?php endfor; ?>
</div>
<?php endif; ?>

<?php else: ?>
<div class="empty-state">
    <div class="empty-state-icon"><i class="hgi hgi-stroke hgi-search-visual"></i></div>
    <div class="empty-state-title">No audits yet</div>
    <div class="empty-state-desc">Run your first audit to see results saved here.</div>
    <a href="<?= APP_URL ?>/seo_auditor.php" class="btn btn-primary"><i class="hgi hgi-stroke hgi-plus-sign"></i> Run Audit</a>
</div>
<?php endif; ?>
<?php endif; // end list vs single view ?>

<?php if ($view_audit && !empty($view_audit['public_token'])): ?>
<!-- ── Email Report Modal ─────────────────────────────────────── -->
<div id="email-modal-overlay" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:1050;align-items:center;justify-content:center;">
  <div style="background:#fff;border-radius:14px;width:100%;max-width:460px;box-shadow:0 8px 40px rgba(0,0,0,.18);margin:16px;">
    <div style="padding:20px 24px;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;">
      <div style="font-weight:700;font-size:15px;"><i class="hgi hgi-stroke hgi-mail-01"></i> Email Audit Report</div>
      <button id="email-modal-close" style="background:none;border:none;cursor:pointer;font-size:20px;color:#94a3b8;line-height:1;">&times;</button>
    </div>
    <div style="padding:20px 24px;">
      <div style="margin-bottom:14px;">
        <label style="font-size:12px;font-weight:600;color:#475569;display:block;margin-bottom:5px;">Client Email <span style="color:#ef4444">*</span></label>
        <input type="email" id="em-email" placeholder="client@example.com"
               style="width:100%;padding:9px 12px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:14px;outline:none;">
      </div>
      <div style="margin-bottom:14px;">
        <label style="font-size:12px;font-weight:600;color:#475569;display:block;margin-bottom:5px;">Client Name <span style="font-weight:400;color:#94a3b8">(optional)</span></label>
        <input type="text" id="em-name" placeholder="Jane Smith"
               style="width:100%;padding:9px 12px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:14px;outline:none;">
      </div>
      <div style="margin-bottom:18px;">
        <label style="font-size:12px;font-weight:600;color:#475569;display:block;margin-bottom:5px;">Personal Note <span style="font-weight:400;color:#94a3b8">(optional)</span></label>
        <textarea id="em-note" rows="3" placeholder="Hi! Here's the SEO audit I ran for your site…"
                  style="width:100%;padding:9px 12px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:14px;resize:vertical;outline:none;font-family:inherit;"></textarea>
      </div>
      <div style="background:#f8fafc;border:1.5px solid #e2e8f0;border-radius:8px;padding:10px 14px;font-size:12px;color:#64748b;margin-bottom:18px;">
        <strong>Public report link:</strong><br>
        <span style="word-break:break-all;color:#6366f1;"><?= h(APP_URL . '/seo_report.php?token=' . urlencode($view_audit['public_token'])) ?></span>
      </div>
      <div id="em-error" style="display:none;background:#fee2e2;color:#dc2626;padding:8px 12px;border-radius:7px;font-size:13px;margin-bottom:12px;"></div>
      <div id="em-success" style="display:none;background:#dcfce7;color:#16a34a;padding:8px 12px;border-radius:7px;font-size:13px;margin-bottom:12px;"></div>
      <div style="display:flex;gap:8px;justify-content:flex-end;">
        <button id="em-cancel" class="btn btn-outline btn-sm">Cancel</button>
        <button id="em-send" class="btn btn-primary btn-sm">
          <i class="hgi hgi-stroke hgi-mail-send-01"></i> Send Report
        </button>
      </div>
    </div>
  </div>
</div>
<script>
(function () {
  var overlay   = document.getElementById('email-modal-overlay');
  var btnOpen   = document.getElementById('btn-email-report');
  var btnClose  = document.getElementById('email-modal-close');
  var btnCancel = document.getElementById('em-cancel');
  var btnSend   = document.getElementById('em-send');
  var errBox    = document.getElementById('em-error');
  var okBox     = document.getElementById('em-success');
  var copyBtn   = document.getElementById('btn-copy-link');

  function openModal()  { overlay.style.display = 'flex'; errBox.style.display='none'; okBox.style.display='none'; }
  function closeModal() { overlay.style.display = 'none'; }

  if (btnOpen)   btnOpen.addEventListener('click', openModal);
  if (btnClose)  btnClose.addEventListener('click', closeModal);
  if (btnCancel) btnCancel.addEventListener('click', closeModal);
  overlay.addEventListener('click', function(e){ if(e.target===overlay) closeModal(); });

  if (copyBtn) {
    copyBtn.addEventListener('click', function () {
      var url = copyBtn.getAttribute('data-url');
      navigator.clipboard.writeText(url).then(function () {
        var orig = copyBtn.innerHTML;
        copyBtn.innerHTML = '<i class="hgi hgi-stroke hgi-check-01"></i> Copied!';
        setTimeout(function(){ copyBtn.innerHTML = orig; }, 2000);
      }).catch(function() {
        var ta = document.createElement('textarea');
        ta.value = url; document.body.appendChild(ta); ta.select();
        document.execCommand('copy'); document.body.removeChild(ta);
      });
    });
  }

  if (btnSend) {
    btnSend.addEventListener('click', function () {
      var email = document.getElementById('em-email').value.trim();
      var name  = document.getElementById('em-name').value.trim();
      var note  = document.getElementById('em-note').value.trim();
      errBox.style.display = 'none'; okBox.style.display = 'none';
      if (!email) { errBox.textContent = 'Please enter a client email address.'; errBox.style.display = 'block'; return; }
      btnSend.disabled = true;
      btnSend.innerHTML = 'Sending\u2026';
      var csrf = (document.querySelector('meta[name="csrf-token"]') || {}).content || '';
      var fd = new FormData();
      fd.append('audit_id', '<?= (int)($view_audit['id'] ?? 0) ?>');
      fd.append('to_email', email);
      fd.append('to_name',  name);
      fd.append('note',     note);
      fetch('<?= APP_URL ?>/auditor/email_report.php', {
        method: 'POST', body: fd, credentials: 'same-origin',
        headers: { 'X-CSRF-Token': csrf }
      })
      .then(function(r) { return r.json(); })
      .then(function(res) {
        if (res.success) {
          okBox.textContent = '\u2713 Report sent to ' + email;
          okBox.style.display = 'block';
          btnSend.innerHTML = 'Sent!';
          setTimeout(closeModal, 2200);
        } else {
          errBox.textContent = res.error || 'Failed to send.';
          errBox.style.display = 'block';
          btnSend.disabled = false;
          btnSend.innerHTML = '<i class="hgi hgi-stroke hgi-mail-send-01"></i> Send Report';
        }
      })
      .catch(function() {
        errBox.textContent = 'Network error. Please try again.';
        errBox.style.display = 'block';
        btnSend.disabled = false;
        btnSend.innerHTML = '<i class="hgi hgi-stroke hgi-mail-send-01"></i> Send Report';
      });
    });
  }
})();
</script>
<?php endif; ?>

<?php include __DIR__ . '/layouts/footer.php'; ?>