<?php
set_exception_handler(function($e) {
    error_log('[LeadPro reports] ' . $e->getMessage() . ' ' . $e->getFile() . ':' . $e->getLine());
    http_response_code(500);
    echo '<div style="font-family:sans-serif;padding:40px;color:#dc2626"><b>Analytics error:</b> '
        . htmlspecialchars($e->getMessage()) . '</div>';
    exit;
});

require_once __DIR__ . '/config/auth.php';
$user       = require_permission('reports', 'view');
$account_id = (int)($user['account_id'] ?? 0);
$is_super   = is_super_admin();
$role       = $user['role_name'] ?? 'agent';

$page_title = 'Analytics';
$active_nav = 'reports';

// ── Role capability flags ─────────────────────────────────────
// account_owner / super_admin : full access + domain + form filter
// manager                     : all forms in account, no domain filter
// agent                       : ONLY their assigned leads
$can_filter_domain = ($is_super || $role === 'account_owner');
$can_see_all_leads = ($is_super || in_array($role, ['account_owner', 'manager']));
$agent_scope       = !$can_see_all_leads; // restrict to assigned_to = user id

// ── URL params ────────────────────────────────────────────────
$tab      = $_GET['tab']       ?? 'overview';
$range    = $_GET['range']     ?? '30';
$f_domain = $can_filter_domain ? (int)($_GET['domain_id'] ?? 0) : 0;
$f_form   = (int)($_GET['form_id'] ?? 0);

// Date range
$range_days = ['7'=>7,'30'=>30,'90'=>90,'year'=>365];
$days        = $range_days[$range] ?? 30;
$date_to     = date('Y-m-d');
$date_from   = date('Y-m-d', strtotime("-{$days} days"));
$prev_from   = date('Y-m-d', strtotime("-" . ($days * 2) . " days"));
$prev_to     = date('Y-m-d', strtotime("-{$days} days -1 day"));

// ── Base WHERE builder (parameterised, no string interpolation) ─
// Returns [sql_fragment, bind_types_string, params_array]
// NOTE: does NOT include date range — callers add that themselves
function base_scope(bool $is_super, int $account_id, int $f_domain, int $f_form,
                    bool $agent_scope, int $user_id): array {
    $parts  = ["(l.is_deleted IS NULL OR l.is_deleted = 0)"];
    $types  = '';
    $params = [];

    if (!$is_super) {
        $parts[]  = 'l.account_id = ?';
        $types   .= 'i';
        $params[] = $account_id;
    }
    if ($agent_scope) {
        $parts[]  = 'l.assigned_to = ?';
        $types   .= 'i';
        $params[] = $user_id;
    }
    if ($f_domain > 0) {
        $parts[]  = 'l.domain_id = ?';
        $types   .= 'i';
        $params[] = $f_domain;
    }
    if ($f_form > 0) {
        $parts[]  = 'l.form_id = ?';
        $types   .= 'i';
        $params[] = $f_form;
    }
    return ['WHERE ' . implode(' AND ', $parts), $types, $params];
}

[$base_w, $base_t, $base_p] = base_scope(
    $is_super, $account_id, $f_domain, $f_form, $agent_scope, (int)$user['id']
);

// Helpers to merge date range into scope
function with_dates(string $w, string $t, array $p, string $from, string $to): array {
    return [$w . ' AND DATE(l.submitted_at) BETWEEN ? AND ?', $t . 'ss', array_merge($p, [$from, $to])];
}

[$dw, $dt, $dp]        = with_dates($base_w, $base_t, $base_p, $date_from, $date_to);
[$pw_w, $pw_t, $pw_p]  = with_dates($base_w, $base_t, $base_p, $prev_from, $prev_to);

// ── Filter dropdowns ──────────────────────────────────────────
$domain_opts = [];
$form_opts   = [];

if ($can_filter_domain) {
    $domain_opts = $is_super
        ? db_fetch_all('SELECT id, domain FROM domains WHERE is_active=1 ORDER BY domain')
        : db_fetch_all('SELECT id, domain FROM domains WHERE account_id=? AND is_active=1 ORDER BY domain', 'i', $account_id);
}

if ($f_domain > 0) {
    $form_opts = db_fetch_all('SELECT id, name FROM lead_forms WHERE domain_id=? AND is_active=1 ORDER BY name', 'i', $f_domain);
} elseif (!$agent_scope) {
    $form_opts = $is_super
        ? db_fetch_all('SELECT id, name FROM lead_forms WHERE is_active=1 ORDER BY name LIMIT 60')
        : db_fetch_all('SELECT id, name FROM lead_forms WHERE account_id=? AND is_active=1 ORDER BY name LIMIT 60', 'i', $account_id);
}

// ══════════════════════════════════════════════════════════════
//  DATA QUERIES — grouped by tab
// ══════════════════════════════════════════════════════════════

// ─── OVERVIEW ────────────────────────────────────────────────
$summary = db_fetch(
    "SELECT
        COUNT(*)                          AS total,
        SUM(status='new')                 AS new_l,
        SUM(status='contacted')           AS contacted,
        SUM(status='qualified')           AS qualified,
        SUM(status='converted')           AS converted,
        SUM(status='lost')                AS lost,
        SUM(status='spam')                AS spam,
        ROUND(AVG(COALESCE(score,0)),1)   AS avg_score,
        SUM(COALESCE(score,0) >= 70)      AS hot,
        SUM(COALESCE(score,0) BETWEEN 35 AND 69) AS warm,
        SUM(COALESCE(score,0) < 35 AND COALESCE(score,0) > 0) AS cold,
        SUM(score IS NULL OR score = 0)   AS unscored
     FROM leads l $dw", $dt, ...$dp
) ?? [];

$prev_summary = db_fetch(
    "SELECT COUNT(*) AS total, SUM(status='converted') AS converted
     FROM leads l $pw_w", $pw_t, ...$pw_p
) ?? [];

// Leads over time — daily
$daily_rows = db_fetch_all(
    "SELECT DATE(submitted_at) AS day,
            COUNT(*) AS n,
            SUM(status='converted') AS conv,
            SUM(status='qualified') AS qual
     FROM leads l $dw GROUP BY DATE(submitted_at) ORDER BY day",
    $dt, ...$dp
);
$daily_idx = [];
foreach ($daily_rows as $r) $daily_idx[$r['day']] = $r;
$daily_full = [];
for ($c = strtotime($date_from); $c <= strtotime($date_to); $c = strtotime('+1 day', $c)) {
    $day = date('Y-m-d', $c);
    $daily_full[] = [
        'day'  => $day,
        'n'    => (int)($daily_idx[$day]['n']    ?? 0),
        'conv' => (int)($daily_idx[$day]['conv'] ?? 0),
        'qual' => (int)($daily_idx[$day]['qual'] ?? 0),
    ];
}

// Status breakdown
$by_status = db_fetch_all(
    "SELECT status, COUNT(*) AS n FROM leads l $dw GROUP BY status ORDER BY n DESC",
    $dt, ...$dp
);

// Score distribution
$score_dist = db_fetch(
    "SELECT SUM(COALESCE(score,0)>=70) AS hot,
            SUM(COALESCE(score,0) BETWEEN 35 AND 69) AS warm,
            SUM(COALESCE(score,0)<35 AND COALESCE(score,0)>0) AS cold,
            SUM(score IS NULL OR score=0) AS unscored
     FROM leads l $dw", $dt, ...$dp
) ?? [];

// Heatmap hour×dow
$hm_rows = db_fetch_all(
    "SELECT HOUR(submitted_at) AS hr, DAYOFWEEK(submitted_at)-1 AS dow, COUNT(*) AS n
     FROM leads l $dw GROUP BY hr, dow",
    $dt, ...$dp
);
$heatmap = [];
for ($d = 0; $d < 7; $d++) for ($h = 0; $h < 24; $h++) $heatmap[$d][$h] = 0;
foreach ($hm_rows as $r) $heatmap[(int)$r['dow']][(int)$r['hr']] = (int)$r['n'];

// Domain comparison
$by_domain = db_fetch_all(
    "SELECT d.domain, COUNT(*) AS n, SUM(l.status='converted') AS conv,
            ROUND(SUM(l.status='converted')/COUNT(*)*100,1) AS rate
     FROM leads l JOIN domains d ON d.id=l.domain_id $dw
     GROUP BY l.domain_id ORDER BY n DESC LIMIT 10",
    $dt, ...$dp
);

// Top forms
$by_form = db_fetch_all(
    "SELECT f.name AS form_name, COUNT(*) AS n,
            SUM(l.status='converted') AS conv,
            ROUND(AVG(COALESCE(l.score,0)),0) AS avg_score
     FROM leads l JOIN lead_forms f ON f.id=l.form_id $dw
     GROUP BY l.form_id ORDER BY n DESC LIMIT 10",
    $dt, ...$dp
);

// Campaign perf overview
$campaigns_ov = db_fetch_all(
    "SELECT COALESCE(NULLIF(utm_campaign,''),'(none)') AS campaign,
            COALESCE(NULLIF(utm_source,''),'(direct)') AS source,
            COUNT(*) AS n,
            SUM(status='converted') AS conv,
            ROUND(SUM(status='converted')/COUNT(*)*100,1) AS rate,
            ROUND(AVG(COALESCE(score,0)),0) AS avg_score
     FROM leads l $dw
     GROUP BY utm_campaign, utm_source ORDER BY n DESC LIMIT 12",
    $dt, ...$dp
);

// ─── GEO ─────────────────────────────────────────────────────
$by_country = db_fetch_all(
    "SELECT COALESCE(NULLIF(country,''),'Unknown') AS country,
            COUNT(*) AS n, SUM(status='converted') AS conv
     FROM leads l $dw GROUP BY country ORDER BY n DESC LIMIT 40",
    $dt, ...$dp
);

$by_device = db_fetch_all(
    "SELECT COALESCE(device_type,'unknown') AS device, COUNT(*) AS n
     FROM leads l $dw GROUP BY device ORDER BY n DESC",
    $dt, ...$dp
);

$by_browser = db_fetch_all(
    "SELECT COALESCE(NULLIF(browser,''),'Other') AS browser, COUNT(*) AS n
     FROM leads l $dw GROUP BY browser ORDER BY n DESC LIMIT 8",
    $dt, ...$dp
);

// ─── BEHAVIORAL ───────────────────────────────────────────────
// Avg response time = submitted_at → first comment
$resp_time = db_fetch(
    "SELECT ROUND(AVG(TIMESTAMPDIFF(MINUTE, l.submitted_at, fc.first_at)/60),1) AS avg_hrs,
            ROUND(MIN(TIMESTAMPDIFF(MINUTE, l.submitted_at, fc.first_at)/60),1) AS min_hrs,
            ROUND(MAX(TIMESTAMPDIFF(MINUTE, l.submitted_at, fc.first_at)/60),1) AS max_hrs
     FROM leads l
     JOIN (SELECT lead_id, MIN(created_at) AS first_at
           FROM lead_comments WHERE user_id IS NOT NULL GROUP BY lead_id) fc
       ON fc.lead_id = l.id
     $dw AND l.status != 'spam'",
    $dt, ...$dp
) ?? [];

// Avg close time = submitted_at → updated_at for converted
$close_time = db_fetch(
    "SELECT ROUND(AVG(TIMESTAMPDIFF(HOUR, submitted_at, updated_at)),1) AS avg_hrs
     FROM leads l $dw AND status='converted'",
    $dt, ...$dp
) ?? [];

// Stage funnel
$funnel = db_fetch(
    "SELECT COUNT(*) AS total,
            SUM(status IN ('contacted','qualified','converted','lost')) AS s_contacted,
            SUM(status IN ('qualified','converted','lost'))             AS s_qualified,
            SUM(status = 'converted')                                  AS s_converted
     FROM leads l $dw AND status != 'spam'",
    $dt, ...$dp
) ?? [];

// Agent performance
$agent_perf = db_fetch_all(
    "SELECT CONCAT(u.first_name,' ',u.last_name) AS agent,
            u.id AS uid,
            COUNT(*) AS assigned,
            SUM(l.status='converted') AS conv,
            SUM(l.status='qualified') AS qual,
            SUM(l.status='new')       AS still_new,
            SUM(l.status='lost')      AS lost,
            ROUND(SUM(l.status='converted')/COUNT(*)*100,1) AS rate,
            ROUND(AVG(COALESCE(l.score,0)),0) AS avg_score,
            ROUND(AVG(CASE WHEN l.status='converted'
                THEN TIMESTAMPDIFF(HOUR,l.submitted_at,l.updated_at) END),1) AS avg_close_h
     FROM leads l JOIN users u ON u.id=l.assigned_to
     $dw AND l.assigned_to IS NOT NULL
     GROUP BY l.assigned_to ORDER BY conv DESC LIMIT 15",
    $dt, ...$dp
);

// Weekly trend for behavioral
$weekly = db_fetch_all(
    "SELECT YEARWEEK(submitted_at,1) AS yw, COUNT(*) AS n,
            SUM(status='converted') AS conv,
            ROUND(SUM(status='converted')/COUNT(*)*100,1) AS rate
     FROM leads l $dw GROUP BY yw ORDER BY yw",
    $dt, ...$dp
);

// ─── ATTRIBUTION ──────────────────────────────────────────────
$by_source = db_fetch_all(
    "SELECT COALESCE(NULLIF(utm_source,''),'(direct)') AS source,
            COUNT(*) AS n, SUM(status='converted') AS conv,
            ROUND(SUM(status='converted')/COUNT(*)*100,1) AS rate,
            ROUND(AVG(COALESCE(score,0)),0) AS avg_score
     FROM leads l $dw GROUP BY utm_source ORDER BY n DESC LIMIT 12",
    $dt, ...$dp
);

$by_medium = db_fetch_all(
    "SELECT COALESCE(NULLIF(utm_medium,''),'(none)') AS medium,
            COUNT(*) AS n, SUM(status='converted') AS conv,
            ROUND(SUM(status='converted')/COUNT(*)*100,1) AS rate
     FROM leads l $dw GROUP BY utm_medium ORDER BY n DESC LIMIT 10",
    $dt, ...$dp
);

$src_medium_matrix = db_fetch_all(
    "SELECT COALESCE(NULLIF(utm_source,''),'direct') AS source,
            COALESCE(NULLIF(utm_medium,''),'none') AS medium,
            COUNT(*) AS n, SUM(status='converted') AS conv
     FROM leads l $dw GROUP BY utm_source, utm_medium ORDER BY n DESC LIMIT 16",
    $dt, ...$dp
);

$paid_organic = db_fetch_all(
    "SELECT
        CASE
          WHEN LOWER(utm_medium) IN ('cpc','ppc','paid','paid_social','paid_search','ads','paidsocial') THEN 'Paid'
          WHEN LOWER(utm_medium) IN ('organic','seo') THEN 'Organic'
          WHEN LOWER(utm_medium) IN ('social','social_media','socialmedia') THEN 'Social'
          WHEN LOWER(utm_medium) IN ('email','newsletter','mail') THEN 'Email'
          WHEN LOWER(utm_medium) = 'referral' THEN 'Referral'
          WHEN utm_medium IS NULL OR utm_medium = '' THEN 'Direct'
          ELSE 'Other'
        END AS channel,
        COUNT(*) AS n, SUM(status='converted') AS conv,
        ROUND(SUM(status='converted')/COUNT(*)*100,1) AS rate
     FROM leads l $dw GROUP BY channel ORDER BY n DESC",
    $dt, ...$dp
);

$utm_full = db_fetch_all(
    "SELECT COALESCE(NULLIF(utm_campaign,''),'(none)') AS campaign,
            COALESCE(NULLIF(utm_source,''),'(direct)') AS source,
            COALESCE(NULLIF(utm_medium,''),'(none)')   AS medium,
            COUNT(*) AS n, SUM(status='converted') AS conv,
            ROUND(SUM(status='converted')/COUNT(*)*100,1) AS rate,
            ROUND(AVG(COALESCE(score,0)),0) AS avg_score
     FROM leads l $dw GROUP BY utm_campaign, utm_source, utm_medium ORDER BY n DESC LIMIT 25",
    $dt, ...$dp
);

// ─── SALES DASHBOARD ──────────────────────────────────────────
$pipeline = db_fetch(
    "SELECT COUNT(*) AS total,
            SUM(status='new')        AS new_l,
            SUM(status='contacted')  AS contacted,
            SUM(status='qualified')  AS qualified,
            SUM(status='converted')  AS won,
            SUM(status='lost')       AS lost
     FROM leads l $dw AND status != 'spam'",
    $dt, ...$dp
) ?? [];

$conv_weekly = db_fetch_all(
    "SELECT YEARWEEK(submitted_at,1) AS yw, COUNT(*) AS total,
            SUM(status='converted') AS conv,
            ROUND(SUM(status='converted')/COUNT(*)*100,1) AS rate
     FROM leads l $dw AND status != 'spam'
     GROUP BY yw ORDER BY yw",
    $dt, ...$dp
);

$top_conv_campaigns = db_fetch_all(
    "SELECT COALESCE(NULLIF(utm_campaign,''),'(direct)') AS campaign,
            COUNT(*) AS n, SUM(status='converted') AS conv,
            ROUND(SUM(status='converted')/COUNT(*)*100,1) AS rate,
            ROUND(AVG(COALESCE(score,0)),0) AS avg_score
     FROM leads l $dw AND status != 'spam'
     GROUP BY utm_campaign HAVING conv > 0 ORDER BY rate DESC LIMIT 10",
    $dt, ...$dp
);

// velocity: leads/day this vs previous period
$total       = (int)($summary['total'] ?? 0);
$prev_total  = (int)($prev_summary['total'] ?? 0);
$prev_conv   = (int)($prev_summary['converted'] ?? 0);
$leads_per_day = $days > 0 ? round($total / $days, 1) : 0;
$conv_rate   = $total > 0 ? round((int)($summary['converted']??0) / $total * 100, 1) : 0;
$prev_rate   = $prev_total > 0 ? round($prev_conv / $prev_total * 100, 1) : 0;

// ── Status colour map ─────────────────────────────────────────
$status_col = [
    'new'=>'#3b82f6','contacted'=>'#f59e0b','qualified'=>'#8b5cf6',
    'converted'=>'#22c55e','lost'=>'#94a3b8','spam'=>'#ef4444',
];

// ── Country ISO → flag + coords map ──────────────────────────
$country_meta = [
    'US'=>['🇺🇸',[37.09,-95.71]],'IN'=>['🇮🇳',[20.59,78.96]],'GB'=>['🇬🇧',[55.38,-3.44]],
    'CA'=>['🇨🇦',[56.13,-106.35]],'AU'=>['🇦🇺',[-25.27,133.78]],'DE'=>['🇩🇪',[51.17,10.45]],
    'FR'=>['🇫🇷',[46.23,2.21]],'NL'=>['🇳🇱',[52.13,5.29]],'SE'=>['🇸🇪',[60.13,18.64]],
    'NO'=>['🇳🇴',[60.47,8.47]],'BR'=>['🇧🇷',[-14.24,-51.93]],'MX'=>['🇲🇽',[23.63,-102.55]],
    'AR'=>['🇦🇷',[-38.42,-63.62]],'CO'=>['🇨🇴',[4.57,-74.30]],'NG'=>['🇳🇬',[9.08,8.68]],
    'KE'=>['🇰🇪',[-0.02,37.91]],'ZA'=>['🇿🇦',[-30.56,22.94]],'EG'=>['🇪🇬',[26.82,30.80]],
    'PK'=>['🇵🇰',[30.38,69.35]],'BD'=>['🇧🇩',[23.69,90.36]],'SG'=>['🇸🇬',[1.35,103.82]],
    'MY'=>['🇲🇾',[4.21,101.98]],'PH'=>['🇵🇭',[12.88,121.77]],'ID'=>['🇮🇩',[-0.79,113.92]],
    'TH'=>['🇹🇭',[15.87,100.99]],'VN'=>['🇻🇳',[14.06,108.28]],'JP'=>['🇯🇵',[36.20,138.25]],
    'KR'=>['🇰🇷',[35.91,127.77]],'CN'=>['🇨🇳',[35.86,104.19]],'TW'=>['🇹🇼',[23.70,120.96]],
    'HK'=>['🇭🇰',[22.40,114.11]],'AE'=>['🇦🇪',[23.42,53.85]],'SA'=>['🇸🇦',[23.89,45.08]],
    'TR'=>['🇹🇷',[38.96,35.24]],'IL'=>['🇮🇱',[31.05,34.85]],'RU'=>['🇷🇺',[61.52,105.32]],
    'UA'=>['🇺🇦',[48.38,31.17]],'PL'=>['🇵🇱',[51.92,19.15]],'RO'=>['🇷🇴',[45.94,24.97]],
    'IT'=>['🇮🇹',[41.87,12.57]],'ES'=>['🇪🇸',[40.46,-3.75]],'PT'=>['🇵🇹',[39.40,-8.22]],
    'BE'=>['🇧🇪',[50.50,4.47]],'CH'=>['🇨🇭',[46.82,8.23]],'AT'=>['🇦🇹',[47.52,14.55]],
    'NZ'=>['🇳🇿',[-40.90,174.89]],'FI'=>['🇫🇮',[61.92,25.75]],'DK'=>['🇩🇰',[56.26,9.50]],
    'IE'=>['🇮🇪',[53.41,-8.24]],'GH'=>['🇬🇭',[7.95,-1.02]],'TZ'=>['🇹🇿',[-6.37,34.89]],
    'MA'=>['🇲🇦',[31.79,-7.09]],'LK'=>['🇱🇰',[7.87,80.77]],'NP'=>['🇳🇵',[28.39,84.12]],
];

function fmt_hrs(float $h): string {
    if ($h <= 0)   return '—';
    if ($h < 1)    return round($h * 60) . 'm';
    if ($h < 48)   return number_format($h, 1) . 'h';
    return number_format($h / 24, 1) . 'd';
}

function trend_pct($curr, $prev): string {
    if (!$prev || !is_numeric($prev) || $prev == 0) return '';
    $pct = round(($curr - $prev) / $prev * 100, 1);
    if ($pct > 0)  return "<span class='kpi-trend up'>▲ {$pct}%</span>";
    if ($pct < 0)  return "<span class='kpi-trend dn'>▼ " . abs($pct) . "%</span>";
    return "<span class='kpi-trend fl'>→ 0%</span>";
}

// ─── RESPONSE TIME ───────────────────────────────────────────
// Response time = time between lead submitted_at and first status change away from 'new'
// We measure this via the lead_comments/audit_log first entry for each lead, or first_contacted_at
if ($tab === 'response') {
    // Per-agent response time stats using first outbound activity
    // "First response" = earliest lead_comment OR earliest status!=new from audit_log
    // We approximate via: MIN(lc.created_at) per lead for leads that are no longer 'new'
    $resp_agent_rows = db_fetch_all(
        "SELECT
            CONCAT(u.first_name,' ',u.last_name) AS agent_name,
            u.id AS agent_id,
            COUNT(DISTINCT l.id) AS total_leads,
            COUNT(DISTINCT CASE WHEN l.status != 'new' THEN l.id END) AS responded,
            ROUND(AVG(CASE WHEN l.status != 'new' AND fc.first_comment IS NOT NULL
                THEN TIMESTAMPDIFF(MINUTE, l.submitted_at, fc.first_comment) END) / 60, 2) AS avg_hrs,
            ROUND(MIN(CASE WHEN l.status != 'new' AND fc.first_comment IS NOT NULL
                THEN TIMESTAMPDIFF(MINUTE, l.submitted_at, fc.first_comment) END) / 60, 2) AS min_hrs,
            ROUND(MAX(CASE WHEN l.status != 'new' AND fc.first_comment IS NOT NULL
                THEN TIMESTAMPDIFF(MINUTE, l.submitted_at, fc.first_comment) END) / 60, 2) AS max_hrs,
            SUM(CASE WHEN l.status != 'new' AND fc.first_comment IS NOT NULL
                AND TIMESTAMPDIFF(MINUTE, l.submitted_at, fc.first_comment) <= 60 THEN 1 ELSE 0 END) AS within_1h,
            SUM(CASE WHEN l.status != 'new' AND fc.first_comment IS NOT NULL
                AND TIMESTAMPDIFF(MINUTE, l.submitted_at, fc.first_comment) <= 240 THEN 1 ELSE 0 END) AS within_4h,
            SUM(CASE WHEN l.status != 'new' AND fc.first_comment IS NOT NULL
                AND TIMESTAMPDIFF(MINUTE, l.submitted_at, fc.first_comment) <= 1440 THEN 1 ELSE 0 END) AS within_24h
         FROM leads l
         JOIN users u ON u.id = l.assigned_to
         LEFT JOIN (
             SELECT lead_id, MIN(created_at) AS first_comment
             FROM lead_comments GROUP BY lead_id
         ) fc ON fc.lead_id = l.id
         {$dw} AND l.assigned_to IS NOT NULL AND l.is_deleted = 0
         GROUP BY u.id
         ORDER BY avg_hrs ASC",
        $dt, ...$dp
    );

    // Overall account response time
    $resp_overall = db_fetch(
        "SELECT
            COUNT(DISTINCT l.id) AS total,
            COUNT(DISTINCT CASE WHEN l.status != 'new' THEN l.id END) AS responded,
            ROUND(AVG(CASE WHEN l.status != 'new' AND fc.first_comment IS NOT NULL
                THEN TIMESTAMPDIFF(MINUTE, l.submitted_at, fc.first_comment) END) / 60, 2) AS avg_hrs,
            SUM(CASE WHEN l.status != 'new' AND fc.first_comment IS NOT NULL
                AND TIMESTAMPDIFF(MINUTE, l.submitted_at, fc.first_comment) <= 60 THEN 1 ELSE 0 END) AS within_1h,
            SUM(CASE WHEN l.status != 'new' AND fc.first_comment IS NOT NULL
                AND TIMESTAMPDIFF(MINUTE, l.submitted_at, fc.first_comment) <= 1440 THEN 1 ELSE 0 END) AS within_24h,
            SUM(CASE WHEN l.status = 'new'
                AND TIMESTAMPDIFF(HOUR, l.submitted_at, NOW()) > 24 THEN 1 ELSE 0 END) AS overdue_new
         FROM leads l
         LEFT JOIN (
             SELECT lead_id, MIN(created_at) AS first_comment
             FROM lead_comments GROUP BY lead_id
         ) fc ON fc.lead_id = l.id
         {$dw} AND l.is_deleted = 0",
        $dt, ...$dp
    ) ?? [];

    // Response time distribution buckets (in minutes)
    $resp_buckets_raw = db_fetch_all(
        "SELECT
            CASE
                WHEN TIMESTAMPDIFF(MINUTE, l.submitted_at, fc.first_comment) <= 30   THEN 'Under 30m'
                WHEN TIMESTAMPDIFF(MINUTE, l.submitted_at, fc.first_comment) <= 60   THEN '30m–1h'
                WHEN TIMESTAMPDIFF(MINUTE, l.submitted_at, fc.first_comment) <= 240  THEN '1h–4h'
                WHEN TIMESTAMPDIFF(MINUTE, l.submitted_at, fc.first_comment) <= 480  THEN '4h–8h'
                WHEN TIMESTAMPDIFF(MINUTE, l.submitted_at, fc.first_comment) <= 1440 THEN '8h–24h'
                ELSE 'Over 24h'
            END AS bucket,
            COUNT(*) AS n
         FROM leads l
         JOIN (
             SELECT lead_id, MIN(created_at) AS first_comment
             FROM lead_comments GROUP BY lead_id
         ) fc ON fc.lead_id = l.id
         {$dw} AND l.status != 'new' AND l.is_deleted = 0
         GROUP BY bucket",
        $dt, ...$dp
    );
    $bucket_order = ['Under 30m','30m–1h','1h–4h','4h–8h','8h–24h','Over 24h'];
    $bucket_idx   = array_fill_keys($bucket_order, 0);
    foreach ($resp_buckets_raw as $b) $bucket_idx[$b['bucket']] = (int)$b['n'];

    // Daily trend of avg response time
    $resp_daily = db_fetch_all(
        "SELECT DATE(l.submitted_at) AS day,
            ROUND(AVG(TIMESTAMPDIFF(MINUTE, l.submitted_at, fc.first_comment)) / 60, 2) AS avg_hrs,
            COUNT(*) AS n
         FROM leads l
         JOIN (
             SELECT lead_id, MIN(created_at) AS first_comment
             FROM lead_comments GROUP BY lead_id
         ) fc ON fc.lead_id = l.id
         {$dw} AND l.status != 'new' AND l.is_deleted = 0
         GROUP BY DATE(l.submitted_at)
         ORDER BY day",
        $dt, ...$dp
    );

    // Threshold config (stored in platform_settings)
    $resp_threshold_key = "resp_threshold_{$account_id}";
    $resp_thresh_row = db_fetch('SELECT value FROM platform_settings WHERE `key`=?', 's', $resp_threshold_key);
    $resp_threshold  = $resp_thresh_row ? (float)$resp_thresh_row['value'] : 4.0; // default 4 hrs

    // Save threshold if posted
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resp_threshold']) && can('settings','edit')) {
        $new_thresh = max(0.25, min(72, (float)$_POST['resp_threshold']));
        db_query('INSERT INTO platform_settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)',
            'ss', $resp_threshold_key, $new_thresh);
        $resp_threshold = $new_thresh;
    }
} else {
    $resp_agent_rows = $resp_overall = $resp_buckets_raw = $resp_daily = [];
    $bucket_idx = []; $resp_threshold = 4.0;
}

// ─── SOURCE ROI ───────────────────────────────────────────────
if ($tab === 'source_roi') {
    $roi_by_source = db_fetch_all(
        "SELECT
            COALESCE(NULLIF(l.utm_source,''),'(direct)') AS source,
            COALESCE(NULLIF(l.utm_medium,''),'(none)')   AS medium,
            COUNT(*)                                       AS total,
            SUM(l.status='converted')                     AS converted,
            SUM(l.status='qualified')                     AS qualified,
            SUM(l.status='lost')                          AS lost,
            SUM(l.status='new')                           AS still_new,
            ROUND(AVG(COALESCE(l.score,0)),1)             AS avg_score,
            ROUND(AVG(COALESCE(l.engagement_score,0)),1)  AS avg_engagement,
            ROUND(AVG(CASE WHEN l.status!='new' AND fc.first_comment IS NOT NULL
                THEN TIMESTAMPDIFF(MINUTE,l.submitted_at,fc.first_comment) END)/60,2) AS avg_resp_hrs,
            MIN(l.submitted_at)                            AS first_seen,
            MAX(l.submitted_at)                            AS last_seen
         FROM leads l
         LEFT JOIN (SELECT lead_id, MIN(created_at) AS first_comment FROM lead_comments GROUP BY lead_id) fc
            ON fc.lead_id = l.id
         {$dw} AND l.is_deleted=0
         GROUP BY l.utm_source, l.utm_medium
         ORDER BY total DESC LIMIT 20",
        $dt, ...$dp
    );

    // Enrich with conversion rate and quality tier
    foreach ($roi_by_source as &$rs) {
        $rs['conv_rate']  = $rs['total'] > 0 ? round($rs['converted'] / $rs['total'] * 100, 1) : 0;
        $rs['qual_rate']  = $rs['total'] > 0 ? round(($rs['converted'] + $rs['qualified']) / $rs['total'] * 100, 1) : 0;
        // Quality tier: A/B/C/D based on conv_rate + avg_score
        $q = $rs['conv_rate'] * 0.6 + (float)$rs['avg_score'] * 0.4;
        $rs['tier'] = $q >= 50 ? 'A' : ($q >= 30 ? 'B' : ($q >= 15 ? 'C' : 'D'));
    }
    unset($rs);

    // Daily source volume for top 4 sources
    $top_sources = array_slice(array_column($roi_by_source, 'source'), 0, 4);
    $roi_daily   = [];
    if ($top_sources) {
        $ph  = implode(',', array_fill(0, count($top_sources), '?'));
        $raw = db_fetch_all(
            "SELECT DATE(l.submitted_at) AS day,
                COALESCE(NULLIF(l.utm_source,''),'(direct)') AS source,
                COUNT(*) AS n
             FROM leads l {$dw} AND COALESCE(NULLIF(l.utm_source,''),'(direct)') IN ($ph)
             GROUP BY day, l.utm_source ORDER BY day",
            $dt . str_repeat('s', count($top_sources)), ...array_merge($dp, $top_sources)
        );
        foreach ($raw as $r) $roi_daily[$r['source']][$r['day']] = (int)$r['n'];
    }
} else {
    $roi_by_source = []; $roi_daily = []; $top_sources = [];
}

include __DIR__ . '/layouts/header.php';
?>
<!-- ════════════════════ ANALYTICS STYLES ═══════════════════ -->
<style>
/* Layout */
.an-shell { display:flex; flex-direction:column; gap:0; }
.an-topbar { display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px; margin-bottom:20px; }
.an-title  { font-size:1.3rem; font-weight:800; color:var(--gray-900); letter-spacing:-.025em; }
.an-meta   { font-size:.74rem; color:var(--gray-400); margin-top:2px; }
.an-controls { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }

/* Filters */
.an-select { height:32px; padding:0 10px; border:1.5px solid var(--gray-200); border-radius:8px; font-size:.76rem; color:var(--gray-700); background:#fff; cursor:pointer; outline:none; }
.an-select:focus { border-color:var(--brand-400); }
.range-btns { display:flex; gap:2px; }
.range-btns a { padding:5px 11px; border-radius:7px; font-size:.73rem; font-weight:700; text-decoration:none; color:var(--gray-500); border:1.5px solid transparent; transition:.12s; }
.range-btns a:hover { color:var(--gray-700); background:var(--gray-50); }
.range-btns a.on  { background:var(--brand-600); color:#fff; }

/* Tab nav */
.an-tabs { display:flex; border-bottom:2px solid var(--gray-100); margin-bottom:22px; gap:0; overflow-x:auto; }
.an-tab  { display:flex; align-items:center; gap:7px; padding:11px 18px; font-size:.79rem; font-weight:600; color:var(--gray-500); text-decoration:none; border-bottom:2.5px solid transparent; margin-bottom:-2px; white-space:nowrap; transition:.12s; }
.an-tab:hover  { color:var(--gray-700); }
.an-tab.on { color:var(--brand-600); border-bottom-color:var(--brand-600); }
.an-tab svg { flex-shrink:0; opacity:.7; }
.an-tab.on svg { opacity:1; }

/* KPI grid */
.kpi-row { display:grid; grid-template-columns:repeat(auto-fill,minmax(148px,1fr)); gap:12px; margin-bottom:20px; }
.kpi { background:#fff; border:1.5px solid var(--gray-100); border-radius:13px; padding:16px 17px 14px; border-top-width:3px; }
.kpi-v { font-size:1.65rem; font-weight:800; letter-spacing:-.04em; line-height:1; }
.kpi-l { font-size:.68rem; font-weight:700; text-transform:uppercase; letter-spacing:.06em; color:var(--gray-400); margin-top:5px; }
.kpi-trend { display:inline-block; font-size:.67rem; font-weight:700; padding:2px 6px; border-radius:20px; margin-top:5px; }
.kpi-trend.up { background:#f0fdf4; color:#16a34a; }
.kpi-trend.dn { background:#fef2f2; color:#dc2626; }
.kpi-trend.fl { background:var(--gray-50); color:var(--gray-400); }

/* Chart cards */
.an-card { background:#fff; border:1.5px solid var(--gray-100); border-radius:13px; overflow:hidden; margin-bottom:16px; }
.an-ch   { display:flex; align-items:center; justify-content:space-between; padding:15px 18px 12px; border-bottom:1px solid var(--gray-50); }
.an-ct   { font-size:.85rem; font-weight:700; color:var(--gray-800); }
.an-cs   { font-size:.71rem; color:var(--gray-400); margin-top:2px; }
.an-cb   { padding:16px 18px; }

/* 2 and 3 col grids */
.g2 { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
.g3 { display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px; }
@media(max-width:960px) { .g2,.g3 { grid-template-columns:1fr; } }

/* Progress bar rows */
.pb-row  { display:flex; align-items:center; gap:9px; margin-bottom:8px; }
.pb-lbl  { font-size:.74rem; color:var(--gray-600); min-width:90px; max-width:140px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.pb-bar  { flex:1; height:6px; background:var(--gray-100); border-radius:3px; overflow:hidden; }
.pb-fill { height:100%; border-radius:3px; transition:width .4s; }
.pb-val  { font-size:.71rem; font-weight:700; color:var(--gray-500); min-width:28px; text-align:right; }
.pb-rate { font-size:.67rem; font-weight:700; color:#16a34a; min-width:30px; text-align:right; }

/* Funnel steps */
.fn-step { position:relative; display:flex; align-items:center; gap:12px; padding:11px 14px; background:var(--gray-50); border-radius:10px; margin-bottom:7px; overflow:hidden; }
.fn-bar  { position:absolute; left:0; top:0; bottom:0; opacity:.15; pointer-events:none; }
.fn-ico  { width:30px; height:30px; border-radius:8px; display:flex; align-items:center; justify-content:center; flex-shrink:0; z-index:1; }
.fn-num  { font-size:1.2rem; font-weight:800; color:var(--gray-900); min-width:46px; z-index:1; }
.fn-lbl  { font-size:.77rem; color:var(--gray-600); z-index:1; flex:1; }
.fn-pct  { font-size:.71rem; font-weight:700; padding:2px 8px; border-radius:20px; z-index:1; }
.fn-drop { font-size:.65rem; color:#ef4444; font-weight:700; z-index:1; }

/* Geo rows */
.geo-row { display:flex; align-items:center; gap:9px; padding:6px 0; border-bottom:1px solid var(--gray-50); }
.geo-row:last-child { border:none; }
.geo-flag { font-size:.9rem; width:20px; text-align:center; flex-shrink:0; }
.geo-name { font-size:.76rem; color:var(--gray-700); flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.geo-bar  { width:70px; height:4px; background:var(--gray-100); border-radius:2px; overflow:hidden; flex-shrink:0; }
.geo-fill { height:100%; background:var(--brand-400); border-radius:2px; }
.geo-n    { font-size:.71rem; font-weight:700; color:var(--gray-500); min-width:24px; text-align:right; }

/* Heatmap */
.hm-cell { border-radius:2px; cursor:default; }

/* Matrix table overrides */
.mx-table th { font-size:.66rem; text-transform:uppercase; letter-spacing:.05em; color:var(--gray-400); font-weight:700; background:var(--gray-50); padding:8px 12px; }
.mx-table td { font-size:.76rem; padding:8px 12px; }

/* Sales leaderboard */
.lb-row { display:flex; align-items:center; gap:10px; padding:9px 0; border-bottom:1px solid var(--gray-50); }
.lb-row:last-child { border:none; }
.lb-rank { font-size:.78rem; font-weight:700; color:var(--gray-400); width:20px; text-align:center; flex-shrink:0; }
.lb-ava  { width:30px; height:30px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:.62rem; font-weight:700; color:#fff; flex-shrink:0; }
.lb-name { font-size:.8rem; font-weight:600; color:var(--gray-800); flex:1; }
.lb-bar-wrap { width:80px; height:4px; background:var(--gray-100); border-radius:2px; overflow:hidden; }
.lb-bar-fill { height:100%; border-radius:2px; transition:width .6s; }
.lb-stat { font-size:.72rem; font-weight:700; min-width:28px; text-align:right; }

/* Role scope badge */
.scope-badge { display:inline-flex; align-items:center; gap:4px; font-size:.7rem; font-weight:600; padding:2px 9px; border-radius:20px; background:var(--brand-50); color:var(--brand-700); margin-left:6px; vertical-align:middle; }

/* Responsive tweaks */
@media(max-width:640px) {
  .kpi-row { grid-template-columns:1fr 1fr; }
  .an-tab  { padding:9px 12px; font-size:.72rem; }
}
</style>

<?php
// ── Build filter form base URL ────────────────────────────────
function filter_url(string $tab, string $range, int $domain_id, int $form_id): string {
    $q = http_build_query(array_filter([
        'tab'       => $tab,
        'range'     => $range,
        'domain_id' => $domain_id ?: null,
        'form_id'   => $form_id   ?: null,
    ], function($v) { return $v !== null && $v !== ''; }));
    return 'reports.php?' . $q;
}
$base_url = filter_url($tab, $range, $f_domain, $f_form);
?>

<!-- ── Top bar ──────────────────────────────────────────────── -->
<div class="an-topbar">
  <div>
    <div class="an-title">
      Analytics
      <?php if ($agent_scope): ?>
        <span class="scope-badge">
          <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          Your leads only
        </span>
      <?php elseif ($role === 'manager'): ?>
        <span class="scope-badge">All forms</span>
      <?php endif; ?>
    </div>
    <div class="an-meta">
      <?= format_dt($date_from . ' 00:00:00', 'd M Y') ?> → <?= format_dt($date_to . ' 00:00:00', 'd M Y') ?>
      &nbsp;·&nbsp; <?= number_format($total) ?> lead<?= $total != 1 ? 's' : '' ?>
    </div>
  </div>

  <div class="an-controls">
    <!-- Domain filter (account_owner / super only) -->
    <?php if ($can_filter_domain && $domain_opts): ?>
    <form method="GET" id="domForm" style="display:contents;">
      <input type="hidden" name="tab"   value="<?= h($tab) ?>">
      <input type="hidden" name="range" value="<?= h($range) ?>">
      <?php if ($f_form): ?><input type="hidden" name="form_id" value="<?= $f_form ?>"><?php endif; ?>
      <select name="domain_id" class="an-select" onchange="document.getElementById('domForm').submit()">
        <option value="">All domains</option>
        <?php foreach ($domain_opts as $d): ?>
        <option value="<?= $d['id'] ?>" <?= $f_domain == $d['id'] ? 'selected' : '' ?>><?= h($d['domain']) ?></option>
        <?php endforeach; ?>
      </select>
    </form>
    <?php endif; ?>

    <!-- Form filter -->
    <?php if ($form_opts): ?>
    <form method="GET" id="formForm" style="display:contents;">
      <input type="hidden" name="tab"   value="<?= h($tab) ?>">
      <input type="hidden" name="range" value="<?= h($range) ?>">
      <?php if ($f_domain): ?><input type="hidden" name="domain_id" value="<?= $f_domain ?>"><?php endif; ?>
      <select name="form_id" class="an-select" onchange="document.getElementById('formForm').submit()">
        <option value="">All forms</option>
        <?php foreach ($form_opts as $f): ?>
        <option value="<?= $f['id'] ?>" <?= $f_form == $f['id'] ? 'selected' : '' ?>><?= h($f['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </form>
    <?php endif; ?>

    <!-- Date range -->
    <div class="range-btns">
      <?php foreach (['7'=>'7D','30'=>'30D','90'=>'90D','year'=>'1Y'] as $rv => $rl): ?>
      <a href="<?= filter_url($tab, $rv, $f_domain, $f_form) ?>"
         class="<?= $range === $rv ? 'on' : '' ?>"><?= $rl ?></a>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- ── Tab navigation ────────────────────────────────────────── -->
<div class="an-tabs">
  <?php
  $tabs_nav = [
    ['overview',    'Overview',      'M3 3h18v3H3zm0 6h18v3H3zm0 6h18v3H3z'],
    ['geo',         'Geo',           'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z'],
    ['behavioral',  'Behavioral',    'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M23 21v-2a4 4 0 0 1-3-3.87M16 3.13a4 4 0 0 1 0 7.75M9 7a4 4 0 1 0 0-8 4 4 0 0 0 0 8z'],
    ['attribution', 'Attribution',   'M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z'],
    ['sales',       'Sales',         'M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z'],
    ['response',    'Response Time', 'M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm0-2a8 8 0 1 0 0-16 8 8 0 0 0 0 16zm1-8h3l-4 4-4-4h3V8h2v4z'],
    ['source_roi',  'Source ROI',    'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z'],
  ];
  foreach ($tabs_nav as [$tid, $tlbl, $tpath]):
  ?>
  <a href="<?= filter_url($tid, $range, $f_domain, $f_form) ?>"
     class="an-tab <?= $tab === $tid ? 'on' : '' ?>">
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="<?= $tpath ?>"/></svg>
    <?= $tlbl ?>
  </a>
  <?php endforeach; ?>
</div>


<?php /* ═══════════════════════════════════════════════════════
        TAB 1 — OVERVIEW
════════════════════════════════════════════════════════════ */ ?>
<?php if ($tab === 'overview'): ?>

<!-- KPI cards -->
<div class="kpi-row">
  <?php
  $prev_converted = (int)($prev_summary['converted'] ?? 0);
  $kpis = [
    ['Total Leads',  $total,                                    trend_pct($total, $prev_total),        '#2563eb'],
    ['Converted',    (int)($summary['converted']??0),           trend_pct((int)($summary['converted']??0), $prev_converted), '#16a34a'],
    ['Conv. Rate',   $conv_rate.'%',                            trend_pct($conv_rate, $prev_rate),     '#7c3aed'],
    ['Avg Score',    round((float)($summary['avg_score']??0)),  '', '#d97706'],
    ['Hot 🔥',       (int)($summary['hot']??0),                 '', '#ef4444'],
    ['Warm',         (int)($summary['warm']??0),                '', '#f59e0b'],
    ['Cold',         (int)($summary['cold']??0),                '', '#3b82f6'],
    ['Spam',         (int)($summary['spam']??0),                '', '#94a3b8'],
  ];
  foreach ($kpis as [$lbl,$val,$trend,$col]):
  ?>
  <div class="kpi" style="border-top-color:<?= $col ?>;">
    <div class="kpi-v" style="color:<?= $col ?>;"><?= is_numeric($val) ? number_format((float)$val) : $val ?></div>
    <div class="kpi-l"><?= $lbl ?></div>
    <?= $trend ?>
  </div>
  <?php endforeach; ?>
</div>

<!-- Leads over time -->
<div class="an-card">
  <div class="an-ch">
    <div>
      <div class="an-ct">Leads Over Time</div>
      <div class="an-cs"><?= count($daily_full) ?> days · <?= number_format($total) ?> total</div>
    </div>
  </div>
  <div class="an-cb">
    <canvas id="cTimeChart" height="72"></canvas>
  </div>
</div>

<!-- Row: status donut + quality donut -->
<div class="g2">
  <div class="an-card" style="margin-bottom:0;">
    <div class="an-ch"><div class="an-ct">Lead Status</div></div>
    <div class="an-cb" style="display:flex;align-items:center;gap:16px;">
      <canvas id="cStatus" style="max-width:160px;max-height:160px;flex-shrink:0;"></canvas>
      <div style="flex:1;">
        <?php foreach ($by_status as $s):
          $col = $status_col[$s['status']] ?? '#94a3b8';
          $pct = $total > 0 ? round($s['n']/$total*100) : 0;
        ?>
        <div style="display:flex;align-items:center;gap:7px;margin-bottom:6px;">
          <div style="width:9px;height:9px;border-radius:50%;background:<?= $col ?>;flex-shrink:0;"></div>
          <span style="font-size:.74rem;color:var(--gray-700);flex:1;"><?= ucfirst($s['status']) ?></span>
          <span style="font-size:.74rem;font-weight:700;"><?= number_format($s['n']) ?></span>
          <span style="font-size:.67rem;color:var(--gray-400);width:26px;text-align:right;"><?= $pct ?>%</span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <div class="an-card" style="margin-bottom:0;">
    <div class="an-ch">
      <div><div class="an-ct">Lead Quality</div><div class="an-cs">Score distribution (rule-based 0–100)</div></div>
    </div>
    <div class="an-cb" style="display:flex;align-items:center;gap:16px;">
      <canvas id="cQuality" style="max-width:160px;max-height:160px;flex-shrink:0;"></canvas>
      <div style="flex:1;">
        <?php foreach ([['Hot','#ef4444','hot'],['Warm','#f59e0b','warm'],['Cold','#3b82f6','cold'],['Unscored','#cbd5e1','unscored']] as [$ql,$qc,$qk]):
          $qv = (int)($score_dist[$qk]??0);
          $qp = $total > 0 ? round($qv/$total*100) : 0;
        ?>
        <div style="display:flex;align-items:center;gap:7px;margin-bottom:6px;">
          <div style="width:9px;height:9px;border-radius:50%;background:<?= $qc ?>;flex-shrink:0;"></div>
          <span style="font-size:.74rem;color:var(--gray-700);flex:1;"><?= $ql ?></span>
          <span style="font-size:.74rem;font-weight:700;"><?= number_format($qv) ?></span>
          <span style="font-size:.67rem;color:var(--gray-400);width:26px;text-align:right;"><?= $qp ?>%</span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>
<div style="margin-bottom:16px;"></div>

<!-- Row: domain comparison + top forms -->
<div class="g2">
  <?php if ($by_domain && !$f_domain): ?>
  <div class="an-card" style="margin-bottom:0;">
    <div class="an-ch"><div class="an-ct">Domain Comparison</div></div>
    <div class="an-cb">
      <canvas id="cDomain" height="150"></canvas>
    </div>
  </div>
  <?php endif; ?>

  <div class="an-card" style="margin-bottom:0;">
    <div class="an-ch"><div class="an-ct">Top Forms</div></div>
    <div class="an-cb" style="padding:0;">
      <table class="table mx-table" style="margin:0;">
        <thead><tr><th>Form</th><th>Leads</th><th>Conv.</th><th>Score</th></tr></thead>
        <tbody>
          <?php foreach ($by_form as $bf):
            $r = $bf['n']>0 ? round($bf['conv']/$bf['n']*100) : 0;
            $sc = (int)($bf['avg_score']??0);
            $scc = $sc>=70?'#ef4444':($sc>=35?'#f59e0b':'#3b82f6');
          ?>
          <tr>
            <td style="max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.76rem;"><?= h($bf['form_name']) ?></td>
            <td style="font-weight:700;"><?= $bf['n'] ?></td>
            <td>
              <span style="color:#16a34a;font-weight:700;"><?= $bf['conv'] ?></span>
              <span style="font-size:.67rem;color:var(--gray-400);margin-left:2px;"><?= $r ?>%</span>
            </td>
            <td><span style="color:<?= $scc ?>;font-weight:700;"><?= $sc ?></span></td>
          </tr>
          <?php endforeach; ?>
          <?php if (!$by_form): ?>
          <tr><td colspan="4" style="text-align:center;color:var(--gray-300);padding:20px;font-size:.8rem;">No data in period</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<div style="margin-bottom:16px;"></div>

<!-- Submission heatmap (hour × day) -->
<div class="an-card">
  <div class="an-ch">
    <div><div class="an-ct">Submission Heatmap</div><div class="an-cs">Hour of day × day of week · darker = more leads</div></div>
  </div>
  <div class="an-cb" style="overflow-x:auto;">
    <div id="cHeatmap"></div>
  </div>
</div>

<!-- Campaign performance -->
<?php if ($campaigns_ov): ?>
<div class="an-card">
  <div class="an-ch"><div class="an-ct">Campaign Performance</div><div class="an-cs">Top UTM campaigns this period</div></div>
  <div class="an-cb" style="padding:0;overflow-x:auto;">
    <table class="table mx-table" style="margin:0;">
      <thead><tr><th>Campaign</th><th>Source</th><th>Leads</th><th>Conv.</th><th>Rate</th><th>Avg Score</th></tr></thead>
      <tbody>
        <?php foreach ($campaigns_ov as $c):
          $sc=(int)($c['avg_score']??0);$scc=$sc>=70?'#ef4444':($sc>=35?'#f59e0b':'#3b82f6');
        ?>
        <tr>
          <td style="font-weight:600;"><?= h($c['campaign']) ?></td>
          <td style="color:var(--gray-500);"><?= h($c['source']) ?></td>
          <td style="font-weight:700;"><?= $c['n'] ?></td>
          <td style="color:#16a34a;font-weight:700;"><?= $c['conv'] ?></td>
          <td>
            <div style="display:flex;align-items:center;gap:5px;">
              <div style="width:36px;height:4px;background:var(--gray-100);border-radius:2px;overflow:hidden;">
                <div style="height:100%;width:<?= min(100,$c['rate']) ?>%;background:#22c55e;"></div>
              </div>
              <span style="font-size:.72rem;font-weight:700;"><?= $c['rate'] ?>%</span>
            </div>
          </td>
          <td><span style="color:<?= $scc ?>;font-weight:700;"><?= $sc ?></span></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>


<?php /* ═══════════════════════════════════════════════════════
        TAB 2 — GEO ANALYTICS
════════════════════════════════════════════════════════════ */ ?>
<?php elseif ($tab === 'geo'): ?>

<!-- Device + Browser + Top countries row -->
<div class="g3">
  <!-- Device -->
  <div class="an-card" style="margin-bottom:0;">
    <div class="an-ch"><div class="an-ct">Device Types</div></div>
    <div class="an-cb">
      <canvas id="cDevice" height="160"></canvas>
    </div>
  </div>

  <!-- Browser -->
  <div class="an-card" style="margin-bottom:0;">
    <div class="an-ch"><div class="an-ct">Browsers</div></div>
    <div class="an-cb" style="padding:14px 16px;">
      <?php
      $bicons = ['Chrome'=>'🌐','Firefox'=>'🦊','Safari'=>'🧭','Edge'=>'🔷','Opera'=>'🔴','Samsung'=>'📱','Other'=>'❓'];
      $maxb = $by_browser ? max(array_column($by_browser,'n')) : 1;
      foreach ($by_browser as $b):
        $bpct = round($b['n'] / $maxb * 100);
        $bico = $bicons[$b['browser']] ?? '❓';
      ?>
      <div class="pb-row">
        <div class="pb-lbl"><?= $bico ?> <?= h($b['browser']) ?></div>
        <div class="pb-bar"><div class="pb-fill" style="width:<?= $bpct ?>%;background:var(--brand-400);"></div></div>
        <div class="pb-val"><?= $b['n'] ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Top countries quick list -->
  <div class="an-card" style="margin-bottom:0;">
    <div class="an-ch"><div class="an-ct">Top Countries</div></div>
    <div class="an-cb" style="padding:14px 16px;">
      <?php
      $maxcc = $by_country ? max(array_column($by_country,'n')) : 1;
      foreach (array_slice($by_country,0,8) as $c):
        $meta = $country_meta[$c['country']] ?? ['🌍',null];
        $flag = $meta[0];
        $cpct = round($c['n']/$maxcc*100);
      ?>
      <div class="geo-row">
        <div class="geo-flag"><?= $flag ?></div>
        <div class="geo-name"><?= h($c['country']) ?></div>
        <div class="geo-bar"><div class="geo-fill" style="width:<?= $cpct ?>%;"></div></div>
        <div class="geo-n"><?= $c['n'] ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<div style="margin-bottom:16px;"></div>

<!-- World map -->
<div class="an-card">
  <div class="an-ch">
    <div>
      <div class="an-ct">Geographic Distribution</div>
      <div class="an-cs">Bubble size = lead volume · click for details</div>
    </div>
  </div>
  <div style="padding:0;">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css">
    <div id="cWorldMap" style="height:360px;border-radius:0 0 12px 12px;z-index:1;"></div>
  </div>
</div>

<!-- Full country table -->
<div class="an-card">
  <div class="an-ch">
    <div><div class="an-ct">Country Breakdown</div><div class="an-cs"><?= count($by_country) ?> countries represented</div></div>
  </div>
  <div style="overflow-x:auto;">
    <table class="table mx-table" style="margin:0;">
      <thead><tr><th>Country</th><th>Leads</th><th>Conv.</th><th>Conv. Rate</th><th>Share</th></tr></thead>
      <tbody>
        <?php foreach ($by_country as $c):
          $meta = $country_meta[$c['country']] ?? ['🌍',null];
          $crate = $c['n'] > 0 ? round($c['conv']/$c['n']*100) : 0;
          $share = $total   > 0 ? round($c['n']/$total*100,1) : 0;
        ?>
        <tr>
          <td style="white-space:nowrap;">
            <span style="margin-right:5px;"><?= $meta[0] ?></span><?= h($c['country']) ?>
          </td>
          <td style="font-weight:700;"><?= number_format($c['n']) ?></td>
          <td style="color:#16a34a;font-weight:700;"><?= $c['conv'] ?></td>
          <td>
            <div style="display:flex;align-items:center;gap:5px;">
              <div style="width:34px;height:4px;background:var(--gray-100);border-radius:2px;overflow:hidden;">
                <div style="height:100%;width:<?= $crate ?>%;background:#22c55e;"></div>
              </div>
              <span style="font-size:.71rem;"><?= $crate ?>%</span>
            </div>
          </td>
          <td style="color:var(--gray-400);font-size:.71rem;"><?= $share ?>%</td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$by_country): ?>
        <tr><td colspan="5" style="text-align:center;color:var(--gray-300);padding:24px;">
          No country data — enable Cloudflare proxy to auto-detect countries
        </td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>


<?php /* ═══════════════════════════════════════════════════════
        TAB 3 — BEHAVIORAL
════════════════════════════════════════════════════════════ */ ?>
<?php elseif ($tab === 'behavioral'): ?>

<!-- Timing KPIs -->
<div class="kpi-row" style="grid-template-columns:repeat(auto-fill,minmax(170px,1fr));">
  <?php
  $avg_resp  = (float)($resp_time['avg_hrs']   ?? 0);
  $min_resp  = (float)($resp_time['min_hrs']   ?? 0);
  $avg_close = (float)($close_time['avg_hrs']  ?? 0);
  $fn_total  = (int)($funnel['total']           ?? 0);
  $fn_cont   = (int)($funnel['s_contacted']     ?? 0);
  $drop_pct  = $fn_total > 0 ? (100 - round($fn_cont/$fn_total*100)) : 0;

  $beh_kpis = [
    ['Avg Response',  fmt_hrs($avg_resp),  'Time to first contact', '#2563eb'],
    ['Fastest Reply', fmt_hrs($min_resp),  'Quickest first contact','#16a34a'],
    ['Avg Close',     fmt_hrs($avg_close), 'Submitted → Converted', '#7c3aed'],
    ['Top-Funnel Drop', $drop_pct.'%',     '% lost before contact', '#d97706'],
    ['Leads/Day',     $leads_per_day,      'Avg daily volume',      '#0891b2'],
  ];
  foreach ($beh_kpis as [$lbl,$val,$sub,$col]):
  ?>
  <div class="kpi" style="border-top-color:<?= $col ?>;">
    <div class="kpi-v" style="color:<?= $col ?>;"><?= $val ?></div>
    <div class="kpi-l"><?= $lbl ?></div>
    <div style="font-size:.67rem;color:var(--gray-400);margin-top:4px;"><?= $sub ?></div>
  </div>
  <?php endforeach; ?>
</div>

<div class="g2">
  <!-- Stage funnel -->
  <div class="an-card" style="margin-bottom:0;">
    <div class="an-ch">
      <div><div class="an-ct">Pipeline Funnel</div><div class="an-cs">Stage drop-off analysis</div></div>
    </div>
    <div class="an-cb">
      <?php
      $fn_qual = (int)($funnel['s_qualified'] ?? 0);
      $fn_conv = (int)($funnel['s_converted'] ?? 0);
      $fn_steps = [
        [$fn_total, 'All Leads',  '#3b82f6', 'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2'],
        [$fn_cont,  'Contacted',  '#f59e0b', 'M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 14'],
        [$fn_qual,  'Qualified',  '#8b5cf6', 'M22 11.08V12a10 10 0 1 1-5.93-9.14'],
        [$fn_conv,  'Converted',  '#22c55e', 'M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z'],
      ];
      foreach ($fn_steps as $i => [$fv, $fl, $fc, $fp]):
        $fpct = $fn_total > 0 ? round($fv/$fn_total*100) : 0;
        $fdrop = ($i > 0 && $fn_steps[$i-1][0] > 0) ? round((1-$fv/$fn_steps[$i-1][0])*100) : 0;
      ?>
      <div class="fn-step" style="margin-left:<?= $i*14 ?>px;">
        <div class="fn-bar" style="width:<?= max(4,$fpct) ?>%;background:<?= $fc ?>;"></div>
        <div class="fn-ico" style="background:<?= $fc ?>1a;">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="<?= $fc ?>" stroke-width="2"><path d="<?= $fp ?>"/></svg>
        </div>
        <div class="fn-num"><?= number_format($fv) ?></div>
        <div class="fn-lbl"><?= $fl ?></div>
        <span class="fn-pct" style="background:<?= $fc ?>1a;color:<?= $fc ?>;"><?= $fpct ?>%</span>
        <?php if ($fdrop > 0): ?>
        <span class="fn-drop">-<?= $fdrop ?>%</span>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Weekly trend -->
  <div class="an-card" style="margin-bottom:0;">
    <div class="an-ch">
      <div><div class="an-ct">Weekly Trend</div><div class="an-cs">Volume + win rate per week</div></div>
    </div>
    <div class="an-cb">
      <canvas id="cWeekly" height="200"></canvas>
    </div>
  </div>
</div>
<div style="margin-bottom:16px;"></div>

<!-- Agent performance table -->
<div class="an-card">
  <div class="an-ch">
    <div><div class="an-ct">Sales Rep Performance</div><div class="an-cs">Assigned leads, conversions, close time</div></div>
  </div>
  <?php if ($agent_perf): ?>
  <div style="overflow-x:auto;">
    <table class="table mx-table" style="margin:0;">
      <thead>
        <tr><th>Rep</th><th>Assigned</th><th>Won</th><th>Qualified</th><th>Win Rate</th><th>Avg Score</th><th>Avg Close</th><th>Pending</th></tr>
      </thead>
      <tbody>
        <?php foreach ($agent_perf as $ap):
          $parts = explode(' ', trim($ap['agent']));
          $ini   = strtoupper(substr($parts[0],0,1) . (isset($parts[1]) ? substr($parts[1],0,1) : ''));
          $avc   = ['#2563eb','#7c3aed','#0891b2','#16a34a','#d97706'];
          $ac    = $avc[abs(crc32($ap['agent'])) % 5];
          $asc   = (int)($ap['avg_score']??0);
          $ascc  = $asc>=70?'#ef4444':($asc>=35?'#f59e0b':'#3b82f6');
        ?>
        <tr>
          <td>
            <div style="display:flex;align-items:center;gap:7px;">
              <div style="width:27px;height:27px;border-radius:50%;background:<?= $ac ?>;display:flex;align-items:center;justify-content:center;font-size:.6rem;font-weight:700;color:#fff;flex-shrink:0;"><?= $ini ?></div>
              <span style="font-size:.78rem;"><?= h($ap['agent']) ?></span>
            </div>
          </td>
          <td style="font-weight:700;"><?= $ap['assigned'] ?></td>
          <td style="color:#16a34a;font-weight:700;"><?= $ap['conv'] ?></td>
          <td style="color:#8b5cf6;font-weight:700;"><?= $ap['qual'] ?></td>
          <td>
            <div style="display:flex;align-items:center;gap:5px;">
              <div style="width:34px;height:4px;background:var(--gray-100);border-radius:2px;overflow:hidden;">
                <div style="height:100%;width:<?= min(100,(float)$ap['rate']) ?>%;background:#22c55e;"></div>
              </div>
              <span style="font-size:.71rem;font-weight:700;"><?= $ap['rate'] ?>%</span>
            </div>
          </td>
          <td><span style="color:<?= $ascc ?>;font-weight:700;"><?= $asc ?></span></td>
          <td style="color:var(--gray-500);"><?= fmt_hrs((float)($ap['avg_close_h']??0)) ?></td>
          <td style="color:var(--gray-400);"><?= $ap['still_new'] ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php else: ?>
  <div style="text-align:center;padding:32px;color:var(--gray-300);font-size:.82rem;">No assigned leads in this period</div>
  <?php endif; ?>
</div>


<?php /* ═══════════════════════════════════════════════════════
        TAB 4 — ATTRIBUTION
════════════════════════════════════════════════════════════ */ ?>
<?php elseif ($tab === 'attribution'): ?>

<!-- Channel KPIs -->
<div class="kpi-row" style="grid-template-columns:repeat(auto-fill,minmax(140px,1fr));">
  <?php
  $ch_palette = [
    'Paid'    =>['#fef2f2','#ef4444'],'Organic' =>['#f0fdf4','#16a34a'],
    'Social'  =>['#eff6ff','#3b82f6'],'Email'   =>['#faf5ff','#7c3aed'],
    'Referral'=>['#fff7ed','#d97706'],'Direct'  =>['#f8fafc','#64748b'],
    'Other'   =>['#f1f5f9','#94a3b8'],
  ];
  foreach ($paid_organic as $ch):
    [$bg,$col] = $ch_palette[$ch['channel']] ?? ['#f8fafc','#64748b'];
  ?>
  <div class="kpi" style="border-top-color:<?= $col ?>;">
    <div class="kpi-v" style="color:<?= $col ?>;"><?= number_format($ch['n']) ?></div>
    <div class="kpi-l"><?= h($ch['channel']) ?></div>
    <div style="font-size:.68rem;color:#16a34a;font-weight:700;margin-top:4px;"><?= $ch['rate'] ?>% won</div>
  </div>
  <?php endforeach; ?>
</div>

<div class="g2">
  <!-- Sources horizontal bar -->
  <div class="an-card" style="margin-bottom:0;">
    <div class="an-ch"><div class="an-ct">Traffic Sources</div><div class="an-cs">utm_source</div></div>
    <div class="an-cb">
      <canvas id="cSources" height="190"></canvas>
    </div>
  </div>

  <!-- Mediums list -->
  <div class="an-card" style="margin-bottom:0;">
    <div class="an-ch"><div class="an-ct">Mediums</div><div class="an-cs">utm_medium with win rates</div></div>
    <div class="an-cb" style="padding:14px 16px;">
      <?php
      $maxm = $by_medium ? max(array_column($by_medium,'n')) : 1;
      foreach ($by_medium as $m):
        $mpct = round($m['n']/$maxm*100);
      ?>
      <div class="pb-row">
        <div class="pb-lbl"><?= h($m['medium']) ?></div>
        <div class="pb-bar"><div class="pb-fill" style="width:<?= $mpct ?>%;background:var(--brand-500);"></div></div>
        <div class="pb-val"><?= $m['n'] ?></div>
        <div class="pb-rate"><?= $m['rate'] ?>%</div>
      </div>
      <?php endforeach; ?>
      <?php if (!$by_medium): ?>
      <div style="text-align:center;color:var(--gray-300);padding:20px;font-size:.8rem;">No UTM data yet</div>
      <?php endif; ?>
    </div>
  </div>
</div>
<div style="margin-bottom:16px;"></div>

<!-- Source × Medium matrix -->
<div class="an-card">
  <div class="an-ch">
    <div><div class="an-ct">Source / Medium Matrix</div><div class="an-cs">Top channel combinations</div></div>
  </div>
  <div style="overflow-x:auto;">
    <table class="table mx-table" style="margin:0;">
      <thead><tr><th>Source</th><th>Medium</th><th>Leads</th><th>Converted</th><th>Win Rate</th></tr></thead>
      <tbody>
        <?php foreach ($src_medium_matrix as $sm):
          $smr = $sm['n'] > 0 ? round($sm['conv']/$sm['n']*100) : 0;
        ?>
        <tr>
          <td style="font-weight:600;"><?= h($sm['source']) ?></td>
          <td><span style="background:var(--gray-50);border:1px solid var(--gray-100);padding:2px 8px;border-radius:4px;font-size:.71rem;"><?= h($sm['medium']) ?></span></td>
          <td style="font-weight:700;"><?= $sm['n'] ?></td>
          <td style="color:#16a34a;font-weight:700;"><?= $sm['conv'] ?></td>
          <td>
            <div style="display:flex;align-items:center;gap:5px;">
              <div style="width:34px;height:4px;background:var(--gray-100);border-radius:2px;overflow:hidden;">
                <div style="height:100%;width:<?= $smr ?>%;background:#22c55e;"></div>
              </div>
              <span style="font-size:.71rem;"><?= $smr ?>%</span>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$src_medium_matrix): ?>
        <tr><td colspan="5" style="text-align:center;color:var(--gray-300);padding:24px;">
          No UTM data — add ?utm_source=google&utm_medium=cpc to campaign URLs
        </td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Full UTM campaign table -->
<div class="an-card">
  <div class="an-ch">
    <div><div class="an-ct">All Campaigns</div><div class="an-cs"><?= count($utm_full) ?> campaigns in period</div></div>
  </div>
  <div style="overflow-x:auto;">
    <table class="table mx-table" style="margin:0;">
      <thead><tr><th>Campaign</th><th>Source</th><th>Medium</th><th>Leads</th><th>Won</th><th>Rate</th><th>Score</th></tr></thead>
      <tbody>
        <?php foreach ($utm_full as $uc):
          $usc=(int)($uc['avg_score']??0);$uscc=$usc>=70?'#ef4444':($usc>=35?'#f59e0b':'#3b82f6');
        ?>
        <tr>
          <td style="font-weight:600;max-width:130px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= h($uc['campaign']) ?></td>
          <td style="color:var(--gray-500);"><?= h($uc['source']) ?></td>
          <td><span style="background:var(--gray-50);border:1px solid var(--gray-100);padding:1px 7px;border-radius:3px;font-size:.7rem;"><?= h($uc['medium']) ?></span></td>
          <td style="font-weight:700;"><?= $uc['n'] ?></td>
          <td style="color:#16a34a;font-weight:700;"><?= $uc['conv'] ?></td>
          <td style="font-weight:700;"><?= $uc['rate'] ?>%</td>
          <td><span style="color:<?= $uscc ?>;font-weight:700;"><?= $usc ?></span></td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$utm_full): ?>
        <tr><td colspan="7" style="text-align:center;color:var(--gray-300);padding:24px;">No campaign data in this period</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>


<?php /* ═══════════════════════════════════════════════════════
        TAB 5 — SALES DASHBOARD
════════════════════════════════════════════════════════════ */ ?>
<?php elseif ($tab === 'sales'): ?>

<?php
$pl_total  = (int)($pipeline['total']     ?? 0);
$pl_won    = (int)($pipeline['won']       ?? 0);
$pl_qual   = (int)($pipeline['qualified'] ?? 0);
$pl_cont   = (int)($pipeline['contacted'] ?? 0);
$pl_new    = (int)($pipeline['new_l']     ?? 0);
$pl_lost   = (int)($pipeline['lost']      ?? 0);
$win_rate  = $pl_total > 0 ? round($pl_won/$pl_total*100,1) : 0;
$prev_win  = $prev_total > 0 ? round($prev_conv/$prev_total*100,1) : 0;
?>

<!-- Sales KPIs -->
<div class="kpi-row">
  <?php
  $skpis = [
    ['Won',          $pl_won,         trend_pct($pl_won, $prev_conv),       '#16a34a'],
    ['Win Rate',     $win_rate.'%',   trend_pct($win_rate, $prev_win),      '#22c55e'],
    ['In Pipeline',  $pl_qual+$pl_cont,'',                                  '#3b82f6'],
    ['New Leads',    $pl_new,         trend_pct($total, $prev_total),       '#7c3aed'],
    ['Lost',         $pl_lost,        '',                                   '#94a3b8'],
    ['Velocity',     $leads_per_day.'/d','',                                '#d97706'],
  ];
  foreach ($skpis as [$lbl,$val,$trend,$col]):
  ?>
  <div class="kpi" style="border-top-color:<?= $col ?>;">
    <div class="kpi-v" style="color:<?= $col ?>;"><?= is_numeric($val) ? number_format((float)$val) : $val ?></div>
    <div class="kpi-l"><?= $lbl ?></div>
    <?= $trend ?>
  </div>
  <?php endforeach; ?>
</div>

<div class="g2">
  <!-- Win rate trend -->
  <div class="an-card" style="margin-bottom:0;">
    <div class="an-ch"><div class="an-ct">Win Rate Trend</div><div class="an-cs">Weekly conversion %</div></div>
    <div class="an-cb">
      <canvas id="cWinRate" height="195"></canvas>
    </div>
  </div>

  <!-- Pipeline donut -->
  <div class="an-card" style="margin-bottom:0;">
    <div class="an-ch"><div class="an-ct">Pipeline Breakdown</div></div>
    <div class="an-cb" style="display:flex;align-items:center;gap:16px;">
      <canvas id="cPipeline" style="max-width:160px;max-height:160px;flex-shrink:0;"></canvas>
      <div style="flex:1;">
        <?php
        $pipe_rows = [
          ['Won','#22c55e',$pl_won],['Qualified','#8b5cf6',$pl_qual],
          ['Contacted','#f59e0b',$pl_cont],['New','#3b82f6',$pl_new],['Lost','#94a3b8',$pl_lost],
        ];
        foreach ($pipe_rows as [$prl,$prc,$prv]):
          $prpct = $pl_total > 0 ? round($prv/$pl_total*100) : 0;
        ?>
        <div style="display:flex;align-items:center;gap:7px;margin-bottom:6px;">
          <div style="width:9px;height:9px;border-radius:50%;background:<?= $prc ?>;flex-shrink:0;"></div>
          <span style="font-size:.74rem;flex:1;color:var(--gray-700);"><?= $prl ?></span>
          <span style="font-size:.74rem;font-weight:700;"><?= number_format($prv) ?></span>
          <span style="font-size:.67rem;color:var(--gray-400);width:26px;text-align:right;"><?= $prpct ?>%</span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>
<div style="margin-bottom:16px;"></div>

<!-- Best converting campaigns -->
<?php if ($top_conv_campaigns): ?>
<div class="an-card">
  <div class="an-ch"><div class="an-ct">Best Converting Campaigns</div><div class="an-cs">Highest win rate · sorted by rate</div></div>
  <div style="overflow-x:auto;">
    <table class="table mx-table" style="margin:0;">
      <thead><tr><th>Campaign</th><th>Leads</th><th>Won</th><th>Win Rate</th><th>Avg Score</th></tr></thead>
      <tbody>
        <?php foreach ($top_conv_campaigns as $tc):
          $tsc=(int)($tc['avg_score']??0);$tscc=$tsc>=70?'#ef4444':($tsc>=35?'#f59e0b':'#3b82f6');
        ?>
        <tr>
          <td style="font-weight:600;"><?= h($tc['campaign']) ?></td>
          <td><?= $tc['n'] ?></td>
          <td style="color:#16a34a;font-weight:700;"><?= $tc['conv'] ?></td>
          <td>
            <div style="display:flex;align-items:center;gap:6px;">
              <div style="width:46px;height:5px;background:var(--gray-100);border-radius:2px;overflow:hidden;">
                <div style="height:100%;width:<?= min(100,(float)$tc['rate']) ?>%;background:#22c55e;border-radius:2px;"></div>
              </div>
              <span style="font-weight:700;color:#16a34a;"><?= $tc['rate'] ?>%</span>
            </div>
          </td>
          <td><span style="color:<?= $tscc ?>;font-weight:700;"><?= $tsc ?></span></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<!-- Sales leaderboard -->
<?php if ($agent_perf): ?>
<div class="an-card">
  <div class="an-ch"><div class="an-ct">Sales Leaderboard</div><div class="an-cs">Ranked by conversions won</div></div>
  <div class="an-cb">
    <?php
    usort($agent_perf, function($a,$b) { return (int)$b['conv'] - (int)$a['conv']; });
    $max_lb = max(1, (int)($agent_perf[0]['conv'] ?? 1));
    $medals = ['🥇','🥈','🥉'];
    foreach ($agent_perf as $ri => $ap):
      $parts = explode(' ', trim($ap['agent']));
      $ini   = strtoupper(substr($parts[0],0,1).(isset($parts[1])?substr($parts[1],0,1):''));
      $avc   = ['#2563eb','#7c3aed','#0891b2','#16a34a','#d97706'];
      $ac    = $avc[abs(crc32($ap['agent'])) % 5];
      $bw    = $max_lb > 0 ? round((int)$ap['conv']/$max_lb*100) : 0;
    ?>
    <div class="lb-row">
      <div class="lb-rank"><?= $medals[$ri] ?? '#'.($ri+1) ?></div>
      <div class="lb-ava" style="background:<?= $ac ?>;"><?= $ini ?></div>
      <div style="flex:1;min-width:0;">
        <div class="lb-name"><?= h($ap['agent']) ?></div>
        <div class="lb-bar-wrap" style="margin-top:4px;">
          <div class="lb-bar-fill" style="width:<?= $bw ?>%;background:<?= $ac ?>;"></div>
        </div>
      </div>
      <div class="lb-stat" style="color:#16a34a;"><?= $ap['conv'] ?><div style="font-size:.62rem;color:var(--gray-400);font-weight:400;">won</div></div>
      <div class="lb-stat"><?= $ap['rate'] ?>%<div style="font-size:.62rem;color:var(--gray-400);font-weight:400;">rate</div></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<?php endif; // end tab switch ?>

<?php if ($tab === 'response'): ?>
<?php
$rt_total     = (int)($resp_overall['total']     ?? 0);
$rt_responded = (int)($resp_overall['responded'] ?? 0);
$rt_avg       = (float)($resp_overall['avg_hrs'] ?? 0);
$rt_1h        = (int)($resp_overall['within_1h'] ?? 0);
$rt_24h       = (int)($resp_overall['within_24h']?? 0);
$rt_overdue   = (int)($resp_overall['overdue_new']??0);
$rt_resp_rate = $rt_total > 0 ? round($rt_responded / $rt_total * 100, 1) : 0;
$rt_1h_pct    = $rt_responded > 0 ? round($rt_1h / $rt_responded * 100, 1) : 0;
$rt_24h_pct   = $rt_responded > 0 ? round($rt_24h / $rt_responded * 100, 1) : 0;
$over_thresh  = $rt_avg > $resp_threshold && $rt_avg > 0;
?>

<!-- Threshold alert banner -->
<?php if ($over_thresh): ?>
<div style="background:#fef2f2;border:1.5px solid #fca5a5;border-radius:10px;padding:12px 18px;margin-bottom:18px;display:flex;align-items:center;gap:10px;">
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
  <div style="font-size:.82rem;color:#991b1b;">
    <strong>Response time alert:</strong> Average response time of <strong><?= fmt_hrs($rt_avg) ?></strong> exceeds your threshold of <strong><?= fmt_hrs($resp_threshold) ?></strong>.
  </div>
</div>
<?php endif; ?>

<!-- KPI row -->
<div class="kpi-row">
<?php
$rt_kpis = [
  ['Avg Response Time', $rt_avg > 0 ? fmt_hrs($rt_avg) : '—',   $over_thresh ? '#ef4444' : '#16a34a'],
  ['Response Rate',     $rt_resp_rate.'%',                        '#3b82f6'],
  ['Within 1 Hour',     $rt_1h_pct.'%',                          '#22c55e'],
  ['Within 24 Hours',   $rt_24h_pct.'%',                         '#8b5cf6'],
  ['Responded',         number_format($rt_responded),             '#64748b'],
  ['Overdue (>24h new)',number_format($rt_overdue),               $rt_overdue > 0 ? '#f59e0b' : '#94a3b8'],
];
foreach ($rt_kpis as [$lbl, $val, $col]):
?>
<div class="kpi" style="border-top-color:<?= $col ?>;">
  <div class="kpi-v" style="color:<?= $col ?>;"><?= $val ?></div>
  <div class="kpi-l"><?= $lbl ?></div>
</div>
<?php endforeach; ?>
</div>

<div class="g2" style="margin-bottom:20px;">

  <!-- Response time distribution chart -->
  <div class="an-card">
    <div class="an-ch"><div class="an-ct">Response Time Distribution</div><div class="an-cs">How quickly leads receive a first response</div></div>
    <div class="an-cb"><canvas id="cRespDist" height="200"></canvas></div>
  </div>

  <!-- Daily avg response time trend -->
  <div class="an-card">
    <div class="an-ch"><div class="an-ct">Avg Response Time Trend</div><div class="an-cs">Daily average (hours) over period</div></div>
    <div class="an-cb"><canvas id="cRespTrend" height="200"></canvas></div>
  </div>

</div>

<!-- Per-agent table -->
<div class="an-card" style="margin-bottom:20px;">
  <div class="an-ch">
    <div>
      <div class="an-ct">Agent Response Times</div>
      <div class="an-cs">Breakdown by assigned agent — sorted by fastest average</div>
    </div>
  </div>
  <div style="overflow-x:auto;">
    <table class="table mx-table" style="margin:0;">
      <thead>
        <tr>
          <th>Agent</th>
          <th style="text-align:center;">Leads</th>
          <th style="text-align:center;">Responded</th>
          <th style="text-align:center;">Avg Response</th>
          <th style="text-align:center;">Fastest</th>
          <th style="text-align:center;">Slowest</th>
          <th style="text-align:center;">Within 1h</th>
          <th style="text-align:center;">Within 4h</th>
          <th style="text-align:center;">Within 24h</th>
          <th>Performance</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($resp_agent_rows): ?>
        <?php foreach ($resp_agent_rows as $ar):
          $avg  = (float)($ar['avg_hrs'] ?? 0);
          $resp = (int)$ar['responded'];
          $tot  = (int)$ar['total_leads'];
          $rate = $tot > 0 ? round($resp / $tot * 100) : 0;
          $w1h  = $resp > 0 ? round((int)$ar['within_1h']  / $resp * 100) : 0;
          $w4h  = $resp > 0 ? round((int)$ar['within_4h']  / $resp * 100) : 0;
          $w24h = $resp > 0 ? round((int)$ar['within_24h'] / $resp * 100) : 0;

          // Color-code avg: green <1h, yellow 1-4h, orange 4-8h, red >8h
          if ($avg <= 0)        $avgColor = '#94a3b8';
          elseif ($avg <= 1)    $avgColor = '#16a34a';
          elseif ($avg <= 4)    $avgColor = '#ca8a04';
          elseif ($avg <= 8)    $avgColor = '#ea580c';
          else                   $avgColor = '#dc2626';

          // Alert if agent exceeds threshold
          $agentAlert = $avg > $resp_threshold && $avg > 0;
        ?>
        <tr style="<?= $agentAlert ? 'background:#fef2f2;' : '' ?>">
          <td style="font-weight:600;display:flex;align-items:center;gap:7px;">
            <?php if ($agentAlert): ?>
            <span title="Exceeds threshold" style="color:#ef4444;font-size:.9rem;">⚠</span>
            <?php endif; ?>
            <a href="<?= APP_URL ?>/leads.php?assigned=<?= $ar['agent_id'] ?>" style="color:var(--gray-800);text-decoration:none;"><?= h($ar['agent_name']) ?></a>
          </td>
          <td style="text-align:center;"><?= $tot ?></td>
          <td style="text-align:center;">
            <?= $resp ?> <span style="font-size:.68rem;color:var(--gray-400);">(<?= $rate ?>%)</span>
          </td>
          <td style="text-align:center;font-weight:700;color:<?= $avgColor ?>;"><?= $avg > 0 ? fmt_hrs($avg) : '—' ?></td>
          <td style="text-align:center;color:#16a34a;"><?= $ar['min_hrs'] > 0 ? fmt_hrs((float)$ar['min_hrs']) : '—' ?></td>
          <td style="text-align:center;color:#ef4444;"><?= $ar['max_hrs'] > 0 ? fmt_hrs((float)$ar['max_hrs']) : '—' ?></td>
          <td style="text-align:center;">
            <div style="display:flex;align-items:center;gap:5px;justify-content:center;">
              <div style="width:40px;height:5px;background:var(--gray-100);border-radius:3px;overflow:hidden;">
                <div style="height:100%;width:<?= $w1h ?>%;background:#16a34a;border-radius:3px;"></div>
              </div>
              <span style="font-size:.72rem;color:var(--gray-600);"><?= $w1h ?>%</span>
            </div>
          </td>
          <td style="text-align:center;">
            <div style="display:flex;align-items:center;gap:5px;justify-content:center;">
              <div style="width:40px;height:5px;background:var(--gray-100);border-radius:3px;overflow:hidden;">
                <div style="height:100%;width:<?= $w4h ?>%;background:#3b82f6;border-radius:3px;"></div>
              </div>
              <span style="font-size:.72rem;color:var(--gray-600);"><?= $w4h ?>%</span>
            </div>
          </td>
          <td style="text-align:center;">
            <div style="display:flex;align-items:center;gap:5px;justify-content:center;">
              <div style="width:40px;height:5px;background:var(--gray-100);border-radius:3px;overflow:hidden;">
                <div style="height:100%;width:<?= $w24h ?>%;background:#8b5cf6;border-radius:3px;"></div>
              </div>
              <span style="font-size:.72rem;color:var(--gray-600);"><?= $w24h ?>%</span>
            </div>
          </td>
          <td>
            <?php
            // Sparkline-style rating
            $stars = $avg <= 0 ? 0 : ($avg <= 1 ? 5 : ($avg <= 2 ? 4 : ($avg <= 4 ? 3 : ($avg <= 8 ? 2 : 1))));
            for ($s=1;$s<=5;$s++) echo '<span style="color:'.($s<=$stars?'#f59e0b':'var(--gray-200)').';">★</span>';
            ?>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php else: ?>
        <tr><td colspan="10" style="text-align:center;padding:32px;color:var(--gray-400);">No response data for this period. Response time is measured when a lead receives its first comment.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Threshold settings -->
<?php if (can('settings','edit')): ?>
<div class="an-card" style="margin-bottom:20px;">
  <div class="an-ch"><div class="an-ct">Response Time Threshold</div><div class="an-cs">Alert when average response time exceeds this value</div></div>
  <div class="an-cb">
    <form method="POST" style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
      <?= csrf_field() ?>
      <input type="hidden" name="tab" value="response">
      <input type="hidden" name="range" value="<?= h($range) ?>">
      <label style="font-size:.8rem;font-weight:600;color:var(--gray-700);">Alert threshold:</label>
      <input type="number" name="resp_threshold" value="<?= $resp_threshold ?>" min="0.25" max="72" step="0.25"
        class="form-control form-control-sm" style="width:80px;">
      <span style="font-size:.8rem;color:var(--gray-500);">hours</span>
      <button type="submit" class="btn btn-primary btn-sm">Save</button>
      <span style="font-size:.74rem;color:var(--gray-400);">Current: <?= fmt_hrs($resp_threshold) ?> · Alerts shown at top of this page if exceeded</span>
    </form>
  </div>
</div>
<?php endif; ?>

<!-- Tips -->
<div class="an-card" style="background:#f0f9ff;border-color:#bae6fd;">
  <div class="an-cb" style="padding:14px 18px;">
    <div style="font-size:.78rem;font-weight:700;color:#0369a1;margin-bottom:8px;">📖 How Response Time is Measured</div>
    <div style="font-size:.75rem;color:#0c4a6e;line-height:1.8;">
      Response time is calculated as the time between a lead's submission and the <strong>first comment</strong> posted by an agent on that lead.
      Leads still in <em>New</em> status with no comments are not counted. For the most accurate data, agents should post a comment when they first contact a lead.
    </div>
  </div>
</div>

<?php endif; // end response tab ?>

<?php if ($tab === 'source_roi'): ?>
<?php
$tier_cfg = [
    'A' => ['bg'=>'#f0fdf4','border'=>'#86efac','text'=>'#15803d','label'=>'A — Top'],
    'B' => ['bg'=>'#eff6ff','border'=>'#93c5fd','text'=>'#1d4ed8','label'=>'B — Good'],
    'C' => ['bg'=>'#fffbeb','border'=>'#fde68a','text'=>'#92400e','label'=>'C — Avg'],
    'D' => ['bg'=>'#fef2f2','border'=>'#fca5a5','text'=>'#991b1b','label'=>'D — Poor'],
];

$total_leads = array_sum(array_column($roi_by_source, 'total'));
$total_conv  = array_sum(array_column($roi_by_source, 'converted'));
$overall_cr  = $total_leads > 0 ? round($total_conv / $total_leads * 100, 1) : 0;
?>

<!-- Summary KPIs -->
<div class="kpi-row" style="margin-bottom:20px;">
  <?php
  $top_src  = $roi_by_source[0] ?? [];
  $best_cr  = !empty($roi_by_source) ? max(array_column($roi_by_source,'conv_rate')) : 0;
  $best_src = '';
  foreach ($roi_by_source as $r) { if ($r['conv_rate'] == $best_cr) { $best_src = $r['source']; break; } }
  $src_count = count($roi_by_source);
  $a_sources = count(array_filter($roi_by_source, function($r){ return $r['tier']==='A'; }));
  $skpis = [
    ['Sources Tracked', $src_count,        '#3b82f6'],
    ['Total Leads',     number_format($total_leads), '#6366f1'],
    ['Overall Conv.',   $overall_cr.'%',   '#16a34a'],
    ['Best Conv. Rate', $best_cr.'%',      '#22c55e'],
    ['Top Source',      h($best_src?:'—'), '#f59e0b'],
    ['Grade A Sources', $a_sources,        '#8b5cf6'],
  ];
  foreach ($skpis as [$lbl,$val,$col]): ?>
  <div class="kpi" style="border-top-color:<?= $col ?>;">
    <div class="kpi-v" style="color:<?= $col ?>;"><?= $val ?></div>
    <div class="kpi-l"><?= $lbl ?></div>
  </div>
  <?php endforeach; ?>
</div>

<div class="g2" style="margin-bottom:20px;">

  <!-- Source volume bar chart -->
  <div class="an-card">
    <div class="an-ch"><div class="an-ct">Lead Volume by Source</div><div class="an-cs">Top sources in period</div></div>
    <div class="an-cb"><canvas id="cSrcVolume" height="200"></canvas></div>
  </div>

  <!-- Conversion rate by source -->
  <div class="an-card">
    <div class="an-ch"><div class="an-ct">Conversion Rate by Source</div><div class="an-cs">% of leads converted</div></div>
    <div class="an-cb"><canvas id="cSrcConv" height="200"></canvas></div>
  </div>

</div>

<!-- Source ROI master table -->
<div class="an-card" style="margin-bottom:20px;">
  <div class="an-ch">
    <div><div class="an-ct">Source Performance Matrix</div><div class="an-cs">Full breakdown — click a source to filter leads</div></div>
  </div>
  <div style="overflow-x:auto;">
    <table class="table mx-table" style="margin:0;">
      <thead>
        <tr>
          <th>Source</th>
          <th>Medium</th>
          <th style="text-align:center;">Grade</th>
          <th style="text-align:center;">Leads</th>
          <th style="text-align:center;">Converted</th>
          <th style="text-align:center;">Conv. Rate</th>
          <th style="text-align:center;">Qualified+</th>
          <th style="text-align:center;">Avg Score</th>
          <th style="text-align:center;">Avg Engage</th>
          <th style="text-align:center;">Avg Response</th>
          <th>Funnel</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($roi_by_source): foreach ($roi_by_source as $rs):
          $tc = $tier_cfg[$rs['tier']];
          $funnel_w_conv = $rs['total'] > 0 ? round($rs['converted']/$rs['total']*100) : 0;
          $funnel_w_qual = $rs['total'] > 0 ? round(($rs['converted']+$rs['qualified'])/$rs['total']*100) : 0;
        ?>
        <tr>
          <td style="font-weight:600;">
            <a href="<?= APP_URL ?>/leads.php?<?= http_build_query(['utm_source'=>$rs['source']!=='(direct)'?$rs['source']:'']) ?>"
               style="color:var(--gray-800);text-decoration:none;">
              <?= h($rs['source']) ?>
            </a>
          </td>
          <td style="font-size:.75rem;color:var(--gray-500);"><?= h($rs['medium']) ?></td>
          <td style="text-align:center;">
            <span style="display:inline-block;padding:2px 8px;border-radius:6px;font-size:.72rem;font-weight:800;background:<?= $tc['bg'] ?>;border:1px solid <?= $tc['border'] ?>;color:<?= $tc['text'] ?>;">
              <?= $tc['label'] ?>
            </span>
          </td>
          <td style="text-align:center;font-weight:600;"><?= number_format($rs['total']) ?></td>
          <td style="text-align:center;color:#16a34a;font-weight:600;"><?= $rs['converted'] ?></td>
          <td style="text-align:center;">
            <span style="font-weight:700;color:<?= $rs['conv_rate']>=$overall_cr?'#16a34a':'#ef4444' ?>;">
              <?= $rs['conv_rate'] ?>%
            </span>
            <?php if ($rs['conv_rate'] >= $overall_cr): ?>
            <span style="font-size:.65rem;color:#16a34a;">▲</span>
            <?php else: ?>
            <span style="font-size:.65rem;color:#ef4444;">▼</span>
            <?php endif; ?>
          </td>
          <td style="text-align:center;color:#8b5cf6;"><?= $rs['qual_rate'] ?>%</td>
          <td style="text-align:center;"><?= $rs['avg_score'] > 0 ? $rs['avg_score'] : '—' ?></td>
          <td style="text-align:center;"><?= $rs['avg_engagement'] > 0 ? $rs['avg_engagement'] : '—' ?></td>
          <td style="text-align:center;font-size:.75rem;color:<?= ($rs['avg_resp_hrs']&&$rs['avg_resp_hrs']>4)?'#ef4444':'#16a34a' ?>;">
            <?= $rs['avg_resp_hrs'] ? fmt_hrs((float)$rs['avg_resp_hrs']) : '—' ?>
          </td>
          <td style="min-width:120px;">
            <div style="position:relative;height:14px;background:var(--gray-100);border-radius:3px;overflow:hidden;">
              <div style="position:absolute;left:0;top:0;height:100%;width:<?= $funnel_w_qual ?>%;background:#8b5cf633;border-radius:3px;"></div>
              <div style="position:absolute;left:0;top:0;height:100%;width:<?= $funnel_w_conv ?>%;background:#16a34a;border-radius:3px;"></div>
            </div>
            <div style="font-size:.64rem;color:var(--gray-400);margin-top:2px;"><?= $funnel_w_conv ?>% conv · <?= $funnel_w_qual ?>% qual+</div>
          </td>
        </tr>
        <?php endforeach; else: ?>
        <tr><td colspan="11" style="text-align:center;padding:32px;color:var(--gray-400);">No source data. Add UTM parameters to your campaign URLs to track source performance.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- UTM tip -->
<div class="an-card" style="background:#f8fafc;border-color:#e2e8f0;">
  <div class="an-cb" style="padding:14px 18px;">
    <div style="font-size:.78rem;font-weight:700;color:#475569;margin-bottom:6px;">💡 Improve source tracking</div>
    <div style="font-size:.74rem;color:#64748b;line-height:1.8;">
      Add UTM parameters to all campaign links: <code style="background:#e2e8f0;padding:1px 5px;border-radius:4px;">?utm_source=google&amp;utm_medium=cpc&amp;utm_campaign=spring25</code>
      <br>Grade A = conv rate ≥ 50 or high avg score · B = 30+ · C = 15+ · D = &lt;15
    </div>
  </div>
</div>
<?php endif; // end source_roi tab ?>


<!-- ═══════════════ JAVASCRIPT ══════════════════════════════ -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<?php if ($tab === 'geo'): ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<?php endif; ?>

<script>
Chart.defaults.font.family = "-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif";
Chart.defaults.color = '#94a3b8';
const GRID_CLR = '#f1f5f9';

<?php if ($tab === 'overview'): ?>
// ── Time chart ───────────────────────────────────────────────
(function(){
  const labels = <?= json_encode(array_column($daily_full,'day')) ?>;
  const total  = <?= json_encode(array_column($daily_full,'n')) ?>;
  const conv   = <?= json_encode(array_column($daily_full,'conv')) ?>;
  const qual   = <?= json_encode(array_column($daily_full,'qual')) ?>;

  new Chart(document.getElementById('cTimeChart'), {
    type: 'bar',
    data: {
      labels: labels.map(d => { const dt=new Date(d+'T12:00:00'); return dt.toLocaleDateString('en',{day:'numeric',month:'short'}); }),
      datasets: [
        { label:'Leads', data:total, backgroundColor:'rgba(59,130,246,.18)', borderColor:'#3b82f6', borderWidth:1.5, borderRadius:3, order:2 },
        { label:'Converted', data:conv, type:'line', borderColor:'#22c55e', backgroundColor:'rgba(34,197,94,.07)', borderWidth:2, pointRadius:0, tension:.4, fill:true, order:1 },
        { label:'Qualified', data:qual, type:'line', borderColor:'#8b5cf6', backgroundColor:'transparent', borderWidth:1.5, pointRadius:0, tension:.4, borderDash:[5,4], order:1 },
      ]
    },
    options: {
      responsive:true, interaction:{mode:'index',intersect:false},
      plugins:{legend:{position:'top',labels:{boxWidth:11,padding:14,font:{size:11}}}},
      scales:{
        x:{grid:{display:false},ticks:{maxTicksLimit:14,font:{size:10}}},
        y:{beginAtZero:true,grid:{color:GRID_CLR},ticks:{stepSize:1,font:{size:10}}}
      }
    }
  });
})();

// ── Status donut ─────────────────────────────────────────────
(function(){
  const cols = <?= json_encode(array_values(array_map(function($s) use ($status_col) { return isset($status_col[$s['status']]) ? $status_col[$s['status']] : '#94a3b8'; }, $by_status))) ?>;
  new Chart(document.getElementById('cStatus'), {
    type:'doughnut',
    data:{ labels:<?= json_encode(array_map('ucfirst',array_column($by_status,'status'))) ?>, datasets:[{ data:<?= json_encode(array_column($by_status,'n')) ?>, backgroundColor:cols, borderWidth:2, borderColor:'#fff' }] },
    options:{ responsive:true, cutout:'68%', plugins:{legend:{display:false}} }
  });
})();

// ── Quality donut ────────────────────────────────────────────
(function(){
  new Chart(document.getElementById('cQuality'), {
    type:'doughnut',
    data:{ labels:['Hot','Warm','Cold','Unscored'],
      datasets:[{ data:[<?= (int)($score_dist['hot']??0) ?>,<?= (int)($score_dist['warm']??0) ?>,<?= (int)($score_dist['cold']??0) ?>,<?= (int)($score_dist['unscored']??0) ?>],
        backgroundColor:['#ef4444','#f59e0b','#3b82f6','#e2e8f0'], borderWidth:2, borderColor:'#fff' }] },
    options:{ responsive:true, cutout:'65%', plugins:{legend:{display:false}} }
  });
})();

<?php if ($by_domain && !$f_domain): ?>
// ── Domain comparison ─────────────────────────────────────────
(function(){
  new Chart(document.getElementById('cDomain'), {
    type:'bar',
    data:{
      labels:<?= json_encode(array_column($by_domain,'domain')) ?>,
      datasets:[
        { label:'Leads', data:<?= json_encode(array_column($by_domain,'n')) ?>, backgroundColor:'rgba(59,130,246,.25)', borderColor:'#3b82f6', borderWidth:1.5, borderRadius:3 },
        { label:'Converted', data:<?= json_encode(array_column($by_domain,'conv')) ?>, backgroundColor:'rgba(34,197,94,.4)', borderColor:'#22c55e', borderWidth:1.5, borderRadius:3 }
      ]
    },
    options:{ responsive:true, plugins:{legend:{position:'top',labels:{boxWidth:10,padding:10,font:{size:10}}}},
      scales:{x:{grid:{display:false},ticks:{font:{size:10}}},y:{beginAtZero:true,grid:{color:GRID_CLR}}} }
  });
})();
<?php endif; ?>

// ── Heatmap ───────────────────────────────────────────────────
(function(){
  const container = document.getElementById('cHeatmap');
  const days   = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const data   = <?= json_encode($heatmap) ?>;
  let maxVal   = 0;
  for(let d=0;d<7;d++) for(let h=0;h<24;h++) if(data[d][h]>maxVal) maxVal=data[d][h];

  const CW=24, CH=20, LW=32, TH=20;
  const W = LW + 24*CW + 6;
  const H = TH + 7*CH + 4;

  let html = `<div style="position:relative;width:${W}px;height:${H}px;user-select:none;">`;
  for(let h=0;h<24;h++){
    const lbl=h===0?'12a':h<12?h+'a':h===12?'12p':(h-12)+'p';
    html+=`<div style="position:absolute;left:${LW+h*CW+1}px;top:1px;font-size:8.5px;color:#94a3b8;width:${CW-2}px;text-align:center;">${lbl}</div>`;
  }
  for(let d=0;d<7;d++){
    html+=`<div style="position:absolute;left:0;top:${TH+d*CH+3}px;font-size:9.5px;color:#64748b;width:${LW-3}px;text-align:right;">${days[d]}</div>`;
    for(let h=0;h<24;h++){
      const v=data[d][h]||0;
      const alpha = maxVal>0 ? 0.06+v/maxVal*0.94 : 0.06;
      const bg = v===0 ? '#f1f5f9' : `rgba(37,99,235,${alpha.toFixed(2)})`;
      const tc = alpha>0.55 ? '#fff' : '#334155';
      const tooltip=`${days[d]} ${h<12?h||12:h-12||12}${h<12?'am':'pm'}: ${v} lead${v!==1?'s':''}`;
      html+=`<div class="hm-cell" title="${tooltip}" style="position:absolute;left:${LW+h*CW+1}px;top:${TH+d*CH+1}px;width:${CW-2}px;height:${CH-2}px;background:${bg};display:flex;align-items:center;justify-content:center;font-size:${v>=10?7:8}px;color:${tc};font-weight:600;">${v||''}</div>`;
    }
  }
  html+='</div>';
  container.innerHTML=html;
})();

<?php elseif ($tab === 'geo'): ?>
// ── World map (Leaflet) ──────────────────────────────────────
(function(){
  const geoData = <?php
    $geo_js = array_map(function($c) use ($country_meta) {
        return [
            'code'   => $c['country'],
            'n'      => (int)$c['n'],
            'conv'   => (int)$c['conv'],
            'coords' => isset($country_meta[$c['country']]) ? $country_meta[$c['country']][1] : null,
            'flag'   => isset($country_meta[$c['country']]) ? $country_meta[$c['country']][0] : '🌍',
        ];
    }, $by_country);
    echo json_encode($geo_js);
  ?>;

  const map = L.map('cWorldMap', { zoomControl:true, scrollWheelZoom:false }).setView([20,5], 2);
  L.tileLayer('https://{s}.basemaps.cartocdn.com/light_nolabels/{z}/{x}/{y}{r}.png', {
    attribution:'&copy; <a href="https://carto.com/">CARTO</a> &copy; OSM',
    subdomains:'abcd', maxZoom:18
  }).addTo(map);

  const maxN = Math.max(1, ...geoData.map(d=>d.n));
  geoData.forEach(d => {
    if (!d.coords) return;
    const r    = Math.max(7, Math.min(38, 7 + (d.n/maxN)*31));
    const pct  = d.n > 0 ? Math.round(d.conv/d.n*100) : 0;
    const alpha= 0.15 + (d.n/maxN)*0.65;
    L.circleMarker(d.coords, {
      radius:r, fillColor:'#3b82f6', color:'#1d4ed8',
      weight:1.5, opacity:.9, fillOpacity:alpha
    }).addTo(map).bindPopup(
      `<b style="font-size:13px;">${d.flag} ${d.code}</b><br>
       <span style="color:#475569;">${d.n.toLocaleString()} leads</span><br>
       <span style="color:#16a34a;">${d.conv} converted (${pct}%)</span>`
    );
  });
})();

<?php elseif ($tab === 'behavioral'): ?>
// ── Weekly trend chart ───────────────────────────────────────
(function(){
  const wd = <?= json_encode($weekly) ?>;
  new Chart(document.getElementById('cWeekly'), {
    type:'bar',
    data:{
      labels: wd.map(w=>'W'+String(w.yw).slice(-2)),
      datasets:[
        { label:'Leads', data:wd.map(w=>w.n), backgroundColor:'rgba(59,130,246,.22)', borderColor:'#3b82f6', borderWidth:1.5, borderRadius:3, yAxisID:'y', order:2 },
        { label:'Win Rate %', data:wd.map(w=>w.rate), type:'line', borderColor:'#22c55e', backgroundColor:'transparent', borderWidth:2, pointRadius:2, pointBackgroundColor:'#22c55e', tension:.4, yAxisID:'y1', order:1 }
      ]
    },
    options:{
      responsive:true, interaction:{mode:'index',intersect:false},
      plugins:{legend:{position:'top',labels:{boxWidth:10,padding:12,font:{size:10}}}},
      scales:{
        x:{grid:{display:false},ticks:{font:{size:10}}},
        y:{beginAtZero:true,grid:{color:GRID_CLR},ticks:{font:{size:10}},position:'left'},
        y1:{beginAtZero:true,max:100,position:'right',grid:{display:false},ticks:{font:{size:10},callback:v=>v+'%'}}
      }
    }
  });
})();

<?php elseif ($tab === 'attribution'): ?>
// ── Sources horizontal bar ─────────────────────────────────
(function(){
  new Chart(document.getElementById('cSources'), {
    type:'bar',
    data:{
      labels:<?= json_encode(array_column($by_source,'source')) ?>,
      datasets:[
        { label:'Leads', data:<?= json_encode(array_column($by_source,'n')) ?>, backgroundColor:'rgba(59,130,246,.25)', borderColor:'#3b82f6', borderWidth:1.5, borderRadius:3 },
        { label:'Converted', data:<?= json_encode(array_column($by_source,'conv')) ?>, backgroundColor:'rgba(34,197,94,.45)', borderColor:'#22c55e', borderWidth:1.5, borderRadius:3 }
      ]
    },
    options:{
      indexAxis:'y', responsive:true,
      plugins:{legend:{position:'top',labels:{boxWidth:10,padding:10,font:{size:10}}}},
      scales:{x:{beginAtZero:true,grid:{color:GRID_CLR},ticks:{font:{size:10}}},y:{grid:{display:false},ticks:{font:{size:11}}}}
    }
  });
})();

<?php elseif ($tab === 'sales'): ?>
// ── Win rate trend line ──────────────────────────────────────
(function(){
  const wd = <?= json_encode($conv_weekly) ?>;
  new Chart(document.getElementById('cWinRate'), {
    type:'line',
    data:{
      labels:wd.map(w=>'W'+String(w.yw).slice(-2)),
      datasets:[{
        label:'Win Rate %', data:wd.map(w=>w.rate),
        borderColor:'#22c55e', backgroundColor:'rgba(34,197,94,.09)',
        borderWidth:2.5, pointRadius:3, pointBackgroundColor:'#22c55e', tension:.4, fill:true
      }]
    },
    options:{
      responsive:true, plugins:{legend:{display:false}},
      scales:{x:{grid:{display:false},ticks:{font:{size:10}}},y:{beginAtZero:true,max:100,grid:{color:GRID_CLR},ticks:{font:{size:10},callback:v=>v+'%'}}}
    }
  });
})();

// ── Pipeline donut ───────────────────────────────────────────
(function(){
  new Chart(document.getElementById('cPipeline'), {
    type:'doughnut',
    data:{
      labels:['Won','Qualified','Contacted','New','Lost'],
      datasets:[{
        data:[<?= $pl_won ?>,<?= $pl_qual ?>,<?= $pl_cont ?>,<?= $pl_new ?>,<?= $pl_lost ?>],
        backgroundColor:['#22c55e','#8b5cf6','#f59e0b','#3b82f6','#94a3b8'],
        borderWidth:2, borderColor:'#fff'
      }]
    },
    options:{ responsive:true, cutout:'65%', plugins:{legend:{display:false}} }
  });
})();
<?php endif; ?>
</script>

<?php if ($tab === 'response'): ?>
<script>
(function(){
  // Distribution bar chart
  const buckets = <?= json_encode(array_keys($bucket_idx)) ?>;
  const counts  = <?= json_encode(array_values($bucket_idx)) ?>;
  const colors  = ['#16a34a','#22c55e','#3b82f6','#f59e0b','#ea580c','#ef4444'];
  const el = document.getElementById('cRespDist');
  if (el) new Chart(el, {
    type: 'bar',
    data: {
      labels: buckets,
      datasets: [{
        label: 'Leads',
        data: counts,
        backgroundColor: colors,
        borderRadius: 5,
        borderWidth: 0,
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { display: false }, ticks: { font: { size: 11 } } },
        y: { beginAtZero: true, grid: { color: GRID_CLR }, ticks: { font: { size: 11 } } }
      }
    }
  });

  // Daily trend line
  const trendData = <?= json_encode($resp_daily) ?>;
  const el2 = document.getElementById('cRespTrend');
  if (el2 && trendData.length) {
    new Chart(el2, {
      type: 'line',
      data: {
        labels: trendData.map(function(r) {
          var d = new Date(r.day+'T12:00:00');
          return d.toLocaleDateString('en',{day:'numeric',month:'short'});
        }),
        datasets: [{
          label: 'Avg Response (hrs)',
          data: trendData.map(function(r){ return parseFloat(r.avg_hrs)||0; }),
          borderColor: '#3b82f6',
          backgroundColor: 'rgba(59,130,246,.08)',
          borderWidth: 2,
          pointRadius: 3,
          tension: 0.4,
          fill: true,
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
          x: { grid: { display: false }, ticks: { font: { size: 10 } } },
          y: {
            beginAtZero: true,
            grid: { color: GRID_CLR },
            ticks: {
              font: { size: 10 },
              callback: function(v) { return v + 'h'; }
            }
          }
        }
      }
    });
  } else if (el2) {
    el2.parentElement.innerHTML = '<div style="text-align:center;padding:40px;color:var(--gray-400);font-size:.8rem;">No trend data for this period</div>';
  }
})();
</script>
<?php endif; ?>

<?php if ($tab === 'source_roi'): ?>
<script>
(function(){
  const labels  = <?= json_encode(array_column($roi_by_source,'source')) ?>;
  const volumes = <?= json_encode(array_column($roi_by_source,'total')) ?>;
  const convRates = <?= json_encode(array_column($roi_by_source,'conv_rate')) ?>;
  const tiers   = <?= json_encode(array_column($roi_by_source,'tier')) ?>;

  const tierColor = { A:'#16a34a', B:'#3b82f6', C:'#f59e0b', D:'#ef4444' };
  const barColors = tiers.map(function(t){ return tierColor[t] || '#94a3b8'; });

  // Volume chart
  const elV = document.getElementById('cSrcVolume');
  if (elV) new Chart(elV, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{ label:'Leads', data: volumes, backgroundColor: barColors, borderRadius: 5, borderWidth: 0 }]
    },
    options: {
      responsive: true, indexAxis: 'y',
      plugins: { legend: { display: false } },
      scales: {
        x: { beginAtZero: true, grid: { color: GRID_CLR }, ticks: { font: { size: 10 } } },
        y: { grid: { display: false }, ticks: { font: { size: 10 } } }
      }
    }
  });

  // Conversion rate chart
  const elC = document.getElementById('cSrcConv');
  if (elC) {
    const overallCr = <?= $overall_cr ?>;
    new Chart(elC, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'Conv. Rate %',
          data: convRates,
          backgroundColor: convRates.map(function(cr){ return cr >= overallCr ? 'rgba(22,163,74,.75)' : 'rgba(239,68,68,.65)'; }),
          borderRadius: 5, borderWidth: 0
        }]
      },
      options: {
        responsive: true, indexAxis: 'y',
        plugins: {
          legend: { display: false },
          annotation: {}
        },
        scales: {
          x: { beginAtZero: true, max: 100, grid: { color: GRID_CLR }, ticks: { font: { size: 10 }, callback: function(v){ return v+'%'; } } },
          y: { grid: { display: false }, ticks: { font: { size: 10 } } }
        }
      }
    });
  }
})();
</script>
<?php endif; ?>

<?php include __DIR__ . '/layouts/footer.php'; ?>
