<?php
require_once __DIR__ . '/config/auth.php';
$user       = require_permission('leads', 'edit');
$is_super   = is_super_admin();
$account_id = (int)($user['account_id'] ?? 0);
$page_title = 'Spam & Abuse Protection';
$active_nav = 'spam';

// ── POST actions ─────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { http_response_code(403); die('CSRF'); }
    $act = isset($_POST['action']) ? $_POST['action'] : '';

    // Block IP
    if ($act === 'block_ip') {
        $ip      = trim(isset($_POST['ip_address']) ? $_POST['ip_address'] : '');
        $reason  = trim(isset($_POST['reason'])     ? $_POST['reason']     : '');
        $scope   = (isset($_POST['scope']) && $_POST['scope'] === 'platform' && $is_super) ? null : $account_id;
        $expires = trim(isset($_POST['expires']) ? $_POST['expires'] : '');
        $exp_val = ($expires === 'permanent' || !$expires) ? null : date('Y-m-d H:i:s', strtotime('+' . $expires));

        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Invalid IP address.'];
        } else {
            $existing = $scope === null
                ? db_fetch('SELECT id FROM ip_blocklist WHERE ip_address = ? AND account_id IS NULL', 's', $ip)
                : db_fetch('SELECT id FROM ip_blocklist WHERE ip_address = ? AND account_id = ?', 'si', $ip, $scope);
            if ($existing) {
                $_SESSION['flash'] = ['type'=>'error','msg'=>'IP already blocked.'];
            } else {
                if ($scope === null) {
                    db_insert('INSERT INTO ip_blocklist (account_id, ip_address, reason, blocked_by, expires_at) VALUES (NULL,?,?,?,?)', 'ssis', $ip, $reason, (int)$user['id'], $exp_val);
                } else {
                    db_insert('INSERT INTO ip_blocklist (account_id, ip_address, reason, blocked_by, expires_at) VALUES (?,?,?,?,?)', 'issis', $scope, $ip, $reason, (int)$user['id'], $exp_val);
                }
                audit('spam.ip_blocked', 'ip:' . $ip);
                $_SESSION['flash'] = ['type'=>'success','msg'=>'IP ' . $ip . ' blocked.'];
            }
        }

    // Unblock IP
    } elseif ($act === 'unblock_ip') {
        $id = (int)(isset($_POST['id']) ? $_POST['id'] : 0);
        // Verify ownership
        if ($is_super) {
            $row = db_fetch('SELECT id, ip_address FROM ip_blocklist WHERE id = ?', 'i', $id);
        } else {
            $row = db_fetch('SELECT id, ip_address FROM ip_blocklist WHERE id = ? AND account_id = ?', 'ii', $id, $account_id);
        }
        if ($row) {
            db_query('DELETE FROM ip_blocklist WHERE id = ?', 'i', $id);
            audit('spam.ip_unblocked', 'ip:' . $row['ip_address']);
            $_SESSION['flash'] = ['type'=>'success','msg'=>'IP unblocked.'];
        }

    // Block email domain
    } elseif ($act === 'block_domain') {
        $domain = strtolower(trim(isset($_POST['domain']) ? $_POST['domain'] : ''));
        $reason = trim(isset($_POST['reason']) ? $_POST['reason'] : '');
        $scope  = (isset($_POST['scope']) && $_POST['scope'] === 'platform' && $is_super) ? null : $account_id;
        $domain = ltrim($domain, '@');

        if (!$domain || !preg_match('/^[a-z0-9][a-z0-9\.\-]+\.[a-z]{2,}$/', $domain)) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Invalid domain format.'];
        } else {
            $existing = $scope === null
                ? db_fetch('SELECT id FROM email_domain_blocklist WHERE domain = ? AND account_id IS NULL', 's', $domain)
                : db_fetch('SELECT id FROM email_domain_blocklist WHERE domain = ? AND account_id = ?', 'si', $domain, $scope);
            if ($existing) {
                $_SESSION['flash'] = ['type'=>'error','msg'=>'Domain already blocked.'];
            } else {
                if ($scope === null) {
                    db_insert('INSERT INTO email_domain_blocklist (account_id, domain, reason, blocked_by) VALUES (NULL,?,?,?)', 'ssi', $domain, $reason, (int)$user['id']);
                } else {
                    db_insert('INSERT INTO email_domain_blocklist (account_id, domain, reason, blocked_by) VALUES (?,?,?,?)', 'issi', $scope, $domain, $reason, (int)$user['id']);
                }
                $_SESSION['flash'] = ['type'=>'success','msg'=>'Domain @' . $domain . ' blocked.'];
            }
        }

    // Remove email domain
    } elseif ($act === 'remove_domain') {
        $id = (int)(isset($_POST['id']) ? $_POST['id'] : 0);
        if ($is_super) {
            $row = db_fetch('SELECT id, domain FROM email_domain_blocklist WHERE id = ?', 'i', $id);
        } else {
            $row = db_fetch('SELECT id, domain FROM email_domain_blocklist WHERE id = ? AND account_id = ?', 'ii', $id, $account_id);
        }
        if ($row) {
            db_query('DELETE FROM email_domain_blocklist WHERE id = ?', 'i', $id);
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Domain removed.'];
        }

    // Add keyword rule
    } elseif ($act === 'add_keyword') {
        $keyword = strtolower(trim(isset($_POST['keyword']) ? $_POST['keyword'] : ''));
        $kaction = (isset($_POST['kaction']) && $_POST['kaction'] === 'block') ? 'block' : 'flag';
        $scope   = (isset($_POST['scope']) && $_POST['scope'] === 'platform' && $is_super) ? null : $account_id;

        if (strlen($keyword) < 2) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Keyword too short.'];
        } else {
            $existing = $scope === null
                ? db_fetch('SELECT id FROM spam_keyword_rules WHERE keyword = ? AND account_id IS NULL', 's', $keyword)
                : db_fetch('SELECT id FROM spam_keyword_rules WHERE keyword = ? AND account_id = ?', 'si', $keyword, $scope);
            if ($existing) {
                $_SESSION['flash'] = ['type'=>'error','msg'=>'Keyword already exists.'];
            } else {
                if ($scope === null) {
                    db_insert('INSERT INTO spam_keyword_rules (account_id, keyword, action, blocked_by) VALUES (NULL,?,?,?)', 'ssi', $keyword, $kaction, (int)$user['id']);
                } else {
                    db_insert('INSERT INTO spam_keyword_rules (account_id, keyword, action, blocked_by) VALUES (?,?,?,?)', 'issi', $scope, $keyword, $kaction, (int)$user['id']);
                }
                $_SESSION['flash'] = ['type'=>'success','msg'=>'"' . $keyword . '" added.'];
            }
        }

    // Remove keyword
    } elseif ($act === 'remove_keyword') {
        $id = (int)(isset($_POST['id']) ? $_POST['id'] : 0);
        if ($is_super) {
            db_query('DELETE FROM spam_keyword_rules WHERE id = ?', 'i', $id);
        } else {
            db_query('DELETE FROM spam_keyword_rules WHERE id = ? AND account_id = ?', 'ii', $id, $account_id);
        }
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Keyword removed.'];

    // Mark lead as not-spam
    } elseif ($act === 'not_spam') {
        $lead_id = (int)(isset($_POST['lead_id']) ? $_POST['lead_id'] : 0);
        if ($is_super) {
            db_query('UPDATE leads SET status = ?, spam_score = 0, notes = NULL WHERE id = ?', 'si', 'new', $lead_id);
        } else {
            db_query('UPDATE leads SET status = ?, spam_score = 0, notes = NULL WHERE id = ? AND account_id = ?', 'sii', 'new', $lead_id, $account_id);
        }
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Lead moved to inbox.'];

    // Delete spam lead
    } elseif ($act === 'delete_lead') {
        $lead_id = (int)(isset($_POST['lead_id']) ? $_POST['lead_id'] : 0);
        if ($is_super) {
            db_query('DELETE FROM leads WHERE id = ?', 'i', $lead_id);
        } else {
            db_query('DELETE FROM leads WHERE id = ? AND account_id = ?', 'ii', $lead_id, $account_id);
        }
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Lead deleted.'];

    // Bulk delete all spam
    } elseif ($act === 'bulk_delete_spam') {
        if ($is_super) {
            db_query("DELETE FROM leads WHERE status = 'spam'");
        } else {
            db_query("DELETE FROM leads WHERE status = 'spam' AND account_id = ?", 'i', $account_id);
        }
        $_SESSION['flash'] = ['type'=>'success','msg'=>'All spam leads deleted.'];
    }

    header('Location: ' . APP_URL . '/spam.php' . (isset($_GET['tab']) ? '?tab=' . urlencode($_GET['tab']) : ''));
    exit;
}

$flash      = isset($_SESSION['flash']) ? $_SESSION['flash'] : null;
unset($_SESSION['flash']);
$active_tab = in_array(isset($_GET['tab']) ? $_GET['tab'] : '', ['ips','domains','keywords','queue']) ? $_GET['tab'] : 'overview';

// ── Load data ────────────────────────────────────────────────

// Stats
if ($is_super) {
    $stat_spam_total   = (int)(db_fetch("SELECT COUNT(*) AS n FROM leads WHERE status='spam'")['n'] ?? 0);
    $stat_spam_today   = (int)(db_fetch("SELECT COUNT(*) AS n FROM leads WHERE status='spam' AND DATE(submitted_at)=CURDATE()")['n'] ?? 0);
    $stat_ips_blocked  = (int)(db_fetch("SELECT COUNT(*) AS n FROM ip_blocklist")['n'] ?? 0);
    $stat_auto_blocked = (int)(db_fetch("SELECT COUNT(*) AS n FROM ip_blocklist WHERE auto_blocked=1")['n'] ?? 0);
    $stat_domains      = (int)(db_fetch("SELECT COUNT(*) AS n FROM email_domain_blocklist")['n'] ?? 0);
    $stat_keywords     = (int)(db_fetch("SELECT COUNT(*) AS n FROM spam_keyword_rules")['n'] ?? 0);
    // Top offending IPs (last 24h)
    $top_ips = db_fetch_all(
        "SELECT ip_address, COUNT(*) AS n, SUM(spam_score) AS total_score
         FROM leads WHERE status='spam' AND submitted_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
         GROUP BY ip_address ORDER BY n DESC LIMIT 10"
    );
} else {
    $stat_spam_total   = (int)(db_fetch("SELECT COUNT(*) AS n FROM leads WHERE status='spam' AND account_id=?", 'i', $account_id)['n'] ?? 0);
    $stat_spam_today   = (int)(db_fetch("SELECT COUNT(*) AS n FROM leads WHERE status='spam' AND account_id=? AND DATE(submitted_at)=CURDATE()", 'i', $account_id)['n'] ?? 0);
    $stat_ips_blocked  = (int)(db_fetch("SELECT COUNT(*) AS n FROM ip_blocklist WHERE account_id=?", 'i', $account_id)['n'] ?? 0);
    $stat_auto_blocked = (int)(db_fetch("SELECT COUNT(*) AS n FROM ip_blocklist WHERE account_id=? AND auto_blocked=1", 'i', $account_id)['n'] ?? 0);
    $stat_domains      = (int)(db_fetch("SELECT COUNT(*) AS n FROM email_domain_blocklist WHERE account_id IS NULL OR account_id=?", 'i', $account_id)['n'] ?? 0);
    $stat_keywords     = (int)(db_fetch("SELECT COUNT(*) AS n FROM spam_keyword_rules WHERE account_id IS NULL OR account_id=?", 'i', $account_id)['n'] ?? 0);
    $top_ips = db_fetch_all(
        "SELECT ip_address, COUNT(*) AS n, SUM(spam_score) AS total_score
         FROM leads WHERE status='spam' AND account_id=? AND submitted_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
         GROUP BY ip_address ORDER BY n DESC LIMIT 10",
        'i', $account_id
    );
}

// IP blocklist
if ($is_super) {
    $ip_blocks = db_fetch_all(
        'SELECT b.*, u.first_name, u.last_name, a.name AS account_name
         FROM ip_blocklist b
         LEFT JOIN users u ON u.id = b.blocked_by
         LEFT JOIN accounts a ON a.id = b.account_id
         ORDER BY b.created_at DESC LIMIT 200'
    );
} else {
    $ip_blocks = db_fetch_all(
        'SELECT b.*, u.first_name, u.last_name, NULL AS account_name
         FROM ip_blocklist b
         LEFT JOIN users u ON u.id = b.blocked_by
         WHERE b.account_id = ? OR b.account_id IS NULL
         ORDER BY b.account_id IS NULL ASC, b.created_at DESC LIMIT 200',
        'i', $account_id
    );
}

// Email domains
if ($is_super) {
    $domains = db_fetch_all('SELECT d.*, u.first_name, u.last_name, a.name AS account_name FROM email_domain_blocklist d LEFT JOIN users u ON u.id=d.blocked_by LEFT JOIN accounts a ON a.id=d.account_id ORDER BY d.account_id IS NOT NULL, d.domain');
} else {
    $domains = db_fetch_all('SELECT d.*, u.first_name, u.last_name, NULL AS account_name FROM email_domain_blocklist d LEFT JOIN users u ON u.id=d.blocked_by WHERE d.account_id IS NULL OR d.account_id=? ORDER BY d.account_id IS NOT NULL, d.domain', 'i', $account_id);
}

// Keywords
if ($is_super) {
    $keywords = db_fetch_all('SELECT k.*, u.first_name, u.last_name, a.name AS account_name FROM spam_keyword_rules k LEFT JOIN users u ON u.id=k.blocked_by LEFT JOIN accounts a ON a.id=k.account_id ORDER BY k.account_id IS NOT NULL, k.keyword');
} else {
    $keywords = db_fetch_all('SELECT k.*, u.first_name, u.last_name, NULL AS account_name FROM spam_keyword_rules k LEFT JOIN users u ON u.id=k.blocked_by WHERE k.account_id IS NULL OR k.account_id=? ORDER BY k.account_id IS NOT NULL, k.keyword', 'i', $account_id);
}

// Spam queue (recent spam leads)
if ($is_super) {
    $spam_queue = db_fetch_all(
        "SELECT l.*, f.name AS form_name, a.name AS account_name
         FROM leads l
         JOIN lead_forms f ON f.id = l.form_id
         JOIN accounts a ON a.id = l.account_id
         WHERE l.status = 'spam'
         ORDER BY l.submitted_at DESC LIMIT 100"
    );
} else {
    $spam_queue = db_fetch_all(
        "SELECT l.*, f.name AS form_name, NULL AS account_name
         FROM leads l
         JOIN lead_forms f ON f.id = l.form_id
         WHERE l.status = 'spam' AND l.account_id = ?
         ORDER BY l.submitted_at DESC LIMIT 100",
        'i', $account_id
    );
}

// For spam queue: get first email/name value per lead
$lead_previews = [];
if ($spam_queue) {
    $ids = implode(',', array_map(function($r) { return (int)$r['id']; }, $spam_queue));
    $vals = db_fetch_all("SELECT lead_id, field_key, field_label, value FROM lead_values WHERE lead_id IN ($ids) ORDER BY id ASC");
    foreach ($vals as $v) {
        $lid = (int)$v['lead_id'];
        if (!isset($lead_previews[$lid])) $lead_previews[$lid] = ['name'=>'','email'=>''];
        $lbl = strtolower($v['field_key'] . ' ' . $v['field_label']);
        if (!$lead_previews[$lid]['email'] && (strpos($lbl,'email') !== false)) $lead_previews[$lid]['email'] = $v['value'];
        if (!$lead_previews[$lid]['name']  && (strpos($lbl,'name') !== false))  $lead_previews[$lid]['name']  = $v['value'];
    }
}

include __DIR__ . '/layouts/header.php';
?>

<?php if ($flash): ?>
<div class="alert alert-<?= h($flash['type']) ?> mb-4" data-auto-dismiss><?= h($flash['msg']) ?></div>
<?php endif; ?>

<div class="page-header">
    <div>
        <h1 class="page-title">Spam &amp; Abuse Protection</h1>
        <p class="page-subtitle">Two-layer filtering: hard blocks + smart scoring</p>
    </div>
</div>

<!-- Tabs -->
<div class="tabs-pill mb-3">
    <?php foreach ([
    'overview' => 'Overview',
    'ips'      => 'IP Blocklist (' . $stat_ips_blocked . ')',
    'domains'  => 'Email Domains (' . $stat_domains . ')',
    'keywords' => 'Keywords (' . $stat_keywords . ')',
    'queue'    => 'Spam Queue (' . $stat_spam_total . ')',
  ] as $tab => $lbl): ?>
    <a href="?tab=<?= $tab ?>" class="tab-pill <?= ($active_tab===$tab) ? 'on' : '' ?>">
        <?= h($lbl) ?>
    </a>
    <?php endforeach; ?>
</div>

<?php if ($active_tab === 'overview'): ?>

<!-- Stats row -->
<div class="grid grid-cols-4 gap-4">
    <?php foreach ([
        ['Spam Caught Today', $stat_spam_today,   'card-b2',    'spam'],
        ['Total Spam',        $stat_spam_total,   'card-b3',    'spam'],
        ['IPs Blocked',       $stat_ips_blocked,  'card-b4',    'globe-02'],
        ['Auto-Blocked IPs',  $stat_auto_blocked, 'card-b5',    'globe-02'],
      ] as [$label, $val, $color, $icon]): 
    ?>
    
    <div class="card card-stat <?= $color ?>">        
        <div>
            <div class="card-label"><?= $label ?></div>
            <div class="card-value mt-1"><?= $val ?></div>
        </div>
        <i class="hgi hgi-stroke hgi-<?= $icon ?>"></i>
    </div>
    <?php endforeach; ?>
</div>

<!-- Layer diagram -->
<div class="card">
    <div class="card-header">
        <div class="card-title">Protection Layers</div>
    </div>
    <div class="card-body grid grid-cols-2 gap-6">
        <?php foreach ([
              ['Layer 1 — Hard Block', 'var(--danger-10)','var(--danger)', [
                'IP Blocklist (manual + auto)' => 'Request rejected silently',
                'Honeypot field filled'        => 'Silent drop — bot sees success',
                'Submission < 2 seconds'       => 'Silent drop',
              ]],
              ['Layer 2 — Soft Score', 'var(--warning-10)','var(--warning)', [
                'Rate limit (10/hr/form)'      => '+50 spam score',
                'Global rate limit (30/hr)'    => '+50 — auto-blocks at 50/hr',
                'Duplicate email (5 min)'      => '+40 spam score',
                'Blocked email domain'         => '+60 spam score',
                'Spam keyword match'           => '+30–80 (flag or block)',
                'Bot user agent'               => '+25 spam score',
                'All fields identical'         => '+35 spam score',
              ]],
            ] as [$title, $bg, $color, $items]): 
        ?>
        <div>
            <div class="flex gap-2 items-center mb-2">
                <div class="icon-block" style="background: <?= $bg ?>; color:<?= $color ?>;">L<?= $title[6] ?></div>
                <span class="font-semibold text-md"><?= $title ?></span>
            </div>
            <?php foreach ($items as $check => $result): ?>
            <div class="card-row">
                <div><?= h($check) ?></div>
                <div class="badge" style="background: <?= $bg ?>; color:<?= $color ?>;"><?= h($result) ?></div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="card-footer">
        <strong>Score threshold:</strong> &nbsp;0–49 = new lead &nbsp;·&nbsp; 50–99 = saved as spam &nbsp;·&nbsp; 100+ = silent drop (not saved)
    </div>
</div>

<!-- Top offending IPs (last 24h) -->
<?php if ($top_ips): ?>
<div class="card">
    <div class="card-header">
        <div class="card-title">Top Offending IPs — Last 24 Hours</div>
        <a href="?tab=ips" class="btn btn-secondary btn-sm">Manage All<i class="hgi hgi-stroke hgi-arrow-right-02"></i></a>
    </div>
    <table class="table card-body">
        <thead>
            <tr>
                <th>IP Address</th>
                <th>Spam Submissions</th>
                <th>Total Score</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($top_ips as $tip): ?>
            <tr>
                <td style="font-family:var(--font-mono);"><?= h($tip['ip_address']) ?></td>
                <td><span class="badge badge-red"><?= (int)$tip['n'] ?> submissions</span></td>
                <td style="color:var(--gray-50);"><?= (int)$tip['total_score'] ?></td>
                <td>
                    <form method="POST" style="display:inline;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="block_ip">
                        <input type="hidden" name="ip_address" value="<?= h($tip['ip_address']) ?>">
                        <input type="hidden" name="reason" value="High spam volume">
                        <input type="hidden" name="expires" value="permanent">
                        <?php if ($is_super): ?><input type="hidden" name="scope" value="platform"><?php endif; ?>
                        <button class="btn btn-danger btn-sm" type="submit"><i class="hgi hgi-stroke hgi-cancel-circle"></i>Block IP</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php elseif ($active_tab === 'ips'): ?>

<div class="page-cols">
    <!-- Add IP form -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">Block an IP</div>
        </div>
        <form method="POST">
            <div class="card-body">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="block_ip">
                <div class="form-group">
                    <label class="form-label">IP Address</label>
                    <input type="text" name="ip_address" class="form-control" placeholder="192.168.1.1" required pattern="^(\d{1,3}\.){3}\d{1,3}$|^[0-9a-fA-F:]+$">
                </div>
                <div class="form-group">
                    <label class="form-label">Reason</label>
                    <input type="text" name="reason" class="form-control" placeholder="Spam, abuse, etc." maxlength="255">
                </div>
                <div class="form-group">
                    <label class="form-label">Expires</label>
                    <select name="expires" class="form-control">
                        <option value="permanent">Permanent</option>
                        <option value="1 day">24 hours</option>
                        <option value="7 days">7 days</option>
                        <option value="30 days">30 days</option>
                        <option value="90 days">90 days</option>
                    </select>
                </div>
                <?php if ($is_super): ?>
                <div class="form-group">
                    <label class="form-label">Scope</label>
                    <select name="scope" class="form-control">
                        <option value="platform">Platform-wide (all accounts)</option>
                        <option value="account">This account only</option>
                    </select>
                </div>
                <?php endif; ?>
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-danger w-full"><i class="hgi hgi-stroke hgi-cancel-circle"></i>Block IP</button>
            </div>
        </form>
    </div>
    
    
    <div>
        <div class="card">
            <div class="card-header">
                <div class="card-title">Blocked IPs</div>
                <div class="card-subtitle"><?= count($ip_blocks) ?> total</div>
            </div>
            <?php if ($ip_blocks): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>IP Address</th>
                        <th>Reason</th><?php if($is_super):?><th>Scope</th><?php endif;?><th>Blocked By</th>
                        <th>Expires</th>
                        <th>Hits</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($ip_blocks as $b):
                        $is_platform = ($b['account_id'] === null);
                        $is_auto     = (bool)$b['auto_blocked'];
                        $expired     = $b['expires_at'] && strtotime($b['expires_at']) < time();
                    ?>
                    <tr style="<?= $expired ? 'opacity:.5;' : '' ?>">
                        <td style="font-family:var(--font-mono);">
                            <?= h($b['ip_address']) ?>
                            <?php if ($is_auto): ?><span class="badge badge-blue">auto</span><?php endif; ?>
                            <?php if ($expired): ?><span class="badge badge-gray">expired</span><?php endif; ?>
                        </td>
                        <td><?= h($b['reason'] ?? '—') ?></td>
                        <?php if ($is_super): ?>
                        <td><span class="badge <?= $is_platform ? 'badge-outline-danger' : 'badge-outline-warning' ?>"><?= $is_platform ? 'Platform' : h($b['account_name'] ?? 'Account') ?></span></td>
                        <?php endif; ?>
                        <td><?= $b['blocked_by'] ? h($b['first_name'] . ' ' . $b['last_name']) : '<span style="color:var(--gray-40)">System</span>' ?></td>
                        <td><?= $b['expires_at'] ? format_dt($b['expires_at'], 'd M Y') : '∞ Permanent' ?></td>
                        <td><span class="badge badge-gray"><?= number_format((int)$b['hit_count']) ?></span></td>
                        <td class="text-right">
                            <?php if ($is_super || !$is_platform): ?>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Unblock this IP?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="unblock_ip">
                                <input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
                                <button class="btn btn-outline btn-sm" type="submit"><i class="hgi hgi-stroke hgi-cancel-circle"></i>Unblock</button>
                            </form>
                            <?php else: ?>
                            <span class="badge badge-warning">Platform-wide</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div class="py-8 text-sm text-muted text-center">No IPs blocked yet.</div>
            <?php endif; ?>
        </div>
    </div>

    
</div>

<?php elseif ($active_tab === 'domains'): ?>

<div class="page-cols">
    
    <div class="card">
        <div class="card-header">
            <div class="card-title">Block a Domain</div>
        </div>
        <form method="POST">
            <div class="card-body">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="block_domain">
                <div class="form-group">
                    <label class="form-label">Domain</label>
                    <input type="text" name="domain" class="form-control" placeholder="mailinator.com" required>
                    <div class="form-help">Enter without @ sign</div>
                </div>
                <div class="form-group">
                    <label class="form-label">Reason</label>
                    <input type="text" name="reason" class="form-control" placeholder="Disposable, competitor, etc.">
                </div>
                <?php if ($is_super): ?>
                <div class="form-group">
                    <label class="form-label">Scope</label>
                    <select name="scope" class="form-control">
                        <option value="platform">Platform-wide</option>
                        <option value="account">This account only</option>
                    </select>
                </div>
                <?php endif; ?>
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-danger w-full"><i class="hgi hgi-stroke hgi-cancel-circle"></i>Block Domain</button>
            </div>
        </form>
    </div>
    
    <div class="card">
        <div class="card-header">
            <div class="card-title">Blocked Email Domains</div>
            <div class="card-subtitle"><?= count($domains) ?> total</div>
        </div>
        <?php if ($domains): ?>
        <table class="table" style="margin:0;">
            <thead>
                <tr>
                    <th>Domain</th>
                    <th>Reason</th><?php if($is_super):?><th>Scope</th><?php endif;?><th>Added</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($domains as $d):
                  $is_platform = ($d['account_id'] === null);
                ?>
                <tr>
                    <td style="font-family:var(--font-mono);">@<?= h($d['domain']) ?></td>
                    <td><span class="badge badge-outline-grey badge-sm"><?= h($d['reason'] ?? '—') ?></span></td>
                    <?php if ($is_super): ?>
                    <td><span class="badge badge-sm <?= $is_platform ? 'badge-outline-danger' : 'badge-outline-warning' ?>"><?= $is_platform ? 'Platform' : h($d['account_name'] ?? 'Account') ?></span></td>
                    <?php endif; ?>
                    <td><?= format_dt($d['created_at'], 'd M Y') ?></td>
                    <td class="text-right">
                        <?php if ($is_super || !$is_platform): ?>
                        <form method="POST" style="display:inline;" onsubmit="return confirm('Remove this domain block?')">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="remove_domain">
                            <input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
                            <button class="btn btn-danger btn-sm" type="submit"><i class="hgi hgi-stroke hgi-cancel-circle"></i>Remove</button>
                        </form>
                        <?php else: ?>
                        <span>Platform</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="py-8 text-center text-muted text-sm">No domains blocked.</div>
        <?php endif; ?>
    </div>

    
</div>

<?php elseif ($active_tab === 'keywords'): ?>

<div class="page-cols">
    <div class="card">
        <div class="card-header">
            <div class="card-title">Add Keyword Rule</div>
        </div>
        <form method="POST">
            <div class="card-body">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="add_keyword">
                <div class="form-group">
                    <label class="form-label">Keyword / Phrase</label>
                    <input type="text" name="keyword" class="form-control" placeholder="e.g. casino, buy now" required maxlength="255">
                    <div class="form-help">Case-insensitive, partial match</div>
                </div>
                <div class="form-group">
                    <label class="form-label">Action</label>
                    <select name="kaction" class="form-control">
                        <option value="flag">Flag as spam (save + mark spam)</option>
                        <option value="block">Block silently (drop, show success)</option>
                    </select>
                </div>
                <?php if ($is_super): ?>
                <div class="form-group">
                    <label class="form-label">Scope</label>
                    <select name="scope" class="form-control">
                        <option value="platform">Platform-wide</option>
                        <option value="account">This account only</option>
                    </select>
                </div>
                <?php endif; ?>
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-primary btn-sm w-full"><i class="hgi hgi-stroke hgi-cancel-circle"></i>Add Rule</button>
            </div>
        </form>
    </div>
    
    <div class="card">
        <div class="card-header">
            <div class="card-title">Spam Keyword Rules</div>
            <div class="card-subtitle"><?= count($keywords) ?> rules</div>
        </div>
        <?php if ($keywords): ?>
        <table class="table" style="margin:0;">
            <thead>
                <tr>
                    <th>Keyword</th>
                    <th>Action</th><?php if($is_super):?><th>Scope</th><?php endif;?><th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($keywords as $kw):
                  $is_platform = ($kw['account_id'] === null);
                ?>
                <tr>
                    <td style="font-family:var(--font-mono);"><?= h($kw['keyword']) ?></td>
                    <td>
                        <span class="badge badge-sm <?= $kw['action']==='block' ? 'badge-outline-danger' : 'badge-outline-warning' ?>">
                            <?= $kw['action'] === 'block' ? '<i class="hgi hgi-stroke hgi-cancel-circle"></i>Block' : '<i class="hgi hgi-stroke hgi-flag-01"></i>Flag' ?>
                        </span>
                    </td>
                    <?php if ($is_super): ?>
                    <td><span class="badge <?= $is_platform ? 'badge-outline-danger' : 'badge-outline-warning' ?>"><?= $is_platform ? 'Platform' : h($kw['account_name'] ?? 'Account') ?></span></td>
                    <?php endif; ?>
                    <td class="text-right">
                        <?php if ($is_super || !$is_platform): ?>
                        <form method="POST" style="display:inline;" onsubmit="return confirm('Remove keyword?')">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="remove_keyword">
                            <input type="hidden" name="id" value="<?= (int)$kw['id'] ?>">
                            <button class="btn btn-danger btn-sm" type="submit"><i class="hgi hgi-stroke hgi-cancel-circle"></i>Remove</button>
                        </form>
                        <?php else: ?>
                        <span>Platform</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="py-8 text-center text-muted text-sm">No keyword rules.</div>
        <?php endif; ?>
    </div>

    
</div>

<?php elseif ($active_tab === 'queue'): ?>

<div class="card">
    <div class="card-header">
        <div>
            <div class="card-title">Spam Queue</div>
            <div class="card-subtitle"><?= $stat_spam_total ?> spam leads</div>
        </div>
        <?php if ($stat_spam_total > 0): ?>
        <form method="POST" style="margin-left:auto;" onsubmit="return confirm('Delete ALL spam leads permanently? This cannot be undone.')">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="bulk_delete_spam">
            <button class="btn btn-danger btn-sm" type="submit"><i class="hgi hgi-stroke hgi-delete-02"></i>Delete All Spam</button>
        </form>
        <?php endif; ?>
    </div>
    <?php if ($spam_queue): ?>
    <table class="table">
        <thead>
            <tr>
                <th>Lead</th>
                <th>IP Address</th>
                <th>Score</th>
                <th>Reason</th>
                <?php if ($is_super): ?><th>Account</th><?php endif; ?>
                <th>Date</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($spam_queue as $lead):
                $prev  = isset($lead_previews[$lead['id']]) ? $lead_previews[$lead['id']] : ['name'=>'','email'=>''];
                $score = (int)($lead['spam_score'] ?? 0);
                $score_color = $score >= 80 ? '#dc2626' : ($score >= 50 ? '#d97706' : '#64748b');
            ?>
            <tr>
                <td>
                    <div style="font-size:.82rem;font-weight:600;"><?= $prev['name'] ? h($prev['name']) : '<span style="color:var(--gray-400)">—</span>' ?></div>
                    <div style="font-size:.72rem;color:var(--gray-400);"><?= $prev['email'] ? h($prev['email']) : h($lead['reference_no']) ?></div>
                </td>
                <td style="font-family:var(--font-mono);font-size:.8rem;color:var(--gray-500);"><?= h($lead['ip_address'] ?? '—') ?></td>
                <td>
                    <span style="font-size:.8rem;font-weight:700;color:<?= $score_color ?>;"><?= $score ?></span>
                </td>
                <td style="font-size:.72rem;color:var(--gray-500);max-width:160px;">
                    <?= $lead['notes'] ? h(str_replace(['[Spam flags: ',']'],'',$lead['notes'])) : '—' ?>
                </td>
                <?php if ($is_super): ?><td style="font-size:.78rem;"><?= h($lead['account_name'] ?? '—') ?></td><?php endif; ?>
                <td style="font-size:.75rem;color:var(--gray-400);"><?= format_dt($lead['submitted_at'], 'd M H:i') ?></td>
                <td>
                    <div style="display:flex;gap:4px;flex-wrap:nowrap;">
                        <!-- Block IP from spam queue -->
                        <?php if ($lead['ip_address']): ?>
                        <form method="POST" style="display:inline;" onsubmit="return confirm('Block IP <?= h($lead['ip_address']) ?>?')">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="block_ip">
                            <input type="hidden" name="ip_address" value="<?= h($lead['ip_address']) ?>">
                            <input type="hidden" name="reason" value="Blocked from spam queue">
                            <input type="hidden" name="expires" value="permanent">
                            <?php if ($is_super): ?><input type="hidden" name="scope" value="platform"><?php endif; ?>
                            <button class="btn btn-secondary btn-sm" type="submit" title="Block IP">🚫</button>
                        </form>
                        <?php endif; ?>
                        <!-- Not spam -->
                        <form method="POST" style="display:inline;">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="not_spam">
                            <input type="hidden" name="lead_id" value="<?= (int)$lead['id'] ?>">
                            <button class="btn btn-secondary btn-sm" type="submit" title="Not spam — move to inbox">✓</button>
                        </form>
                        <!-- Delete -->
                        <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this lead?')">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="delete_lead">
                            <input type="hidden" name="lead_id" value="<?= (int)$lead['id'] ?>">
                            <button class="btn btn-danger btn-sm" type="submit" title="Delete">✕</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
    <div class="empty-state">
        <div class="empty-state-icon">
            <i class="hgi hgi-stroke hgi-web-protection"></i>
        </div>
        <div class="empty-state-title">Spam queue is empty</div>
        <div class="empty-state-desc">All submissions are clean.</div>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php include __DIR__ . '/layouts/footer.php'; ?>