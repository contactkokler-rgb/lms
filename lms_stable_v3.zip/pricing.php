<?php
/**
 * Pricing Plans & Services Management (Super Admin)
 */
require_once __DIR__ . '/config/auth.php';
$user = require_permission('billing', 'manage_pricing');
if (!is_super_admin()) {
    $_SESSION['flash'] = ['type'=>'error','msg'=>'Access denied'];
    header('Location: ' . APP_URL . '/index.php'); exit;
}

$page_title = 'Pricing Plans';
$active_nav = 'pricing';
$action  = $_GET['action'] ?? '';
$plan_id = (int)($_GET['id'] ?? 0);
$tab     = $_GET['tab'] ?? 'plans';

// All platform services catalog
$ALL_SERVICES = [
    'campaigns'       => ['label' => 'Campaigns',        'icon' => 'hgi-rocket-02'],
    'landing_pages'   => ['label' => 'Landing Pages',    'icon' => 'hgi-web-design-01'],
    'seo_auditor'     => ['label' => 'SEO Auditor',       'icon' => 'hgi-search-visual'],
    'reports'         => ['label' => 'Reports',           'icon' => 'hgi-chart-bar-line'],
    'sales_reports'   => ['label' => 'Sales Reports',    'icon' => 'hgi-trending-up-01'],
    'lead_scoring'    => ['label' => 'Lead Scoring',     'icon' => 'hgi-star-02'],
    'spam_protection' => ['label' => 'Spam Protection',  'icon' => 'hgi-shield-01'],
];

// Handle toggle via GET (legacy)
if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'toggle' && $plan_id > 0) {
    db_query('UPDATE pricing_plans SET is_active = NOT is_active WHERE id = ?', 'i', $plan_id);
    header('Location: ' . APP_URL . '/pricing.php?tab=plans'); exit;
}

// POST handling
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { http_response_code(403); die('CSRF'); }

    $post_action = $_POST['post_action'] ?? '';

    if ($post_action === 'create_plan' || $post_action === 'edit_plan') {
        $name         = trim($_POST['name'] ?? '');
        $slug         = trim($_POST['slug'] ?? '');
        $price        = (float)($_POST['price'] ?? 0);
        $domains      = (int)($_POST['domains_limit'] ?? 1);
        $forms        = (int)($_POST['forms_limit'] ?? 3);
        $leads        = (int)($_POST['leads_per_month'] ?? 100);
        $team_members = (int)($_POST['team_members_limit'] ?? 1);
        $description  = trim($_POST['description'] ?? '');

        if ($post_action === 'create_plan' && $name && $slug) {
            $stmt = db()->prepare('INSERT INTO pricing_plans (name,slug,description,price_monthly,domains_limit,forms_limit,leads_per_month,team_members_limit) VALUES (?,?,?,?,?,?,?,?)');
            $stmt->bind_param('sssdiiii', $name, $slug, $description, $price, $domains, $forms, $leads, $team_members);
            if ($stmt->execute()) {
                $_SESSION['flash'] = ['type'=>'success','msg'=>'Plan created.'];
                header('Location: ' . APP_URL . '/pricing.php?tab=plans'); exit;
            } else {
                $_SESSION['flash'] = ['type'=>'error','msg'=>'Error: ' . $stmt->error];
            }
        } elseif ($post_action === 'edit_plan' && $plan_id > 0) {
            $stmt = db()->prepare('UPDATE pricing_plans SET name=?,slug=?,description=?,price_monthly=?,domains_limit=?,forms_limit=?,leads_per_month=?,team_members_limit=? WHERE id=?');
            $stmt->bind_param('sssdiiiii', $name, $slug, $description, $price, $domains, $forms, $leads, $team_members, $plan_id);
            if ($stmt->execute()) {
                $_SESSION['flash'] = ['type'=>'success','msg'=>'Plan updated.'];
                header('Location: ' . APP_URL . '/pricing.php?tab=plans'); exit;
            } else {
                $_SESSION['flash'] = ['type'=>'error','msg'=>'Error: ' . $stmt->error];
            }
        }

    } elseif ($post_action === 'save_services') {
        $pid      = (int)($_POST['plan_id'] ?? 0);
        $services = $_POST['services'] ?? [];

        if ($pid) {
            db_query('DELETE FROM plan_services WHERE plan_id = ?', 'i', $pid);
            foreach ($services as $svc_key) {
                if (!isset($ALL_SERVICES[$svc_key])) continue;
                $existing = db_fetch('SELECT id FROM services_catalog WHERE service_key = ?', 's', $svc_key);
                $svc_id   = $existing ? $existing['id'] : db_insert('INSERT IGNORE INTO services_catalog (service_key, label) VALUES (?,?)', 'ss', $svc_key, $ALL_SERVICES[$svc_key]['label']);
                if ($svc_id) db_query('INSERT IGNORE INTO plan_services (plan_id, service_id) VALUES (?,?)', 'ii', $pid, $svc_id);
            }
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Services updated.'];
        }
        header('Location: ' . APP_URL . '/pricing.php?tab=services'); exit;
    }
}

// Ensure services_catalog table exists and is seeded
db()->query("CREATE TABLE IF NOT EXISTS `services_catalog` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `service_key` varchar(60) NOT NULL,
  `label` varchar(120) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_service_key` (`service_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

foreach ($ALL_SERVICES as $key => $info) {
    db()->query("INSERT IGNORE INTO services_catalog (service_key, label) VALUES ('" .
        db()->real_escape_string($key) . "','" . db()->real_escape_string($info['label']) . "')");
}

$plans = db_fetch_all('SELECT * FROM pricing_plans ORDER BY price_monthly ASC');
$edit_plan = ($action === 'edit' && $plan_id > 0) ? db_fetch('SELECT * FROM pricing_plans WHERE id = ?', 'i', $plan_id) : null;

// Build plan → services map
$plan_services_map = [];
$svc_rows = db_fetch_all('SELECT ps.plan_id, sc.service_key FROM plan_services ps JOIN services_catalog sc ON sc.id = ps.service_id');
foreach ($svc_rows as $r) { $plan_services_map[$r['plan_id']][] = $r['service_key']; }

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
include __DIR__ . '/layouts/header.php';
?>

<div class="page-header">
    <div>
        <div class="page-title"><i class="hgi hgi-stroke hgi-trending-up-01"></i> Pricing Plans</div>
        <div class="page-subtitle">Configure subscription plans and service access</div>
    </div>
    <?php if ($tab !== 'services' && !in_array($action, ['create','edit'])): ?>
    <a href="?action=create&tab=plans" class="btn btn-primary btn-sm"><i class="hgi hgi-stroke hgi-plus-sign"></i> New Plan</a>
    <?php endif; ?>
</div>

<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type'] === 'error' ? 'danger' : 'success' ?> mb-5" data-auto-dismiss><?= $flash['msg'] ?></div>
<?php endif; ?>

<div class="tabs mb-5">
    <a href="?tab=plans" class="tab <?= $tab !== 'services' ? 'tab-active' : '' ?>"><i class="hgi hgi-stroke hgi-trending-up-01"></i> Plans</a>
    <a href="?tab=services" class="tab <?= $tab === 'services' ? 'tab-active' : '' ?>"><i class="hgi hgi-stroke hgi-settings-01"></i> Service Access</a>
</div>

<?php if ($tab !== 'services'): // ─── PLANS TAB ?>

<?php if ($action === 'create' || $action === 'edit'): ?>
<div class="card" style="max-width:680px;">
    <div class="card-header"><div class="card-title"><?= $action === 'create' ? 'Create Plan' : 'Edit Plan: ' . h($edit_plan['name'] ?? '') ?></div></div>
    <div class="card-body">
        <form method="POST">
            <?= csrf_field() ?>
            <input type="hidden" name="post_action" value="<?= $action === 'create' ? 'create_plan' : 'edit_plan' ?>">
            <div class="grid grid-cols-2 gap-3 mb-3">
                <div class="form-group">
                    <label class="form-label">Plan Name *</label>
                    <input type="text" name="name" class="input input-sm" placeholder="Starter" value="<?= h($edit_plan['name'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">URL Slug *</label>
                    <input type="text" name="slug" class="input input-sm" placeholder="starter" value="<?= h($edit_plan['slug'] ?? '') ?>" required>
                </div>
            </div>
            <div class="form-group mb-3">
                <label class="form-label">Description</label>
                <textarea name="description" class="input input-sm" rows="2"><?= h($edit_plan['description'] ?? '') ?></textarea>
            </div>
            <div class="form-group mb-4">
                <label class="form-label">Monthly Price (USD) *</label>
                <input type="number" name="price" class="input input-sm" step="0.01" min="0" value="<?= h($edit_plan['price_monthly'] ?? '0') ?>" required>
            </div>
            <div class="fieldset">Limits</div>
            <div class="grid grid-cols-2 gap-3">
                <div class="form-group">
                    <label class="form-label">Max Domains</label>
                    <input type="number" name="domains_limit" class="input input-sm" min="1" value="<?= h($edit_plan['domains_limit'] ?? '1') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Max Forms</label>
                    <input type="number" name="forms_limit" class="input input-sm" min="1" value="<?= h($edit_plan['forms_limit'] ?? '3') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Leads per Month</label>
                    <input type="number" name="leads_per_month" class="input input-sm" min="1" value="<?= h($edit_plan['leads_per_month'] ?? '300') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Max Team Members</label>
                    <input type="number" name="team_members_limit" class="input input-sm" min="1" value="<?= h($edit_plan['team_members_limit'] ?? '2') ?>">
                </div>
            </div>
            <div class="flex gap-2 mt-4">
                <button type="submit" class="btn btn-primary btn-sm"><i class="hgi hgi-stroke hgi-tick-02"></i> <?= $action === 'create' ? 'Create Plan' : 'Save Changes' ?></button>
                <a href="<?= APP_URL ?>/pricing.php?tab=plans" class="btn btn-secondary btn-sm">Cancel</a>
            </div>
        </form>
    </div>
</div>

<?php else: // plan list ?>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(270px,1fr));gap:16px;">
    <?php foreach ($plans as $plan):
        $plan_svcs = $plan_services_map[$plan['id']] ?? [];
    ?>
    <div class="card" style="<?= !$plan['is_active'] ? 'opacity:.65;' : '' ?>">
        <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 16px 0;">
            <div style="font-weight:600;"><?= h($plan['name']) ?></div>
            <span class="badge badge-sm <?= $plan['is_active'] ? 'badge-green' : 'badge-gray' ?>"><?= $plan['is_active'] ? 'Active' : 'Inactive' ?></span>
        </div>
        <div style="padding:8px 16px 14px;">
            <div style="font-size:1.5rem;font-weight:700;color:var(--color-brand,#2563eb);">$<?= number_format($plan['price_monthly'],2) ?>/mo</div>
            <p style="font-size:.8rem;color:var(--color-text-muted);margin:4px 0 10px;"><?= h($plan['description'] ?? '') ?></p>
            <ul style="font-size:.8rem;list-style:none;padding:10px 0;margin:0 0 10px;border-top:1px solid var(--border);display:flex;flex-direction:column;gap:5px;">
                <li>🌐 <?= $plan['domains_limit'] ?> domain<?= $plan['domains_limit']!=1?'s':'' ?></li>
                <li>📝 <?= $plan['forms_limit'] ?> form<?= $plan['forms_limit']!=1?'s':'' ?></li>
                <li>📊 <?= number_format($plan['leads_per_month']) ?> leads/mo</li>
                <li>👥 <?= $plan['team_members_limit'] ?> team member<?= $plan['team_members_limit']!=1?'s':'' ?></li>
            </ul>
            <?php if ($plan_svcs): ?>
            <div style="font-size:.75rem;color:var(--color-text-muted);margin-bottom:10px;">
                <strong style="color:var(--color-text);">Services:</strong>
                <?php foreach ($plan_svcs as $sk): ?>
                <span class="badge badge-sm badge-blue" style="margin:1px 2px;"><?= h($ALL_SERVICES[$sk]['label'] ?? $sk) ?></span>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div style="font-size:.75rem;color:var(--color-text-muted);margin-bottom:10px;">No services — <a href="?tab=services">configure</a></div>
            <?php endif; ?>
            <div style="display:flex;gap:8px;">
                <a href="?action=edit&id=<?= $plan['id'] ?>&tab=plans" class="btn btn-sm btn-secondary" style="flex:1;text-align:center;">Edit</a>
                <a href="?action=toggle&id=<?= $plan['id'] ?>&tab=plans" class="btn btn-sm btn-ghost" style="flex:1;text-align:center;" onclick="return confirm('<?= $plan['is_active']?'Disable':'Enable' ?> plan?')"><?= $plan['is_active'] ? 'Disable' : 'Enable' ?></a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php else: // ─── SERVICES TAB ?>
<div class="card mb-5">
    <div style="padding:16px 16px 14px;border-bottom:1px solid var(--border);">
        <div style="font-weight:600;font-size:.95rem;">Configure Service Access per Plan</div>
        <p style="font-size:.82rem;color:var(--color-text-muted);margin:4px 0 0;">Select which services each plan can access. These control feature gating across the platform.</p>
    </div>
    <form method="POST">
        <?= csrf_field() ?>
        <input type="hidden" name="post_action" value="save_services">
        <input type="hidden" name="plan_id" value="" id="svc_plan_id">
        <div style="padding:16px;">
            <div class="form-group mb-4">
                <label class="form-label">Select Plan to Configure</label>
                <select class="select select-sm" style="max-width:320px;" id="plan_selector" onchange="switchPlan(this.value)">
                    <option value="">— Choose a plan —</option>
                    <?php foreach ($plans as $p): ?>
                    <option value="<?= $p['id'] ?>"><?= h($p['name']) ?> ($<?= number_format($p['price_monthly'],2) ?>/mo)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div id="svc_grid" style="display:none;">
                <div class="fieldset">Available Services</div>
                <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px;margin-bottom:16px;">
                    <?php foreach ($ALL_SERVICES as $svc_key => $svc_info): ?>
                    <label style="display:flex;align-items:center;gap:10px;padding:12px 14px;border:1px solid var(--border);border-radius:8px;cursor:pointer;background:var(--surface);">
                        <input type="checkbox" name="services[]" value="<?= $svc_key ?>" id="svc_cb_<?= $svc_key ?>" style="width:16px;height:16px;flex-shrink:0;">
                        <div>
                            <div style="font-size:.88rem;font-weight:600;"><?= h($svc_info['label']) ?></div>
                            <div style="font-size:.72rem;color:var(--color-text-muted);"><?= $svc_key ?></div>
                        </div>
                    </label>
                    <?php endforeach; ?>
                </div>
                <div class="flex gap-2">
                    <button type="submit" class="btn btn-primary btn-sm"><i class="hgi hgi-stroke hgi-tick-02"></i> Save</button>
                    <button type="button" class="btn btn-secondary btn-sm" onclick="selectAll(true)">All</button>
                    <button type="button" class="btn btn-ghost btn-sm" onclick="selectAll(false)">None</button>
                </div>
            </div>
        </div>
    </form>
</div>

<!-- Matrix table -->
<div class="card">
    <div style="padding:12px 16px;border-bottom:1px solid var(--border);font-weight:600;font-size:.9rem;">Service Access Matrix</div>
    <div style="overflow-x:auto;">
        <table class="table">
            <thead>
                <tr>
                    <th>Plan</th>
                    <?php foreach ($ALL_SERVICES as $sk => $si): ?><th style="text-align:center;font-size:.75rem;white-space:nowrap;"><?= h($si['label']) ?></th><?php endforeach; ?>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($plans as $p): $ps = $plan_services_map[$p['id']] ?? []; ?>
                <tr>
                    <td><div style="font-weight:600;font-size:.88rem;"><?= h($p['name']) ?></div><div class="text-xs text-muted">$<?= number_format($p['price_monthly'],2) ?>/mo</div></td>
                    <?php foreach ($ALL_SERVICES as $sk => $si): ?>
                    <td style="text-align:center;"><?= in_array($sk,$ps) ? '<span style="color:#16a34a;font-size:1.1rem;">✓</span>' : '<span style="color:#d1d5db;">✗</span>' ?></td>
                    <?php endforeach; ?>
                    <td><button class="btn btn-secondary btn-xs" onclick="quickEdit(<?= $p['id'] ?>, <?= json_encode($ps) ?>)">Edit</button></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
const planServicesData = <?= json_encode($plan_services_map) ?>;

function switchPlan(planId) {
    document.getElementById('svc_plan_id').value = planId;
    const grid = document.getElementById('svc_grid');
    if (!planId) { grid.style.display = 'none'; return; }
    grid.style.display = 'block';
    document.querySelectorAll('input[name="services[]"]').forEach(cb => cb.checked = false);
    (planServicesData[planId] || []).forEach(svc => {
        const cb = document.getElementById('svc_cb_' + svc);
        if (cb) cb.checked = true;
    });
}

function quickEdit(planId, services) {
    document.getElementById('plan_selector').value = planId;
    switchPlan(planId);
    // Override with passed services array
    document.querySelectorAll('input[name="services[]"]').forEach(cb => cb.checked = false);
    services.forEach(svc => { const cb = document.getElementById('svc_cb_' + svc); if(cb) cb.checked = true; });
    document.getElementById('svc_grid').scrollIntoView({behavior:'smooth'});
}

function selectAll(checked) {
    document.querySelectorAll('input[name="services[]"]').forEach(cb => cb.checked = checked);
}
</script>
<?php endif; ?>

<?php include __DIR__ . '/layouts/footer.php'; ?>