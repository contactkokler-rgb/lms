<?php
require_once __DIR__ . '/config/auth.php';
require_once __DIR__ . '/config/BillingService.php';
require_permission('team', 'view');
$user = auth_user();

$page_title    = 'Team';
$page_subtitle = 'Manage your team members and their access';
$active_nav    = 'team';

$account_id = $user['account_id'];
$err = $_GET['msg'] ?? '';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { die('Invalid CSRF token'); }
    $action = $_POST['action'] ?? '';

    if ($action === 'update_status' && can('team', 'edit')) {
        $uid    = (int)$_POST['user_id'];
        $status = in_array($_POST['status'], ['active','inactive','suspended']) ? $_POST['status'] : 'inactive';
        db_query('UPDATE users SET status=?, updated_at=NOW() WHERE id=? AND account_id=?', 'sii', $status, $uid, $account_id);
        audit('user.status_changed', "user:$uid", ['status' => $status]);
        header('Location: team.php?msg=updated'); exit;
    }

    if ($action === 'update_role' && can('team', 'edit')) {
        $uid     = (int)$_POST['user_id'];
        $role_id = (int)$_POST['role_id'];
        // Prevent assigning super_admin role via this page
        $role = db_fetch('SELECT * FROM roles WHERE id=? AND name != "super_admin"', 'i', $role_id);
        if ($role) {
            db_query('UPDATE users SET role_id=?, updated_at=NOW() WHERE id=? AND account_id=?', 'iii', $role_id, $uid, $account_id);
            audit('user.role_changed', "user:$uid", ['role_id' => $role_id]);
        }
        header('Location: team.php?msg=updated'); exit;
    }

    if ($action === 'remove' && can('team', 'remove')) {
        $uid = (int)$_POST['user_id'];
        // Soft delete — set status to inactive and remove from account
        db_query('UPDATE users SET status="inactive", account_id=NULL, updated_at=NOW() WHERE id=? AND account_id=?', 'ii', $uid, $account_id);
        audit('user.removed', "user:$uid");
        header('Location: team.php?msg=removed'); exit;
    }

    // Approve a pending invitation — creates user directly, no email needed
    if ($action === 'approve_invite' && can('team', 'invite')) {
        // Plan enforcement
        if (!is_super_admin()) {
            BillingService::enforce($account_id, 'can_add_team_member', 'add a new team member');
            if ($err = BillingService::enforceLimit($account_id, 'team_member')) {
                $_SESSION['flash'] = ['type' => 'error', 'msg' => $err];
                header('Location: team.php'); exit;
            }
        }
        $inv_id = (int)($_POST['invite_id'] ?? 0);
        $inv = db_fetch('SELECT * FROM invitations WHERE id = ? AND account_id = ? AND status = "pending"', 'ii', $inv_id, $account_id);
        if ($inv) {
            $existing = db_fetch('SELECT id FROM users WHERE email = ?', 's', $inv['email']);
            if ($existing) {
                // Existing user: reactivate and assign to account, generate new temp password
                $temp_pass = strtoupper(substr(bin2hex(random_bytes(3)), 0, 4)) . '-' . strtolower(substr(bin2hex(random_bytes(3)), 0, 4));
                $hash = password_hash($temp_pass, PASSWORD_BCRYPT, ['cost' => 10]);
                db_query('UPDATE users SET account_id=?, role_id=?, status="active", password_hash=?, updated_at=NOW() WHERE id=?', 'iiis', $account_id, (int)$inv['role_id'], $hash, (int)$existing['id']);
                $_SESSION['approved_member'] = ['email' => $inv['email'], 'temp_pass' => $temp_pass, 'is_new' => false];
            } else {
                // New user: readable temp password format e.g. "XKCD-pass8"
                $temp_pass = strtoupper(substr(bin2hex(random_bytes(3)), 0, 4)) . '-' . strtolower(substr(bin2hex(random_bytes(3)), 0, 4));
                $hash = password_hash($temp_pass, PASSWORD_BCRYPT, ['cost' => 10]);
                $name_parts = explode('@', $inv['email']);
                db_insert(
                    'INSERT INTO users (account_id, role_id, email, password_hash, first_name, last_name, status) VALUES (?,?,?,?,?,?,?)',
                    'iisssss',
                    $account_id, (int)$inv['role_id'], $inv['email'], $hash,
                    ucfirst($name_parts[0]), '', 'active'
                );
                $_SESSION['approved_member'] = ['email' => $inv['email'], 'temp_pass' => $temp_pass, 'is_new' => true];
            }
            db_query('UPDATE invitations SET status = "accepted" WHERE id = ?', 'i', $inv_id);
            audit('team.invite_approved', 'email:' . $inv['email']);
        }
        header('Location: team.php'); exit;
    }

    // Set / reset password for an existing team member
    if ($action === 'set_member_password' && can('team', 'edit')) {
        $uid      = (int)($_POST['user_id'] ?? 0);
        $new_pass = trim($_POST['new_password'] ?? '');
        $confirm  = trim($_POST['confirm_password'] ?? '');
        $member   = $uid ? db_fetch('SELECT id, email, first_name FROM users WHERE id = ? AND account_id = ?', 'ii', $uid, $account_id) : null;

        if (!$member) {
            $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Member not found.'];
        } elseif (strlen($new_pass) < 8) {
            $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Password must be at least 8 characters.'];
        } elseif ($new_pass !== $confirm) {
            $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Passwords do not match.'];
        } else {
            $hash = password_hash($new_pass, PASSWORD_BCRYPT, ['cost' => 10]);
            db_query('UPDATE users SET password_hash=?, updated_at=NOW() WHERE id=?', 'si', $hash, $uid);
            audit('team.password_set', 'user:' . $uid);
            $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Password updated for ' . h($member['first_name']) . '.'];
        }
        header('Location: team.php'); exit;
    }

    // Revoke a pending invitation
    if ($action === 'revoke_invite' && can('team', 'invite')) {
        $inv_id = (int)($_POST['invite_id'] ?? 0);
        db_query('UPDATE invitations SET status = "revoked" WHERE id = ? AND account_id = ?', 'ii', $inv_id, $account_id);
        audit('team.invite_revoked', "invite:$inv_id");
        $_SESSION['flash'] = ['type' => 'success', 'msg' => 'Invitation revoked.'];
        header('Location: team.php'); exit;
    }

} // end if POST

// Fetch team members
$members = db_fetch_all(
    'SELECT u.id, u.first_name, u.last_name, u.email, u.designation, u.status, u.last_login_at,
            u.created_at, u.avatar, r.name AS role_name, r.label AS role_label, r.id AS role_id,
            inv.email AS invited_email
     FROM users u
     JOIN roles r ON r.id = u.role_id
     LEFT JOIN invitations inv ON inv.email = u.email AND inv.account_id = ?
     WHERE u.account_id = ?
     ORDER BY r.id ASC, u.first_name ASC',
    'ii', $account_id, $account_id
);

// Pending invites
$invites = db_fetch_all(
    'SELECT i.*, r.label AS role_label, u.first_name AS invited_by_name, u.last_name AS invited_by_last
     FROM invitations i
     JOIN roles r ON r.id = i.role_id
     JOIN users u ON u.id = i.invited_by
     WHERE i.account_id = ? AND i.status = "pending" AND i.expires_at > NOW()
     ORDER BY i.created_at DESC',
    'i', $account_id
);

// Roles for invite modal (no super_admin)
$roles = db_fetch_all("SELECT * FROM roles WHERE name != 'super_admin' ORDER BY id");

// Pick up session flash (from approve/revoke) or GET msg param
$flash = null;
if (!empty($_SESSION['flash'])) {
    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
} elseif (!empty($_GET['msg'])) {
    $msg_map = [
        'invited'  => ['type' => 'success', 'msg' => 'Invitation sent successfully.'],
        'updated'  => ['type' => 'success', 'msg' => 'Team member updated.'],
        'removed'  => ['type' => 'warning', 'msg' => 'Team member removed.'],
    ];
    if (isset($msg_map[$_GET['msg']])) {
        $flash = $msg_map[$_GET['msg']];
    }
}

// Approved member temp password — shown once then cleared
$approved_member = null;
if (!empty($_SESSION['approved_member'])) {
    $approved_member = $_SESSION['approved_member'];
    unset($_SESSION['approved_member']);
}

include __DIR__ . '/layouts/header.php';

$role_badge = [
  'account_owner' => 'badge-purple',
  'manager'       => 'badge-blue',
  'agent'         => 'badge-green',
];
$status_badge = [
  'active'    => 'badge-green',
  'inactive'  => 'badge-gray',
  'suspended' => 'badge-red',
  'invited'   => 'badge-yellow',
];
?>


<?php if ($flash): ?>
<div class="alert alert-<?= h($flash['type']) ?> mb-4" data-auto-dismiss>
    <?php if ($flash['type'] === 'success'): ?>
    <i class="hgi hgi-stroke hgi-tick-02"></i>
    <?php else: ?>
    <i class="hgi hgi-stroke hgi-alert-01"></i>
    <?php endif; ?>
    <?= h($flash['msg']) ?>
</div>
<?php endif; ?>



<?php if ($approved_member): ?>
<div class="alert alert-big alert-success mb-6">
    <div class="flex gap-3 flex-1 items-start">
        <i class="hgi hgi-stroke hgi-information-circle"></i>
    
        <div class="w-full">
            <div class="text-base font-semibold">
                <?= $approved_member['is_new'] ? 'Team member added' : 'Member reactivated' ?> — share their login credentials
            </div>
            <div>
                <?= h($approved_member['email']) ?> has been added to your team. Share the credentials below securely — they can change the password after logging in.
            </div>
            <div style="display:flex;gap:20px;flex-wrap:wrap;">
                <div>
                    <div style="font-size:.68rem;font-weight:700;color:#15803d;text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px;">Email</div>
                    <code style="font-size:.85rem;background:#dcfce7;padding:5px 12px;border-radius:6px;color:#14532d;font-family:var(--font-mono);user-select:all;"><?= h($approved_member['email']) ?></code>
                </div>
                <div>
                    <div style="font-size:.68rem;font-weight:700;color:#15803d;text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px;">Temporary Password</div>
                    <div style="display:flex;align-items:center;gap:8px;">
                        <code id="tempPassCode" style="font-size:.85rem;background:#dcfce7;padding:5px 12px;border-radius:6px;color:#14532d;font-family:var(--font-mono);letter-spacing:.08em;user-select:all;"><?= h($approved_member['temp_pass']) ?></code>
                        <button type="button" onclick="copyTempPass()" class="btn btn-xs btn-white" id="copyPassBtn">Copy</button>
                    </div>
                </div>
            </div>
            <div class="mt-2">
                This password is shown only once. You can always set a new one from the team member's action menu.
            </div>
        </div>
    </div>
</div>
<script>
    function copyTempPass() {
        var code = document.getElementById('tempPassCode').textContent;
        if (navigator.clipboard) {
            navigator.clipboard.writeText(code).then(function() {
                var btn = document.getElementById('copyPassBtn');
                btn.textContent = 'Copied!';
                setTimeout(function() {
                    btn.textContent = 'Copy';
                }, 2000);
            });
        }
    }
</script>
<?php endif; ?>

<!-- Stats -->
<div class="grid grid-cols-4 gap-4">
    <?php
        $total   = count($members);
        $active  = count(array_filter($members, function($m) { return $m['status'] === 'active'; }));
        $pending = count($invites);
        $agents  = count(array_filter($members, function($m) { return $m['role_name'] === 'agent'; }));
    ?>
    <?php foreach ([
        ['Total Members', $total,    'card-b2', 'user-multiple-02'],
        ['Active',        $active,   'card-b3', 'user-check-01'],
        ['Pending Invites',$pending, 'card-b4', 'user-lock-01'],
        ['Agents',        $agents,   'card-b5', 'user-id-verification'],
      ] as [$label, $val, $color, $icon]): 
    ?>

    <div class="card card-stat <?= $color ?>">
        <div>
            <div class="card-label"><?= $label ?></div>
            <div class="card-value mt-1"><?= $val ?></div>
        </div>
        <i class="hgi hgi-stroke hgi-<?= $icon ?>"></i>
    </div>

    <?php endforeach; ?>
</div>

<!-- Members Table -->
<div class="card" style="overflow: visible;">
    <div class="card-header">
        <div>
            <div class="card-title">Team Members</div>
            <div class="card-subtitle"><?= $total ?> member<?= $total !== 1 ? 's' : '' ?> in your workspace</div>
        </div>
        <div class="flex gap-2">

            <div class="form-group m-0 form-wrapper">
                <span class="icon left-icon">
                    <i class="hgi hgi-stroke hgi-search-01"></i>
                </span>

                <input type="text"  id="member-search" placeholder="Search members…">
            </div>

            <?php if (can('team', 'invite')): ?>
            <button class="btn btn-primary" onclick="openModal('invite-modal')">
                <i class="hgi hgi-stroke hgi-plus-sign"></i>Invite Member
            </button>
            <?php endif; ?>
        </div>
    </div>


    <?php if (empty($members)): ?>
    <div class="empty-state">
        <div class="empty-state-icon">
            <i class="hgi hgi-stroke hgi-user-multiple-02"></i>
        </div>
        <div class="empty-state-title">No team members yet</div>
        <div class="empty-state-desc">Invite your first team member to get started.</div>
        <?php if (can('team', 'invite')): ?>
        <button class="btn btn-primary" onclick="openModal('invite-modal')"><i class="hgi hgi-stroke hgi-plus-sign"></i>Invite Members</button>
        <?php endif; ?>
    </div>
    <?php else: ?>


    <div class="table-wrap">
        <table class="table" id="members-table">
            <thead>
                <tr>
                    <th>Member</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Last Active</th>
                    <th>Joined</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($members as $m): ?>
                <?php
                  $initials = strtoupper(substr($m['first_name'],0,1) . substr($m['last_name'],0,1));
                  $is_self  = $m['id'] === $user['id'];
                ?>
                <tr class="member-row">
                    <td>
                        <div class="flex items-center gap-3">
                            <div class="avatar text-white" style="background: <?= user_color($m['id']) ?>;">
                                <?php if ($m['avatar']): ?><img src="<?= htmlspecialchars($m['avatar']) ?>" alt="">
                                <?php else: ?><?= $initials ?><?php endif; ?>
                            </div>
                            <div class="min-w-0">
                                <div class="text-semibold truncate">
                                    <?= htmlspecialchars($m['first_name'] . ' ' . $m['last_name']) ?>
                                    <?php if ($is_self): ?><span class="badge badge-gray" style="margin-left:4px;">You</span><?php endif; ?>
                                </div>
                                <div class="text-xs text-muted truncate"><?= htmlspecialchars($m['email']) ?></div>
                                <?php if ($m['designation']): ?>
                                <div class="text-xs text-muted"><?= htmlspecialchars($m['designation']) ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                    <td>
                        <span class="badge badge-sm badge badge-outline-<?= $role_badge[$m['role_name']] ?? 'gray' ?>">
                            <?= htmlspecialchars($m['role_label']) ?>
                        </span>
                    </td>
                    <td>
                        <span class="badge badge-sm <?= $status_badge[$m['status']] ?? 'badge-gray' ?>">
                            <span class="badge-dot"></span>
                            <?= ucfirst($m['status']) ?>
                        </span>
                    </td>
                    <td class="text-muted text-sm">
                        <?= $m['last_login_at'] ? format_dt($m['last_login_at'], 'd M Y') : '—' ?>
                    </td>
                    <td class="text-muted text-sm">
                        <?= format_dt($m['created_at'], 'd M Y') ?>
                    </td>
                    <td class="text-right">
                        <?php if (!$is_self && can('team', 'edit')): ?>
                        
                        

                        <div class="dropdown" id="member-menu-<?= $m['id'] ?>">
                            <button class="btn btn-outline btn-icon btn-sm" onclick="this.nextElementSibling.classList.toggle('show')">
                                <i class="hgi hgi-stroke hgi-list-setting"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right">
                                <button class="dropdown-item" onclick="openEditModal(<?= $m['id'] ?>, '<?= htmlspecialchars(addslashes($m['first_name'] . ' ' . $m['last_name'])) ?>', <?= $m['role_id'] ?>, '<?= $m['status'] ?>')">
                                    <i class="hgi hgi-stroke hgi-configuration-02"></i>
                                    Edit Role & Status
                                </button>
                                <?php if (can('team', 'edit')): ?>
                                <button class="dropdown-item" onclick="openSetPasswordModal(<?= $m['id'] ?>, '<?= htmlspecialchars(addslashes($m['first_name'] . ' ' . $m['last_name'])) ?>')">
                                    <i class="hgi hgi-stroke hgi-lock-password"></i>
                                    Set Password
                                </button>
                                <?php endif; ?>
                                <?php if (can('team', 'remove')): ?>
                                <div class="dropdown-divider"></div>
                                <button class="dropdown-item text-danger" onclick="confirmRemove(<?= $m['id'] ?>, '<?= htmlspecialchars(addslashes($m['first_name'] . ' ' . $m['last_name'])) ?>')">
                                    <i class="hgi hgi-stroke hgi-user-remove-01"></i>
                                    Remove from Team
                                </button>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<!-- Pending Invitations -->
<?php if (!empty($invites)): ?>
<div class="card">
    <div class="card-header">
        <div class="flex items-center justify-between w-full">
            <div class="card-title">Pending Invitations</div>
            <div><span class="badge badge-warning"><?= count($invites) ?> invitation<?= count($invites) !== 1 ? 's' : '' ?></span> awaiting acceptance</div>
        </div>
    </div>
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Invited By</th>
                    <th>Expires</th>
                    <th class="text-right"></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($invites as $inv): ?>
                <tr>
                    <td>
                        <div class="flex items-center gap-2">
                            <div class="avatar avatar-sm" style="background:#e2e8f0; color:#64748b;">
                                <?= strtoupper(substr($inv['email'], 0, 1)) ?>
                            </div>
                            <?= htmlspecialchars($inv['email']) ?>
                        </div>
                    </td>
                    <td><span class="badge badge-gray"><?= htmlspecialchars($inv['role_label']) ?></span></td>
                    <td class="text-muted text-sm"><?= htmlspecialchars($inv['invited_by_name'] . ' ' . $inv['invited_by_last']) ?></td>
                    <td class="text-sm">
                        <?php
                          $exp = strtotime($inv['expires_at']);
                          $hrs = round(($exp - time()) / 3600);
                          echo $hrs < 24 ? "<span class='text-danger'>{$hrs}h left</span>" : format_dt($inv['expires_at'], 'd M Y');
                        ?>
                    </td>
                    <td class="flex justify-end gap-1">
                        <?php if (can('team', 'invite')): ?>
                        <form method="POST" onsubmit="return confirm('Revoke this invitation?')">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="revoke_invite">
                            <input type="hidden" name="invite_id" value="<?= $inv['id'] ?>">
                            <button class="btn btn-danger btn-sm" type="submit"><i class="hgi hgi-stroke hgi-alert-01"></i>Revoke</button>
                        </form>
                        <form method="POST">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="approve_invite">
                            <input type="hidden" name="invite_id" value="<?= $inv['id'] ?>">
                            <button class="btn btn-primary btn-sm" type="submit"><i class="hgi hgi-stroke hgi-tick-02"></i>Approve</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>


<!-- Invite Modal -->
<?php if (can('team', 'invite')): ?>
<div class="modal-overlay" id="invite-modal">
    <form action="invite.php" method="POST" class="modal">
        <div class="modal-header">
            <div>
                <div class="modal-title">Invite Team Member</div>
                <div class="modal-subtitle">They'll receive an email with a setup link</div>
            </div>
        </div>
        <div class="modal-body">
            <input type="hidden" name="_csrf" value="<?= csrf_token() ?>">
            
            <div class="form-group">
                <label class="form-label">Email Address <span>*</span></label>
                <input type="email" name="email" class="form-control" placeholder="colleague@company.com" required>
            </div>
            <div class="form-group">
                <label class="form-label">First Name</label>
                <input type="text" name="first_name" class="form-control" placeholder="Optional">
            </div>
            <div class="form-group">
                <label class="form-label">Role <span>*</span></label>
                <select name="role_id" class="form-control form-select" required>
                    <option value="">Select a role…</option>
                    <?php foreach ($roles as $r): ?>
                    <?php if ($r['name'] === 'account_owner') continue; ?>
                    <option value="<?= $r['id'] ?>"><?= htmlspecialchars($r['label']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="alert alert-info">
                <i class="hgi hgi-stroke hgi-information-circle"></i>
                The invitation link expires after 72 hours.
            </div>           
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-white" onclick="closeModal('invite-modal')">Cancel</button>
            <button type="submit" class="btn btn-primary"><i class="hgi hgi-stroke hgi-tick-02"></i>Send Invitation</button>
        </div>
    </form>
</div>
<?php endif; ?>


<!-- Edit Member Modal -->
<div class="modal-overlay" id="edit-modal">
    <div class="modal">
        <div class="modal-header">
            <div>
                <div class="modal-title" id="edit-modal-name">Edit Member</div>
                <div class="modal-subtitle">Update role and account status</div>
            </div>
        </div>
        <form method="POST">
            <input type="hidden" name="_csrf" value="<?= csrf_token() ?>">
            <input type="hidden" name="action" value="update_role">
            <input type="hidden" name="user_id" id="edit-user-id">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Role</label>
                    <select name="role_id" id="edit-role-id" class="form-control form-select">
                        <?php foreach ($roles as $r): ?>
                        <?php if ($r['name'] === 'account_owner') continue; ?>
                        <option value="<?= $r['id'] ?>"><?= htmlspecialchars($r['label']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group" style="margin-bottom:0;">
                    <label class="form-label">Status</label>
                    <select name="status" id="edit-status" class="form-control form-select" form="status-form">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                        <option value="suspended">Suspended</option>
                    </select>
                    <div class="form-hint">Suspended members cannot log in.</div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-white" onclick="closeModal('edit-modal')">Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="hgi hgi-stroke hgi-tick-02"></i>Save Changes</button>
            </div>
        </form>
    </div>
</div>

<!-- Set Password Modal -->
<div class="modal-overlay" id="set-password-modal">
    <div class="modal">
        <div class="modal-header">
            <div>
                <div class="modal-title" id="set-pw-modal-name">Set Password</div>
                <div class="modal-subtitle">Member will use this to log in</div>
            </div>
        </div>
        <form method="POST" id="set-pw-form">
            <div class="modal-body">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="set_member_password">
                <input type="hidden" name="user_id" id="set-pw-user-id">
                
                <div class="form-group">
                    <label class="form-label form-label-required">New Password</label>
                    <div style="position:relative;">
                        <input type="password" name="new_password" id="set-pw-input" class="form-control" minlength="8" required autocomplete="new-password" placeholder="Min 8 characters" style="padding-right:60px;" oninput="setPwStrength(this.value)">
                        <button type="button" onclick="toggleSetPw()" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:.72rem;color:var(--brand-500);font-weight:700;">Show</button>
                    </div>
                    <div class="progress mt-1">
                        <div id="setPwBar" class="progress-bar" style="transition:width .2s,background .2s"></div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label form-label-required">Confirm Password</label>
                    <input type="password" name="confirm_password" class="form-control" required autocomplete="new-password" placeholder="Repeat password">
                </div>
                <div class="alert alert-warning mt-3">
                    <i class="hgi hgi-stroke hgi-alert-01"></i>
                    The member's current session will remain active. They'll use this password on their next login.
                </div>
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-white" onclick="closeModal('set-password-modal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Set Password</button>
            </div>
        </form>
    </div>
</div>

<!-- Remove Confirm -->
<form method="POST" id="remove-form">
    <input type="hidden" name="_csrf" value="<?= csrf_token() ?>">
    <input type="hidden" name="action" value="remove">
    <input type="hidden" name="user_id" id="remove-user-id">
</form>

<script>
    function openEditModal(id, name, roleId, status) {
        document.getElementById('edit-user-id').value = id;
        document.getElementById('edit-modal-name').textContent = 'Edit — ' + name;
        document.getElementById('edit-role-id').value = roleId;
        document.getElementById('edit-status').value = status;
        openModal('edit-modal');
    }

    function openSetPasswordModal(id, name) {
        document.getElementById('set-pw-user-id').value = id;
        document.getElementById('set-pw-modal-name').textContent = 'Set Password — ' + name;
        document.getElementById('set-pw-input').value = '';
        document.getElementById('set-pw-form').querySelector('[name="confirm_password"]').value = '';
        document.getElementById('setPwBar').style.width = '0';
        openModal('set-password-modal');
    }

    function toggleSetPw() {
        var inp = document.getElementById('set-pw-input');
        var btn = inp.nextElementSibling;
        inp.type = inp.type === 'password' ? 'text' : 'password';
        btn.textContent = inp.type === 'password' ? 'Show' : 'Hide';
    }

    function setPwStrength(v) {
        var score = 0;
        if (v.length >= 8) score++;
        if (v.length >= 12) score++;
        if (/[A-Z]/.test(v)) score++;
        if (/[0-9]/.test(v)) score++;
        if (/[^A-Za-z0-9]/.test(v)) score++;
        var colors = ['#ef4444', '#f97316', '#eab308', '#22c55e', '#16a34a'];
        var bar = document.getElementById('setPwBar');
        bar.style.width = ((score / 5) * 100) + '%';
        bar.style.background = colors[score - 1] || '#e2e8f0';
    }

    function confirmRemove(id, name) {
        if (confirm('Remove ' + name + ' from your team? They will lose access immediately.')) {
            document.getElementById('remove-user-id').value = id;
            document.getElementById('remove-form').submit();
        }
    }

    // Client-side search
    document.getElementById('member-search')?.addEventListener('input', function() {
        const q = this.value.toLowerCase();
        document.querySelectorAll('#members-table .member-row').forEach(row => {
            row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
        });
    });
</script>

<?php include __DIR__ . '/layouts/footer.php'; ?>