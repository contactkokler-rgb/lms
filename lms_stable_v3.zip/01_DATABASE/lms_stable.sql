-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Mar 27, 2026 at 12:15 PM
-- Server version: 5.7.39
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lms4`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT 'UTC',
  `plan` enum('free','starter','pro','enterprise') COLLATE utf8mb4_unicode_ci DEFAULT 'free',
  `plan_expires_at` datetime DEFAULT NULL,
  `status` enum('active','suspended','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `name`, `slug`, `email`, `phone`, `website`, `logo`, `timezone`, `plan`, `plan_expires_at`, `status`, `created_at`, `updated_at`) VALUES
(2, 'Ebrandist', 'ebrandist', 'ebrandist@gmail.com', '', '', NULL, 'Asia/Kolkata', 'free', '2026-04-27 23:59:59', 'active', '2026-03-10 07:07:51', '2026-03-27 13:55:17');

-- --------------------------------------------------------

--
-- Table structure for table `account_plans`
--

DROP TABLE IF EXISTS `account_plans`;
CREATE TABLE `account_plans` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `plan_id` int(10) UNSIGNED NOT NULL,
  `status` enum('trial','active','expired','cancelled') DEFAULT 'trial',
  `plan_starts_at` datetime DEFAULT NULL,
  `plan_expires_at` datetime DEFAULT NULL,
  `billing_cycle_starts` date DEFAULT NULL,
  `billing_cycle_ends` date DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account_plans`
--

INSERT INTO `account_plans` (`id`, `account_id`, `plan_id`, `status`, `plan_starts_at`, `plan_expires_at`, `billing_cycle_starts`, `billing_cycle_ends`, `created_at`, `updated_at`) VALUES
(1, 2, 1, 'active', '2026-03-27 08:25:17', '2026-04-27 23:59:59', NULL, NULL, '2026-03-27 13:55:17', '2026-03-27 13:55:17');

-- --------------------------------------------------------

--
-- Table structure for table `account_subscriptions`
--

DROP TABLE IF EXISTS `account_subscriptions`;
CREATE TABLE `account_subscriptions` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `plan_id` int(10) UNSIGNED NOT NULL,
  `status` enum('trial','active','expired','cancelled') DEFAULT 'trial',
  `trial_started_at` datetime DEFAULT NULL,
  `trial_ends_at` datetime DEFAULT NULL,
  `subscription_started_at` datetime DEFAULT NULL,
  `subscription_ends_at` datetime DEFAULT NULL,
  `next_billing_date` datetime DEFAULT NULL,
  `auto_renew` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `account_usage`
--

DROP TABLE IF EXISTS `account_usage`;
CREATE TABLE `account_usage` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `billing_month` varchar(7) DEFAULT NULL,
  `domains_created` int(11) DEFAULT '0',
  `forms_created` int(11) DEFAULT '0',
  `leads_count` int(11) DEFAULT '0',
  `team_members_added` int(11) DEFAULT '0',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
CREATE TABLE `audit_log` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `account_id` int(10) UNSIGNED DEFAULT NULL,
  `action` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `audit_log`
--

INSERT INTO `audit_log` (`id`, `user_id`, `account_id`, `action`, `target`, `meta`, `ip_address`, `created_at`) VALUES
(1, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '122.160.108.18', '2026-03-09 11:05:00'),
(2, 1, NULL, 'domain.created', 'domain:kokler.in', NULL, '122.160.108.18', '2026-03-09 11:05:20'),
(3, 1, NULL, 'form.created', 'form:1', NULL, '122.160.108.18', '2026-03-09 11:05:46'),
(4, 1, NULL, 'domain.deleted', 'domain:2', NULL, '122.160.108.18', '2026-03-09 11:11:25'),
(5, 1, NULL, 'domain.created', 'domain:kokler.in', NULL, '122.160.108.18', '2026-03-09 11:11:39'),
(6, 1, NULL, 'form.created', 'form:2', NULL, '122.160.108.18', '2026-03-09 12:50:51'),
(7, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '103.84.203.253', '2026-03-10 01:11:38'),
(8, 1, NULL, 'form.updated', 'form:2', NULL, '103.84.203.253', '2026-03-10 01:32:20'),
(9, 1, NULL, 'form.updated', 'form:2', NULL, '103.84.203.253', '2026-03-10 01:32:36'),
(10, 1, NULL, 'lead.assigned', 'lead:2', '{\"to\":4}', '103.84.203.253', '2026-03-10 01:38:18'),
(11, 1, NULL, 'lead.assigned', 'lead:1', '{\"to\":5}', '103.84.203.253', '2026-03-10 01:38:22'),
(12, 1, NULL, 'auth.logout', NULL, NULL, '103.84.203.253', '2026-03-10 01:38:25'),
(13, NULL, NULL, 'auth.login', NULL, '{\"email\":\"raj@acme.com\"}', '103.84.203.253', '2026-03-10 01:38:31'),
(14, NULL, NULL, 'auth.logout', NULL, NULL, '103.84.203.253', '2026-03-10 01:38:47'),
(15, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '103.84.203.253', '2026-03-10 01:38:54'),
(16, 1, NULL, 'auth.logout', NULL, NULL, '103.84.203.253', '2026-03-10 01:38:58'),
(17, NULL, NULL, 'auth.login', NULL, '{\"email\":\"raj@acme.com\"}', '103.84.203.253', '2026-03-10 01:39:18'),
(18, NULL, NULL, 'auth.logout', NULL, NULL, '103.84.203.253', '2026-03-10 01:39:29'),
(19, NULL, NULL, 'auth.login', NULL, '{\"email\":\"james@acme.com\"}', '103.84.203.253', '2026-03-10 01:39:55'),
(20, NULL, NULL, 'auth.logout', NULL, NULL, '103.84.203.253', '2026-03-10 01:45:40'),
(21, NULL, NULL, 'auth.login', NULL, '{\"email\":\"raj@acme.com\"}', '103.84.203.253', '2026-03-10 01:45:49'),
(22, NULL, NULL, 'auth.logout', NULL, NULL, '103.84.203.253', '2026-03-10 01:46:34'),
(23, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '103.84.203.253', '2026-03-10 01:48:08'),
(24, 1, NULL, 'auth.logout', NULL, NULL, '103.84.203.253', '2026-03-10 01:57:08'),
(25, NULL, NULL, 'auth.login', NULL, '{\"email\":\"james@acme.com\"}', '103.84.203.253', '2026-03-10 01:57:16'),
(26, NULL, NULL, 'auth.logout', NULL, NULL, '103.84.203.253', '2026-03-10 01:57:31'),
(27, NULL, NULL, 'auth.login', NULL, '{\"email\":\"raj@acme.com\"}', '103.84.203.253', '2026-03-10 01:57:39'),
(28, NULL, NULL, 'auth.logout', NULL, NULL, '103.84.203.253', '2026-03-10 01:58:01'),
(29, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '103.84.203.253', '2026-03-10 01:58:10'),
(30, 1, NULL, 'form.created', 'form:3', NULL, '122.160.108.18', '2026-03-10 05:04:56'),
(31, 1, NULL, 'lead.kanban_moved', 'lead:1,status:contacted', NULL, '122.160.108.18', '2026-03-10 06:33:32'),
(32, 1, NULL, 'lead.kanban_moved', 'lead:1,status:new', NULL, '122.160.108.18', '2026-03-10 06:33:43'),
(33, 1, NULL, 'platform.ai_updated', 'user:1', NULL, '122.160.108.18', '2026-03-10 06:34:25'),
(34, 1, NULL, 'platform.ai_updated', 'user:1', NULL, '122.160.108.18', '2026-03-10 06:36:19'),
(35, 1, NULL, 'platform.ai_updated', 'user:1', NULL, '122.160.108.18', '2026-03-10 07:01:32'),
(36, 1, NULL, 'account.created', 'account:2', '{\"name\":\"Ebrandist\"}', '122.160.108.18', '2026-03-10 07:07:51'),
(37, 1, NULL, 'auth.logout', NULL, NULL, '122.160.108.18', '2026-03-10 07:08:13'),
(38, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '122.160.108.18', '2026-03-10 07:08:30'),
(39, 7, 2, 'invitation.sent', NULL, '{\"email\":\"test@ebrandist.com\",\"role_id\":3}', '122.160.108.18', '2026-03-10 07:09:10'),
(40, 7, 2, 'domain.created', 'domain:ebrandist.com', NULL, '122.160.108.18', '2026-03-10 07:10:13'),
(41, 7, 2, 'form.created', 'form:4', NULL, '122.160.108.18', '2026-03-10 07:13:28'),
(42, 7, 2, 'auth.logout', NULL, NULL, '122.160.108.18', '2026-03-10 08:01:46'),
(43, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '122.160.108.18', '2026-03-10 08:02:57'),
(44, 1, NULL, 'auth.logout', NULL, NULL, '122.160.108.18', '2026-03-10 11:08:00'),
(45, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '122.160.108.18', '2026-03-10 11:08:33'),
(46, 1, NULL, 'auth.logout', NULL, NULL, '122.160.108.18', '2026-03-10 11:08:43'),
(47, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '122.160.108.18', '2026-03-10 11:08:57'),
(48, 7, 2, 'team.invite_approved', 'email:test@ebrandist.com', NULL, '122.160.108.18', '2026-03-10 11:16:50'),
(49, 7, 2, 'account.updated', 'account:2', NULL, '122.160.108.18', '2026-03-10 11:35:07'),
(50, 7, 2, 'domain.deleted', 'domain:ebrandist.com', NULL, '122.160.108.18', '2026-03-10 11:42:28'),
(51, 7, 2, 'domain.created', 'domain:ebrandist.com', NULL, '122.160.108.18', '2026-03-10 11:42:58'),
(52, 7, 2, 'domain.deleted', 'domain:ebrandist.com', NULL, '122.160.108.18', '2026-03-10 11:50:22'),
(53, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '2405:201:4019:c058:808c:922:75f7:f47', '2026-03-10 12:12:50'),
(54, 7, 2, 'auth.logout', NULL, NULL, '122.160.108.18', '2026-03-10 12:34:08'),
(55, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '122.160.108.18', '2026-03-10 12:34:14'),
(56, 1, NULL, 'account.updated', 'account:1', NULL, '122.160.108.18', '2026-03-10 12:34:47'),
(57, 1, NULL, 'role.updated', 'role:2', NULL, '122.160.108.18', '2026-03-10 12:35:24'),
(58, 1, NULL, 'auth.logout', NULL, NULL, '122.160.108.18', '2026-03-10 12:35:29'),
(59, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '122.160.108.18', '2026-03-10 12:35:38'),
(60, 7, 2, 'auth.logout', NULL, NULL, '122.160.108.18', '2026-03-10 12:35:45'),
(61, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '122.160.108.18', '2026-03-10 12:35:49'),
(62, 1, NULL, 'role.updated', 'role:2', NULL, '122.160.108.18', '2026-03-10 12:36:12'),
(63, 1, NULL, 'domain.deleted', 'domain:acme-marketing.com', NULL, '122.160.108.18', '2026-03-10 12:36:34'),
(64, 1, NULL, 'domain.deleted', 'domain:kokler.in', NULL, '122.160.108.18', '2026-03-10 12:36:37'),
(66, 1, NULL, 'auth.logout', NULL, NULL, '122.160.108.18', '2026-03-10 12:37:39'),
(67, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '122.160.108.18', '2026-03-10 12:37:43'),
(68, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '103.84.203.253', '2026-03-11 02:17:09'),
(69, 1, NULL, 'auth.logout', NULL, NULL, '103.84.203.253', '2026-03-11 02:18:14'),
(70, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '103.84.203.253', '2026-03-11 02:18:20'),
(71, 7, 2, 'auth.logout', NULL, NULL, '122.160.108.18', '2026-03-11 09:19:16'),
(72, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '122.160.108.18', '2026-03-11 09:19:22'),
(73, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '122.160.108.18', '2026-03-11 09:23:39'),
(74, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '122.160.108.18', '2026-03-11 09:23:49'),
(75, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '122.160.108.18', '2026-03-11 09:24:38'),
(76, 1, NULL, 'auth.logout', NULL, NULL, '122.160.108.18', '2026-03-11 09:24:40'),
(77, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '122.160.108.18', '2026-03-11 09:24:47'),
(78, 7, 2, 'auth.logout', NULL, NULL, '122.160.108.18', '2026-03-11 09:25:07'),
(79, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '122.160.108.18', '2026-03-11 09:25:12'),
(80, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '122.160.108.18', '2026-03-11 09:25:28'),
(81, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '122.160.108.18', '2026-03-11 12:51:10'),
(82, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '122.160.108.18', '2026-03-11 13:09:33'),
(83, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '122.160.108.18', '2026-03-11 13:17:40'),
(84, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '103.84.203.253', '2026-03-12 02:10:00'),
(85, 1, NULL, 'auth.logout', NULL, NULL, '122.160.108.18', '2026-03-12 05:28:13'),
(86, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '122.160.108.18', '2026-03-12 06:03:00'),
(87, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '122.160.108.18', '2026-03-12 09:13:36'),
(88, 1, NULL, 'auth.logout', NULL, NULL, '122.160.108.18', '2026-03-12 09:17:47'),
(89, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '122.160.108.18', '2026-03-12 09:18:19'),
(90, 7, 2, 'domain.created', 'domain:kokler.in', NULL, '122.160.108.18', '2026-03-12 09:18:43'),
(91, 7, 2, 'domain.verified', 'domain:kokler.in', NULL, '122.160.108.18', '2026-03-12 09:25:50'),
(92, 7, 2, 'form.created', 'form:5', NULL, '122.160.108.18', '2026-03-12 09:27:03'),
(93, 7, 2, 'lead.ai_analyzed', 'lead:4', NULL, '122.160.108.18', '2026-03-12 09:33:08'),
(94, 7, 2, 'lead.kanban_moved', 'lead:5,status:contacted', NULL, '122.160.108.18', '2026-03-12 09:43:10'),
(95, 7, 2, 'lead.kanban_moved', 'lead:5,status:contacted', NULL, '122.160.108.18', '2026-03-12 09:43:12'),
(96, 7, 2, 'lead.kanban_moved', 'lead:5,status:qualified', NULL, '122.160.108.18', '2026-03-12 09:43:14'),
(97, 7, 2, 'lead.kanban_moved', 'lead:4,status:converted', NULL, '122.160.108.18', '2026-03-12 09:43:17'),
(98, 7, 2, 'lead.kanban_moved', 'lead:4,status:converted', NULL, '122.160.108.18', '2026-03-12 09:43:18'),
(99, 7, 2, 'lead.kanban_moved', 'lead:4,status:new', NULL, '122.160.108.18', '2026-03-12 09:43:22'),
(100, 7, 2, 'lead.kanban_moved', 'lead:5,status:qualified', NULL, '122.160.108.18', '2026-03-12 09:43:27'),
(101, 7, 2, 'lead.merged', 'primary:5,merged:4', NULL, '122.160.108.18', '2026-03-12 09:45:09'),
(102, 7, 2, 'lead.updated', 'lead:5', NULL, '122.160.108.18', '2026-03-12 09:45:44'),
(103, 7, 2, 'lead.assigned', 'lead:5', '{\"to\":8}', '122.160.108.18', '2026-03-12 09:45:56'),
(104, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '2405:201:4019:c058:b1b8:c00:8b3e:85d6', '2026-03-12 10:41:49'),
(105, 7, 2, 'lead.ai_analyzed', 'lead:5', NULL, '122.160.108.18', '2026-03-12 11:32:16'),
(106, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '122.160.108.18', '2026-03-13 09:39:05'),
(107, 7, 2, 'campaign.created', 'campaign:1', NULL, '122.160.108.18', '2026-03-13 09:40:38'),
(108, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '103.84.203.253', '2026-03-14 02:53:03'),
(109, 7, 2, 'auth.logout', NULL, NULL, '103.84.203.253', '2026-03-14 03:23:45'),
(110, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '103.84.203.253', '2026-03-14 03:23:52'),
(111, 1, NULL, 'auth.logout', NULL, NULL, '103.84.203.253', '2026-03-14 03:24:51'),
(112, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '103.84.203.253', '2026-03-14 03:24:58'),
(113, 7, 2, 'lead.ai_analyzed', 'lead:6', NULL, '103.84.203.253', '2026-03-14 03:26:41'),
(114, 7, 2, 'campaign.edited', 'campaign:1', NULL, '103.84.203.253', '2026-03-14 03:54:09'),
(115, 7, 2, 'account.reminder_settings_updated', 'account:2', NULL, '103.84.203.253', '2026-03-14 04:16:00'),
(116, 7, 2, 'auth.logout', NULL, NULL, '103.84.203.253', '2026-03-14 08:57:28'),
(117, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '103.84.203.253', '2026-03-14 08:57:34'),
(118, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '103.84.203.253', '2026-03-14 08:57:52'),
(119, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '103.84.203.253', '2026-03-14 09:01:59'),
(120, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '103.84.203.253', '2026-03-14 09:05:19'),
(121, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '103.84.203.253', '2026-03-14 09:15:23'),
(122, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '103.84.203.253', '2026-03-14 09:15:34'),
(123, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '103.84.203.253', '2026-03-15 03:41:10'),
(124, 7, 2, 'auth.logout', NULL, NULL, '103.84.203.253', '2026-03-15 03:41:27'),
(125, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '103.84.203.253', '2026-03-15 03:41:31'),
(126, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '103.84.203.253', '2026-03-15 03:41:55'),
(127, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '103.84.203.253', '2026-03-15 03:42:03'),
(128, 1, NULL, 'auth.logout', NULL, NULL, '103.84.203.253', '2026-03-15 03:43:15'),
(129, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '103.84.203.253', '2026-03-15 03:43:40'),
(130, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '103.84.203.253', '2026-03-15 13:49:08'),
(131, 7, 2, 'campaign.created', 'campaign:3', NULL, '103.84.203.253', '2026-03-15 14:13:41'),
(132, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '103.84.203.253', '2026-03-16 02:03:13'),
(133, 7, 2, 'auth.logout', NULL, NULL, '103.84.203.253', '2026-03-16 02:58:10'),
(134, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '103.84.203.253', '2026-03-16 02:58:15'),
(135, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-16 11:05:42'),
(136, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-16 11:06:04'),
(137, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-16 11:28:01'),
(138, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-16 14:05:37'),
(139, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-16 17:18:20'),
(140, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-17 06:35:30'),
(141, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-17 06:35:58'),
(142, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-17 06:36:14'),
(143, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-17 07:11:37'),
(144, 1, NULL, 'user.role_changed', 'user:0', '{\"role_id\":3}', '::1', '2026-03-17 07:49:58'),
(145, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-17 10:45:30'),
(146, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-17 10:45:57'),
(147, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-17 10:46:14'),
(148, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-17 11:23:11'),
(149, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-17 11:23:16'),
(150, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-17 11:27:40'),
(151, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-17 12:54:53'),
(152, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"suspended\"}', '::1', '2026-03-17 12:55:34'),
(153, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"cancelled\"}', '::1', '2026-03-17 12:56:15'),
(154, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-17 12:56:41'),
(155, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-17 12:56:48'),
(156, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"suspended\"}', '::1', '2026-03-17 12:57:44'),
(157, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-17 12:57:50'),
(158, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-17 13:02:50'),
(159, 1, NULL, 'account.plan_changed', 'account:2', '{\"plan\":\"pro\"}', '::1', '2026-03-17 13:02:50'),
(160, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"suspended\"}', '::1', '2026-03-17 13:02:59'),
(161, 1, NULL, 'account.plan_changed', 'account:2', '{\"plan\":\"pro\"}', '::1', '2026-03-17 13:02:59'),
(162, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-17 13:03:07'),
(163, 1, NULL, 'account.plan_changed', 'account:2', '{\"plan\":\"pro\"}', '::1', '2026-03-17 13:03:07'),
(164, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-17 13:03:40'),
(165, 1, NULL, 'account.plan_changed', 'account:2', '{\"plan\":\"enterprise\"}', '::1', '2026-03-17 13:03:40'),
(166, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-17 13:03:58'),
(167, 1, NULL, 'account.plan_changed', 'account:2', '{\"plan\":\"pro\"}', '::1', '2026-03-17 13:03:58'),
(168, 1, NULL, 'account.created', 'account:3', '{\"name\":\"tester\"}', '::1', '2026-03-17 13:04:54'),
(169, 1, NULL, 'account.deleted', 'account:3', '{\"name\":\"tester\"}', '::1', '2026-03-17 16:04:21'),
(170, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-17 16:17:35'),
(171, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-17 16:18:43'),
(172, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-17 16:43:45'),
(173, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-17 16:44:49'),
(174, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-18 06:37:35'),
(175, 7, 2, 'campaign.created', 'campaign:7', NULL, '::1', '2026-03-18 11:34:57'),
(176, 7, 2, 'campaign.created', 'campaign:8', '{\"name\":\"Grow Your Biz\",\"source\":\"ai_generator\"}', '::1', '2026-03-18 11:36:18'),
(177, 7, 2, 'campaign.edited', 'campaign:8', NULL, '::1', '2026-03-18 11:37:00'),
(178, 7, 2, 'campaign.edited', 'campaign:7', NULL, '::1', '2026-03-18 11:48:59'),
(179, 7, 2, 'campaign.edited', 'campaign:8', NULL, '::1', '2026-03-18 11:49:14'),
(180, 7, 2, 'campaign.deleted', 'campaign:8', NULL, '::1', '2026-03-18 11:49:49'),
(181, 7, 2, 'campaign.deleted', 'campaign:7', NULL, '::1', '2026-03-18 11:51:36'),
(182, 7, 2, 'campaign.archived', 'campaign:1', NULL, '::1', '2026-03-18 11:52:16'),
(183, 7, 2, 'campaign.edited', 'campaign:1', NULL, '::1', '2026-03-18 11:52:32'),
(184, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-18 11:53:04'),
(185, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-18 11:53:15'),
(186, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-18 11:59:46'),
(187, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-18 11:59:50'),
(188, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-18 12:01:13'),
(189, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-18 12:01:17'),
(190, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-18 12:02:04'),
(191, 1, NULL, 'account.plan_changed', 'account:2', '{\"plan\":\"pro\"}', '::1', '2026-03-18 12:02:04'),
(192, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-18 12:03:55'),
(193, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-18 12:03:58'),
(194, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-18 12:28:43'),
(195, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-18 12:28:47'),
(196, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-18 12:29:07'),
(197, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-18 12:29:10'),
(198, 7, 2, 'campaign.created', 'campaign:10', '{\"name\":\"Elevate Digital\",\"source\":\"ai_generator\"}', '::1', '2026-03-18 14:58:40'),
(199, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-19 08:01:27'),
(200, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-19 09:34:32'),
(201, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-19 09:34:38'),
(202, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-19 09:37:06'),
(203, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-19 09:37:11'),
(204, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-19 09:40:29'),
(205, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-19 09:40:34'),
(206, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-19 09:45:21'),
(207, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-19 09:45:26'),
(208, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-19 10:01:38'),
(209, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-19 10:01:44'),
(210, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-19 10:02:04'),
(211, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-19 10:02:15'),
(212, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-19 10:02:20'),
(213, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-19 10:33:30'),
(214, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-19 10:33:38'),
(215, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-19 10:33:57'),
(216, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-19 10:35:24'),
(217, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-19 10:35:29'),
(218, 7, 2, 'domain.created', 'domain:ebrandist.com', NULL, '::1', '2026-03-19 10:55:37'),
(219, 7, 2, 'lead.ai_predicted', 'lead:7', NULL, '::1', '2026-03-19 17:11:07'),
(220, 7, 2, 'lead.ai_analyzed', 'lead:6', NULL, '::1', '2026-03-19 17:16:37'),
(221, 7, 2, 'lead.ai_analyzed', 'lead:6', NULL, '::1', '2026-03-19 17:16:49'),
(222, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-19 18:39:20'),
(223, 7, 2, 'campaign.deleted', 'campaign:10', NULL, '103.84.203.253', '2026-03-19 13:30:10'),
(224, 7, 2, 'campaign.deleted', 'campaign:3', NULL, '103.84.203.253', '2026-03-19 13:30:13'),
(225, 7, 2, 'campaign.deleted', 'campaign:1', NULL, '103.84.203.253', '2026-03-19 13:30:16'),
(226, 7, 2, 'form.deleted', 'form:5', NULL, '103.84.203.253', '2026-03-19 13:30:27'),
(227, 7, 2, 'form.created', 'form:6', NULL, '103.84.203.253', '2026-03-19 13:31:05'),
(228, 7, 2, 'campaign.created', 'campaign:11', '{\"name\":\"Grow Online\",\"source\":\"ai_generator\"}', '103.84.203.253', '2026-03-19 13:31:54'),
(229, 7, 2, 'lead.ai_analyzed', 'lead:9', NULL, '103.84.203.253', '2026-03-19 13:56:54'),
(230, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '103.84.203.253', '2026-03-20 01:26:36'),
(231, 7, 2, 'auth.logout', NULL, NULL, '122.160.108.18', '2026-03-20 04:52:49'),
(232, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '122.160.108.18', '2026-03-20 04:53:06'),
(233, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '122.160.108.18', '2026-03-20 04:57:28'),
(234, 1, NULL, 'auth.logout', NULL, NULL, '122.160.108.18', '2026-03-20 04:59:03'),
(235, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '122.160.108.18', '2026-03-20 04:59:09'),
(236, 7, 2, 'lead.auto_reply_sent', 'lead:9', NULL, '122.160.108.18', '2026-03-20 05:19:59'),
(237, 7, 2, 'form.updated', 'form:6', NULL, '122.160.108.18', '2026-03-20 05:22:15'),
(238, 7, 2, 'lead.auto_reply_sent', 'lead:9', NULL, '122.160.108.18', '2026-03-20 05:49:56'),
(239, 7, 2, 'form.updated', 'form:6', NULL, '122.160.108.18', '2026-03-20 05:50:45'),
(240, 7, 2, 'form.updated', 'form:6', NULL, '122.160.108.18', '2026-03-20 05:53:29'),
(241, 7, 2, 'lead.auto_reply_sent', 'lead:10', NULL, '122.160.108.18', '2026-03-20 06:13:46'),
(242, 7, 2, 'form.updated', 'form:6', NULL, '122.160.108.18', '2026-03-20 06:17:00'),
(243, 7, 2, 'lead.auto_reply_sent', 'lead:12', NULL, '122.160.108.18', '2026-03-20 06:19:49'),
(244, 7, 2, 'lead.email_sent', 'lead:12', NULL, '122.160.108.18', '2026-03-20 06:19:56'),
(245, 7, 2, 'form.updated', 'form:6', NULL, '122.160.108.18', '2026-03-20 06:50:30'),
(246, 7, 2, 'lead.ai_analyzed', 'lead:14', NULL, '122.160.108.18', '2026-03-20 07:04:15'),
(247, 7, 2, 'auth.logout', NULL, NULL, '122.160.108.18', '2026-03-20 09:17:33'),
(248, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '122.160.108.18', '2026-03-20 09:17:56'),
(249, 1, NULL, 'user.password_changed', 'user:1', NULL, '122.160.108.18', '2026-03-20 09:18:13'),
(250, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '122.160.108.18', '2026-03-20 09:19:50'),
(251, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '122.160.108.18', '2026-03-20 09:21:33'),
(252, 1, NULL, 'auth.logout', NULL, NULL, '122.160.108.18', '2026-03-20 09:21:39'),
(253, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '122.160.108.18', '2026-03-20 09:21:56'),
(254, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '122.160.108.18', '2026-03-20 09:22:23'),
(255, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '122.160.108.18', '2026-03-20 09:22:53'),
(256, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '122.160.108.18', '2026-03-20 09:23:00'),
(257, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '122.160.108.18', '2026-03-20 09:23:11'),
(258, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '122.160.108.18', '2026-03-20 09:23:29'),
(259, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '122.160.108.18', '2026-03-20 09:23:58'),
(260, 1, NULL, 'auth.logout', NULL, NULL, '122.160.108.18', '2026-03-20 09:24:08'),
(261, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '122.160.108.18', '2026-03-20 09:24:43'),
(262, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-20 15:01:23'),
(263, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-20 15:01:39'),
(264, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-20 15:02:31'),
(265, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-20 15:03:06'),
(266, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-20 15:03:11'),
(267, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-20 15:06:12'),
(268, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-20 15:07:09'),
(269, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-20 15:09:11'),
(270, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-20 15:09:43'),
(271, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-20 15:09:46'),
(272, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-20 15:09:56'),
(273, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-20 15:12:41'),
(274, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-20 15:12:56'),
(275, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-20 15:13:55'),
(276, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-20 15:14:03'),
(277, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-20 15:14:09'),
(278, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-20 15:15:06'),
(279, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-20 15:16:05'),
(280, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-20 16:51:10'),
(281, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-20 16:52:04'),
(282, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-20 16:52:07'),
(283, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-20 16:54:17'),
(284, 7, 2, 'account.reminder_settings_updated', 'account:2', NULL, '::1', '2026-03-20 17:35:58'),
(285, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-20 17:39:48'),
(286, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-20 17:39:54'),
(287, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-20 17:40:37'),
(288, 1, NULL, 'account.plan_changed', 'account:2', '{\"plan\":\"pro\"}', '::1', '2026-03-20 17:40:37'),
(289, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-20 17:41:21'),
(290, 1, NULL, 'account.plan_changed', 'account:2', '{\"plan\":\"pro\"}', '::1', '2026-03-20 17:41:21'),
(291, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-20 17:41:46'),
(292, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-20 17:41:51'),
(293, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-21 07:30:49'),
(294, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-21 07:30:53'),
(295, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-21 07:33:45'),
(296, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 07:34:33'),
(297, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-21 07:34:37'),
(298, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-21 07:38:41'),
(299, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-21 07:38:54'),
(300, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-21 07:40:12'),
(301, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 07:44:28'),
(302, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 08:18:54'),
(303, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 08:21:01'),
(304, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 08:21:10'),
(305, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 08:23:48'),
(306, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 08:25:08'),
(307, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 10:02:19'),
(308, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 10:02:32'),
(309, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 10:03:47'),
(310, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 10:04:06'),
(311, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 10:04:27'),
(312, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-21 10:19:07'),
(313, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-21 10:38:44'),
(314, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 10:40:32'),
(315, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-21 10:40:40'),
(316, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-21 10:47:10'),
(317, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 10:47:25'),
(318, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-21 10:47:28'),
(319, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-21 10:47:51'),
(320, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 10:48:00'),
(321, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-21 10:48:02'),
(322, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-21 11:28:57'),
(323, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 11:32:37'),
(324, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 11:33:04'),
(325, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-21 11:44:06'),
(326, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-21 11:44:12'),
(327, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-21 12:09:36'),
(328, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-21 12:09:43'),
(329, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:12:27'),
(330, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:13:01'),
(331, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:13:14'),
(332, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-21 12:14:45'),
(333, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-21 12:14:54'),
(334, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:18:20'),
(335, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:18:32'),
(336, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:19:57'),
(337, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:20:20'),
(338, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:20:50'),
(339, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-21 12:21:10'),
(340, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-21 12:21:19'),
(341, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:21:39'),
(342, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:21:54'),
(343, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:22:14'),
(344, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:22:27'),
(345, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:25:28'),
(346, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:25:50'),
(347, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:26:22'),
(348, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:26:38'),
(349, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:26:51'),
(350, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-21 12:26:57'),
(351, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-21 12:30:25'),
(352, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:42:31'),
(353, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:42:58'),
(354, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:44:07'),
(355, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:44:46'),
(356, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-21 12:45:01'),
(357, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-21 12:45:11'),
(358, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-21 12:45:20'),
(359, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-21 17:36:04'),
(360, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-21 17:36:11'),
(361, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-21 17:36:35'),
(362, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-21 17:36:43'),
(363, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-21 18:26:18'),
(364, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-21 18:33:29'),
(365, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-21 18:46:58'),
(366, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-21 18:47:03'),
(367, 1, NULL, 'user.profile_updated', 'user:1', NULL, '::1', '2026-03-21 20:09:39'),
(368, 1, NULL, 'user.profile_updated', 'user:1', NULL, '::1', '2026-03-21 20:13:50'),
(369, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-21 20:35:23'),
(370, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-21 20:35:28'),
(371, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-22 08:00:56'),
(372, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-22 08:01:07'),
(373, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-22 08:13:36'),
(374, 7, 2, 'account.reminder_settings_updated', 'account:2', NULL, '::1', '2026-03-22 08:44:54'),
(375, 7, 2, 'account.reminder_settings_updated', 'account:2', NULL, '::1', '2026-03-22 08:45:22'),
(376, 7, 2, 'account.reminder_settings_updated', 'account:2', NULL, '::1', '2026-03-22 08:49:01'),
(377, 7, 2, 'account.reminder_settings_updated', 'account:2', NULL, '::1', '2026-03-22 08:49:36'),
(378, 7, 2, 'account.reminder_settings_updated', 'account:2', NULL, '::1', '2026-03-22 08:49:40'),
(379, 7, 2, 'account.reminder_settings_updated', 'account:2', NULL, '::1', '2026-03-22 08:49:56'),
(380, 7, 2, 'account.reminder_settings_updated', 'account:2', NULL, '::1', '2026-03-22 08:50:03'),
(381, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-22 08:50:30'),
(382, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-22 08:50:36'),
(383, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-22 08:57:14'),
(384, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-22 08:57:41'),
(385, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-22 08:58:06'),
(386, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-22 08:58:11'),
(387, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-22 08:58:17'),
(388, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-22 09:03:18'),
(389, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-22 09:03:34'),
(390, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-22 09:03:40'),
(391, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-22 09:03:44'),
(392, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-22 09:04:06'),
(393, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-22 09:06:14'),
(394, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-22 09:06:23'),
(395, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-22 09:40:18'),
(396, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-23 06:44:16'),
(397, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-23 10:39:52'),
(398, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-23 10:40:00'),
(399, 7, 2, 'invitation.sent', NULL, '{\"email\":\"contactkokler@gmail.com\",\"role_id\":3}', '::1', '2026-03-23 10:48:34'),
(400, 7, 2, 'team.invite_revoked', 'invite:2', NULL, '::1', '2026-03-23 12:25:30'),
(401, 7, 2, 'invitation.sent', NULL, '{\"email\":\"contactkokler@gmail.com\",\"role_id\":4}', '::1', '2026-03-23 13:05:42'),
(402, 7, 2, 'team.invite_approved', 'email:contactkokler@gmail.com', NULL, '::1', '2026-03-23 13:29:00'),
(403, 7, 2, 'user.removed', 'user:10', NULL, '::1', '2026-03-23 13:37:24'),
(404, 7, 2, 'invitation.sent', NULL, '{\"email\":\"contactkokler@gmail.com\",\"role_id\":3}', '::1', '2026-03-23 13:37:38'),
(405, 7, 2, 'team.invite_approved', 'email:contactkokler@gmail.com', NULL, '::1', '2026-03-23 13:37:41'),
(406, 7, 2, 'spam.ip_blocked', 'ip:192.168.1.1', NULL, '::1', '2026-03-23 15:04:05'),
(407, 7, 2, 'spam.ip_unblocked', 'ip:192.168.1.1', NULL, '::1', '2026-03-23 15:06:22'),
(408, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-23 15:22:52'),
(409, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-23 15:22:56'),
(410, 1, NULL, 'spam.ip_blocked', 'ip:192.168.1.1', NULL, '::1', '2026-03-23 15:24:33'),
(411, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-23 16:18:13'),
(412, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-23 16:18:18'),
(413, 7, 2, 'lead.updated', 'lead:14', NULL, '::1', '2026-03-23 17:46:51'),
(414, 7, 2, 'lead.ownership_transferred', 'lead:14', '{\"from\":0,\"to\":7,\"reason\":\"\"}', '::1', '2026-03-23 17:47:14'),
(415, 7, 2, 'lead.updated', 'lead:14', NULL, '::1', '2026-03-23 17:47:14'),
(416, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-24 06:31:36'),
(417, 7, 2, 'lead.assigned', 'lead:13', '{\"to\":7}', '::1', '2026-03-24 10:48:48'),
(418, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-24 13:09:16'),
(419, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-24 13:09:19'),
(420, 1, NULL, 'role.assigned', 'user:4', NULL, '::1', '2026-03-24 13:39:49'),
(421, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-25 06:54:18'),
(422, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-25 06:55:28'),
(423, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-25 06:55:34'),
(424, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-25 06:55:59'),
(425, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-25 06:56:04'),
(426, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-25 06:57:25'),
(427, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-25 06:57:33'),
(428, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-25 06:57:40'),
(429, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-25 06:57:44'),
(430, 1, NULL, 'role.updated', 'role:1', NULL, '::1', '2026-03-25 06:58:06'),
(431, 1, NULL, 'role.updated', 'role:3', NULL, '::1', '2026-03-25 06:58:24'),
(432, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-25 06:58:27'),
(433, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-25 06:58:32'),
(434, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-25 14:24:32'),
(435, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-25 14:24:41'),
(436, 1, NULL, 'role.updated', 'role:1', NULL, '::1', '2026-03-25 14:25:09'),
(437, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-25 14:25:42'),
(438, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-25 14:25:49'),
(439, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-25 14:26:24'),
(440, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-25 14:26:38'),
(441, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-25 14:27:17'),
(442, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-25 14:27:22'),
(443, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-25 14:27:33'),
(444, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-25 14:27:54'),
(445, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-25 14:28:08'),
(446, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-25 14:28:38'),
(447, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-25 15:42:21'),
(448, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-25 15:42:29'),
(449, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-25 16:37:01'),
(450, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-25 16:37:07'),
(451, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-25 17:13:07'),
(452, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-25 17:13:12'),
(453, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-25 17:18:35'),
(454, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-25 17:18:40'),
(455, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-25 17:21:40'),
(456, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-25 17:21:45'),
(457, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-25 17:23:16'),
(458, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-25 17:23:23'),
(459, NULL, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-26 07:52:38'),
(460, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-26 07:52:43'),
(461, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-27 07:26:31'),
(462, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-27 07:40:15'),
(463, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-27 07:40:20'),
(464, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-27 07:41:28'),
(465, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-27 07:41:35'),
(466, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-27 07:43:43'),
(467, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-27 07:43:49'),
(468, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-27 07:44:12'),
(469, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-27 07:44:18'),
(470, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-27 10:32:54'),
(471, 1, NULL, 'account.plan_changed', 'account:2', '{\"plan\":\"pro\"}', '::1', '2026-03-27 10:32:54'),
(472, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-27 10:32:56'),
(473, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-27 10:33:02'),
(474, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-27 10:34:55'),
(475, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-27 10:35:54'),
(476, 1, NULL, 'platform.ai_updated', 'user:1', NULL, '::1', '2026-03-27 10:37:36'),
(477, 1, NULL, 'platform.ai_updated', 'user:1', NULL, '::1', '2026-03-27 10:37:43'),
(478, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-27 10:50:13'),
(479, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-27 11:27:23'),
(480, 1, NULL, 'account.plan_changed', 'account:2', '{\"plan\":\"pro\"}', '::1', '2026-03-27 11:27:23'),
(481, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-27 11:27:53'),
(482, 1, NULL, 'account.plan_changed', 'account:2', '{\"plan\":\"pro\"}', '::1', '2026-03-27 11:27:53'),
(483, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-27 11:36:38'),
(484, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-27 11:36:50'),
(485, 1, NULL, 'platform.settings_updated', 'user:1', NULL, '::1', '2026-03-27 11:40:46'),
(486, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-27 11:44:08'),
(487, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-27 11:44:50'),
(488, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-27 12:41:32'),
(489, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-27 12:41:43'),
(490, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-27 12:41:51'),
(491, 1, NULL, 'account.plan_changed', 'account:2', '{\"plan\":\"pro\"}', '::1', '2026-03-27 12:41:51'),
(492, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-27 12:41:55'),
(493, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-27 12:41:59'),
(494, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-27 12:49:57'),
(495, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-27 12:50:02'),
(496, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-27 12:51:06'),
(497, 1, NULL, 'account.plan_changed', 'account:2', '{\"plan\":\"pro\"}', '::1', '2026-03-27 12:51:06'),
(498, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-27 12:51:40'),
(499, 1, NULL, 'account.plan_changed', 'account:2', '{\"plan\":\"pro\"}', '::1', '2026-03-27 12:51:40'),
(500, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-27 12:54:28'),
(501, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-27 12:54:34'),
(502, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-27 12:55:12'),
(503, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-27 12:55:18'),
(504, 1, NULL, 'role.updated', 'role:2', NULL, '::1', '2026-03-27 12:55:50'),
(505, 1, NULL, 'role.updated', 'role:2', NULL, '::1', '2026-03-27 12:55:55'),
(506, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-27 12:56:26'),
(507, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-27 12:56:30'),
(508, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-27 12:57:31'),
(509, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-27 12:57:37'),
(510, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-27 13:14:31'),
(511, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-27 13:14:36'),
(512, 1, NULL, 'account.created', 'account:4', '{\"name\":\"Kokler\"}', '::1', '2026-03-27 13:17:40'),
(513, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-27 13:17:51'),
(514, NULL, NULL, 'auth.login', NULL, '{\"email\":\"contact@kokler.in\"}', '::1', '2026-03-27 13:18:11'),
(515, NULL, NULL, 'domain.created', 'domain:kokler.in', NULL, '::1', '2026-03-27 13:19:26'),
(516, NULL, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-27 13:20:00'),
(517, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-27 13:20:06'),
(518, 1, NULL, 'account.status_changed', 'account:4', '{\"status\":\"active\"}', '::1', '2026-03-27 13:20:13'),
(519, 1, NULL, 'account.status_changed', 'account:4', '{\"status\":\"active\"}', '::1', '2026-03-27 13:20:24'),
(520, 1, NULL, 'account.status_changed', 'account:4', '{\"status\":\"active\"}', '::1', '2026-03-27 13:20:45'),
(521, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-27 13:23:01'),
(522, NULL, NULL, 'auth.login', NULL, '{\"email\":\"contact@kokler.in\"}', '::1', '2026-03-27 13:23:07'),
(523, NULL, NULL, 'domain.deleted', 'domain:kokler.in', NULL, '::1', '2026-03-27 13:25:05'),
(524, NULL, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-27 13:26:58'),
(525, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-27 13:27:03'),
(526, 7, 2, 'lead.kanban_moved', 'lead:8,status:contacted', NULL, '::1', '2026-03-27 13:27:42'),
(527, 7, 2, 'lead.kanban_moved', 'lead:12,status:contacted', NULL, '::1', '2026-03-27 13:27:46'),
(528, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-27 13:39:51'),
(529, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-27 13:39:55'),
(530, 1, NULL, 'account.status_changed', 'account:4', '{\"status\":\"active\"}', '::1', '2026-03-27 13:40:11'),
(531, 1, NULL, 'account.status_changed', 'account:4', '{\"status\":\"active\"}', '::1', '2026-03-27 13:40:32'),
(532, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-27 13:40:39'),
(533, NULL, NULL, 'auth.login', NULL, '{\"email\":\"contact@kokler.in\"}', '::1', '2026-03-27 13:40:49'),
(534, NULL, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-27 13:41:08'),
(535, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-27 13:41:34'),
(536, 1, NULL, 'account.deleted', 'account:4', '{\"name\":\"Kokler\"}', '::1', '2026-03-27 13:47:56'),
(537, 1, NULL, 'account.status_changed', 'account:2', '{\"status\":\"active\"}', '::1', '2026-03-27 13:53:05'),
(538, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-27 13:53:12'),
(539, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-27 13:53:17'),
(540, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-27 13:53:27');
INSERT INTO `audit_log` (`id`, `user_id`, `account_id`, `action`, `target`, `meta`, `ip_address`, `created_at`) VALUES
(541, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-27 13:53:31'),
(542, 1, NULL, 'account.plan_assigned', 'account:2', '{\"plan\":\"Personal\",\"type\":\"active\",\"expires\":\"2026-04-27 23:59:59\"}', '::1', '2026-03-27 13:55:17'),
(543, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-27 13:57:05'),
(544, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-27 13:57:10'),
(545, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-27 14:04:46'),
(546, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-27 14:04:55'),
(547, 1, NULL, 'auth.logout', NULL, NULL, '::1', '2026-03-27 16:33:36'),
(548, 7, 2, 'auth.login', NULL, '{\"email\":\"ebrandist@gmail.com\"}', '::1', '2026-03-27 16:33:41'),
(549, 7, 2, 'auth.logout', NULL, NULL, '::1', '2026-03-27 17:24:18'),
(550, 1, NULL, 'auth.login', NULL, '{\"email\":\"admin@leadpro.com\"}', '::1', '2026-03-27 17:24:22');

-- --------------------------------------------------------

--
-- Table structure for table `billing_emails`
--

DROP TABLE IF EXISTS `billing_emails`;
CREATE TABLE `billing_emails` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `email_type` enum('invoice','payment_reminder','renewal_reminder','expiration_warning') DEFAULT 'invoice',
  `recipient_email` varchar(255) DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `reference_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `campaigns`
--

DROP TABLE IF EXISTS `campaigns`;
CREATE TABLE `campaigns` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `objective` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('draft','active','paused','archived') COLLATE utf8mb4_unicode_ci DEFAULT 'draft',
  `owner_id` int(10) UNSIGNED DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `color` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT '#2563eb',
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ai_service` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ai_target_audience` text COLLATE utf8mb4_unicode_ci,
  `ai_location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ai_pricing` text COLLATE utf8mb4_unicode_ci,
  `ai_booking_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ai_context` text COLLATE utf8mb4_unicode_ci,
  `reply_mode` enum('suggest','auto_instant','auto_intent') COLLATE utf8mb4_unicode_ci DEFAULT 'suggest' COMMENT 'Default reply mode for leads from this campaign',
  `auto_reply_tone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'professional' COMMENT 'professional|friendly|urgent'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `campaigns`
--

INSERT INTO `campaigns` (`id`, `account_id`, `name`, `description`, `objective`, `status`, `owner_id`, `start_date`, `end_date`, `color`, `created_by`, `created_at`, `updated_at`, `ai_service`, `ai_target_audience`, `ai_location`, `ai_pricing`, `ai_booking_url`, `ai_context`, `reply_mode`, `auto_reply_tone`) VALUES
(11, 2, 'Grow Online', NULL, 'Generate leads for small business owners with a free trial offer', 'draft', NULL, NULL, NULL, '#f0f4ff', 7, '2026-03-19 13:31:54', '2026-03-20 01:26:46', NULL, NULL, 'Gurgaon', NULL, '', NULL, 'suggest', 'professional');

-- --------------------------------------------------------

--
-- Table structure for table `campaign_knowledge_faqs`
--

DROP TABLE IF EXISTS `campaign_knowledge_faqs`;
CREATE TABLE `campaign_knowledge_faqs` (
  `id` int(10) UNSIGNED NOT NULL,
  `campaign_id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `question` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'e.g. pricing, process, eligibility',
  `is_active` tinyint(1) DEFAULT '1',
  `sort_order` int(10) DEFAULT '0',
  `times_used` int(10) DEFAULT '0' COMMENT 'Phase 12: how many times AI used this entry',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `campaign_knowledge_pages`
--

DROP TABLE IF EXISTS `campaign_knowledge_pages`;
CREATE TABLE `campaign_knowledge_pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `campaign_id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `url` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_title` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci COMMENT 'Extracted plain text from the page',
  `word_count` int(10) DEFAULT '0',
  `status` enum('pending','crawled','failed') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `error_message` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crawled_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `campaign_knowledge_pages`
--

INSERT INTO `campaign_knowledge_pages` (`id`, `campaign_id`, `account_id`, `url`, `page_title`, `content`, `word_count`, `status`, `error_message`, `crawled_at`, `created_at`) VALUES
(1, 11, 2, 'https://ebrandist.com/', 'eBrandist - Best Digital Marketing Agency Delhi NCR | Growth Experts', 'eBrandist - Best Digital Marketing Agency Delhi NCR | Growth Experts\n\n \n \n\n \n \n\nSkip to content\n \n \n \n \n \n \n \n\n \n\n \n +91 9013609389Call or Whatsapp Now! \n\n \n \n\n \n \n\n \n \n \n\n \n \n \n \n \n \n \n \n \n \n Your Growth-Focused Digital Marketing Agency \n \n \n \n We fuel digital growth and turn clicks into customers \n \n \n \n \n \n \n Get a Free Consultation Today!\n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n Revenue-Driving Digital Marketing Agency In Delhi NCR\n \n \n \n \n If you’re looking for digital marketing experts to take your business to the next level, you’ve come to the right place. At eBrandist, we offer a wide range of digital marketing services, all of which can be tailored to the needs of your business. Our services are available for most industries, helping you to reach your target audience and drive sales.  \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n\n \n \n \n \n \n \n\n \n \n Customized Strategies \n \n \n \n Our marketing plans are customised according to your brand’s goals, industry, and target audience. \n \n \n \n \n \n \n \n \n \n\n \n \n \n \n \n \n\n \n \n Experienced Team \n \n \n \n Our experts use state-of-art tools and data-backed insights to create strategies for your business. \n \n \n \n \n \n \n \n \n \n\n \n \n \n \n \n \n\n \n \n Client-Centric Approach \n \n \n \n Our team works with you to understand your business needs and we deliver solutions that deliver maximum results. \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n Our Result-Driven Digital Marketing Services \n \n \n \n Unlock your brand’s full potential with our AI-driven, result-oriented digital marketing solutions: \n \n \n \n \n \n\n \n \n \n \n \n \n\n \n \n Website Development \n \n \n \n Build stunning, high-converting websites. \n \n \n \n \n \n \n \n \n \n\n \n \n \n \n \n \n\n \n \n SEO Services \n \n \n \n Rank higher, attract organic traffic, and build authority. \n \n \n \n \n \n \n \n \n \n\n \n \n \n \n \n \n\n \n \n Google Ads \n \n \n \n Maximize ROI with data-driven ad campaigns.\n \n \n \n \n \n \n \n \n \n \n\n \n \n \n \n \n \n\n \n \n Facebook Marketing \n \n \n \n Target the right audience &amp; maximize ROI with high-converting ads. \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n Why Choose eBrandist as your Digital Marketing Agency Delhi NCR? \n \n \n \n \n In the fast-evolving digital world, small businesses must leverage strategic and budget-friendly marketing solutions to stay ahead. Our Digital Marketing Agency is dedicated to empowering small businesses by enhancing their online visibility, connecting them with the right audience, and delivering measurable growth. \n \n \n \n \n \n \n Contact Now\n \n \n \n \n \n \n \n \n \n \n \n\n \n \n \n \n \n \n\n \n \n Conversion-Optimized Web Development \n \n \n \n A strong online presence starts with an optimized website. We build high-performing, mobile-friendly websites that turn visitors into loyal customers.\n \n \n \n \n \n \n \n \n \n \n\n \n \n \n \n \n \n\n \n \n Cutting-Edge SEO &amp; Organic Growth \n \n \n \n Our SEO experts help you rank higher on search engines with proven on-page, off-page, and technical SEO strategies.\n \n \n \n \n \n \n \n \n \n \n\n \n \n \n \n \n \n\n \n \n Multi-Channel Social Media Growth \n \n \n \n We leverage the latest trends across platforms like Instagram, Facebook, LinkedIn, and more to boost brand awareness and engagement.\n \n \n \n \n \n \n \n \n \n \n\n \n \n \n \n \n \n\n \n \n Data-Driven Marketing Strategies \n \n \n \n Every campaign we create is backed by deep analytics, real-time tracking, and measurable KPIs to ensure maximum ROI.\n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n Industries we served \n \n \n \n Elevate Your Brand with eBrandist &#8211; Cutting-Edge Web Design &amp; Digital Solutions for Every Industry \n \n \n \n \n E-commerce \n \n \n \n Manufacturers \n \n \n \n Doctors \n \n \n \n Lawyers \n \n \n \n Chartered Accountants \n \n \n \n Interior Designers \n \n \n \n Real Estate \n \n \n \n Schools &amp; Colleges \n \n \n \n \n \n \n \n \n \n \n Elevate Your Brand with eBrandist – A Premier Web Design &amp; Digital Marketing Agency In Delhi NCR \n \n \n \n At eBrandist, we go beyond conventional marketing strategies to amplify your brand’s success. As a top-tier web design and digital marketing agency, we specialize in crafting customized solutions that align with your business goals. Whether you&#8217;re looking to enhance your online presence, attract the right audience, or boost conversions, our expert-driven approach ensures measurable growth and lasting impact.Our comprehensive digital marketing services cater to diverse industries, helping businesses of all sizes thrive in the digital landscape. From SEO and social media marketing to website design and performance-driven campaigns, we tailor our strategies to suit your unique needs. Let’s take your business beyond expectations &#8211; partner with eBrandist today and unlock new possibilities! 🚀 \n \n \n \n \n \n \n Years Experience \n \n 0\n \n \n \n \n \n \n \n \n Completed Projects \n \n 0\n \n \n \n \n \n \n \n \n Campaigns Delivered \n \n 0\n \n \n \n \n \n \n \n \n Running Projects \n \n 0\n \n \n \n \n \n \n \n \n \n \n \n \n \n Let’s grow your business online! Contact us today for a FREE Website or Account Audit! \n \n \n \n Connecting Your Brand with the Right Customers\n \n \n \n \n \n \n Book a call now! \n \n \n \n \n Contact Form DemoNamePhone NumberEmailService RequiredWebsite DevelopmentSEO ServicesGoogle AdsFacebook MarketingShopify PPCMessageSubmit Request', 564, 'crawled', NULL, '2026-03-19 13:51:12', '2026-03-19 13:51:04');

-- --------------------------------------------------------

--
-- Table structure for table `campaign_knowledge_policies`
--

DROP TABLE IF EXISTS `campaign_knowledge_policies`;
CREATE TABLE `campaign_knowledge_policies` (
  `id` int(10) UNSIGNED NOT NULL,
  `campaign_id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `policy_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'cancellation|appointment|refund|consultation|other',
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `sort_order` int(10) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `campaign_knowledge_pricing`
--

DROP TABLE IF EXISTS `campaign_knowledge_pricing`;
CREATE TABLE `campaign_knowledge_pricing` (
  `id` int(10) UNSIGNED NOT NULL,
  `campaign_id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `service_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'e.g. £199, From £50, £99-£299',
  `price_notes` text COLLATE utf8mb4_unicode_ci COMMENT 'What is included, payment terms etc.',
  `special_offer` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'e.g. 20% off this month, Free consultation',
  `is_active` tinyint(1) DEFAULT '1',
  `sort_order` int(10) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `campaign_knowledge_pricing`
--

INSERT INTO `campaign_knowledge_pricing` (`id`, `campaign_id`, `account_id`, `service_name`, `price`, `price_notes`, `special_offer`, `is_active`, `sort_order`, `created_at`) VALUES
(1, 11, 2, 'Website Development', '200', '', '20%', 1, 0, '2026-03-19 13:50:38');

-- --------------------------------------------------------

--
-- Table structure for table `campaign_knowledge_profile`
--

DROP TABLE IF EXISTS `campaign_knowledge_profile`;
CREATE TABLE `campaign_knowledge_profile` (
  `id` int(10) UNSIGNED NOT NULL,
  `campaign_id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `business_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_description` text COLLATE utf8mb4_unicode_ci,
  `industry` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `working_hours` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'e.g. Mon-Fri 9am-6pm, Sat 10am-4pm',
  `service_locations` text COLLATE utf8mb4_unicode_ci COMMENT 'Areas/cities served',
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `tone_of_voice` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'professional' COMMENT 'professional|friendly|formal|casual',
  `language` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'en',
  `extra_context` text COLLATE utf8mb4_unicode_ci COMMENT 'Anything else AI should know about this business',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `campaign_knowledge_profile`
--

INSERT INTO `campaign_knowledge_profile` (`id`, `campaign_id`, `account_id`, `business_name`, `business_description`, `industry`, `working_hours`, `service_locations`, `phone`, `email`, `website`, `address`, `tone_of_voice`, `language`, `extra_context`, `updated_at`) VALUES
(1, 11, 2, 'Grow Online', 'Your website is about your business, not ours. One consultants will meet with you to learn about your business, and the sort of website you need. Then we’ll help you get everything ready for your new website/app to be created. \r\n\r\nBefore launching your marketing plan we create a strategy from information in the discovery & research process. A structured plan means you’re in control of your digital strategy with a clear growth plan.', 'Digital Marketing Agency', '', 'Gurgaon', '9219222255', 'contact@ebrandist.com', 'https://ebrandist.com/', 'Sector 62, Noida, Uttar Pradesh 201012', 'professional', 'en', 'tst', '2026-03-20 01:26:57');

-- --------------------------------------------------------

--
-- Table structure for table `campaign_knowledge_services`
--

DROP TABLE IF EXISTS `campaign_knowledge_services`;
CREATE TABLE `campaign_knowledge_services` (
  `id` int(10) UNSIGNED NOT NULL,
  `campaign_id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `benefits` text COLLATE utf8mb4_unicode_ci COMMENT 'Key benefits, one per line',
  `duration` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'e.g. 60 minutes, 2-3 weeks',
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `sort_order` int(10) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `campaign_knowledge_services`
--

INSERT INTO `campaign_knowledge_services` (`id`, `campaign_id`, `account_id`, `name`, `description`, `benefits`, `duration`, `category`, `is_active`, `sort_order`, `created_at`) VALUES
(1, 11, 2, 'Website Development', 'Your website is often your first and only chance to make a good impression when someone finds you online. It takes a lot of time and effort to make a good first impression. We’ve been building beautiful websites for over 15 years, helping businesses large and small close the deal. At eBrandist, we identify the project requirements based on analysis and direction from the client and try to build the web that will bring them the most value long-term. We offer mobile websites with faster load times, optimized browsing and sites that are responsive to multiple screen sizes.', 'WordPress Development\r\nE-commerce Development\r\nWebsite Redesigning', '2-3 Sessions', 'Website', 1, 0, '2026-03-19 13:50:18');

-- --------------------------------------------------------

--
-- Table structure for table `campaign_knowledge_usage`
--

DROP TABLE IF EXISTS `campaign_knowledge_usage`;
CREATE TABLE `campaign_knowledge_usage` (
  `id` int(10) UNSIGNED NOT NULL,
  `campaign_id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `lead_id` int(10) UNSIGNED DEFAULT NULL,
  `source_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'smart_reply|lead_analysis|follow_up',
  `query_text` text COLLATE utf8mb4_unicode_ci COMMENT 'The lead message or context that triggered retrieval',
  `kb_types_used` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'CSV: profile,services,pricing,faq,policy,page',
  `kb_entry_ids` text COLLATE utf8mb4_unicode_ci COMMENT 'JSON: {faq:[1,3], pricing:[2]}',
  `confidence` tinyint(3) DEFAULT NULL COMMENT '0-100, AI confidence in retrieved knowledge',
  `was_helpful` tinyint(1) DEFAULT NULL COMMENT 'null=unknown, 1=yes, 0=no (for future feedback)',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `campaign_pages`
--

DROP TABLE IF EXISTS `campaign_pages`;
CREATE TABLE `campaign_pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `campaign_id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('draft','published') COLLATE utf8mb4_unicode_ci DEFAULT 'draft',
  `page_data` longtext COLLATE utf8mb4_unicode_ci,
  `meta_title` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_desc` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_id` int(10) UNSIGNED DEFAULT NULL,
  `views` int(10) UNSIGNED DEFAULT '0',
  `published_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `og_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `campaign_pages`
--

INSERT INTO `campaign_pages` (`id`, `campaign_id`, `account_id`, `title`, `slug`, `status`, `page_data`, `meta_title`, `meta_desc`, `form_id`, `views`, `published_at`, `created_at`, `updated_at`, `og_image`) VALUES
(10, 11, 2, 'Unlock Your Online Potential', 'unlock-your-online-potential', 'published', '[{\"type\":\"nav_bar\",\"brand\":\"DigitalBoost\",\"brandUrl\":\"#\",\"links\":[{\"label\":\"Features\",\"url\":\"#\"},{\"label\":\"Pricing\",\"url\":\"#\"}],\"ctaText\":\"Start Free Trial\",\"ctaUrl\":\"#\",\"ctaBg\":\"#2563eb\",\"bgColor\":\"#ffffff\",\"textColor\":\"#475569\",\"id\":\"aia6e18571\",\"padding\":\"20\"},{\"type\":\"hero_section\",\"headline\":\"Transform Your Business with Digital Marketing\",\"subheadline\":\"Get a free trial and see the results for yourself\",\"btnText\":\"Start Free Trial\",\"btnUrl\":\"#\",\"btnBg\":\"#2563eb\",\"bgColor\":\"#1e293b\",\"overlayColor\":\"rgba(0,0,0,0.5)\",\"layout\":\"split\",\"showForm\":true,\"formTitle\":\"Get Started with Your Free Trial\",\"minHeight\":500,\"id\":\"aia1e00a8e\",\"padding\":\"20\"},{\"type\":\"trust_badges\",\"badges\":[\"Google Partner\",\"Facebook Marketing Partner\",\"ISO 27001 Certified\",\"4.9/5 Rated\"],\"id\":\"ai57e0d53e\",\"padding\":\"20\"},{\"type\":\"feature_grid\",\"headline\":\"What You\'ll Get with DigitalBoost\",\"subheadline\":\"Expert digital marketing solutions to grow your business\",\"cols\":3,\"bgColor\":\"#fff\",\"items\":[{\"icon\":\"🎯\",\"title\":\"Targeted Advertising\",\"desc\":\"Reach your ideal audience with precision targeting\"},{\"icon\":\"⚡\",\"title\":\"Lightning-Fast Results\",\"desc\":\"See real results in no time with our expert strategies\"},{\"icon\":\"🛡\",\"title\":\"Expert Guidance\",\"desc\":\"Get dedicated support from our team of experts\"}],\"id\":\"aie0235a56\",\"padding\":\"20\"},{\"type\":\"testimonial\",\"quote\":\"DigitalBoost has been a game-changer for our business. We\'ve seen a significant increase in sales and website traffic.\",\"author\":\"Emily Chen\",\"role\":\"Owner, Green Earth Landscaping\",\"color\":\"#2563eb\",\"id\":\"aie5b79397\",\"padding\":\"20\"},{\"type\":\"stats_row\",\"bgColor\":\"#f8fafc\",\"items\":[{\"number\":\"100+\",\"label\":\"Happy Clients\"},{\"number\":\"500%\",\"label\":\"Average ROI Increase\"},{\"number\":\"24/7\",\"label\":\"Dedicated Support\"}],\"id\":\"ai05703a3f\",\"padding\":\"20\"},{\"type\":\"lead_form\",\"title\":\"Get Started with Your Free Trial\",\"submitText\":\"Start Free Trial\",\"successMsg\":\"Thank you for signing up! We\'ll be in touch soon.\",\"bg\":\"#f8fafc\",\"id\":\"ai7d36fef8\",\"padding\":\"20\"},{\"type\":\"footer_block\",\"brand\":\"DigitalBoost\",\"description\":\"Empowering small businesses to succeed online\",\"bgColor\":\"#0f172a\",\"textColor\":\"#94a3b8\",\"brandColor\":\"#fff\",\"columns\":[{\"title\":\"Product\",\"links\":[{\"label\":\"Features\",\"url\":\"#\"}]},{\"title\":\"Company\",\"links\":[{\"label\":\"About\",\"url\":\"#\"}]}],\"copyright\":\" 2024. All rights reserved.\",\"id\":\"aica6149af\",\"padding\":\"20\"}]', 'Grow Online', 'Generate leads for small business owners with a free trial offer', 6, 14, '2026-03-19 13:31:58', '2026-03-19 13:31:54', '2026-03-20 07:03:28', '');

-- --------------------------------------------------------

--
-- Table structure for table `campaign_templates`
--

DROP TABLE IF EXISTS `campaign_templates`;
CREATE TABLE `campaign_templates` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'NULL = system template, set = user-saved',
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'general',
  `description` varchar(400) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thumbnail_emoji` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '?',
  `thumbnail_color` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT '#2563eb',
  `page_data` longtext COLLATE utf8mb4_unicode_ci COMMENT 'JSON blocks array',
  `is_system` tinyint(1) DEFAULT '1',
  `sort_order` int(11) DEFAULT '0',
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `is_active` tinyint(1) DEFAULT '1',
  `is_featured` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `campaign_templates`
--

INSERT INTO `campaign_templates` (`id`, `account_id`, `name`, `category`, `description`, `thumbnail_emoji`, `thumbnail_color`, `page_data`, `is_system`, `sort_order`, `created_by`, `created_at`, `is_active`, `is_featured`) VALUES
(1, NULL, 'Lead Generation', 'lead_gen', 'Minimal high-converting page: headline, benefits, and a lead capture form.', 'user-account', '#2563eb', '[{\"id\":\"t1a\",\"type\":\"headline\",\"padding\":\"40\",\"text\":\"Get [Your Offer] Today\",\"align\":\"center\",\"size\":\"2.4rem\",\"color\":\"#0f172a\",\"bold\":true},{\"id\":\"t1b\",\"type\":\"subheadline\",\"padding\":\"8\",\"text\":\"Join thousands of businesses already growing with us.\",\"align\":\"center\",\"size\":\"1.15rem\",\"color\":\"#475569\",\"bold\":false},{\"id\":\"t1c\",\"type\":\"spacer\",\"height\":\"20\"},{\"id\":\"t1d\",\"type\":\"bullet_list\",\"padding\":\"20\",\"items\":[\"✅ Benefit one — explain the key value\",\"✅ Benefit two — another reason to act\",\"✅ Benefit three — seal the deal\",\"✅ No commitment. Cancel anytime.\"],\"color\":\"#334155\"},{\"id\":\"t1e\",\"type\":\"lead_form\",\"padding\":\"24\",\"title\":\"Claim Your Free Access\",\"submitText\":\"Get Started Now\",\"successMsg\":\"Thank you! We will be in touch shortly.\",\"bg\":\"#f8fafc\"},{\"id\":\"t1f\",\"type\":\"trust_badges\",\"padding\":\"20\",\"badges\":[\"SSL Secured\",\"No Credit Card\",\"GDPR Compliant\",\"5-Star Support\"]}]', 1, 1, NULL, '2026-03-14 08:04:10', 1, 0),
(2, NULL, 'Webinar Registration', 'webinar', 'Countdown timer, agenda, speaker info, and registration form.', '🎥', '#7c3aed', '[{\"id\":\"t2a\",\"type\":\"section_title\",\"padding\":\"32\",\"text\":\"FREE LIVE WEBINAR\",\"align\":\"center\",\"size\":\"0.85rem\",\"color\":\"#7c3aed\"},{\"id\":\"t2b\",\"type\":\"headline\",\"padding\":\"12\",\"text\":\"[Topic]: How to [Result] in [Timeframe]\",\"align\":\"center\",\"size\":\"2.2rem\",\"color\":\"#0f172a\",\"bold\":true},{\"id\":\"t2c\",\"type\":\"paragraph\",\"padding\":\"10\",\"text\":\"Join us live on [Date] at [Time] — limited seats available.\",\"align\":\"center\",\"size\":\"1rem\",\"color\":\"#64748b\"},{\"id\":\"t2d\",\"type\":\"countdown\",\"padding\":\"24\",\"label\":\"Webinar starts in:\",\"targetDate\":\"2026-04-01\"},{\"id\":\"t2e\",\"type\":\"bullet_list\",\"padding\":\"20\",\"items\":[\"What you will learn in this webinar\",\"Key insight #2 attendees always value\",\"Live Q&A session with the expert\",\"Free resource pack for all attendees\"],\"color\":\"#334155\"},{\"id\":\"t2f\",\"type\":\"lead_form\",\"padding\":\"24\",\"title\":\"Reserve Your Free Seat\",\"submitText\":\"Register Now — It\'s Free\",\"successMsg\":\"You are registered! Check your email for details.\",\"bg\":\"#faf5ff\"},{\"id\":\"t2g\",\"type\":\"trust_badges\",\"padding\":\"16\",\"badges\":[\"Free to Attend\",\"Live + Replay\",\"Expert Speaker\",\"Certificate of Attendance\"]}]', 1, 2, NULL, '2026-03-14 08:04:10', 1, 0),
(3, NULL, 'Product Launch', 'product_launch', 'Hero headline, feature highlights, pricing, and a strong CTA.', '🚀', '#0ea5e9', '[{\"id\":\"t3a\",\"type\":\"offer_banner\",\"padding\":\"24\",\"headline\":\"🚀 Now Live — Introducing [Product Name]\",\"text\":\"Early access pricing ends soon. Lock in your rate today.\",\"bg1\":\"#0ea5e9\",\"bg2\":\"#2563eb\"},{\"id\":\"t3b\",\"type\":\"headline\",\"padding\":\"36\",\"text\":\"[Product Name] — [One-line Value Proposition]\",\"align\":\"center\",\"size\":\"2.2rem\",\"color\":\"#0f172a\",\"bold\":true},{\"id\":\"t3c\",\"type\":\"paragraph\",\"padding\":\"10\",\"text\":\"[Product Name] helps [target audience] to [achieve outcome] without [pain point].\",\"align\":\"center\",\"size\":\"1.05rem\",\"color\":\"#475569\"},{\"id\":\"t3d\",\"type\":\"bullet_list\",\"padding\":\"24\",\"items\":[\"Feature 1 — describe the key capability\",\"Feature 2 — another differentiator\",\"Feature 3 — what makes this unique\",\"Feature 4 — the result users get\"],\"color\":\"#334155\"},{\"id\":\"t3e\",\"type\":\"pricing\",\"padding\":\"28\",\"name\":\"Launch Price\",\"price\":\"49\",\"period\":\"month\",\"features\":[\"Full access to all features\",\"Priority customer support\",\"Free onboarding call\",\"30-day money-back guarantee\"],\"btnText\":\"Start Free Trial\",\"btnBg\":\"#2563eb\"},{\"id\":\"t3f\",\"type\":\"testimonial\",\"padding\":\"20\",\"quote\":\"We saw results within the first week. Absolutely recommend.\",\"author\":\"Sarah K.\",\"role\":\"CEO, GrowthCo\",\"color\":\"#0ea5e9\"}]', 1, 3, NULL, '2026-03-14 08:04:10', 1, 0),
(4, NULL, 'Consultation Booking', 'booking', 'Build trust, show benefits, and drive visitors to book a call.', '📅', '#059669', '[{\"id\":\"t4a\",\"type\":\"headline\",\"padding\":\"40\",\"text\":\"Book Your Free [30-Min] Consultation\",\"align\":\"center\",\"size\":\"2.1rem\",\"color\":\"#0f172a\",\"bold\":true},{\"id\":\"t4b\",\"type\":\"subheadline\",\"padding\":\"10\",\"text\":\"Talk to an expert and get a personalised roadmap — no obligation.\",\"align\":\"center\",\"size\":\"1.1rem\",\"color\":\"#475569\",\"bold\":false},{\"id\":\"t4c\",\"type\":\"bullet_list\",\"padding\":\"24\",\"items\":[\"Understand exactly where you stand today\",\"Get a clear action plan tailored to your goals\",\"Ask any questions — no sales pressure\",\"Walk away with clarity and next steps\"],\"color\":\"#334155\"},{\"id\":\"t4d\",\"type\":\"appointment\",\"padding\":\"24\",\"label\":\"Pick a time that works for you\",\"btnText\":\"📅 Book Your Free Call Now\",\"url\":\"https://calendly.com/\",\"bg\":\"#059669\",\"color\":\"#ffffff\",\"radius\":\"10\"},{\"id\":\"t4e\",\"type\":\"lead_form\",\"padding\":\"24\",\"title\":\"Or send us a message\",\"submitText\":\"Send Message\",\"successMsg\":\"Message received! We will reply within 24 hours.\",\"bg\":\"#f0fdf4\"},{\"id\":\"t4f\",\"type\":\"trust_badges\",\"padding\":\"16\",\"badges\":[\"Free Consultation\",\"No Obligation\",\"Expert Advisor\",\"Same-Day Response\"]}]', 1, 4, NULL, '2026-03-14 08:04:10', 1, 0),
(5, NULL, 'Discount Promotion', 'promotion', 'Urgency-driven offer page with countdown, deal details, and form.', '🎁', '#dc2626', '[{\"id\":\"t5a\",\"type\":\"offer_banner\",\"padding\":\"20\",\"headline\":\"🎁 Limited Time: 50% Off — Today Only\",\"text\":\"This offer expires when the timer hits zero. Do not miss it.\",\"bg1\":\"#dc2626\",\"bg2\":\"#7c3aed\"},{\"id\":\"t5b\",\"type\":\"countdown\",\"padding\":\"24\",\"label\":\"Offer expires in:\",\"targetDate\":\"2026-04-07\"},{\"id\":\"t5c\",\"type\":\"headline\",\"padding\":\"24\",\"text\":\"Get [Product/Service] at Half Price\",\"align\":\"center\",\"size\":\"2rem\",\"color\":\"#0f172a\",\"bold\":true},{\"id\":\"t5d\",\"type\":\"paragraph\",\"padding\":\"10\",\"text\":\"For a limited time, new customers get 50% off their first month. No code needed — discount applied automatically.\",\"align\":\"center\",\"size\":\"1rem\",\"color\":\"#475569\"},{\"id\":\"t5e\",\"type\":\"bullet_list\",\"padding\":\"20\",\"items\":[\"50% off first month — automatically applied\",\"Full access from day one\",\"Cancel anytime — no lock-in\",\"Trusted by 10,000+ businesses\"],\"color\":\"#334155\"},{\"id\":\"t5f\",\"type\":\"lead_form\",\"padding\":\"24\",\"title\":\"Claim Your 50% Discount\",\"submitText\":\"Claim Discount Now\",\"successMsg\":\"Your discount is locked in! Check your email.\",\"bg\":\"#fff7f7\"},{\"id\":\"t5g\",\"type\":\"trust_badges\",\"padding\":\"16\",\"badges\":[\"Verified Offer\",\"Secure Checkout\",\"Instant Access\",\"30-Day Guarantee\"]}]', 1, 5, NULL, '2026-03-14 08:04:10', 1, 0),
(6, NULL, 'SaaS Landing Page', 'saas', 'Full-length SaaS page with hero, features, social proof, pricing, and FAQ.', '💻', '#6366f1', '[{\"id\":\"t6a\",\"type\":\"headline\",\"padding\":\"48\",\"text\":\"The Smarter Way to [Core Job to Be Done]\",\"align\":\"center\",\"size\":\"2.4rem\",\"color\":\"#0f172a\",\"bold\":true},{\"id\":\"t6b\",\"type\":\"subheadline\",\"padding\":\"10\",\"text\":\"[Product Name] helps [ICP] to [outcome] — faster, easier, and without [pain].\",\"align\":\"center\",\"size\":\"1.1rem\",\"color\":\"#64748b\",\"bold\":false},{\"id\":\"t6c\",\"type\":\"cta_button\",\"padding\":\"20\",\"text\":\"Start Free Trial — No Card Needed\",\"url\":\"#lp-form\",\"align\":\"center\",\"bg\":\"#6366f1\",\"color\":\"#fff\",\"size\":\"1rem\",\"radius\":\"10\"},{\"id\":\"t6d\",\"type\":\"trust_badges\",\"padding\":\"16\",\"badges\":[\"14-Day Free Trial\",\"No Credit Card\",\"SOC 2 Compliant\",\"99.9% Uptime\"]},{\"id\":\"t6e\",\"type\":\"divider\",\"padding\":\"8\",\"color\":\"#e2e8f0\"},{\"id\":\"t6f\",\"type\":\"section_title\",\"padding\":\"32\",\"text\":\"Everything you need, nothing you don\'t\",\"align\":\"center\",\"size\":\"0.85rem\",\"color\":\"#6366f1\"},{\"id\":\"t6g\",\"type\":\"bullet_list\",\"padding\":\"20\",\"items\":[\"Feature 1 — core capability explained clearly\",\"Feature 2 — time-saving automation\",\"Feature 3 — integrations that matter\",\"Feature 4 — reporting and analytics\"],\"color\":\"#334155\"},{\"id\":\"t6h\",\"type\":\"testimonial\",\"padding\":\"24\",\"quote\":\"Switched from [competitor] and never looked back. The ROI was immediate.\",\"author\":\"Mark T.\",\"role\":\"Head of Growth, TechCorp\",\"color\":\"#6366f1\"},{\"id\":\"t6i\",\"type\":\"pricing\",\"padding\":\"28\",\"name\":\"Pro\",\"price\":\"79\",\"period\":\"month\",\"features\":[\"Unlimited everything\",\"Team collaboration\",\"API access\",\"Priority support\",\"Custom domain\"],\"btnText\":\"Start Free Trial\",\"btnBg\":\"#6366f1\"},{\"id\":\"t6j\",\"type\":\"faq\",\"padding\":\"28\",\"title\":\"Frequently Asked Questions\",\"items\":[{\"q\":\"Is there a free trial?\",\"a\":\"Yes — 14 days full access, no credit card required.\"},{\"q\":\"Can I cancel anytime?\",\"a\":\"Absolutely. No contracts, cancel in one click.\"},{\"q\":\"Do you offer a discount for annual billing?\",\"a\":\"Yes, annual plans save 20% vs monthly.\"},{\"q\":\"Is my data secure?\",\"a\":\"We are SOC 2 Type II certified and GDPR compliant.\"}]},{\"id\":\"t6k\",\"type\":\"lead_form\",\"padding\":\"32\",\"title\":\"Get Started Free Today\",\"submitText\":\"Create My Free Account\",\"successMsg\":\"Welcome! Check your email to activate your account.\",\"bg\":\"#eef2ff\"}]', 1, 6, NULL, '2026-03-14 08:04:10', 1, 0),
(7, NULL, 'Event Registration', 'event', 'Event details, agenda highlights, speaker bio, and registration form.', '🎪', '#f59e0b', '[{\"id\":\"t7a\",\"type\":\"section_title\",\"padding\":\"32\",\"text\":\"YOU\'RE INVITED\",\"align\":\"center\",\"size\":\"0.8rem\",\"color\":\"#f59e0b\"},{\"id\":\"t7b\",\"type\":\"headline\",\"padding\":\"12\",\"text\":\"[Event Name] — [City] [Year]\",\"align\":\"center\",\"size\":\"2.2rem\",\"color\":\"#0f172a\",\"bold\":true},{\"id\":\"t7c\",\"type\":\"paragraph\",\"padding\":\"10\",\"text\":\"📅 [Date]  •  📍 [Venue]  •  🕐 [Time]\",\"align\":\"center\",\"size\":\"1rem\",\"color\":\"#475569\"},{\"id\":\"t7d\",\"type\":\"bullet_list\",\"padding\":\"24\",\"items\":[\"Keynote: [Speaker Name] on [Topic]\",\"Workshop: [Workshop Title] — hands-on session\",\"Panel: [Panel Topic] with industry leaders\",\"Networking lunch + evening reception\"],\"color\":\"#334155\"},{\"id\":\"t7e\",\"type\":\"countdown\",\"padding\":\"24\",\"label\":\"Event starts in:\",\"targetDate\":\"2026-05-01\"},{\"id\":\"t7f\",\"type\":\"lead_form\",\"padding\":\"24\",\"title\":\"Register Your Seat\",\"submitText\":\"Register Free\",\"successMsg\":\"You are registered! Confirmation sent to your email.\",\"bg\":\"#fffbeb\"},{\"id\":\"t7g\",\"type\":\"trust_badges\",\"padding\":\"16\",\"badges\":[\"Free Entry\",\"Networking Included\",\"Certificate\",\"Lunch Provided\"]}]', 1, 7, NULL, '2026-03-14 08:04:10', 1, 0),
(8, NULL, 'App Download', 'app', 'Mobile app landing page with features, screenshots description, and download CTA.', '📱', '#0f172a', '[{\"id\":\"t8a\",\"type\":\"headline\",\"padding\":\"44\",\"text\":\"[App Name] — [What it Does]\",\"align\":\"center\",\"size\":\"2.2rem\",\"color\":\"#0f172a\",\"bold\":true},{\"id\":\"t8b\",\"type\":\"subheadline\",\"padding\":\"10\",\"text\":\"Available on iOS and Android. Free to download.\",\"align\":\"center\",\"size\":\"1.05rem\",\"color\":\"#64748b\",\"bold\":false},{\"id\":\"t8c\",\"type\":\"cta_button\",\"padding\":\"20\",\"text\":\"⬇ Download on App Store\",\"url\":\"#\",\"align\":\"center\",\"bg\":\"#0f172a\",\"color\":\"#fff\",\"size\":\"1rem\",\"radius\":\"12\"},{\"id\":\"t8d\",\"type\":\"spacer\",\"height\":\"10\"},{\"id\":\"t8e\",\"type\":\"cta_button\",\"padding\":\"8\",\"text\":\"⬇ Get it on Google Play\",\"url\":\"#\",\"align\":\"center\",\"bg\":\"#15803d\",\"color\":\"#fff\",\"size\":\"1rem\",\"radius\":\"12\"},{\"id\":\"t8f\",\"type\":\"divider\",\"padding\":\"24\",\"color\":\"#e2e8f0\"},{\"id\":\"t8g\",\"type\":\"bullet_list\",\"padding\":\"20\",\"items\":[\"Feature 1 — key differentiator\",\"Feature 2 — saves time daily\",\"Feature 3 — works offline\",\"Feature 4 — syncs across all devices\"],\"color\":\"#334155\"},{\"id\":\"t8h\",\"type\":\"reviews\",\"padding\":\"24\",\"title\":\"Loved by 50,000+ users\",\"items\":[{\"stars\":5,\"text\":\"Best app I have used this year. Simple and powerful.\",\"name\":\"Alex M.\"},{\"stars\":5,\"text\":\"Replaced three other apps for me. Highly recommend.\",\"name\":\"Priya S.\"},{\"stars\":4,\"text\":\"Great features and excellent support team.\",\"name\":\"James K.\"}]},{\"id\":\"t8i\",\"type\":\"lead_form\",\"padding\":\"24\",\"title\":\"Get Early Access\",\"submitText\":\"Join Waitlist\",\"successMsg\":\"You are on the list! We will notify you first.\",\"bg\":\"#f8fafc\"}]', 1, 8, NULL, '2026-03-14 08:04:10', 1, 0),
(9, NULL, 'Lead Generation', 'lead_gen', 'Minimal high-converting page: headline, benefits, and a lead capture form.', 'user-account', '#2563eb', '[{\"id\":\"t1a\",\"type\":\"headline\",\"padding\":\"40\",\"text\":\"Get [Your Offer] Today\",\"align\":\"center\",\"size\":\"2.4rem\",\"color\":\"#0f172a\",\"bold\":true},{\"id\":\"t1b\",\"type\":\"subheadline\",\"padding\":\"8\",\"text\":\"Join thousands of businesses already growing with us.\",\"align\":\"center\",\"size\":\"1.15rem\",\"color\":\"#475569\",\"bold\":false},{\"id\":\"t1c\",\"type\":\"spacer\",\"height\":\"20\"},{\"id\":\"t1d\",\"type\":\"bullet_list\",\"padding\":\"20\",\"items\":[\"✅ Benefit one — explain the key value\",\"✅ Benefit two — another reason to act\",\"✅ Benefit three — seal the deal\",\"✅ No commitment. Cancel anytime.\"],\"color\":\"#334155\"},{\"id\":\"t1e\",\"type\":\"lead_form\",\"padding\":\"24\",\"title\":\"Claim Your Free Access\",\"submitText\":\"Get Started Now\",\"successMsg\":\"Thank you! We will be in touch shortly.\",\"bg\":\"#f8fafc\"},{\"id\":\"t1f\",\"type\":\"trust_badges\",\"padding\":\"20\",\"badges\":[\"SSL Secured\",\"No Credit Card\",\"GDPR Compliant\",\"5-Star Support\"]}]', 1, 1, NULL, '2026-03-15 03:02:43', 1, 0),
(10, NULL, 'Webinar Registration', 'webinar', 'Countdown timer, agenda, speaker info, and registration form.', '🎥', '#7c3aed', '[{\"id\":\"t2a\",\"type\":\"section_title\",\"padding\":\"32\",\"text\":\"FREE LIVE WEBINAR\",\"align\":\"center\",\"size\":\"0.85rem\",\"color\":\"#7c3aed\"},{\"id\":\"t2b\",\"type\":\"headline\",\"padding\":\"12\",\"text\":\"[Topic]: How to [Result] in [Timeframe]\",\"align\":\"center\",\"size\":\"2.2rem\",\"color\":\"#0f172a\",\"bold\":true},{\"id\":\"t2c\",\"type\":\"paragraph\",\"padding\":\"10\",\"text\":\"Join us live on [Date] at [Time] — limited seats available.\",\"align\":\"center\",\"size\":\"1rem\",\"color\":\"#64748b\"},{\"id\":\"t2d\",\"type\":\"countdown\",\"padding\":\"24\",\"label\":\"Webinar starts in:\",\"targetDate\":\"2026-04-01\"},{\"id\":\"t2e\",\"type\":\"bullet_list\",\"padding\":\"20\",\"items\":[\"What you will learn in this webinar\",\"Key insight #2 attendees always value\",\"Live Q&A session with the expert\",\"Free resource pack for all attendees\"],\"color\":\"#334155\"},{\"id\":\"t2f\",\"type\":\"lead_form\",\"padding\":\"24\",\"title\":\"Reserve Your Free Seat\",\"submitText\":\"Register Now — It\'s Free\",\"successMsg\":\"You are registered! Check your email for details.\",\"bg\":\"#faf5ff\"},{\"id\":\"t2g\",\"type\":\"trust_badges\",\"padding\":\"16\",\"badges\":[\"Free to Attend\",\"Live + Replay\",\"Expert Speaker\",\"Certificate of Attendance\"]}]', 1, 2, NULL, '2026-03-15 03:02:43', 1, 0),
(11, NULL, 'Product Launch', 'product_launch', 'Hero headline, feature highlights, pricing, and a strong CTA.', '🚀', '#0ea5e9', '[{\"id\":\"t3a\",\"type\":\"offer_banner\",\"padding\":\"24\",\"headline\":\"🚀 Now Live — Introducing [Product Name]\",\"text\":\"Early access pricing ends soon. Lock in your rate today.\",\"bg1\":\"#0ea5e9\",\"bg2\":\"#2563eb\"},{\"id\":\"t3b\",\"type\":\"headline\",\"padding\":\"36\",\"text\":\"[Product Name] — [One-line Value Proposition]\",\"align\":\"center\",\"size\":\"2.2rem\",\"color\":\"#0f172a\",\"bold\":true},{\"id\":\"t3c\",\"type\":\"paragraph\",\"padding\":\"10\",\"text\":\"[Product Name] helps [target audience] to [achieve outcome] without [pain point].\",\"align\":\"center\",\"size\":\"1.05rem\",\"color\":\"#475569\"},{\"id\":\"t3d\",\"type\":\"bullet_list\",\"padding\":\"24\",\"items\":[\"Feature 1 — describe the key capability\",\"Feature 2 — another differentiator\",\"Feature 3 — what makes this unique\",\"Feature 4 — the result users get\"],\"color\":\"#334155\"},{\"id\":\"t3e\",\"type\":\"pricing\",\"padding\":\"28\",\"name\":\"Launch Price\",\"price\":\"49\",\"period\":\"month\",\"features\":[\"Full access to all features\",\"Priority customer support\",\"Free onboarding call\",\"30-day money-back guarantee\"],\"btnText\":\"Start Free Trial\",\"btnBg\":\"#2563eb\"},{\"id\":\"t3f\",\"type\":\"testimonial\",\"padding\":\"20\",\"quote\":\"We saw results within the first week. Absolutely recommend.\",\"author\":\"Sarah K.\",\"role\":\"CEO, GrowthCo\",\"color\":\"#0ea5e9\"}]', 1, 3, NULL, '2026-03-15 03:02:43', 1, 0),
(12, NULL, 'Consultation Booking', 'booking', 'Build trust, show benefits, and drive visitors to book a call.', '📅', '#059669', '[{\"id\":\"t4a\",\"type\":\"headline\",\"padding\":\"40\",\"text\":\"Book Your Free [30-Min] Consultation\",\"align\":\"center\",\"size\":\"2.1rem\",\"color\":\"#0f172a\",\"bold\":true},{\"id\":\"t4b\",\"type\":\"subheadline\",\"padding\":\"10\",\"text\":\"Talk to an expert and get a personalised roadmap — no obligation.\",\"align\":\"center\",\"size\":\"1.1rem\",\"color\":\"#475569\",\"bold\":false},{\"id\":\"t4c\",\"type\":\"bullet_list\",\"padding\":\"24\",\"items\":[\"Understand exactly where you stand today\",\"Get a clear action plan tailored to your goals\",\"Ask any questions — no sales pressure\",\"Walk away with clarity and next steps\"],\"color\":\"#334155\"},{\"id\":\"t4d\",\"type\":\"appointment\",\"padding\":\"24\",\"label\":\"Pick a time that works for you\",\"btnText\":\"📅 Book Your Free Call Now\",\"url\":\"https://calendly.com/\",\"bg\":\"#059669\",\"color\":\"#ffffff\",\"radius\":\"10\"},{\"id\":\"t4e\",\"type\":\"lead_form\",\"padding\":\"24\",\"title\":\"Or send us a message\",\"submitText\":\"Send Message\",\"successMsg\":\"Message received! We will reply within 24 hours.\",\"bg\":\"#f0fdf4\"},{\"id\":\"t4f\",\"type\":\"trust_badges\",\"padding\":\"16\",\"badges\":[\"Free Consultation\",\"No Obligation\",\"Expert Advisor\",\"Same-Day Response\"]}]', 1, 4, NULL, '2026-03-15 03:02:43', 1, 0),
(13, NULL, 'Discount Promotion', 'promotion', 'Urgency-driven offer page with countdown, deal details, and form.', '🎁', '#dc2626', '[{\"id\":\"t5a\",\"type\":\"offer_banner\",\"padding\":\"20\",\"headline\":\"🎁 Limited Time: 50% Off — Today Only\",\"text\":\"This offer expires when the timer hits zero. Do not miss it.\",\"bg1\":\"#dc2626\",\"bg2\":\"#7c3aed\"},{\"id\":\"t5b\",\"type\":\"countdown\",\"padding\":\"24\",\"label\":\"Offer expires in:\",\"targetDate\":\"2026-04-07\"},{\"id\":\"t5c\",\"type\":\"headline\",\"padding\":\"24\",\"text\":\"Get [Product/Service] at Half Price\",\"align\":\"center\",\"size\":\"2rem\",\"color\":\"#0f172a\",\"bold\":true},{\"id\":\"t5d\",\"type\":\"paragraph\",\"padding\":\"10\",\"text\":\"For a limited time, new customers get 50% off their first month. No code needed — discount applied automatically.\",\"align\":\"center\",\"size\":\"1rem\",\"color\":\"#475569\"},{\"id\":\"t5e\",\"type\":\"bullet_list\",\"padding\":\"20\",\"items\":[\"50% off first month — automatically applied\",\"Full access from day one\",\"Cancel anytime — no lock-in\",\"Trusted by 10,000+ businesses\"],\"color\":\"#334155\"},{\"id\":\"t5f\",\"type\":\"lead_form\",\"padding\":\"24\",\"title\":\"Claim Your 50% Discount\",\"submitText\":\"Claim Discount Now\",\"successMsg\":\"Your discount is locked in! Check your email.\",\"bg\":\"#fff7f7\"},{\"id\":\"t5g\",\"type\":\"trust_badges\",\"padding\":\"16\",\"badges\":[\"Verified Offer\",\"Secure Checkout\",\"Instant Access\",\"30-Day Guarantee\"]}]', 1, 5, NULL, '2026-03-15 03:02:43', 1, 0),
(14, NULL, 'SaaS Landing Page', 'saas', 'Full-length SaaS page with hero, features, social proof, pricing, and FAQ.', '💻', '#6366f1', '[{\"id\":\"t6a\",\"type\":\"headline\",\"padding\":\"48\",\"text\":\"The Smarter Way to [Core Job to Be Done]\",\"align\":\"center\",\"size\":\"2.4rem\",\"color\":\"#0f172a\",\"bold\":true},{\"id\":\"t6b\",\"type\":\"subheadline\",\"padding\":\"10\",\"text\":\"[Product Name] helps [ICP] to [outcome] — faster, easier, and without [pain].\",\"align\":\"center\",\"size\":\"1.1rem\",\"color\":\"#64748b\",\"bold\":false},{\"id\":\"t6c\",\"type\":\"cta_button\",\"padding\":\"20\",\"text\":\"Start Free Trial — No Card Needed\",\"url\":\"#lp-form\",\"align\":\"center\",\"bg\":\"#6366f1\",\"color\":\"#fff\",\"size\":\"1rem\",\"radius\":\"10\"},{\"id\":\"t6d\",\"type\":\"trust_badges\",\"padding\":\"16\",\"badges\":[\"14-Day Free Trial\",\"No Credit Card\",\"SOC 2 Compliant\",\"99.9% Uptime\"]},{\"id\":\"t6e\",\"type\":\"divider\",\"padding\":\"8\",\"color\":\"#e2e8f0\"},{\"id\":\"t6f\",\"type\":\"section_title\",\"padding\":\"32\",\"text\":\"Everything you need, nothing you don\'t\",\"align\":\"center\",\"size\":\"0.85rem\",\"color\":\"#6366f1\"},{\"id\":\"t6g\",\"type\":\"bullet_list\",\"padding\":\"20\",\"items\":[\"Feature 1 — core capability explained clearly\",\"Feature 2 — time-saving automation\",\"Feature 3 — integrations that matter\",\"Feature 4 — reporting and analytics\"],\"color\":\"#334155\"},{\"id\":\"t6h\",\"type\":\"testimonial\",\"padding\":\"24\",\"quote\":\"Switched from [competitor] and never looked back. The ROI was immediate.\",\"author\":\"Mark T.\",\"role\":\"Head of Growth, TechCorp\",\"color\":\"#6366f1\"},{\"id\":\"t6i\",\"type\":\"pricing\",\"padding\":\"28\",\"name\":\"Pro\",\"price\":\"79\",\"period\":\"month\",\"features\":[\"Unlimited everything\",\"Team collaboration\",\"API access\",\"Priority support\",\"Custom domain\"],\"btnText\":\"Start Free Trial\",\"btnBg\":\"#6366f1\"},{\"id\":\"t6j\",\"type\":\"faq\",\"padding\":\"28\",\"title\":\"Frequently Asked Questions\",\"items\":[{\"q\":\"Is there a free trial?\",\"a\":\"Yes — 14 days full access, no credit card required.\"},{\"q\":\"Can I cancel anytime?\",\"a\":\"Absolutely. No contracts, cancel in one click.\"},{\"q\":\"Do you offer a discount for annual billing?\",\"a\":\"Yes, annual plans save 20% vs monthly.\"},{\"q\":\"Is my data secure?\",\"a\":\"We are SOC 2 Type II certified and GDPR compliant.\"}]},{\"id\":\"t6k\",\"type\":\"lead_form\",\"padding\":\"32\",\"title\":\"Get Started Free Today\",\"submitText\":\"Create My Free Account\",\"successMsg\":\"Welcome! Check your email to activate your account.\",\"bg\":\"#eef2ff\"}]', 1, 6, NULL, '2026-03-15 03:02:43', 1, 0),
(15, NULL, 'Event Registration', 'event', 'Event details, agenda highlights, speaker bio, and registration form.', '🎪', '#f59e0b', '[{\"id\":\"t7a\",\"type\":\"section_title\",\"padding\":\"32\",\"text\":\"YOU\'RE INVITED\",\"align\":\"center\",\"size\":\"0.8rem\",\"color\":\"#f59e0b\"},{\"id\":\"t7b\",\"type\":\"headline\",\"padding\":\"12\",\"text\":\"[Event Name] — [City] [Year]\",\"align\":\"center\",\"size\":\"2.2rem\",\"color\":\"#0f172a\",\"bold\":true},{\"id\":\"t7c\",\"type\":\"paragraph\",\"padding\":\"10\",\"text\":\"📅 [Date]  •  📍 [Venue]  •  🕐 [Time]\",\"align\":\"center\",\"size\":\"1rem\",\"color\":\"#475569\"},{\"id\":\"t7d\",\"type\":\"bullet_list\",\"padding\":\"24\",\"items\":[\"Keynote: [Speaker Name] on [Topic]\",\"Workshop: [Workshop Title] — hands-on session\",\"Panel: [Panel Topic] with industry leaders\",\"Networking lunch + evening reception\"],\"color\":\"#334155\"},{\"id\":\"t7e\",\"type\":\"countdown\",\"padding\":\"24\",\"label\":\"Event starts in:\",\"targetDate\":\"2026-05-01\"},{\"id\":\"t7f\",\"type\":\"lead_form\",\"padding\":\"24\",\"title\":\"Register Your Seat\",\"submitText\":\"Register Free\",\"successMsg\":\"You are registered! Confirmation sent to your email.\",\"bg\":\"#fffbeb\"},{\"id\":\"t7g\",\"type\":\"trust_badges\",\"padding\":\"16\",\"badges\":[\"Free Entry\",\"Networking Included\",\"Certificate\",\"Lunch Provided\"]}]', 1, 7, NULL, '2026-03-15 03:02:43', 1, 0),
(16, NULL, 'App Download', 'app', 'Mobile app landing page with features, screenshots description, and download CTA.', '📱', '#0f172a', '[{\"id\":\"t8a\",\"type\":\"headline\",\"padding\":\"44\",\"text\":\"[App Name] — [What it Does]\",\"align\":\"center\",\"size\":\"2.2rem\",\"color\":\"#0f172a\",\"bold\":true},{\"id\":\"t8b\",\"type\":\"subheadline\",\"padding\":\"10\",\"text\":\"Available on iOS and Android. Free to download.\",\"align\":\"center\",\"size\":\"1.05rem\",\"color\":\"#64748b\",\"bold\":false},{\"id\":\"t8c\",\"type\":\"cta_button\",\"padding\":\"20\",\"text\":\"⬇ Download on App Store\",\"url\":\"#\",\"align\":\"center\",\"bg\":\"#0f172a\",\"color\":\"#fff\",\"size\":\"1rem\",\"radius\":\"12\"},{\"id\":\"t8d\",\"type\":\"spacer\",\"height\":\"10\"},{\"id\":\"t8e\",\"type\":\"cta_button\",\"padding\":\"8\",\"text\":\"⬇ Get it on Google Play\",\"url\":\"#\",\"align\":\"center\",\"bg\":\"#15803d\",\"color\":\"#fff\",\"size\":\"1rem\",\"radius\":\"12\"},{\"id\":\"t8f\",\"type\":\"divider\",\"padding\":\"24\",\"color\":\"#e2e8f0\"},{\"id\":\"t8g\",\"type\":\"bullet_list\",\"padding\":\"20\",\"items\":[\"Feature 1 — key differentiator\",\"Feature 2 — saves time daily\",\"Feature 3 — works offline\",\"Feature 4 — syncs across all devices\"],\"color\":\"#334155\"},{\"id\":\"t8h\",\"type\":\"reviews\",\"padding\":\"24\",\"title\":\"Loved by 50,000+ users\",\"items\":[{\"stars\":5,\"text\":\"Best app I have used this year. Simple and powerful.\",\"name\":\"Alex M.\"},{\"stars\":5,\"text\":\"Replaced three other apps for me. Highly recommend.\",\"name\":\"Priya S.\"},{\"stars\":4,\"text\":\"Great features and excellent support team.\",\"name\":\"James K.\"}]},{\"id\":\"t8i\",\"type\":\"lead_form\",\"padding\":\"24\",\"title\":\"Get Early Access\",\"submitText\":\"Join Waitlist\",\"successMsg\":\"You are on the list! We will notify you first.\",\"bg\":\"#f8fafc\"}]', 1, 8, NULL, '2026-03-15 03:02:43', 1, 0),
(17, NULL, 'Lead Generation', 'lead_gen', 'Professional lead capture page with hero, benefits, form, and trust signals.', 'user-account', '#2563eb', '[{\"type\": \"nav_bar\", \"id\": \"b522c7e8d\", \"brand\": \"LeadPro\", \"brandUrl\": \"#\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"About\", \"url\": \"#\"}], \"ctaText\": \"Get Started\", \"ctaUrl\": \"#\", \"ctaBg\": \"#2563eb\", \"bgColor\": \"#ffffff\", \"textColor\": \"#475569\", \"padding\": \"16\"}, {\"type\": \"hero_section\", \"id\": \"b397e52e7\", \"headline\": \"Turn Visitors Into Qualified Leads\", \"subheadline\": \"Capture more leads with a high-converting landing page that works around the clock.\", \"btnText\": \"Get Started Free\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"bgColor\": \"#1e293b\", \"overlayColor\": \"rgba(15,23,42,0.7)\", \"layout\": \"split\", \"showForm\": true, \"formTitle\": \"Get Started Today\", \"minHeight\": 500, \"padding\": \"20\"}, {\"type\": \"trust_badges\", \"id\": \"bc8758bd2\", \"badges\": [\"✓ No credit card required\", \"✓ Setup in 5 minutes\", \"✓ Cancel anytime\", \"✓ GDPR compliant\"], \"color\": \"#16a34a\", \"padding\": \"20\"}, {\"type\": \"section_title\", \"id\": \"b2353a974\", \"text\": \"WHY BUSINESSES CHOOSE US\", \"align\": \"center\", \"size\": \"1rem\", \"color\": \"#2563eb\", \"bold\": true, \"padding\": \"20\"}, {\"type\": \"feature_grid\", \"id\": \"b454513b4\", \"headline\": \"Everything You Need to Capture More Leads\", \"subheadline\": \"Built for marketers who want results without the complexity.\", \"cols\": 3, \"bgColor\": \"#fff\", \"cardBg\": \"#fff\", \"cardBorder\": \"#e2e8f0\", \"items\": [{\"icon\": \"🎯\", \"title\": \"Precision Targeting\", \"desc\": \"Reach your ideal audience with laser-focused campaigns that convert.\"}, {\"icon\": \"⚡\", \"title\": \"Instant Setup\", \"desc\": \"Launch your first landing page in under 10 minutes with our templates.\"}, {\"icon\": \"📊\", \"title\": \"Real-Time Analytics\", \"desc\": \"Track every visitor, conversion, and lead source in your dashboard.\"}, {\"icon\": \"🤖\", \"title\": \"AI-Powered\", \"desc\": \"Let AI write your headlines, copy, and CTAs for maximum impact.\"}, {\"icon\": \"🔒\", \"title\": \"Secure & Compliant\", \"desc\": \"GDPR-ready with built-in spam protection and data encryption.\"}, {\"icon\": \"📱\", \"title\": \"Mobile First\", \"desc\": \"Every page looks perfect on any device, automatically.\"}], \"padding\": \"60\"}, {\"type\": \"spacer\", \"id\": \"bafeba3e2\", \"height\": 20}, {\"type\": \"testimonial\", \"id\": \"bcd96ba9e\", \"quote\": \"We doubled our lead volume in 30 days. The conversion rate went from 2.1% to 5.8%.\", \"author\": \"Sarah Mitchell\", \"role\": \"VP Marketing, TechStart Inc\", \"color\": \"#2563eb\", \"padding\": \"40\"}, {\"type\": \"stats_row\", \"id\": \"bf734ce5a\", \"items\": [{\"number\": \"10,000+\", \"label\": \"Happy Customers\"}, {\"number\": \"5.8%\", \"label\": \"Avg. Conversion Rate\"}, {\"number\": \"98%\", \"label\": \"Uptime SLA\"}, {\"number\": \"4.9★\", \"label\": \"Customer Rating\"}], \"bgColor\": \"#f8fafc\", \"numColor\": \"#0f172a\", \"padding\": \"20\"}, {\"type\": \"footer_block\", \"id\": \"b7897db2c\", \"brand\": \"LeadPro\", \"description\": \"Professional lead capture software for modern marketing teams.\", \"bgColor\": \"#0f172a\", \"textColor\": \"#94a3b8\", \"brandColor\": \"#fff\", \"columns\": [{\"title\": \"Product\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"Changelog\", \"url\": \"#\"}]}, {\"title\": \"Company\", \"links\": [{\"label\": \"About\", \"url\": \"#\"}, {\"label\": \"Blog\", \"url\": \"#\"}, {\"label\": \"Careers\", \"url\": \"#\"}]}, {\"title\": \"Support\", \"links\": [{\"label\": \"Help Center\", \"url\": \"#\"}, {\"label\": \"Contact\", \"url\": \"#\"}, {\"label\": \"Privacy\", \"url\": \"#\"}]}], \"copyright\": \"© 2024 YourBrand. All rights reserved.\", \"padding\": \"20\"}]', 1, 1, NULL, '2026-03-15 04:05:30', 1, 1),
(18, NULL, 'SaaS Landing Page', 'saas', 'Full SaaS page with hero, features, pricing, testimonials, and FAQ.', '🚀', '#7c3aed', '[{\"type\": \"nav_bar\", \"id\": \"b298e2dcd\", \"brand\": \"Lunera\", \"brandUrl\": \"#\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"About\", \"url\": \"#\"}], \"ctaText\": \"Start Free Trial\", \"ctaUrl\": \"#\", \"ctaBg\": \"#2563eb\", \"bgColor\": \"#ffffff\", \"textColor\": \"#475569\", \"padding\": \"16\"}, {\"type\": \"announcement_bar\", \"id\": \"b284f4396\", \"text\": \"🎉 New: AI-powered features are now live!\", \"bgColor\": \"#2563eb\", \"textColor\": \"#fff\", \"linkText\": \"See what\'s new\", \"linkUrl\": \"#\", \"padding\": \"10\"}, {\"type\": \"hero_section\", \"id\": \"b6c284fa8\", \"headline\": \"Grow Smarter, Scale Faster\", \"subheadline\": \"The all-in-one platform that replaces five tools with one powerful solution. Start free, no credit card needed.\", \"btnText\": \"Start Free Trial\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"bgColor\": \"#0f172a\", \"overlayColor\": \"rgba(0,0,0,0)\", \"layout\": \"full\", \"showForm\": false, \"formTitle\": \"Get Started Today\", \"minHeight\": 500, \"padding\": \"20\"}, {\"type\": \"section_title\", \"id\": \"b0baaabbc\", \"text\": \"TRUSTED BY 10,000+ BUSINESSES\", \"align\": \"center\", \"size\": \"1rem\", \"color\": \"#2563eb\", \"bold\": true, \"padding\": \"20\"}, {\"type\": \"logo_gallery\", \"id\": \"ba6f6839c\", \"logos\": [\"Google\", \"Airbnb\", \"Spotify\", \"Stripe\", \"Shopify\", \"Notion\"], \"padding\": \"20\"}, {\"type\": \"feature_grid\", \"id\": \"bc7568eac\", \"headline\": \"Powerful Features Built for Growth\", \"subheadline\": \"Everything your team needs to attract leads, close deals, and delight customers.\", \"cols\": 3, \"bgColor\": \"#fff\", \"cardBg\": \"#fff\", \"cardBorder\": \"#e2e8f0\", \"items\": [{\"icon\": \"🎯\", \"title\": \"Smart Lead Capture\", \"desc\": \"Convert visitors with high-converting forms and landing pages.\"}, {\"icon\": \"🤖\", \"title\": \"AI Content Generator\", \"desc\": \"Create headlines, copy, and CTAs in seconds with built-in AI.\"}, {\"icon\": \"📊\", \"title\": \"Advanced Analytics\", \"desc\": \"Understand every interaction with real-time dashboards.\"}, {\"icon\": \"🔗\", \"title\": \"150+ Integrations\", \"desc\": \"Connect to your existing tools with one click.\"}, {\"icon\": \"⚡\", \"title\": \"Automation Workflows\", \"desc\": \"Automate repetitive tasks and focus on what matters.\"}, {\"icon\": \"🛡\", \"title\": \"Enterprise Security\", \"desc\": \"Bank-grade encryption and SOC 2 Type II compliance.\"}], \"padding\": \"60\"}, {\"type\": \"stats_row\", \"id\": \"bfd4c1cda\", \"items\": [{\"number\": \"10k+\", \"label\": \"Active Users\"}, {\"number\": \"99.9%\", \"label\": \"Uptime\"}, {\"number\": \"4.8★\", \"label\": \"Avg Rating\"}, {\"number\": \"24/7\", \"label\": \"Support\"}], \"bgColor\": \"#f8fafc\", \"numColor\": \"#0f172a\", \"padding\": \"20\"}, {\"type\": \"spacer\", \"id\": \"b698cdfae\", \"height\": 20}, {\"type\": \"two_col\", \"id\": \"bb435f454\", \"eyebrow\": \"WHY TEAMS LOVE US\", \"headline\": \"Built for Teams That Move Fast\", \"body\": \"Stop juggling between 5 different tools. Our platform combines lead capture, CRM, analytics, and automation into one seamless workflow that your team will actually love.\", \"imgUrl\": \"https://picsum.photos/seed/saas1/800/600\", \"imgAlt\": \"Built for Teams That Move Fast\", \"imgPosition\": \"left\", \"imgRadius\": 12, \"bullets\": [\"No per-seat pricing — pay one flat rate\", \"Real-time collaboration for your whole team\", \"Automated lead scoring and routing\", \"Native mobile apps for iOS and Android\"], \"showBtn\": true, \"btnText\": \"See How It Works\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"headlineColor\": \"#0f172a\", \"bodyColor\": \"#475569\", \"blockBg\": \"#f8fafc\", \"gap\": 48, \"padding\": \"60\"}, {\"type\": \"spacer\", \"id\": \"bcbe3303c\", \"height\": 20}, {\"type\": \"pricing\", \"id\": \"b99ee8ee5\", \"name\": \"Starter\", \"price\": \"29\", \"period\": \"month\", \"features\": [\"Up to 1,000 leads/month\", \"5 landing pages\", \"Basic analytics\", \"Email support\"], \"btnText\": \"Get Starter\", \"btnBg\": \"#2563eb\", \"padding\": \"40\"}, {\"type\": \"testimonial\", \"id\": \"b6536d5c9\", \"quote\": \"Switched from HubSpot and saved $800/month. The landing page builder alone is worth it.\", \"author\": \"James Wilson\", \"role\": \"CEO, ScaleUp Agency\", \"color\": \"#7c3aed\", \"padding\": \"40\"}, {\"type\": \"faq\", \"id\": \"bc2e7f37f\", \"title\": \"Frequently Asked Questions\", \"items\": [{\"q\": \"Is there a free trial?\", \"a\": \"Yes! 14-day free trial with full access. No credit card required.\"}, {\"q\": \"Can I cancel anytime?\", \"a\": \"Absolutely. Cancel with one click, no questions asked.\"}, {\"q\": \"Do you offer annual plans?\", \"a\": \"Yes, annual plans save you 2 months. Contact us for enterprise pricing.\"}, {\"q\": \"Is my data secure?\", \"a\": \"We use bank-grade encryption and are SOC 2 Type II certified.\"}], \"padding\": \"40\"}, {\"type\": \"footer_block\", \"id\": \"be479e03d\", \"brand\": \"Lunera\", \"description\": \"The all-in-one platform for modern marketing teams.\", \"bgColor\": \"#0f172a\", \"textColor\": \"#94a3b8\", \"brandColor\": \"#fff\", \"columns\": [{\"title\": \"Product\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"Changelog\", \"url\": \"#\"}]}, {\"title\": \"Company\", \"links\": [{\"label\": \"About\", \"url\": \"#\"}, {\"label\": \"Blog\", \"url\": \"#\"}, {\"label\": \"Careers\", \"url\": \"#\"}]}, {\"title\": \"Support\", \"links\": [{\"label\": \"Help Center\", \"url\": \"#\"}, {\"label\": \"Contact\", \"url\": \"#\"}, {\"label\": \"Privacy\", \"url\": \"#\"}]}], \"copyright\": \"© 2024 YourBrand. All rights reserved.\", \"padding\": \"20\"}]', 1, 2, NULL, '2026-03-15 04:05:30', 1, 1),
(19, NULL, 'Webinar Registration', 'webinar', 'Drive webinar sign-ups with urgency, speaker bio, and agenda.', '🎙', '#7c3aed', '[{\"type\": \"nav_bar\", \"id\": \"b5ed3e5d6\", \"brand\": \"YourBrand\", \"brandUrl\": \"#\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"About\", \"url\": \"#\"}], \"ctaText\": \"Register Free\", \"ctaUrl\": \"#\", \"ctaBg\": \"#2563eb\", \"bgColor\": \"#ffffff\", \"textColor\": \"#475569\", \"padding\": \"16\"}, {\"type\": \"announcement_bar\", \"id\": \"b4d7054da\", \"text\": \"⏳ Limited spots! Only 47 seats remaining.\", \"bgColor\": \"#7c3aed\", \"textColor\": \"#fff\", \"linkText\": \"Register Now\", \"linkUrl\": \"#\", \"padding\": \"10\"}, {\"type\": \"hero_section\", \"id\": \"b586fabc1\", \"headline\": \"Free Live Webinar: [Your Topic Here]\", \"subheadline\": \"Join 500+ professionals for an exclusive live training session. Learn the strategies top companies use to 3x their results.\", \"btnText\": \"Register My Free Seat\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"bgColor\": \"#1e293b\", \"overlayColor\": \"rgba(20,10,40,0.75)\", \"layout\": \"split\", \"showForm\": true, \"formTitle\": \"Get Started Today\", \"minHeight\": 500, \"padding\": \"20\"}, {\"type\": \"countdown\", \"id\": \"b94c434ce\", \"targetDate\": \"2026-03-20\", \"label\": \"Webinar starts in:\", \"padding\": \"20\"}, {\"type\": \"section_title\", \"id\": \"b25dd4c04\", \"text\": \"WHAT YOU\'LL LEARN\", \"align\": \"center\", \"size\": \"1rem\", \"color\": \"#2563eb\", \"bold\": true, \"padding\": \"20\"}, {\"type\": \"feature_grid\", \"id\": \"bbd13e022\", \"headline\": \"3 Actionable Strategies You\'ll Walk Away With\", \"subheadline\": null, \"cols\": 3, \"bgColor\": \"#f8fafc\", \"cardBg\": \"#fff\", \"cardBorder\": \"#e2e8f0\", \"items\": [{\"icon\": \"📈\", \"title\": \"Strategy #1: Scale Without Burning Out\", \"desc\": \"Discover the exact system to 3x your output without working more hours.\"}, {\"icon\": \"🎯\", \"title\": \"Strategy #2: Find Your Best Customers\", \"desc\": \"Learn how to attract clients who pay more, complain less, and refer others.\"}, {\"icon\": \"🤖\", \"title\": \"Strategy #3: Automate Your Lead Flow\", \"desc\": \"Set up a system that generates qualified leads on autopilot 24/7.\"}], \"padding\": \"60\"}, {\"type\": \"two_col\", \"id\": \"bf352d1c8\", \"eyebrow\": \"MEET YOUR SPEAKER\", \"headline\": \"Your Host\", \"body\": \"With 15+ years of experience and 200+ speaking engagements, [Speaker Name] has helped thousands of entrepreneurs scale their businesses. Featured in Forbes, Entrepreneur, and Inc Magazine.\", \"imgUrl\": \"https://picsum.photos/seed/speaker/400/500\", \"imgAlt\": \"Your Host\", \"imgPosition\": \"right\", \"imgRadius\": 12, \"bullets\": [\"Author of 3 best-selling business books\", \"Built and sold two 7-figure companies\", \"Mentored 5,000+ entrepreneurs worldwide\"], \"showBtn\": true, \"btnText\": \"Register Now\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"headlineColor\": \"#0f172a\", \"bodyColor\": \"#475569\", \"blockBg\": \"#fff\", \"gap\": 48, \"padding\": \"60\"}, {\"type\": \"testimonial\", \"id\": \"b98175678\", \"quote\": \"This webinar changed how I think about my business. Implemented one strategy and added $40k in revenue.\", \"author\": \"Rachel Torres\", \"role\": \"Founder, GrowthPath\", \"color\": \"#7c3aed\", \"padding\": \"40\"}, {\"type\": \"footer_block\", \"id\": \"bd7495fae\", \"brand\": \"YourBrand\", \"description\": \"Join us for this exclusive live training session.\", \"bgColor\": \"#0f172a\", \"textColor\": \"#94a3b8\", \"brandColor\": \"#fff\", \"columns\": [{\"title\": \"Product\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"Changelog\", \"url\": \"#\"}]}, {\"title\": \"Company\", \"links\": [{\"label\": \"About\", \"url\": \"#\"}, {\"label\": \"Blog\", \"url\": \"#\"}, {\"label\": \"Careers\", \"url\": \"#\"}]}, {\"title\": \"Support\", \"links\": [{\"label\": \"Help Center\", \"url\": \"#\"}, {\"label\": \"Contact\", \"url\": \"#\"}, {\"label\": \"Privacy\", \"url\": \"#\"}]}], \"copyright\": \"© 2024 YourBrand. All rights reserved.\", \"padding\": \"20\"}]', 1, 3, NULL, '2026-03-15 04:05:30', 1, 0),
(20, NULL, 'Consultation Booking', 'booking', 'Book discovery calls with a benefits-led page and appointment CTA.', '📅', '#16a34a', '[{\"type\": \"nav_bar\", \"id\": \"b9d4470ba\", \"brand\": \"YourBrand\", \"brandUrl\": \"#\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"About\", \"url\": \"#\"}], \"ctaText\": \"Book Free Call\", \"ctaUrl\": \"#\", \"ctaBg\": \"#2563eb\", \"bgColor\": \"#ffffff\", \"textColor\": \"#475569\", \"padding\": \"16\"}, {\"type\": \"hero_section\", \"id\": \"ba2391707\", \"headline\": \"Get a Free 30-Minute Strategy Session\", \"subheadline\": \"In just 30 minutes, we\'ll analyse your situation and give you a clear roadmap. No pitch, no pressure — just value.\", \"btnText\": \"Book My Free Session\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"bgColor\": \"#0f172a\", \"overlayColor\": \"rgba(0,0,0,0.4)\", \"layout\": \"split\", \"showForm\": true, \"formTitle\": \"Get Started Today\", \"minHeight\": 500, \"padding\": \"20\"}, {\"type\": \"trust_badges\", \"id\": \"ba53fb3e8\", \"badges\": [\"✓ No obligation\", \"✓ Immediate insights\", \"✓ Tailored to your business\", \"✓ 100% confidential\"], \"color\": \"#16a34a\", \"padding\": \"20\"}, {\"type\": \"feature_grid\", \"id\": \"b9ba7a2b8\", \"headline\": \"What Happens on the Call\", \"subheadline\": null, \"cols\": 3, \"bgColor\": \"#f8fafc\", \"cardBg\": \"#fff\", \"cardBorder\": \"#e2e8f0\", \"items\": [{\"icon\": \"🔍\", \"title\": \"Deep-Dive Analysis\", \"desc\": \"We review your current situation and identify the biggest opportunities.\"}, {\"icon\": \"🗺\", \"title\": \"Custom Roadmap\", \"desc\": \"You\'ll leave with a clear 90-day action plan specific to your goals.\"}, {\"icon\": \"🤝\", \"title\": \"No Hard Sell\", \"desc\": \"This is purely about giving you value. We only work with people we can genuinely help.\"}], \"padding\": \"60\"}, {\"type\": \"two_col\", \"id\": \"b262b12f7\", \"eyebrow\": \"\", \"headline\": \"Why 500+ Businesses Trust Us\", \"body\": \"Our team has worked with companies across 30+ industries. We understand that every business is unique, which is why we never offer cookie-cutter solutions.\", \"imgUrl\": \"https://picsum.photos/seed/consult/800/600\", \"imgAlt\": \"Why 500+ Businesses Trust Us\", \"imgPosition\": \"left\", \"imgRadius\": 12, \"bullets\": [\"Average client revenue increase: 47%\", \"4.9/5 star rating from 300+ clients\", \"Featured in Forbes and Business Insider\"], \"showBtn\": true, \"btnText\": \"Book My Free Session\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"headlineColor\": \"#0f172a\", \"bodyColor\": \"#475569\", \"blockBg\": \"#fff\", \"gap\": 48, \"padding\": \"60\"}, {\"type\": \"appointment\", \"id\": \"be2f48da7\", \"label\": \"Ready to transform your business?\", \"btnText\": \"📅 Book Your Free Strategy Session\", \"url\": \"https://calendly.com/\", \"bg\": \"#2563eb\", \"color\": \"#ffffff\", \"radius\": \"10\", \"padding\": \"40\"}, {\"type\": \"testimonial\", \"id\": \"bf5f80d20\", \"quote\": \"Best 30 minutes I\'ve invested in my business. The team identified $200k in untapped revenue in our first call.\", \"author\": \"Mark Johnson\", \"role\": \"CEO, BrightPath Ltd\", \"color\": \"#16a34a\", \"padding\": \"40\"}, {\"type\": \"footer_block\", \"id\": \"bba2cfa93\", \"brand\": \"YourBrand\", \"description\": \"Expert consulting for ambitious businesses.\", \"bgColor\": \"#0f172a\", \"textColor\": \"#94a3b8\", \"brandColor\": \"#fff\", \"columns\": [{\"title\": \"Product\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"Changelog\", \"url\": \"#\"}]}, {\"title\": \"Company\", \"links\": [{\"label\": \"About\", \"url\": \"#\"}, {\"label\": \"Blog\", \"url\": \"#\"}, {\"label\": \"Careers\", \"url\": \"#\"}]}, {\"title\": \"Support\", \"links\": [{\"label\": \"Help Center\", \"url\": \"#\"}, {\"label\": \"Contact\", \"url\": \"#\"}, {\"label\": \"Privacy\", \"url\": \"#\"}]}], \"copyright\": \"© 2024 YourBrand. All rights reserved.\", \"padding\": \"20\"}]', 1, 4, NULL, '2026-03-15 04:05:30', 1, 0),
(21, NULL, 'Product Launch', 'product_launch', 'Launch a product with offer banner, countdown, pricing, and social proof.', '🚀', '#f59e0b', '[{\"type\": \"nav_bar\", \"id\": \"bc51f45d4\", \"brand\": \"YourBrand\", \"brandUrl\": \"#\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"About\", \"url\": \"#\"}], \"ctaText\": \"Buy Now\", \"ctaUrl\": \"#\", \"ctaBg\": \"#2563eb\", \"bgColor\": \"#ffffff\", \"textColor\": \"#475569\", \"padding\": \"16\"}, {\"type\": \"announcement_bar\", \"id\": \"b92002df4\", \"text\": \"🔥 Launch Special: 40% OFF for the first 48 hours only!\", \"bgColor\": \"#f59e0b\", \"textColor\": \"#fff\", \"linkText\": \"Claim Discount\", \"linkUrl\": \"#\", \"padding\": \"10\"}, {\"type\": \"hero_section\", \"id\": \"b8fa45579\", \"headline\": \"Introducing [Product Name]: The [Benefit] You\'ve Been Waiting For\", \"subheadline\": \"Finally, a solution that [solves the main pain point] without [the main frustration]. Join 1,000+ happy customers who made the switch.\", \"btnText\": \"Get 40% Off Today\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"bgColor\": \"#0f172a\", \"overlayColor\": \"rgba(0,0,0,0.5)\", \"layout\": \"split\", \"showForm\": true, \"formTitle\": \"Get Started Today\", \"minHeight\": 500, \"padding\": \"20\"}, {\"type\": \"countdown\", \"id\": \"ba9caac4a\", \"targetDate\": \"2026-03-17\", \"label\": \"Launch price expires in:\", \"padding\": \"20\"}, {\"type\": \"offer_banner\", \"id\": \"b84c1682d\", \"headline\": \"🔥 Launch Week Only: 40% Off + Free Bonus!\", \"text\": \"Use code LAUNCH40 at checkout. Offer expires Sunday midnight.\", \"bg1\": \"#f59e0b\", \"bg2\": \"#ef4444\", \"padding\": \"20\"}, {\"type\": \"feature_grid\", \"id\": \"ba622fd25\", \"headline\": \"Everything Included in Your Purchase\", \"subheadline\": null, \"cols\": 3, \"bgColor\": \"#fff\", \"cardBg\": \"#fff\", \"cardBorder\": \"#e2e8f0\", \"items\": [{\"icon\": \"✅\", \"title\": \"Core Product\", \"desc\": \"The full product with all features unlocked from day one.\"}, {\"icon\": \"📖\", \"title\": \"Quick-Start Guide\", \"desc\": \"Step-by-step setup guide so you get results in under an hour.\"}, {\"icon\": \"💬\", \"title\": \"Priority Support\", \"desc\": \"Jump the queue with dedicated email support for 90 days.\"}, {\"icon\": \"🎓\", \"title\": \"Training Videos\", \"desc\": \"25+ video tutorials covering every feature in depth.\"}, {\"icon\": \"🔄\", \"title\": \"Free Updates\", \"desc\": \"All future updates included free — forever.\"}, {\"icon\": \"💰\", \"title\": \"30-Day Guarantee\", \"desc\": \"100% money-back guarantee. No questions asked.\"}], \"padding\": \"60\"}, {\"type\": \"testimonial\", \"id\": \"bfd3a31fe\", \"quote\": \"I was skeptical at first, but the results speak for themselves. ROI within 2 weeks.\", \"author\": \"Lisa Chen\", \"role\": \"Marketing Director, NovaBrand\", \"color\": \"#f59e0b\", \"padding\": \"40\"}, {\"type\": \"stats_row\", \"id\": \"bf33dc710\", \"items\": [{\"number\": \"1,000+\", \"label\": \"Happy Customers\"}, {\"number\": \"4.9★\", \"label\": \"Average Rating\"}, {\"number\": \"30-Day\", \"label\": \"Money Back\"}, {\"number\": \"24/7\", \"label\": \"Support\"}], \"bgColor\": \"#f8fafc\", \"numColor\": \"#0f172a\", \"padding\": \"20\"}, {\"type\": \"footer_block\", \"id\": \"bc9a8acc0\", \"brand\": \"YourBrand\", \"description\": \"Premium products for ambitious professionals.\", \"bgColor\": \"#0f172a\", \"textColor\": \"#94a3b8\", \"brandColor\": \"#fff\", \"columns\": [{\"title\": \"Product\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"Changelog\", \"url\": \"#\"}]}, {\"title\": \"Company\", \"links\": [{\"label\": \"About\", \"url\": \"#\"}, {\"label\": \"Blog\", \"url\": \"#\"}, {\"label\": \"Careers\", \"url\": \"#\"}]}, {\"title\": \"Support\", \"links\": [{\"label\": \"Help Center\", \"url\": \"#\"}, {\"label\": \"Contact\", \"url\": \"#\"}, {\"label\": \"Privacy\", \"url\": \"#\"}]}], \"copyright\": \"© 2024 YourBrand. All rights reserved.\", \"padding\": \"20\"}]', 1, 5, NULL, '2026-03-15 04:05:30', 1, 1);
INSERT INTO `campaign_templates` (`id`, `account_id`, `name`, `category`, `description`, `thumbnail_emoji`, `thumbnail_color`, `page_data`, `is_system`, `sort_order`, `created_by`, `created_at`, `is_active`, `is_featured`) VALUES
(22, NULL, 'Agency Services', 'agency', 'Showcase agency services with social proof, stats, and contact form.', '🏆', '#0891b2', '[{\"type\": \"nav_bar\", \"id\": \"ba03d1ef7\", \"brand\": \"BestKit Agency\", \"brandUrl\": \"#\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"About\", \"url\": \"#\"}], \"ctaText\": \"Contact Us\", \"ctaUrl\": \"#\", \"ctaBg\": \"#2563eb\", \"bgColor\": \"#ffffff\", \"textColor\": \"#475569\", \"padding\": \"16\"}, {\"type\": \"hero_section\", \"id\": \"bfb38fc79\", \"headline\": \"Creating Digital Experiences That Convert\", \"subheadline\": \"We design and build websites, campaigns, and marketing systems for ambitious businesses worldwide.\", \"btnText\": \"Get a Free Quote\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"bgColor\": \"#0f172a\", \"overlayColor\": \"rgba(0,0,0,0.45)\", \"layout\": \"full\", \"showForm\": false, \"formTitle\": \"Get Started Today\", \"minHeight\": 500, \"padding\": \"20\"}, {\"type\": \"stats_row\", \"id\": \"bf691a3da\", \"items\": [{\"number\": \"834\", \"label\": \"Startups Served\"}, {\"number\": \"372\", \"label\": \"Projects Completed\"}, {\"number\": \"14\", \"label\": \"Awards Won\"}, {\"number\": \"43\", \"label\": \"Team Members\"}], \"bgColor\": \"#f8fafc\", \"numColor\": \"#0f172a\", \"padding\": \"20\"}, {\"type\": \"two_col\", \"id\": \"b3f6017a0\", \"eyebrow\": \"OUR SKILL\", \"headline\": \"We Aim to Share Knowledge, Attract Talent & Grow Your Business\", \"body\": \"We design & build brand, campaigns & digital projects for business large & small with customer experiences that convert visitors into loyal customers.\", \"imgUrl\": \"https://picsum.photos/seed/agency/800/600\", \"imgAlt\": \"We Aim to Share Knowledge, Attract Talent & Grow Your Business\", \"imgPosition\": \"right\", \"imgRadius\": 12, \"bullets\": [\"Pixel perfect & expertly crafted to meet standards\", \"We love what we do & why we do it for\"], \"showBtn\": true, \"btnText\": \"Learn About Us\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"headlineColor\": \"#0f172a\", \"bodyColor\": \"#475569\", \"blockBg\": \"#f8fafc\", \"gap\": 48, \"padding\": \"60\"}, {\"type\": \"progress_bars\", \"id\": \"ba2e94f99\", \"headline\": \"Our Core Competencies\", \"items\": [{\"label\": \"Business Consulting\", \"value\": 74, \"color\": \"#0891b2\"}, {\"label\": \"Business Startup\", \"value\": 86, \"color\": \"#7c3aed\"}, {\"label\": \"Marketing Analysis\", \"value\": 65, \"color\": \"#16a34a\"}], \"padding\": \"40\"}, {\"type\": \"feature_grid\", \"id\": \"bb99434b2\", \"headline\": \"Special Outstanding Services For Startups\", \"subheadline\": null, \"cols\": 4, \"bgColor\": \"#fff\", \"cardBg\": \"#fff\", \"cardBorder\": \"#e2e8f0\", \"items\": [{\"icon\": \"💼\", \"title\": \"Entrepreneurs\", \"desc\": \"We help founders build the foundation for sustainable growth.\"}, {\"icon\": \"📋\", \"title\": \"Business Plan\", \"desc\": \"Strategic planning that aligns your vision with market opportunity.\"}, {\"icon\": \"📈\", \"title\": \"Capital Markets\", \"desc\": \"Positioning you for investor conversations and funding rounds.\"}, {\"icon\": \"🚀\", \"title\": \"Startups\", \"desc\": \"Full-service support for early-stage companies ready to scale.\"}], \"padding\": \"60\"}, {\"type\": \"contact_info\", \"id\": \"b3714696b\", \"headline\": \"Get In Touch\", \"items\": [{\"icon\": \"📍\", \"label\": \"Location\", \"value\": \"123 Agency Street, New York, NY 10001\"}, {\"icon\": \"📞\", \"label\": \"Phone\", \"value\": \"+1 (555) 234-5678\"}, {\"icon\": \"✉️\", \"label\": \"Email\", \"value\": \"hello@bestkitagency.com\"}, {\"icon\": \"⏰\", \"label\": \"Hours\", \"value\": \"Mon–Fri: 9:00am – 6:00pm\"}], \"padding\": \"40\"}, {\"type\": \"lead_form\", \"id\": \"ba88db120\", \"title\": \"Send Us a Message\", \"submitText\": \"Send Message\", \"successMsg\": \"Thank you! We\'ll be in touch soon.\", \"bg\": \"#f8fafc\", \"padding\": \"20\"}, {\"type\": \"footer_block\", \"id\": \"bcb61090f\", \"brand\": \"BestKit Agency\", \"description\": \"A trusted agency formed to help your business grow.\", \"bgColor\": \"#0f172a\", \"textColor\": \"#94a3b8\", \"brandColor\": \"#fff\", \"columns\": [{\"title\": \"Product\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"Changelog\", \"url\": \"#\"}]}, {\"title\": \"Company\", \"links\": [{\"label\": \"About\", \"url\": \"#\"}, {\"label\": \"Blog\", \"url\": \"#\"}, {\"label\": \"Careers\", \"url\": \"#\"}]}, {\"title\": \"Support\", \"links\": [{\"label\": \"Help Center\", \"url\": \"#\"}, {\"label\": \"Contact\", \"url\": \"#\"}, {\"label\": \"Privacy\", \"url\": \"#\"}]}], \"copyright\": \"© 2024 YourBrand. All rights reserved.\", \"padding\": \"20\"}]', 1, 6, NULL, '2026-03-15 04:05:30', 1, 0),
(23, NULL, 'Event Registration', 'event', 'Drive event sign-ups with date countdown, agenda, and registration form.', '🎪', '#ec4899', '[{\"type\": \"nav_bar\", \"id\": \"b626f7429\", \"brand\": \"YourEvent\", \"brandUrl\": \"#\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"About\", \"url\": \"#\"}], \"ctaText\": \"Register Now\", \"ctaUrl\": \"#\", \"ctaBg\": \"#2563eb\", \"bgColor\": \"#ffffff\", \"textColor\": \"#475569\", \"padding\": \"16\"}, {\"type\": \"hero_section\", \"id\": \"b8cd49b5e\", \"headline\": \"[Event Name] — [City, Date]\", \"subheadline\": \"Join industry leaders for [X] days of workshops, networking, and game-changing insights that will transform your [area].\", \"btnText\": \"Register Now\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"bgColor\": \"#0f172a\", \"overlayColor\": \"rgba(15,10,30,0.7)\", \"layout\": \"split\", \"showForm\": true, \"formTitle\": \"Get Started Today\", \"minHeight\": 500, \"padding\": \"20\"}, {\"type\": \"countdown\", \"id\": \"ba41547c4\", \"targetDate\": \"2026-04-05\", \"label\": \"Event starts in:\", \"padding\": \"20\"}, {\"type\": \"feature_grid\", \"id\": \"b7cd893e2\", \"headline\": \"What to Expect\", \"subheadline\": null, \"cols\": 3, \"bgColor\": \"#f8fafc\", \"cardBg\": \"#fff\", \"cardBorder\": \"#e2e8f0\", \"items\": [{\"icon\": \"🎤\", \"title\": \"Keynote Speakers\", \"desc\": \"Learn from 20+ world-class speakers and industry thought leaders.\"}, {\"icon\": \"🤝\", \"title\": \"Premium Networking\", \"desc\": \"Connect with 500+ professionals in intimate roundtable sessions.\"}, {\"icon\": \"🛠\", \"title\": \"Hands-On Workshops\", \"desc\": \"Walk away with practical skills you can implement immediately.\"}], \"padding\": \"60\"}, {\"type\": \"testimonial\", \"id\": \"b0403ca7b\", \"quote\": \"Last year\'s event was the best investment I made. Made 3 major business connections that turned into partnerships.\", \"author\": \"David Park\", \"role\": \"Entrepreneur & Investor\", \"color\": \"#ec4899\", \"padding\": \"40\"}, {\"type\": \"footer_block\", \"id\": \"b961c3878\", \"brand\": \"YourEvent\", \"description\": \"The premier event for forward-thinking professionals.\", \"bgColor\": \"#0f172a\", \"textColor\": \"#94a3b8\", \"brandColor\": \"#fff\", \"columns\": [{\"title\": \"Product\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"Changelog\", \"url\": \"#\"}]}, {\"title\": \"Company\", \"links\": [{\"label\": \"About\", \"url\": \"#\"}, {\"label\": \"Blog\", \"url\": \"#\"}, {\"label\": \"Careers\", \"url\": \"#\"}]}, {\"title\": \"Support\", \"links\": [{\"label\": \"Help Center\", \"url\": \"#\"}, {\"label\": \"Contact\", \"url\": \"#\"}, {\"label\": \"Privacy\", \"url\": \"#\"}]}], \"copyright\": \"© 2024 YourBrand. All rights reserved.\", \"padding\": \"20\"}]', 1, 7, NULL, '2026-03-15 04:05:30', 1, 0),
(24, NULL, 'Discount Promotion', 'promotion', 'Urgency-driven promotion page with countdown timer, offer banner, and form.', '🎁', '#ef4444', '[{\"type\": \"nav_bar\", \"id\": \"bfd63d99b\", \"brand\": \"YourStore\", \"brandUrl\": \"#\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"About\", \"url\": \"#\"}], \"ctaText\": \"Claim Offer\", \"ctaUrl\": \"#\", \"ctaBg\": \"#2563eb\", \"bgColor\": \"#ffffff\", \"textColor\": \"#475569\", \"padding\": \"16\"}, {\"type\": \"announcement_bar\", \"id\": \"bb87d6b9c\", \"text\": \"🔥 Flash Sale — Ends Midnight Tonight!\", \"bgColor\": \"#ef4444\", \"textColor\": \"#fff\", \"linkText\": \"Shop Now\", \"linkUrl\": \"#\", \"padding\": \"10\"}, {\"type\": \"offer_banner\", \"id\": \"b6a6baa5c\", \"headline\": \"Save 50% This Weekend Only\", \"text\": \"Enter code FLASH50 at checkout. Limited to the first 100 customers.\", \"bg1\": \"#ef4444\", \"bg2\": \"#dc2626\", \"padding\": \"20\"}, {\"type\": \"hero_section\", \"id\": \"bbfae642e\", \"headline\": \"Don\'t Miss This Limited-Time Offer\", \"subheadline\": \"Get [Product/Service] at half price for the next 24 hours only. This deal won\'t come around again.\", \"btnText\": \"Claim My 50% Discount\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"bgColor\": \"#0f172a\", \"overlayColor\": \"rgba(0,0,0,0.5)\", \"layout\": \"split\", \"showForm\": true, \"formTitle\": \"Get Started Today\", \"minHeight\": 500, \"padding\": \"20\"}, {\"type\": \"countdown\", \"id\": \"b4764b378\", \"targetDate\": \"2026-03-16\", \"label\": \"This offer expires in:\", \"padding\": \"20\"}, {\"type\": \"trust_badges\", \"id\": \"bdc84e14d\", \"badges\": [\"✓ 30-day money back guarantee\", \"✓ Instant access\", \"✓ No hidden fees\", \"✓ 10,000+ happy customers\"], \"color\": \"#16a34a\", \"padding\": \"20\"}, {\"type\": \"feature_grid\", \"id\": \"bbce1c866\", \"headline\": \"Here\'s What You\'re Getting\", \"subheadline\": null, \"cols\": 3, \"bgColor\": \"#fff\", \"cardBg\": \"#fff\", \"cardBorder\": \"#e2e8f0\", \"items\": [{\"icon\": \"🎯\", \"title\": \"Main Product\", \"desc\": \"Full access to everything with no limitations or restrictions.\"}, {\"icon\": \"🎓\", \"title\": \"Bonus Training\", \"desc\": \"Exclusive training materials worth $197 — yours free with today\'s purchase.\"}, {\"icon\": \"💬\", \"title\": \"Community Access\", \"desc\": \"Join our private community of 5,000+ members and experts.\"}], \"padding\": \"60\"}, {\"type\": \"testimonial\", \"id\": \"b73192ba3\", \"quote\": \"I almost missed this deal. So glad I didn\'t — it\'s been worth every penny, 10x over.\", \"author\": \"Anna Peterson\", \"role\": \"Small Business Owner\", \"color\": \"#ef4444\", \"padding\": \"40\"}, {\"type\": \"footer_block\", \"id\": \"bc7d23204\", \"brand\": \"YourStore\", \"description\": \"Premium products at unbeatable prices.\", \"bgColor\": \"#0f172a\", \"textColor\": \"#94a3b8\", \"brandColor\": \"#fff\", \"columns\": [{\"title\": \"Product\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"Changelog\", \"url\": \"#\"}]}, {\"title\": \"Company\", \"links\": [{\"label\": \"About\", \"url\": \"#\"}, {\"label\": \"Blog\", \"url\": \"#\"}, {\"label\": \"Careers\", \"url\": \"#\"}]}, {\"title\": \"Support\", \"links\": [{\"label\": \"Help Center\", \"url\": \"#\"}, {\"label\": \"Contact\", \"url\": \"#\"}, {\"label\": \"Privacy\", \"url\": \"#\"}]}], \"copyright\": \"© 2024 YourBrand. All rights reserved.\", \"padding\": \"20\"}]', 1, 8, NULL, '2026-03-15 04:05:30', 1, 0),
(25, NULL, 'Lead Generation', 'lead_gen', 'Professional lead capture page with hero, benefits, form, and trust signals.', 'user-account', '#2563eb', '[{\"type\":\"hero_section\",\"id\":\"b1\",\"headline\":\"Turn Visitors Into Qualified Leads\",\"subheadline\":\"Capture more leads with a high-converting landing page.\",\"btnText\":\"Get Started Free\",\"btnUrl\":\"#\",\"btnBg\":\"#2563eb\",\"bgColor\":\"#1e293b\",\"layout\":\"split\",\"showForm\":true,\"formTitle\":\"Get Started Today\",\"minHeight\":500,\"padding\":\"20\"},{\"type\":\"trust_badges\",\"id\":\"b2\",\"badges\":[\"✓ No credit card required\",\"✓ Setup in 5 minutes\",\"✓ Cancel anytime\",\"✓ GDPR compliant\"],\"color\":\"#16a34a\",\"padding\":\"20\"},{\"type\":\"footer_block\",\"id\":\"b3\",\"brand\":\"LeadPro\",\"description\":\"Professional lead capture software.\",\"bgColor\":\"#0f172a\",\"textColor\":\"#94a3b8\",\"brandColor\":\"#fff\",\"columns\":[],\"copyright\":\"© 2025 YourBrand. All rights reserved.\",\"padding\":\"20\"}]', 1, 1, NULL, '2026-03-15 04:05:58', 1, 1),
(26, NULL, 'SaaS Landing Page', 'saas', 'Full SaaS page with hero, features, pricing and testimonials.', '🚀', '#7c3aed', '[{\"type\":\"hero_section\",\"id\":\"b1\",\"headline\":\"Grow Smarter, Scale Faster\",\"subheadline\":\"The all-in-one platform that replaces five tools.\",\"btnText\":\"Start Free Trial\",\"btnUrl\":\"#\",\"btnBg\":\"#7c3aed\",\"bgColor\":\"#0f172a\",\"layout\":\"full\",\"showForm\":false,\"minHeight\":500,\"padding\":\"20\"},{\"type\":\"footer_block\",\"id\":\"b2\",\"brand\":\"YourBrand\",\"description\":\"The all-in-one platform for modern teams.\",\"bgColor\":\"#0f172a\",\"textColor\":\"#94a3b8\",\"brandColor\":\"#fff\",\"columns\":[],\"copyright\":\"© 2025 YourBrand. All rights reserved.\",\"padding\":\"20\"}]', 1, 2, NULL, '2026-03-15 04:05:58', 1, 1),
(27, NULL, 'Webinar Registration', 'webinar', 'Drive webinar sign-ups with urgency and social proof.', '🎙', '#7c3aed', '[{\"type\":\"hero_section\",\"id\":\"b1\",\"headline\":\"Free Live Webinar: [Your Topic]\",\"subheadline\":\"Join 500+ professionals for an exclusive live training.\",\"btnText\":\"Register My Free Seat\",\"btnUrl\":\"#\",\"btnBg\":\"#7c3aed\",\"bgColor\":\"#1e293b\",\"layout\":\"split\",\"showForm\":true,\"minHeight\":500,\"padding\":\"20\"},{\"type\":\"footer_block\",\"id\":\"b2\",\"brand\":\"YourBrand\",\"description\":\"Join us for this exclusive training.\",\"bgColor\":\"#0f172a\",\"textColor\":\"#94a3b8\",\"brandColor\":\"#fff\",\"columns\":[],\"copyright\":\"© 2025 YourBrand.\",\"padding\":\"20\"}]', 1, 3, NULL, '2026-03-15 04:05:58', 1, 0),
(28, NULL, 'Consultation Booking', 'booking', 'Book discovery calls with a benefits-led page.', '📅', '#16a34a', '[{\"type\":\"hero_section\",\"id\":\"b1\",\"headline\":\"Get a Free 30-Minute Strategy Session\",\"subheadline\":\"In just 30 minutes, get a clear roadmap for your business.\",\"btnText\":\"Book My Free Session\",\"btnUrl\":\"#\",\"btnBg\":\"#16a34a\",\"bgColor\":\"#0f172a\",\"layout\":\"split\",\"showForm\":true,\"minHeight\":500,\"padding\":\"20\"},{\"type\":\"footer_block\",\"id\":\"b2\",\"brand\":\"YourBrand\",\"description\":\"Expert consulting for ambitious businesses.\",\"bgColor\":\"#0f172a\",\"textColor\":\"#94a3b8\",\"brandColor\":\"#fff\",\"columns\":[],\"copyright\":\"© 2025 YourBrand.\",\"padding\":\"20\"}]', 1, 4, NULL, '2026-03-15 04:05:58', 1, 0),
(29, NULL, 'Product Launch', 'product_launch', 'Launch a new product with countdown, features, and early access offer.', '🚀', '#f59e0b', '[{\"type\":\"hero_section\",\"id\":\"b1\",\"headline\":\"Introducing [Product Name]\",\"subheadline\":\"The revolutionary solution that changes everything.\",\"btnText\":\"Get Early Access\",\"btnUrl\":\"#\",\"btnBg\":\"#f59e0b\",\"bgColor\":\"#0f172a\",\"layout\":\"full\",\"showForm\":false,\"minHeight\":500,\"padding\":\"20\"},{\"type\":\"footer_block\",\"id\":\"b2\",\"brand\":\"YourBrand\",\"description\":\"Changing the game, one product at a time.\",\"bgColor\":\"#0f172a\",\"textColor\":\"#94a3b8\",\"brandColor\":\"#fff\",\"columns\":[],\"copyright\":\"© 2025 YourBrand.\",\"padding\":\"20\"}]', 1, 5, NULL, '2026-03-15 04:05:58', 1, 0),
(30, NULL, 'Event Registration', 'event', 'Drive event sign-ups with agenda, speakers, and urgency.', '🎪', '#ec4899', '[{\"type\":\"hero_section\",\"id\":\"b1\",\"headline\":\"[Event Name] — Register Now\",\"subheadline\":\"Join us for a day of learning, networking and inspiration.\",\"btnText\":\"Save My Spot\",\"btnUrl\":\"#\",\"btnBg\":\"#ec4899\",\"bgColor\":\"#1e293b\",\"layout\":\"split\",\"showForm\":true,\"minHeight\":500,\"padding\":\"20\"},{\"type\":\"footer_block\",\"id\":\"b2\",\"brand\":\"YourBrand\",\"description\":\"Bringing people together.\",\"bgColor\":\"#0f172a\",\"textColor\":\"#94a3b8\",\"brandColor\":\"#fff\",\"columns\":[],\"copyright\":\"© 2025 YourBrand.\",\"padding\":\"20\"}]', 1, 6, NULL, '2026-03-15 04:05:58', 1, 0),
(31, NULL, 'Promotion / Offer', 'promotion', 'Flash sale or limited-time offer page with countdown and CTA.', '💰', '#dc2626', '[{\"type\":\"announcement_bar\",\"id\":\"b0\",\"text\":\"⚡ Limited Time Offer — Ends Soon!\",\"bgColor\":\"#dc2626\",\"textColor\":\"#fff\",\"padding\":\"10\"},{\"type\":\"hero_section\",\"id\":\"b1\",\"headline\":\"Get 50% Off — Today Only\",\"subheadline\":\"Our biggest sale of the year. Don\'t miss out.\",\"btnText\":\"Claim My Discount\",\"btnUrl\":\"#\",\"btnBg\":\"#dc2626\",\"bgColor\":\"#0f172a\",\"layout\":\"full\",\"showForm\":false,\"minHeight\":500,\"padding\":\"20\"},{\"type\":\"footer_block\",\"id\":\"b2\",\"brand\":\"YourBrand\",\"description\":\"Unbeatable deals, every day.\",\"bgColor\":\"#0f172a\",\"textColor\":\"#94a3b8\",\"brandColor\":\"#fff\",\"columns\":[],\"copyright\":\"© 2025 YourBrand.\",\"padding\":\"20\"}]', 1, 7, NULL, '2026-03-15 04:05:58', 1, 0),
(32, NULL, 'App Download', 'app', 'Drive mobile app installs with screenshots and store badges.', '📱', '#0891b2', '[{\"type\":\"hero_section\",\"id\":\"b1\",\"headline\":\"Download the App — It\'s Free\",\"subheadline\":\"Join 100,000+ users who already love the experience.\",\"btnText\":\"Download Now\",\"btnUrl\":\"#\",\"btnBg\":\"#0891b2\",\"bgColor\":\"#0f172a\",\"layout\":\"full\",\"showForm\":false,\"minHeight\":500,\"padding\":\"20\"},{\"type\":\"footer_block\",\"id\":\"b2\",\"brand\":\"YourBrand\",\"description\":\"The app that changes how you work.\",\"bgColor\":\"#0f172a\",\"textColor\":\"#94a3b8\",\"brandColor\":\"#fff\",\"columns\":[],\"copyright\":\"© 2025 YourBrand.\",\"padding\":\"20\"}]', 1, 8, NULL, '2026-03-15 04:05:58', 1, 0),
(33, NULL, 'Lead Generation', 'lead_gen', 'Professional lead capture page with hero, benefits, form, and trust signals.', 'user-account', '#2563eb', '[{\"type\": \"nav_bar\", \"id\": \"b522c7e8d\", \"brand\": \"LeadPro\", \"brandUrl\": \"#\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"About\", \"url\": \"#\"}], \"ctaText\": \"Get Started\", \"ctaUrl\": \"#\", \"ctaBg\": \"#2563eb\", \"bgColor\": \"#ffffff\", \"textColor\": \"#475569\", \"padding\": \"16\"}, {\"type\": \"hero_section\", \"id\": \"b397e52e7\", \"headline\": \"Turn Visitors Into Qualified Leads\", \"subheadline\": \"Capture more leads with a high-converting landing page that works around the clock.\", \"btnText\": \"Get Started Free\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"bgColor\": \"#1e293b\", \"overlayColor\": \"rgba(15,23,42,0.7)\", \"layout\": \"split\", \"showForm\": true, \"formTitle\": \"Get Started Today\", \"minHeight\": 500, \"padding\": \"20\"}, {\"type\": \"trust_badges\", \"id\": \"bc8758bd2\", \"badges\": [\"✓ No credit card required\", \"✓ Setup in 5 minutes\", \"✓ Cancel anytime\", \"✓ GDPR compliant\"], \"color\": \"#16a34a\", \"padding\": \"20\"}, {\"type\": \"section_title\", \"id\": \"b2353a974\", \"text\": \"WHY BUSINESSES CHOOSE US\", \"align\": \"center\", \"size\": \"1rem\", \"color\": \"#2563eb\", \"bold\": true, \"padding\": \"20\"}, {\"type\": \"feature_grid\", \"id\": \"b454513b4\", \"headline\": \"Everything You Need to Capture More Leads\", \"subheadline\": \"Built for marketers who want results without the complexity.\", \"cols\": 3, \"bgColor\": \"#fff\", \"cardBg\": \"#fff\", \"cardBorder\": \"#e2e8f0\", \"items\": [{\"icon\": \"🎯\", \"title\": \"Precision Targeting\", \"desc\": \"Reach your ideal audience with laser-focused campaigns that convert.\"}, {\"icon\": \"⚡\", \"title\": \"Instant Setup\", \"desc\": \"Launch your first landing page in under 10 minutes with our templates.\"}, {\"icon\": \"📊\", \"title\": \"Real-Time Analytics\", \"desc\": \"Track every visitor, conversion, and lead source in your dashboard.\"}, {\"icon\": \"🤖\", \"title\": \"AI-Powered\", \"desc\": \"Let AI write your headlines, copy, and CTAs for maximum impact.\"}, {\"icon\": \"🔒\", \"title\": \"Secure & Compliant\", \"desc\": \"GDPR-ready with built-in spam protection and data encryption.\"}, {\"icon\": \"📱\", \"title\": \"Mobile First\", \"desc\": \"Every page looks perfect on any device, automatically.\"}], \"padding\": \"60\"}, {\"type\": \"spacer\", \"id\": \"bafeba3e2\", \"height\": 20}, {\"type\": \"testimonial\", \"id\": \"bcd96ba9e\", \"quote\": \"We doubled our lead volume in 30 days. The conversion rate went from 2.1% to 5.8%.\", \"author\": \"Sarah Mitchell\", \"role\": \"VP Marketing, TechStart Inc\", \"color\": \"#2563eb\", \"padding\": \"40\"}, {\"type\": \"stats_row\", \"id\": \"bf734ce5a\", \"items\": [{\"number\": \"10,000+\", \"label\": \"Happy Customers\"}, {\"number\": \"5.8%\", \"label\": \"Avg. Conversion Rate\"}, {\"number\": \"98%\", \"label\": \"Uptime SLA\"}, {\"number\": \"4.9★\", \"label\": \"Customer Rating\"}], \"bgColor\": \"#f8fafc\", \"numColor\": \"#0f172a\", \"padding\": \"20\"}, {\"type\": \"footer_block\", \"id\": \"b7897db2c\", \"brand\": \"LeadPro\", \"description\": \"Professional lead capture software for modern marketing teams.\", \"bgColor\": \"#0f172a\", \"textColor\": \"#94a3b8\", \"brandColor\": \"#fff\", \"columns\": [{\"title\": \"Product\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"Changelog\", \"url\": \"#\"}]}, {\"title\": \"Company\", \"links\": [{\"label\": \"About\", \"url\": \"#\"}, {\"label\": \"Blog\", \"url\": \"#\"}, {\"label\": \"Careers\", \"url\": \"#\"}]}, {\"title\": \"Support\", \"links\": [{\"label\": \"Help Center\", \"url\": \"#\"}, {\"label\": \"Contact\", \"url\": \"#\"}, {\"label\": \"Privacy\", \"url\": \"#\"}]}], \"copyright\": \"© 2024 YourBrand. All rights reserved.\", \"padding\": \"20\"}]', 1, 1, NULL, '2026-03-15 04:07:07', 1, 1),
(34, NULL, 'SaaS Landing Page', 'saas', 'Full SaaS page with hero, features, pricing, testimonials, and FAQ.', '🚀', '#7c3aed', '[{\"type\": \"nav_bar\", \"id\": \"b298e2dcd\", \"brand\": \"Lunera\", \"brandUrl\": \"#\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"About\", \"url\": \"#\"}], \"ctaText\": \"Start Free Trial\", \"ctaUrl\": \"#\", \"ctaBg\": \"#2563eb\", \"bgColor\": \"#ffffff\", \"textColor\": \"#475569\", \"padding\": \"16\"}, {\"type\": \"announcement_bar\", \"id\": \"b284f4396\", \"text\": \"🎉 New: AI-powered features are now live!\", \"bgColor\": \"#2563eb\", \"textColor\": \"#fff\", \"linkText\": \"See what\'s new\", \"linkUrl\": \"#\", \"padding\": \"10\"}, {\"type\": \"hero_section\", \"id\": \"b6c284fa8\", \"headline\": \"Grow Smarter, Scale Faster\", \"subheadline\": \"The all-in-one platform that replaces five tools with one powerful solution. Start free, no credit card needed.\", \"btnText\": \"Start Free Trial\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"bgColor\": \"#0f172a\", \"overlayColor\": \"rgba(0,0,0,0)\", \"layout\": \"full\", \"showForm\": false, \"formTitle\": \"Get Started Today\", \"minHeight\": 500, \"padding\": \"20\"}, {\"type\": \"section_title\", \"id\": \"b0baaabbc\", \"text\": \"TRUSTED BY 10,000+ BUSINESSES\", \"align\": \"center\", \"size\": \"1rem\", \"color\": \"#2563eb\", \"bold\": true, \"padding\": \"20\"}, {\"type\": \"logo_gallery\", \"id\": \"ba6f6839c\", \"logos\": [\"Google\", \"Airbnb\", \"Spotify\", \"Stripe\", \"Shopify\", \"Notion\"], \"padding\": \"20\"}, {\"type\": \"feature_grid\", \"id\": \"bc7568eac\", \"headline\": \"Powerful Features Built for Growth\", \"subheadline\": \"Everything your team needs to attract leads, close deals, and delight customers.\", \"cols\": 3, \"bgColor\": \"#fff\", \"cardBg\": \"#fff\", \"cardBorder\": \"#e2e8f0\", \"items\": [{\"icon\": \"🎯\", \"title\": \"Smart Lead Capture\", \"desc\": \"Convert visitors with high-converting forms and landing pages.\"}, {\"icon\": \"🤖\", \"title\": \"AI Content Generator\", \"desc\": \"Create headlines, copy, and CTAs in seconds with built-in AI.\"}, {\"icon\": \"📊\", \"title\": \"Advanced Analytics\", \"desc\": \"Understand every interaction with real-time dashboards.\"}, {\"icon\": \"🔗\", \"title\": \"150+ Integrations\", \"desc\": \"Connect to your existing tools with one click.\"}, {\"icon\": \"⚡\", \"title\": \"Automation Workflows\", \"desc\": \"Automate repetitive tasks and focus on what matters.\"}, {\"icon\": \"🛡\", \"title\": \"Enterprise Security\", \"desc\": \"Bank-grade encryption and SOC 2 Type II compliance.\"}], \"padding\": \"60\"}, {\"type\": \"stats_row\", \"id\": \"bfd4c1cda\", \"items\": [{\"number\": \"10k+\", \"label\": \"Active Users\"}, {\"number\": \"99.9%\", \"label\": \"Uptime\"}, {\"number\": \"4.8★\", \"label\": \"Avg Rating\"}, {\"number\": \"24/7\", \"label\": \"Support\"}], \"bgColor\": \"#f8fafc\", \"numColor\": \"#0f172a\", \"padding\": \"20\"}, {\"type\": \"spacer\", \"id\": \"b698cdfae\", \"height\": 20}, {\"type\": \"two_col\", \"id\": \"bb435f454\", \"eyebrow\": \"WHY TEAMS LOVE US\", \"headline\": \"Built for Teams That Move Fast\", \"body\": \"Stop juggling between 5 different tools. Our platform combines lead capture, CRM, analytics, and automation into one seamless workflow that your team will actually love.\", \"imgUrl\": \"https://picsum.photos/seed/saas1/800/600\", \"imgAlt\": \"Built for Teams That Move Fast\", \"imgPosition\": \"left\", \"imgRadius\": 12, \"bullets\": [\"No per-seat pricing — pay one flat rate\", \"Real-time collaboration for your whole team\", \"Automated lead scoring and routing\", \"Native mobile apps for iOS and Android\"], \"showBtn\": true, \"btnText\": \"See How It Works\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"headlineColor\": \"#0f172a\", \"bodyColor\": \"#475569\", \"blockBg\": \"#f8fafc\", \"gap\": 48, \"padding\": \"60\"}, {\"type\": \"spacer\", \"id\": \"bcbe3303c\", \"height\": 20}, {\"type\": \"pricing\", \"id\": \"b99ee8ee5\", \"name\": \"Starter\", \"price\": \"29\", \"period\": \"month\", \"features\": [\"Up to 1,000 leads/month\", \"5 landing pages\", \"Basic analytics\", \"Email support\"], \"btnText\": \"Get Starter\", \"btnBg\": \"#2563eb\", \"padding\": \"40\"}, {\"type\": \"testimonial\", \"id\": \"b6536d5c9\", \"quote\": \"Switched from HubSpot and saved $800/month. The landing page builder alone is worth it.\", \"author\": \"James Wilson\", \"role\": \"CEO, ScaleUp Agency\", \"color\": \"#7c3aed\", \"padding\": \"40\"}, {\"type\": \"faq\", \"id\": \"bc2e7f37f\", \"title\": \"Frequently Asked Questions\", \"items\": [{\"q\": \"Is there a free trial?\", \"a\": \"Yes! 14-day free trial with full access. No credit card required.\"}, {\"q\": \"Can I cancel anytime?\", \"a\": \"Absolutely. Cancel with one click, no questions asked.\"}, {\"q\": \"Do you offer annual plans?\", \"a\": \"Yes, annual plans save you 2 months. Contact us for enterprise pricing.\"}, {\"q\": \"Is my data secure?\", \"a\": \"We use bank-grade encryption and are SOC 2 Type II certified.\"}], \"padding\": \"40\"}, {\"type\": \"footer_block\", \"id\": \"be479e03d\", \"brand\": \"Lunera\", \"description\": \"The all-in-one platform for modern marketing teams.\", \"bgColor\": \"#0f172a\", \"textColor\": \"#94a3b8\", \"brandColor\": \"#fff\", \"columns\": [{\"title\": \"Product\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"Changelog\", \"url\": \"#\"}]}, {\"title\": \"Company\", \"links\": [{\"label\": \"About\", \"url\": \"#\"}, {\"label\": \"Blog\", \"url\": \"#\"}, {\"label\": \"Careers\", \"url\": \"#\"}]}, {\"title\": \"Support\", \"links\": [{\"label\": \"Help Center\", \"url\": \"#\"}, {\"label\": \"Contact\", \"url\": \"#\"}, {\"label\": \"Privacy\", \"url\": \"#\"}]}], \"copyright\": \"© 2024 YourBrand. All rights reserved.\", \"padding\": \"20\"}]', 1, 2, NULL, '2026-03-15 04:07:07', 1, 1),
(35, NULL, 'Webinar Registration', 'webinar', 'Drive webinar sign-ups with urgency, speaker bio, and agenda.', '🎙', '#7c3aed', '[{\"type\": \"nav_bar\", \"id\": \"b5ed3e5d6\", \"brand\": \"YourBrand\", \"brandUrl\": \"#\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"About\", \"url\": \"#\"}], \"ctaText\": \"Register Free\", \"ctaUrl\": \"#\", \"ctaBg\": \"#2563eb\", \"bgColor\": \"#ffffff\", \"textColor\": \"#475569\", \"padding\": \"16\"}, {\"type\": \"announcement_bar\", \"id\": \"b4d7054da\", \"text\": \"⏳ Limited spots! Only 47 seats remaining.\", \"bgColor\": \"#7c3aed\", \"textColor\": \"#fff\", \"linkText\": \"Register Now\", \"linkUrl\": \"#\", \"padding\": \"10\"}, {\"type\": \"hero_section\", \"id\": \"b586fabc1\", \"headline\": \"Free Live Webinar: [Your Topic Here]\", \"subheadline\": \"Join 500+ professionals for an exclusive live training session. Learn the strategies top companies use to 3x their results.\", \"btnText\": \"Register My Free Seat\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"bgColor\": \"#1e293b\", \"overlayColor\": \"rgba(20,10,40,0.75)\", \"layout\": \"split\", \"showForm\": true, \"formTitle\": \"Get Started Today\", \"minHeight\": 500, \"padding\": \"20\"}, {\"type\": \"countdown\", \"id\": \"b94c434ce\", \"targetDate\": \"2026-03-20\", \"label\": \"Webinar starts in:\", \"padding\": \"20\"}, {\"type\": \"section_title\", \"id\": \"b25dd4c04\", \"text\": \"WHAT YOU\'LL LEARN\", \"align\": \"center\", \"size\": \"1rem\", \"color\": \"#2563eb\", \"bold\": true, \"padding\": \"20\"}, {\"type\": \"feature_grid\", \"id\": \"bbd13e022\", \"headline\": \"3 Actionable Strategies You\'ll Walk Away With\", \"subheadline\": null, \"cols\": 3, \"bgColor\": \"#f8fafc\", \"cardBg\": \"#fff\", \"cardBorder\": \"#e2e8f0\", \"items\": [{\"icon\": \"📈\", \"title\": \"Strategy #1: Scale Without Burning Out\", \"desc\": \"Discover the exact system to 3x your output without working more hours.\"}, {\"icon\": \"🎯\", \"title\": \"Strategy #2: Find Your Best Customers\", \"desc\": \"Learn how to attract clients who pay more, complain less, and refer others.\"}, {\"icon\": \"🤖\", \"title\": \"Strategy #3: Automate Your Lead Flow\", \"desc\": \"Set up a system that generates qualified leads on autopilot 24/7.\"}], \"padding\": \"60\"}, {\"type\": \"two_col\", \"id\": \"bf352d1c8\", \"eyebrow\": \"MEET YOUR SPEAKER\", \"headline\": \"Your Host\", \"body\": \"With 15+ years of experience and 200+ speaking engagements, [Speaker Name] has helped thousands of entrepreneurs scale their businesses. Featured in Forbes, Entrepreneur, and Inc Magazine.\", \"imgUrl\": \"https://picsum.photos/seed/speaker/400/500\", \"imgAlt\": \"Your Host\", \"imgPosition\": \"right\", \"imgRadius\": 12, \"bullets\": [\"Author of 3 best-selling business books\", \"Built and sold two 7-figure companies\", \"Mentored 5,000+ entrepreneurs worldwide\"], \"showBtn\": true, \"btnText\": \"Register Now\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"headlineColor\": \"#0f172a\", \"bodyColor\": \"#475569\", \"blockBg\": \"#fff\", \"gap\": 48, \"padding\": \"60\"}, {\"type\": \"testimonial\", \"id\": \"b98175678\", \"quote\": \"This webinar changed how I think about my business. Implemented one strategy and added $40k in revenue.\", \"author\": \"Rachel Torres\", \"role\": \"Founder, GrowthPath\", \"color\": \"#7c3aed\", \"padding\": \"40\"}, {\"type\": \"footer_block\", \"id\": \"bd7495fae\", \"brand\": \"YourBrand\", \"description\": \"Join us for this exclusive live training session.\", \"bgColor\": \"#0f172a\", \"textColor\": \"#94a3b8\", \"brandColor\": \"#fff\", \"columns\": [{\"title\": \"Product\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"Changelog\", \"url\": \"#\"}]}, {\"title\": \"Company\", \"links\": [{\"label\": \"About\", \"url\": \"#\"}, {\"label\": \"Blog\", \"url\": \"#\"}, {\"label\": \"Careers\", \"url\": \"#\"}]}, {\"title\": \"Support\", \"links\": [{\"label\": \"Help Center\", \"url\": \"#\"}, {\"label\": \"Contact\", \"url\": \"#\"}, {\"label\": \"Privacy\", \"url\": \"#\"}]}], \"copyright\": \"© 2024 YourBrand. All rights reserved.\", \"padding\": \"20\"}]', 1, 3, NULL, '2026-03-15 04:07:07', 1, 0),
(36, NULL, 'Consultation Booking', 'booking', 'Book discovery calls with a benefits-led page and appointment CTA.', '📅', '#16a34a', '[{\"type\": \"nav_bar\", \"id\": \"b9d4470ba\", \"brand\": \"YourBrand\", \"brandUrl\": \"#\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"About\", \"url\": \"#\"}], \"ctaText\": \"Book Free Call\", \"ctaUrl\": \"#\", \"ctaBg\": \"#2563eb\", \"bgColor\": \"#ffffff\", \"textColor\": \"#475569\", \"padding\": \"16\"}, {\"type\": \"hero_section\", \"id\": \"ba2391707\", \"headline\": \"Get a Free 30-Minute Strategy Session\", \"subheadline\": \"In just 30 minutes, we\'ll analyse your situation and give you a clear roadmap. No pitch, no pressure — just value.\", \"btnText\": \"Book My Free Session\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"bgColor\": \"#0f172a\", \"overlayColor\": \"rgba(0,0,0,0.4)\", \"layout\": \"split\", \"showForm\": true, \"formTitle\": \"Get Started Today\", \"minHeight\": 500, \"padding\": \"20\"}, {\"type\": \"trust_badges\", \"id\": \"ba53fb3e8\", \"badges\": [\"✓ No obligation\", \"✓ Immediate insights\", \"✓ Tailored to your business\", \"✓ 100% confidential\"], \"color\": \"#16a34a\", \"padding\": \"20\"}, {\"type\": \"feature_grid\", \"id\": \"b9ba7a2b8\", \"headline\": \"What Happens on the Call\", \"subheadline\": null, \"cols\": 3, \"bgColor\": \"#f8fafc\", \"cardBg\": \"#fff\", \"cardBorder\": \"#e2e8f0\", \"items\": [{\"icon\": \"🔍\", \"title\": \"Deep-Dive Analysis\", \"desc\": \"We review your current situation and identify the biggest opportunities.\"}, {\"icon\": \"🗺\", \"title\": \"Custom Roadmap\", \"desc\": \"You\'ll leave with a clear 90-day action plan specific to your goals.\"}, {\"icon\": \"🤝\", \"title\": \"No Hard Sell\", \"desc\": \"This is purely about giving you value. We only work with people we can genuinely help.\"}], \"padding\": \"60\"}, {\"type\": \"two_col\", \"id\": \"b262b12f7\", \"eyebrow\": \"\", \"headline\": \"Why 500+ Businesses Trust Us\", \"body\": \"Our team has worked with companies across 30+ industries. We understand that every business is unique, which is why we never offer cookie-cutter solutions.\", \"imgUrl\": \"https://picsum.photos/seed/consult/800/600\", \"imgAlt\": \"Why 500+ Businesses Trust Us\", \"imgPosition\": \"left\", \"imgRadius\": 12, \"bullets\": [\"Average client revenue increase: 47%\", \"4.9/5 star rating from 300+ clients\", \"Featured in Forbes and Business Insider\"], \"showBtn\": true, \"btnText\": \"Book My Free Session\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"headlineColor\": \"#0f172a\", \"bodyColor\": \"#475569\", \"blockBg\": \"#fff\", \"gap\": 48, \"padding\": \"60\"}, {\"type\": \"appointment\", \"id\": \"be2f48da7\", \"label\": \"Ready to transform your business?\", \"btnText\": \"📅 Book Your Free Strategy Session\", \"url\": \"https://calendly.com/\", \"bg\": \"#2563eb\", \"color\": \"#ffffff\", \"radius\": \"10\", \"padding\": \"40\"}, {\"type\": \"testimonial\", \"id\": \"bf5f80d20\", \"quote\": \"Best 30 minutes I\'ve invested in my business. The team identified $200k in untapped revenue in our first call.\", \"author\": \"Mark Johnson\", \"role\": \"CEO, BrightPath Ltd\", \"color\": \"#16a34a\", \"padding\": \"40\"}, {\"type\": \"footer_block\", \"id\": \"bba2cfa93\", \"brand\": \"YourBrand\", \"description\": \"Expert consulting for ambitious businesses.\", \"bgColor\": \"#0f172a\", \"textColor\": \"#94a3b8\", \"brandColor\": \"#fff\", \"columns\": [{\"title\": \"Product\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"Changelog\", \"url\": \"#\"}]}, {\"title\": \"Company\", \"links\": [{\"label\": \"About\", \"url\": \"#\"}, {\"label\": \"Blog\", \"url\": \"#\"}, {\"label\": \"Careers\", \"url\": \"#\"}]}, {\"title\": \"Support\", \"links\": [{\"label\": \"Help Center\", \"url\": \"#\"}, {\"label\": \"Contact\", \"url\": \"#\"}, {\"label\": \"Privacy\", \"url\": \"#\"}]}], \"copyright\": \"© 2024 YourBrand. All rights reserved.\", \"padding\": \"20\"}]', 1, 4, NULL, '2026-03-15 04:07:07', 1, 0),
(37, NULL, 'Product Launch', 'product_launch', 'Launch a product with offer banner, countdown, pricing, and social proof.', '🚀', '#f59e0b', '[{\"type\": \"nav_bar\", \"id\": \"bc51f45d4\", \"brand\": \"YourBrand\", \"brandUrl\": \"#\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"About\", \"url\": \"#\"}], \"ctaText\": \"Buy Now\", \"ctaUrl\": \"#\", \"ctaBg\": \"#2563eb\", \"bgColor\": \"#ffffff\", \"textColor\": \"#475569\", \"padding\": \"16\"}, {\"type\": \"announcement_bar\", \"id\": \"b92002df4\", \"text\": \"🔥 Launch Special: 40% OFF for the first 48 hours only!\", \"bgColor\": \"#f59e0b\", \"textColor\": \"#fff\", \"linkText\": \"Claim Discount\", \"linkUrl\": \"#\", \"padding\": \"10\"}, {\"type\": \"hero_section\", \"id\": \"b8fa45579\", \"headline\": \"Introducing [Product Name]: The [Benefit] You\'ve Been Waiting For\", \"subheadline\": \"Finally, a solution that [solves the main pain point] without [the main frustration]. Join 1,000+ happy customers who made the switch.\", \"btnText\": \"Get 40% Off Today\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"bgColor\": \"#0f172a\", \"overlayColor\": \"rgba(0,0,0,0.5)\", \"layout\": \"split\", \"showForm\": true, \"formTitle\": \"Get Started Today\", \"minHeight\": 500, \"padding\": \"20\"}, {\"type\": \"countdown\", \"id\": \"ba9caac4a\", \"targetDate\": \"2026-03-17\", \"label\": \"Launch price expires in:\", \"padding\": \"20\"}, {\"type\": \"offer_banner\", \"id\": \"b84c1682d\", \"headline\": \"🔥 Launch Week Only: 40% Off + Free Bonus!\", \"text\": \"Use code LAUNCH40 at checkout. Offer expires Sunday midnight.\", \"bg1\": \"#f59e0b\", \"bg2\": \"#ef4444\", \"padding\": \"20\"}, {\"type\": \"feature_grid\", \"id\": \"ba622fd25\", \"headline\": \"Everything Included in Your Purchase\", \"subheadline\": null, \"cols\": 3, \"bgColor\": \"#fff\", \"cardBg\": \"#fff\", \"cardBorder\": \"#e2e8f0\", \"items\": [{\"icon\": \"✅\", \"title\": \"Core Product\", \"desc\": \"The full product with all features unlocked from day one.\"}, {\"icon\": \"📖\", \"title\": \"Quick-Start Guide\", \"desc\": \"Step-by-step setup guide so you get results in under an hour.\"}, {\"icon\": \"💬\", \"title\": \"Priority Support\", \"desc\": \"Jump the queue with dedicated email support for 90 days.\"}, {\"icon\": \"🎓\", \"title\": \"Training Videos\", \"desc\": \"25+ video tutorials covering every feature in depth.\"}, {\"icon\": \"🔄\", \"title\": \"Free Updates\", \"desc\": \"All future updates included free — forever.\"}, {\"icon\": \"💰\", \"title\": \"30-Day Guarantee\", \"desc\": \"100% money-back guarantee. No questions asked.\"}], \"padding\": \"60\"}, {\"type\": \"testimonial\", \"id\": \"bfd3a31fe\", \"quote\": \"I was skeptical at first, but the results speak for themselves. ROI within 2 weeks.\", \"author\": \"Lisa Chen\", \"role\": \"Marketing Director, NovaBrand\", \"color\": \"#f59e0b\", \"padding\": \"40\"}, {\"type\": \"stats_row\", \"id\": \"bf33dc710\", \"items\": [{\"number\": \"1,000+\", \"label\": \"Happy Customers\"}, {\"number\": \"4.9★\", \"label\": \"Average Rating\"}, {\"number\": \"30-Day\", \"label\": \"Money Back\"}, {\"number\": \"24/7\", \"label\": \"Support\"}], \"bgColor\": \"#f8fafc\", \"numColor\": \"#0f172a\", \"padding\": \"20\"}, {\"type\": \"footer_block\", \"id\": \"bc9a8acc0\", \"brand\": \"YourBrand\", \"description\": \"Premium products for ambitious professionals.\", \"bgColor\": \"#0f172a\", \"textColor\": \"#94a3b8\", \"brandColor\": \"#fff\", \"columns\": [{\"title\": \"Product\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"Changelog\", \"url\": \"#\"}]}, {\"title\": \"Company\", \"links\": [{\"label\": \"About\", \"url\": \"#\"}, {\"label\": \"Blog\", \"url\": \"#\"}, {\"label\": \"Careers\", \"url\": \"#\"}]}, {\"title\": \"Support\", \"links\": [{\"label\": \"Help Center\", \"url\": \"#\"}, {\"label\": \"Contact\", \"url\": \"#\"}, {\"label\": \"Privacy\", \"url\": \"#\"}]}], \"copyright\": \"© 2024 YourBrand. All rights reserved.\", \"padding\": \"20\"}]', 1, 5, NULL, '2026-03-15 04:07:07', 1, 1),
(38, NULL, 'Agency Services', 'agency', 'Showcase agency services with social proof, stats, and contact form.', '🏆', '#0891b2', '[{\"type\": \"nav_bar\", \"id\": \"ba03d1ef7\", \"brand\": \"BestKit Agency\", \"brandUrl\": \"#\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"About\", \"url\": \"#\"}], \"ctaText\": \"Contact Us\", \"ctaUrl\": \"#\", \"ctaBg\": \"#2563eb\", \"bgColor\": \"#ffffff\", \"textColor\": \"#475569\", \"padding\": \"16\"}, {\"type\": \"hero_section\", \"id\": \"bfb38fc79\", \"headline\": \"Creating Digital Experiences That Convert\", \"subheadline\": \"We design and build websites, campaigns, and marketing systems for ambitious businesses worldwide.\", \"btnText\": \"Get a Free Quote\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"bgColor\": \"#0f172a\", \"overlayColor\": \"rgba(0,0,0,0.45)\", \"layout\": \"full\", \"showForm\": false, \"formTitle\": \"Get Started Today\", \"minHeight\": 500, \"padding\": \"20\"}, {\"type\": \"stats_row\", \"id\": \"bf691a3da\", \"items\": [{\"number\": \"834\", \"label\": \"Startups Served\"}, {\"number\": \"372\", \"label\": \"Projects Completed\"}, {\"number\": \"14\", \"label\": \"Awards Won\"}, {\"number\": \"43\", \"label\": \"Team Members\"}], \"bgColor\": \"#f8fafc\", \"numColor\": \"#0f172a\", \"padding\": \"20\"}, {\"type\": \"two_col\", \"id\": \"b3f6017a0\", \"eyebrow\": \"OUR SKILL\", \"headline\": \"We Aim to Share Knowledge, Attract Talent & Grow Your Business\", \"body\": \"We design & build brand, campaigns & digital projects for business large & small with customer experiences that convert visitors into loyal customers.\", \"imgUrl\": \"https://picsum.photos/seed/agency/800/600\", \"imgAlt\": \"We Aim to Share Knowledge, Attract Talent & Grow Your Business\", \"imgPosition\": \"right\", \"imgRadius\": 12, \"bullets\": [\"Pixel perfect & expertly crafted to meet standards\", \"We love what we do & why we do it for\"], \"showBtn\": true, \"btnText\": \"Learn About Us\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"headlineColor\": \"#0f172a\", \"bodyColor\": \"#475569\", \"blockBg\": \"#f8fafc\", \"gap\": 48, \"padding\": \"60\"}, {\"type\": \"progress_bars\", \"id\": \"ba2e94f99\", \"headline\": \"Our Core Competencies\", \"items\": [{\"label\": \"Business Consulting\", \"value\": 74, \"color\": \"#0891b2\"}, {\"label\": \"Business Startup\", \"value\": 86, \"color\": \"#7c3aed\"}, {\"label\": \"Marketing Analysis\", \"value\": 65, \"color\": \"#16a34a\"}], \"padding\": \"40\"}, {\"type\": \"feature_grid\", \"id\": \"bb99434b2\", \"headline\": \"Special Outstanding Services For Startups\", \"subheadline\": null, \"cols\": 4, \"bgColor\": \"#fff\", \"cardBg\": \"#fff\", \"cardBorder\": \"#e2e8f0\", \"items\": [{\"icon\": \"💼\", \"title\": \"Entrepreneurs\", \"desc\": \"We help founders build the foundation for sustainable growth.\"}, {\"icon\": \"📋\", \"title\": \"Business Plan\", \"desc\": \"Strategic planning that aligns your vision with market opportunity.\"}, {\"icon\": \"📈\", \"title\": \"Capital Markets\", \"desc\": \"Positioning you for investor conversations and funding rounds.\"}, {\"icon\": \"🚀\", \"title\": \"Startups\", \"desc\": \"Full-service support for early-stage companies ready to scale.\"}], \"padding\": \"60\"}, {\"type\": \"contact_info\", \"id\": \"b3714696b\", \"headline\": \"Get In Touch\", \"items\": [{\"icon\": \"📍\", \"label\": \"Location\", \"value\": \"123 Agency Street, New York, NY 10001\"}, {\"icon\": \"📞\", \"label\": \"Phone\", \"value\": \"+1 (555) 234-5678\"}, {\"icon\": \"✉️\", \"label\": \"Email\", \"value\": \"hello@bestkitagency.com\"}, {\"icon\": \"⏰\", \"label\": \"Hours\", \"value\": \"Mon–Fri: 9:00am – 6:00pm\"}], \"padding\": \"40\"}, {\"type\": \"lead_form\", \"id\": \"ba88db120\", \"title\": \"Send Us a Message\", \"submitText\": \"Send Message\", \"successMsg\": \"Thank you! We\'ll be in touch soon.\", \"bg\": \"#f8fafc\", \"padding\": \"20\"}, {\"type\": \"footer_block\", \"id\": \"bcb61090f\", \"brand\": \"BestKit Agency\", \"description\": \"A trusted agency formed to help your business grow.\", \"bgColor\": \"#0f172a\", \"textColor\": \"#94a3b8\", \"brandColor\": \"#fff\", \"columns\": [{\"title\": \"Product\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"Changelog\", \"url\": \"#\"}]}, {\"title\": \"Company\", \"links\": [{\"label\": \"About\", \"url\": \"#\"}, {\"label\": \"Blog\", \"url\": \"#\"}, {\"label\": \"Careers\", \"url\": \"#\"}]}, {\"title\": \"Support\", \"links\": [{\"label\": \"Help Center\", \"url\": \"#\"}, {\"label\": \"Contact\", \"url\": \"#\"}, {\"label\": \"Privacy\", \"url\": \"#\"}]}], \"copyright\": \"© 2024 YourBrand. All rights reserved.\", \"padding\": \"20\"}]', 1, 6, NULL, '2026-03-15 04:07:07', 1, 0),
(39, NULL, 'Event Registration', 'event', 'Drive event sign-ups with date countdown, agenda, and registration form.', '🎪', '#ec4899', '[{\"type\": \"nav_bar\", \"id\": \"b626f7429\", \"brand\": \"YourEvent\", \"brandUrl\": \"#\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"About\", \"url\": \"#\"}], \"ctaText\": \"Register Now\", \"ctaUrl\": \"#\", \"ctaBg\": \"#2563eb\", \"bgColor\": \"#ffffff\", \"textColor\": \"#475569\", \"padding\": \"16\"}, {\"type\": \"hero_section\", \"id\": \"b8cd49b5e\", \"headline\": \"[Event Name] — [City, Date]\", \"subheadline\": \"Join industry leaders for [X] days of workshops, networking, and game-changing insights that will transform your [area].\", \"btnText\": \"Register Now\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"bgColor\": \"#0f172a\", \"overlayColor\": \"rgba(15,10,30,0.7)\", \"layout\": \"split\", \"showForm\": true, \"formTitle\": \"Get Started Today\", \"minHeight\": 500, \"padding\": \"20\"}, {\"type\": \"countdown\", \"id\": \"ba41547c4\", \"targetDate\": \"2026-04-05\", \"label\": \"Event starts in:\", \"padding\": \"20\"}, {\"type\": \"feature_grid\", \"id\": \"b7cd893e2\", \"headline\": \"What to Expect\", \"subheadline\": null, \"cols\": 3, \"bgColor\": \"#f8fafc\", \"cardBg\": \"#fff\", \"cardBorder\": \"#e2e8f0\", \"items\": [{\"icon\": \"🎤\", \"title\": \"Keynote Speakers\", \"desc\": \"Learn from 20+ world-class speakers and industry thought leaders.\"}, {\"icon\": \"🤝\", \"title\": \"Premium Networking\", \"desc\": \"Connect with 500+ professionals in intimate roundtable sessions.\"}, {\"icon\": \"🛠\", \"title\": \"Hands-On Workshops\", \"desc\": \"Walk away with practical skills you can implement immediately.\"}], \"padding\": \"60\"}, {\"type\": \"testimonial\", \"id\": \"b0403ca7b\", \"quote\": \"Last year\'s event was the best investment I made. Made 3 major business connections that turned into partnerships.\", \"author\": \"David Park\", \"role\": \"Entrepreneur & Investor\", \"color\": \"#ec4899\", \"padding\": \"40\"}, {\"type\": \"footer_block\", \"id\": \"b961c3878\", \"brand\": \"YourEvent\", \"description\": \"The premier event for forward-thinking professionals.\", \"bgColor\": \"#0f172a\", \"textColor\": \"#94a3b8\", \"brandColor\": \"#fff\", \"columns\": [{\"title\": \"Product\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"Changelog\", \"url\": \"#\"}]}, {\"title\": \"Company\", \"links\": [{\"label\": \"About\", \"url\": \"#\"}, {\"label\": \"Blog\", \"url\": \"#\"}, {\"label\": \"Careers\", \"url\": \"#\"}]}, {\"title\": \"Support\", \"links\": [{\"label\": \"Help Center\", \"url\": \"#\"}, {\"label\": \"Contact\", \"url\": \"#\"}, {\"label\": \"Privacy\", \"url\": \"#\"}]}], \"copyright\": \"© 2024 YourBrand. All rights reserved.\", \"padding\": \"20\"}]', 1, 7, NULL, '2026-03-15 04:07:07', 1, 0);
INSERT INTO `campaign_templates` (`id`, `account_id`, `name`, `category`, `description`, `thumbnail_emoji`, `thumbnail_color`, `page_data`, `is_system`, `sort_order`, `created_by`, `created_at`, `is_active`, `is_featured`) VALUES
(40, NULL, 'Discount Promotion', 'promotion', 'Urgency-driven promotion page with countdown timer, offer banner, and form.', '🎁', '#ef4444', '[{\"type\": \"nav_bar\", \"id\": \"bfd63d99b\", \"brand\": \"YourStore\", \"brandUrl\": \"#\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"About\", \"url\": \"#\"}], \"ctaText\": \"Claim Offer\", \"ctaUrl\": \"#\", \"ctaBg\": \"#2563eb\", \"bgColor\": \"#ffffff\", \"textColor\": \"#475569\", \"padding\": \"16\"}, {\"type\": \"announcement_bar\", \"id\": \"bb87d6b9c\", \"text\": \"🔥 Flash Sale — Ends Midnight Tonight!\", \"bgColor\": \"#ef4444\", \"textColor\": \"#fff\", \"linkText\": \"Shop Now\", \"linkUrl\": \"#\", \"padding\": \"10\"}, {\"type\": \"offer_banner\", \"id\": \"b6a6baa5c\", \"headline\": \"Save 50% This Weekend Only\", \"text\": \"Enter code FLASH50 at checkout. Limited to the first 100 customers.\", \"bg1\": \"#ef4444\", \"bg2\": \"#dc2626\", \"padding\": \"20\"}, {\"type\": \"hero_section\", \"id\": \"bbfae642e\", \"headline\": \"Don\'t Miss This Limited-Time Offer\", \"subheadline\": \"Get [Product/Service] at half price for the next 24 hours only. This deal won\'t come around again.\", \"btnText\": \"Claim My 50% Discount\", \"btnUrl\": \"#\", \"btnBg\": \"#2563eb\", \"bgColor\": \"#0f172a\", \"overlayColor\": \"rgba(0,0,0,0.5)\", \"layout\": \"split\", \"showForm\": true, \"formTitle\": \"Get Started Today\", \"minHeight\": 500, \"padding\": \"20\"}, {\"type\": \"countdown\", \"id\": \"b4764b378\", \"targetDate\": \"2026-03-16\", \"label\": \"This offer expires in:\", \"padding\": \"20\"}, {\"type\": \"trust_badges\", \"id\": \"bdc84e14d\", \"badges\": [\"✓ 30-day money back guarantee\", \"✓ Instant access\", \"✓ No hidden fees\", \"✓ 10,000+ happy customers\"], \"color\": \"#16a34a\", \"padding\": \"20\"}, {\"type\": \"feature_grid\", \"id\": \"bbce1c866\", \"headline\": \"Here\'s What You\'re Getting\", \"subheadline\": null, \"cols\": 3, \"bgColor\": \"#fff\", \"cardBg\": \"#fff\", \"cardBorder\": \"#e2e8f0\", \"items\": [{\"icon\": \"🎯\", \"title\": \"Main Product\", \"desc\": \"Full access to everything with no limitations or restrictions.\"}, {\"icon\": \"🎓\", \"title\": \"Bonus Training\", \"desc\": \"Exclusive training materials worth $197 — yours free with today\'s purchase.\"}, {\"icon\": \"💬\", \"title\": \"Community Access\", \"desc\": \"Join our private community of 5,000+ members and experts.\"}], \"padding\": \"60\"}, {\"type\": \"testimonial\", \"id\": \"b73192ba3\", \"quote\": \"I almost missed this deal. So glad I didn\'t — it\'s been worth every penny, 10x over.\", \"author\": \"Anna Peterson\", \"role\": \"Small Business Owner\", \"color\": \"#ef4444\", \"padding\": \"40\"}, {\"type\": \"footer_block\", \"id\": \"bc7d23204\", \"brand\": \"YourStore\", \"description\": \"Premium products at unbeatable prices.\", \"bgColor\": \"#0f172a\", \"textColor\": \"#94a3b8\", \"brandColor\": \"#fff\", \"columns\": [{\"title\": \"Product\", \"links\": [{\"label\": \"Features\", \"url\": \"#\"}, {\"label\": \"Pricing\", \"url\": \"#\"}, {\"label\": \"Changelog\", \"url\": \"#\"}]}, {\"title\": \"Company\", \"links\": [{\"label\": \"About\", \"url\": \"#\"}, {\"label\": \"Blog\", \"url\": \"#\"}, {\"label\": \"Careers\", \"url\": \"#\"}]}, {\"title\": \"Support\", \"links\": [{\"label\": \"Help Center\", \"url\": \"#\"}, {\"label\": \"Contact\", \"url\": \"#\"}, {\"label\": \"Privacy\", \"url\": \"#\"}]}], \"copyright\": \"© 2024 YourBrand. All rights reserved.\", \"padding\": \"20\"}]', 1, 8, NULL, '2026-03-15 04:07:07', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `domains`
--

DROP TABLE IF EXISTS `domains`;
CREATE TABLE `domains` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `domain` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `verify_token` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `verify_method` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'dns_txt',
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `domains`
--

INSERT INTO `domains` (`id`, `account_id`, `domain`, `label`, `is_active`, `verify_token`, `verified_at`, `verify_method`, `created_by`, `created_at`) VALUES
(6, 2, 'kokler.in', 'Kokler', 1, 'lpv-8a5fb5b2330b5b8f40e2cbd3aa73aa21', '2026-03-12 09:25:50', 'dns_txt', 7, '2026-03-12 09:18:43'),
(7, 2, 'ebrandist.com', 'ebrandist', 1, 'lpv-115fdd11d473887528ca0d69d1d047f0', NULL, 'dns_txt', 7, '2026-03-19 10:55:37');

-- --------------------------------------------------------

--
-- Table structure for table `email_domain_blocklist`
--

DROP TABLE IF EXISTS `email_domain_blocklist`;
CREATE TABLE `email_domain_blocklist` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED DEFAULT NULL,
  `domain` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blocked_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `email_domain_blocklist`
--

INSERT INTO `email_domain_blocklist` (`id`, `account_id`, `domain`, `reason`, `blocked_by`, `created_at`) VALUES
(1, NULL, 'mailinator.com', 'Disposable', NULL, '2026-03-10 05:11:58'),
(2, NULL, 'guerrillamail.com', 'Disposable', NULL, '2026-03-10 05:11:58'),
(3, NULL, 'trashmail.com', 'Disposable', NULL, '2026-03-10 05:11:58'),
(4, NULL, 'temp-mail.org', 'Disposable', NULL, '2026-03-10 05:11:58'),
(5, NULL, 'yopmail.com', 'Disposable', NULL, '2026-03-10 05:11:58'),
(6, NULL, 'sharklasers.com', 'Disposable', NULL, '2026-03-10 05:11:58'),
(7, NULL, 'grr.la', 'Disposable', NULL, '2026-03-10 05:11:58'),
(8, NULL, 'dispostable.com', 'Disposable', NULL, '2026-03-10 05:11:58'),
(9, NULL, 'mailnull.com', 'Disposable', NULL, '2026-03-10 05:11:58'),
(10, NULL, 'spamgourmet.com', 'Disposable', NULL, '2026-03-10 05:11:58'),
(11, NULL, 'trashmail.me', 'Disposable', NULL, '2026-03-10 05:11:58'),
(12, NULL, 'tempr.email', 'Disposable', NULL, '2026-03-10 05:11:58'),
(13, NULL, 'discard.email', 'Disposable', NULL, '2026-03-10 05:11:58'),
(14, NULL, 'spam4.me', 'Disposable', NULL, '2026-03-10 05:11:58'),
(15, NULL, 'maildrop.cc', 'Disposable', NULL, '2026-03-10 05:11:58'),
(16, NULL, 'mailnesia.com', 'Disposable', NULL, '2026-03-10 05:11:58'),
(17, NULL, '10minutemail.com', 'Disposable', NULL, '2026-03-10 05:11:58'),
(18, NULL, 'getairmail.com', 'Disposable', NULL, '2026-03-10 05:11:58'),
(19, NULL, 'gufum.com', 'Disposable', NULL, '2026-03-10 05:11:58'),
(20, NULL, 'fakeinbox.com', 'Disposable', NULL, '2026-03-10 05:11:58'),
(21, NULL, 'throwam.com', 'Disposable', NULL, '2026-03-10 05:11:58'),
(22, NULL, 'mailinator.com', 'Disposable', NULL, '2026-03-13 04:02:20'),
(23, NULL, 'guerrillamail.com', 'Disposable', NULL, '2026-03-13 04:02:20'),
(24, NULL, 'trashmail.com', 'Disposable', NULL, '2026-03-13 04:02:20'),
(25, NULL, 'temp-mail.org', 'Disposable', NULL, '2026-03-13 04:02:20'),
(26, NULL, 'yopmail.com', 'Disposable', NULL, '2026-03-13 04:02:20'),
(27, NULL, 'sharklasers.com', 'Disposable', NULL, '2026-03-13 04:02:20'),
(28, NULL, 'grr.la', 'Disposable', NULL, '2026-03-13 04:02:20'),
(29, NULL, 'dispostable.com', 'Disposable', NULL, '2026-03-13 04:02:20'),
(30, NULL, 'mailnull.com', 'Disposable', NULL, '2026-03-13 04:02:20'),
(31, NULL, 'spamgourmet.com', 'Disposable', NULL, '2026-03-13 04:02:20'),
(32, NULL, 'trashmail.me', 'Disposable', NULL, '2026-03-13 04:02:20'),
(33, NULL, 'tempr.email', 'Disposable', NULL, '2026-03-13 04:02:20'),
(34, NULL, 'discard.email', 'Disposable', NULL, '2026-03-13 04:02:20'),
(35, NULL, 'spam4.me', 'Disposable', NULL, '2026-03-13 04:02:20'),
(36, NULL, 'maildrop.cc', 'Disposable', NULL, '2026-03-13 04:02:20'),
(37, NULL, 'mailnesia.com', 'Disposable', NULL, '2026-03-13 04:02:20'),
(38, NULL, '10minutemail.com', 'Disposable', NULL, '2026-03-13 04:02:20'),
(39, NULL, 'getairmail.com', 'Disposable', NULL, '2026-03-13 04:02:20'),
(40, NULL, 'gufum.com', 'Disposable', NULL, '2026-03-13 04:02:20'),
(41, NULL, 'fakeinbox.com', 'Disposable', NULL, '2026-03-13 04:02:20'),
(42, NULL, 'throwam.com', 'Disposable', NULL, '2026-03-13 04:02:20');

-- --------------------------------------------------------

--
-- Table structure for table `form_fields`
--

DROP TABLE IF EXISTS `form_fields`;
CREATE TABLE `form_fields` (
  `id` int(10) UNSIGNED NOT NULL,
  `form_id` int(10) UNSIGNED NOT NULL,
  `field_key` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_label` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_type` enum('text','email','phone','number','textarea','select','radio','checkbox','date','time','datetime','file','url','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `placeholder` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `validation` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `sort_order` smallint(5) UNSIGNED DEFAULT '0',
  `is_required` tinyint(1) DEFAULT '0',
  `is_visible` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `form_fields`
--

INSERT INTO `form_fields` (`id`, `form_id`, `field_key`, `field_label`, `field_type`, `placeholder`, `default_value`, `options`, `validation`, `sort_order`, `is_required`, `is_visible`) VALUES
(31, 6, 'name', 'Name', 'text', '', '', '[]', '{\"required\":true}', 0, 1, 1),
(32, 6, 'email', 'Email', 'email', '', '', '[]', '{\"required\":true}', 1, 1, 1),
(33, 6, 'message', 'Message', 'textarea', '', '', '[]', '{\"required\":false}', 2, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `invitations`
--

DROP TABLE IF EXISTS `invitations`;
CREATE TABLE `invitations` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `invited_by` int(10) UNSIGNED NOT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `token` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','accepted','expired','revoked') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `expires_at` datetime NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `invoice_number` varchar(50) NOT NULL,
  `plan_id` int(10) UNSIGNED DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) DEFAULT 'USD',
  `status` enum('pending','paid','failed','refunded') DEFAULT 'pending',
  `billing_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `payment_method_id` int(10) UNSIGNED DEFAULT NULL,
  `notes` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ip_blocklist`
--

DROP TABLE IF EXISTS `ip_blocklist`;
CREATE TABLE `ip_blocklist` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auto_blocked` tinyint(1) DEFAULT '0',
  `hit_count` int(10) UNSIGNED DEFAULT '0',
  `blocked_by` int(10) UNSIGNED DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ip_blocklist`
--

INSERT INTO `ip_blocklist` (`id`, `account_id`, `ip_address`, `reason`, `auto_blocked`, `hit_count`, `blocked_by`, `expires_at`, `created_at`) VALUES
(2, NULL, '192.168.1.1', 'Test', 0, 0, 1, NULL, '2026-03-23 15:24:33');

-- --------------------------------------------------------

--
-- Table structure for table `leads`
--

DROP TABLE IF EXISTS `leads`;
CREATE TABLE `leads` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `form_id` int(10) UNSIGNED NOT NULL,
  `domain_id` int(10) UNSIGNED NOT NULL,
  `assigned_to` int(10) UNSIGNED DEFAULT NULL,
  `reference_no` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('new','contacted','qualified','converted','lost','spam') COLLATE utf8mb4_unicode_ci DEFAULT 'new',
  `score` tinyint(3) UNSIGNED DEFAULT '0',
  `score_category` enum('cold','warm','hot') COLLATE utf8mb4_unicode_ci DEFAULT 'cold',
  `engagement_score` tinyint(3) UNSIGNED DEFAULT '0',
  `engagement_level` enum('cold','warm','hot') COLLATE utf8mb4_unicode_ci DEFAULT 'cold',
  `engagement_at` datetime DEFAULT NULL,
  `ai_score` tinyint(3) UNSIGNED DEFAULT NULL,
  `ai_qualification` enum('unqualified','low','medium','high','hot') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ai_summary` text COLLATE utf8mb4_unicode_ci,
  `ai_next_action` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ai_processed_at` datetime DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `source_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_type` enum('desktop','mobile','tablet','bot','unknown') COLLATE utf8mb4_unicode_ci DEFAULT 'unknown',
  `browser` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isp` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referrer` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `utm_source` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `utm_medium` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `utm_campaign` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_id` int(10) UNSIGNED DEFAULT NULL,
  `campaign_page_id` int(10) UNSIGNED DEFAULT NULL,
  `utm_term` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `utm_content` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `utm_device` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitted_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `first_contacted_at` datetime DEFAULT NULL,
  `last_activity_at` datetime DEFAULT NULL,
  `snoozed_until` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `spam_score` tinyint(3) UNSIGNED DEFAULT '0',
  `is_deleted` tinyint(1) DEFAULT '0',
  `deleted_at` datetime DEFAULT NULL,
  `archived_at` datetime DEFAULT NULL,
  `merged_into_id` int(10) UNSIGNED DEFAULT NULL,
  `has_duplicates` tinyint(1) DEFAULT '0',
  `gdpr_erased_at` datetime DEFAULT NULL,
  `ai_intent` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ai_sentiment` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ai_tags` text COLLATE utf8mb4_unicode_ci,
  `ai_lead_category` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ai_reply_count` tinyint(3) UNSIGNED DEFAULT '0' COMMENT 'How many AI auto-replies have been sent for this lead',
  `ai_paused` tinyint(1) DEFAULT '0' COMMENT '1 = AI paused, awaiting human review'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leads`
--

INSERT INTO `leads` (`id`, `account_id`, `form_id`, `domain_id`, `assigned_to`, `reference_no`, `status`, `score`, `score_category`, `engagement_score`, `engagement_level`, `engagement_at`, `ai_score`, `ai_qualification`, `ai_summary`, `ai_next_action`, `ai_processed_at`, `notes`, `source_url`, `ip_address`, `user_agent`, `device_type`, `browser`, `country`, `city`, `isp`, `referrer`, `utm_source`, `utm_medium`, `utm_campaign`, `campaign_id`, `campaign_page_id`, `utm_term`, `utm_content`, `utm_device`, `submitted_at`, `first_contacted_at`, `last_activity_at`, `snoozed_until`, `updated_at`, `spam_score`, `is_deleted`, `deleted_at`, `archived_at`, `merged_into_id`, `has_duplicates`, `gdpr_erased_at`, `ai_intent`, `ai_sentiment`, `ai_tags`, `ai_lead_category`, `ai_reply_count`, `ai_paused`) VALUES
(8, 2, 6, 7, NULL, 'LD-20260319-00001', 'contacted', 50, 'warm', 6, 'cold', '2026-03-24 10:48:43', NULL, NULL, NULL, NULL, NULL, NULL, 'https://sitecanvas.in/lms_beta/lp/unlock-your-online-potential', '103.84.203.253', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'unknown', NULL, NULL, NULL, NULL, NULL, '', '', '', 11, 10, NULL, NULL, NULL, '2026-03-19 13:32:33', NULL, NULL, NULL, '2026-03-27 13:27:42', 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0),
(9, 2, 6, 7, NULL, 'LD-20260319-00002', 'new', 0, 'cold', 28, 'cold', '2026-03-24 10:48:43', 80, 'high', 'Aditya Singhal is a new lead who is interested in developing a website and has shown urgency in his enquiry. He has provided his contact information and is waiting for a response. His message indicates a positive sentiment and a clear intent to take action.', 'Respond to the lead with a personalized email or phone call to discuss his website development requirements and offer a free trial', '2026-03-19 13:56:54', NULL, 'https://sitecanvas.in/lms_beta/lp/unlock-your-online-potential', '103.84.203.253', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'unknown', NULL, NULL, NULL, NULL, NULL, '', '', '', 11, 10, NULL, NULL, NULL, '2026-03-19 13:51:54', NULL, NULL, NULL, '2026-03-24 10:48:43', 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0),
(10, 2, 6, 7, NULL, 'LD-20260320-00001', 'new', 0, 'cold', 18, 'cold', '2026-03-24 10:48:43', NULL, NULL, NULL, NULL, NULL, NULL, 'https://sitecanvas.in/lms_beta2/lp/unlock-your-online-potential', '122.160.108.18', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'unknown', NULL, NULL, NULL, NULL, NULL, '', '', '', 11, 10, NULL, NULL, NULL, '2026-03-20 05:51:56', NULL, NULL, NULL, '2026-03-24 10:48:43', 0, 0, NULL, NULL, NULL, 0, NULL, 'consultation', 'positive', NULL, 'new_lead', 0, 0),
(11, 2, 6, 7, NULL, 'LD-20260320-00002', 'new', 0, 'cold', 6, 'cold', '2026-03-24 10:48:43', NULL, NULL, NULL, NULL, NULL, NULL, 'https://sitecanvas.in/lms_beta2/lp/unlock-your-online-potential', '122.160.108.18', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'unknown', NULL, NULL, NULL, NULL, NULL, '', '', '', 11, 10, NULL, NULL, NULL, '2026-03-20 06:14:30', NULL, NULL, NULL, '2026-03-24 10:48:43', 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0),
(12, 2, 6, 7, NULL, 'LD-20260320-00003', 'contacted', 50, 'warm', 18, 'cold', '2026-03-24 10:48:43', NULL, NULL, NULL, NULL, NULL, NULL, 'https://sitecanvas.in/lms_beta2/lp/unlock-your-online-potential', '122.160.108.18', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'unknown', NULL, NULL, NULL, NULL, NULL, '', '', '', 11, 10, NULL, NULL, NULL, '2026-03-20 06:19:13', NULL, NULL, NULL, '2026-03-27 13:27:46', 0, 0, NULL, NULL, NULL, 0, NULL, 'general_enquiry', 'neutral', NULL, 'new_lead', 0, 0),
(13, 2, 6, 7, 7, 'LD-20260320-00004', 'new', 50, 'warm', 6, 'cold', '2026-03-24 10:48:43', NULL, NULL, NULL, NULL, NULL, NULL, 'https://sitecanvas.in/lms_beta2/lp/unlock-your-online-potential', '122.160.108.18', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'unknown', NULL, NULL, NULL, NULL, NULL, '', '', '', 11, 10, NULL, NULL, NULL, '2026-03-20 06:50:56', NULL, NULL, NULL, '2026-03-24 10:48:48', 0, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0),
(14, 2, 6, 7, 7, 'LD-20260320-00005', 'converted', 50, 'warm', 60, 'warm', '2026-03-24 10:48:43', 40, 'low', 'Rohan is a new lead from Gurgaon who is looking for some cash, indicating a potential interest in the free trial offer. The lead\'s message is brief and lacks specific details about their business needs. The lead\'s urgency is moderate, given their message.', 'Send a follow-up email to Rohan to gather more information about their business and schedule a consultation to discuss the free trial offer.', '2026-03-20 07:04:15', '', 'https://sitecanvas.in/lms_beta2/lp/unlock-your-online-potential', '122.160.108.18', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', 'unknown', NULL, NULL, NULL, NULL, NULL, '', '', '', 11, 10, NULL, NULL, NULL, '2026-03-20 07:03:28', NULL, NULL, NULL, '2026-03-24 10:48:43', 0, 0, NULL, NULL, NULL, 0, NULL, 'general_enquiry', 'neutral', '[\"urgent\",\"price-sensitive\",\"needs-follow-up\"]', 'new_lead', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `lead_ai_replies`
--

DROP TABLE IF EXISTS `lead_ai_replies`;
CREATE TABLE `lead_ai_replies` (
  `id` int(10) UNSIGNED NOT NULL,
  `lead_id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `generated_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'user_id who triggered generation',
  `reply_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `reply_subject` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Email subject line',
  `tone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'professional',
  `reply_mode` enum('suggest','auto_instant','auto_intent') COLLATE utf8mb4_unicode_ci DEFAULT 'suggest',
  `was_sent` tinyint(1) DEFAULT '0',
  `sent_at` datetime DEFAULT NULL,
  `sent_to_email` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `send_error` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kb_used` tinyint(1) DEFAULT '0' COMMENT 'Was knowledge base used for this reply',
  `lead_intent` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Intent at time of generation',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lead_ai_replies`
--

INSERT INTO `lead_ai_replies` (`id`, `lead_id`, `account_id`, `generated_by`, `reply_text`, `reply_subject`, `tone`, `reply_mode`, `was_sent`, `sent_at`, `sent_to_email`, `send_error`, `kb_used`, `lead_intent`, `created_at`) VALUES
(1, 9, 2, 7, 'Hi Aditya, \nWe\'d love to help you develop a stunning website. Our team offers custom WordPress development, e-commerce solutions, and more. \nLet\'s discuss your project. Book a free consultation today!', 'Get Your Dream Website', 'professional', 'auto_instant', 1, '2026-03-20 05:19:59', 'contactkokler@gmail.com', '', 1, '', '2026-03-20 05:19:57'),
(2, 9, 2, 7, 'Hi Aditya, \nWe offer 20% off our website development services. Our team will work closely with you to create a website that drives revenue. \nReply to this email to get started!', 'Unlock Your Online Potential', 'professional', 'auto_instant', 0, NULL, NULL, NULL, 1, '', '2026-03-20 05:19:57'),
(3, 9, 2, 7, 'Hi Aditya, \nOur website development process starts with a discovery session. We\'ll learn about your business and create a custom plan. \nCall us at 9219222255 to schedule your session today!', 'Let\'s Create Your Website', 'professional', 'auto_instant', 0, NULL, NULL, NULL, 1, '', '2026-03-20 05:19:57'),
(4, 9, 2, 7, 'Hi Aditya, \nWe\'d love to help you with your website development. Our team will work closely with you to create a stunning website. \nBook a free consultation today by replying to this email or calling us at 9219222255.', 'Get Your Dream Website', 'professional', 'auto_intent', 0, NULL, NULL, NULL, 1, '', '2026-03-20 05:48:26'),
(5, 9, 2, 7, 'Hi Aditya, \nWe offer custom website development solutions. With our 20% discount, you can get started at an unbeatable price. \nReply to this email to discuss your project and get a quote.', 'Unlock Your Online Potential', 'professional', 'auto_intent', 0, NULL, NULL, NULL, 1, '', '2026-03-20 05:48:26'),
(6, 9, 2, 7, 'Hi Aditya, \nThanks for considering us for your website development needs. \nLet\'s schedule a call to discuss your project in detail. Please reply with your availability, and we\'ll set up a time that suits you.', 'Let\'s Discuss Your Website', 'professional', 'auto_intent', 0, NULL, NULL, NULL, 1, '', '2026-03-20 05:48:26'),
(7, 9, 2, 7, 'Hi Aditya, \nWe\'d love to help you with your website development. Our team can create a custom website that meets your business needs. \nLet\'s schedule a call to discuss further. \nBest, Sushant', 'Get Your Dream Website', 'professional', 'auto_instant', 1, '2026-03-20 05:49:56', 'contactkokler@gmail.com', '', 1, '', '2026-03-20 05:49:54'),
(8, 9, 2, 7, 'Hi Aditya, \nWe\'re offering 20% off our website development services. Our team can help you create a stunning website. \nReply to this email to avail the offer. \nBest, Sushant', 'Website Development Offer', 'professional', 'auto_instant', 0, NULL, NULL, NULL, 1, '', '2026-03-20 05:49:54'),
(9, 9, 2, 7, 'Hi Aditya, \nThanks for reaching out. We\'d love to help you with your website development. \nPlease click this link to schedule a call: https://calendly.com/your-link. \nLooking forward to speaking with you. \nBest, Sushant', 'Next Steps for Your Website', 'professional', 'auto_instant', 0, NULL, NULL, NULL, 1, '', '2026-03-20 05:49:54'),
(10, 10, 2, 7, 'Hi Aditya, \nWe\'d love to help you with your website design. Our expert team offers custom WordPress development, e-commerce solutions, and more. \nBook a free consultation today!', 'Get Your Dream Website', 'professional', 'auto_intent', 0, NULL, NULL, NULL, 1, '', '2026-03-20 05:52:41'),
(11, 10, 2, 7, 'Hi Aditya, \nOur website development services include mobile-friendly designs, faster load times, and optimized browsing. Get 20% off your first project. \nReply to this email to learn more.', 'Unlock Your Online Potential', 'professional', 'auto_intent', 0, NULL, NULL, NULL, 1, '', '2026-03-20 05:52:41'),
(12, 10, 2, 7, 'Hi Aditya, \nWe\'re excited to help you with your website design needs. Call us at 9219222255 to schedule a meeting and let\'s get started on your project today!', 'Let\'s Discuss Your Website', 'professional', 'auto_intent', 0, NULL, NULL, NULL, 1, '', '2026-03-20 05:52:41'),
(13, 10, 2, 7, 'Hi Aditya, \nWe\'d love to help you with website design. Our team offers custom WordPress development and e-commerce solutions. \nBook a free consultation today!', 'Get Your Dream Website', 'professional', 'auto_intent', 1, '2026-03-20 06:13:46', 'contactaadi@gmail.com', '', 1, '', '2026-03-20 06:13:44'),
(14, 10, 2, 7, 'Hi Aditya, \nOur website development services include mobile-friendly designs and responsive layouts. Let\'s discuss your project. \nReply to this email or call us at 9219222255', 'Unlock Your Online Potential', 'professional', 'auto_intent', 0, NULL, NULL, NULL, 1, '', '2026-03-20 06:13:44'),
(15, 10, 2, 7, 'Hi Aditya, \nWe\'re offering 20% off our website development services. \nContact us at contact@ebrandist.com to learn more and redeem your discount', 'Limited Time Offer: 20% Off', 'professional', 'auto_intent', 0, NULL, NULL, NULL, 1, '', '2026-03-20 06:13:44'),
(16, 12, 2, 7, 'Hi Sharad, \nThanks for your interest in growing your online presence. We\'d love to discuss how our website development services can help. \nBook a consultation today!', 'Unlock Your Online Potential', 'professional', 'auto_intent', 0, NULL, NULL, NULL, 1, '', '2026-03-20 06:19:43'),
(17, 12, 2, 7, 'Hi Sharad, \nExcited to help you unlock your online potential. Start your free trial now and let\'s discuss how our services can boost your business. \nReply to this email to get started!', 'Get Started with a Free Trial', 'professional', 'auto_intent', 0, NULL, NULL, NULL, 1, '', '2026-03-20 06:19:43'),
(18, 12, 2, 7, 'Hi Sharad, \nWe\'d love to learn more about your business and create a customized website solution. \nSchedule a call with us to discuss your project and get a quote.', 'Discover Your Website Solution', 'professional', 'auto_intent', 0, NULL, NULL, NULL, 1, '', '2026-03-20 06:19:43'),
(19, 12, 2, 7, 'Hi Sharad, \nThanks for your interest in Grow Online. We\'d love to discuss how our website development services can help your business thrive. \nLet\'s schedule a call to explore further.', 'Unlock Your Online Potential', 'professional', 'auto_instant', 1, '2026-03-20 06:19:49', 'qwkqivfctjgrqfnnii@nespj.com', '', 1, 'general_enquiry', '2026-03-20 06:19:48'),
(20, 12, 2, 7, 'Hi Sharad, \nWe\'re excited to learn more about your business and create a tailored website solution. Please reply with a convenient time for a consultation, and we\'ll be in touch.', 'Discover Your Website Solutions', 'professional', 'auto_instant', 0, NULL, NULL, NULL, 1, 'general_enquiry', '2026-03-20 06:19:48'),
(21, 12, 2, 7, 'Hi Sharad, \nReady to unlock your online potential? Start your free trial today and experience our website development services. Reply to this email or call us at 9219222255 to get started.', 'Get Started with a Free Trial', 'professional', 'auto_instant', 0, NULL, NULL, NULL, 1, 'general_enquiry', '2026-03-20 06:19:48');

-- --------------------------------------------------------

--
-- Table structure for table `lead_ai_results`
--

DROP TABLE IF EXISTS `lead_ai_results`;
CREATE TABLE `lead_ai_results` (
  `id` int(10) UNSIGNED NOT NULL,
  `lead_id` int(10) UNSIGNED NOT NULL,
  `score` tinyint(3) UNSIGNED DEFAULT NULL,
  `qualification` enum('unqualified','low','medium','high','hot') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `summary` text COLLATE utf8mb4_unicode_ci,
  `next_action` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_draft` text COLLATE utf8mb4_unicode_ci,
  `conversion_pct` tinyint(3) UNSIGNED DEFAULT NULL,
  `reasoning` text COLLATE utf8mb4_unicode_ci,
  `model_used` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tokens_used` int(10) UNSIGNED DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `intent` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sentiment` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` text COLLATE utf8mb4_unicode_ci,
  `lead_category` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lead_ai_results`
--

INSERT INTO `lead_ai_results` (`id`, `lead_id`, `score`, `qualification`, `summary`, `next_action`, `email_draft`, `conversion_pct`, `reasoning`, `model_used`, `tokens_used`, `created_at`, `updated_at`, `intent`, `sentiment`, `tags`, `lead_category`) VALUES
(5, 9, 80, 'high', 'Aditya Singhal is a new lead who is interested in developing a website and has shown urgency in his enquiry. He has provided his contact information and is waiting for a response. His message indicates a positive sentiment and a clear intent to take action.', 'Respond to the lead with a personalized email or phone call to discuss his website development requirements and offer a free trial', 'Subject: Next Steps for Your Website Development\n\nHi Aditya,\n\nThank you for considering us for your website development needs. We\'d love to discuss your project further. Can we schedule a call to explore your requirements and provide a customized solution?\n\nLooking forward to hearing from you.\nBest regards,', 70, 'The lead has shown a clear intent to develop a website and has provided his contact information, indicating a high level of interest and urgency. The lead\'s message is brief and to the point, suggesting that he is looking for a quick response and is likely to convert if his needs are met.', 'llama-3.3-70b-versatile', 649, '2026-03-19 13:56:54', '2026-03-19 13:58:01', NULL, NULL, NULL, NULL),
(6, 14, 40, 'low', 'Rohan is a new lead from Gurgaon who is looking for some cash, indicating a potential interest in the free trial offer. The lead\'s message is brief and lacks specific details about their business needs. The lead\'s urgency is moderate, given their message.', 'Send a follow-up email to Rohan to gather more information about their business and schedule a consultation to discuss the free trial offer.', NULL, 20, 'The lead\'s score is low due to the lack of specific details about their business needs and the brief nature of their message. The lead\'s intent is categorized as a general enquiry, and their sentiment is neutral, indicating a moderate level of interest in the offer.', 'llama-3.3-70b-versatile', 660, '2026-03-20 07:04:15', '2026-03-20 07:04:15', 'general_enquiry', 'neutral', '[\"urgent\",\"price-sensitive\",\"needs-follow-up\"]', 'new_lead');

-- --------------------------------------------------------

--
-- Table structure for table `lead_comments`
--

DROP TABLE IF EXISTS `lead_comments`;
CREATE TABLE `lead_comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `lead_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `comment_type` enum('comment','email_sent','email_received','system') COLLATE utf8mb4_unicode_ci DEFAULT 'comment',
  `email_subject` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_to` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_from` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lead_comments`
--

INSERT INTO `lead_comments` (`id`, `lead_id`, `user_id`, `comment`, `created_at`, `comment_type`, `email_subject`, `email_to`, `email_from`) VALUES
(2, 9, 7, 'AI Enrichment:\nIndustry: Technology/Software\nJob title: Founder/Entrepreneur\nNotes: The lead is interested in website development, and the source URL suggests they are looking for online solutions. The email address \'contactkokler@gmail.com\' may not be a personal email, potentially indicating a business inquiry.', '2026-03-19 13:57:32', 'comment', NULL, NULL, NULL),
(3, 9, 7, '✉ Auto-reply sent to contactkokler@gmail.com\nSubject: Get Your Dream Website', '2026-03-20 05:19:59', 'comment', NULL, NULL, NULL),
(4, 9, 7, '✉ Auto-reply sent to contactkokler@gmail.com\nSubject: Get Your Dream Website', '2026-03-20 05:49:56', 'comment', NULL, NULL, NULL),
(5, 10, 7, '✉ Auto-reply sent to contactaadi@gmail.com\nSubject: Get Your Dream Website', '2026-03-20 06:13:46', 'comment', NULL, NULL, NULL),
(6, 12, 7, '✉ Auto-reply sent to qwkqivfctjgrqfnnii@nespj.com\nSubject: Unlock Your Online Potential', '2026-03-20 06:19:49', 'comment', NULL, NULL, NULL),
(7, 12, 7, '✉ Email sent to qwkqivfctjgrqfnnii@nespj.com\nSubject: Get Started with a Free Trial', '2026-03-20 06:19:56', 'comment', NULL, NULL, NULL),
(8, 14, 7, 'AI Enrichment:\nNotes: Lead appears to be a potential customer seeking financial assistance, with a vague message. The email address seems to be a temporary or disposable one, which may indicate a lower quality lead. The source URL suggests the lead is interested in online business or marketing solutions.', '2026-03-20 07:04:37', 'comment', NULL, NULL, NULL),
(9, 14, 7, '🔄 Ownership transferred: Unassigned → Sushant Gupta', '2026-03-23 17:47:14', 'comment', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `lead_duplicates`
--

DROP TABLE IF EXISTS `lead_duplicates`;
CREATE TABLE `lead_duplicates` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `lead_id_a` int(10) UNSIGNED NOT NULL,
  `lead_id_b` int(10) UNSIGNED NOT NULL,
  `match_type` enum('email','phone','name_phone') COLLATE utf8mb4_unicode_ci NOT NULL,
  `match_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detected_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `resolved` tinyint(1) DEFAULT '0',
  `resolved_at` datetime DEFAULT NULL,
  `resolved_by` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_emails_sent`
--

DROP TABLE IF EXISTS `lead_emails_sent`;
CREATE TABLE `lead_emails_sent` (
  `id` int(10) UNSIGNED NOT NULL,
  `lead_id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `sent_by` int(10) UNSIGNED DEFAULT NULL,
  `to_email` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'manual' COMMENT 'manual|smart_reply|auto_reply|follow_up',
  `ai_reply_id` int(10) UNSIGNED DEFAULT NULL,
  `status` enum('sent','failed') COLLATE utf8mb4_unicode_ci DEFAULT 'sent',
  `error` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sent_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `from_email` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'The FROM address used when sending',
  `reply_to` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Reply-To header set on the email'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lead_emails_sent`
--

INSERT INTO `lead_emails_sent` (`id`, `lead_id`, `account_id`, `sent_by`, `to_email`, `subject`, `body`, `source`, `ai_reply_id`, `status`, `error`, `sent_at`, `from_email`, `reply_to`) VALUES
(1, 9, 2, 7, 'contactkokler@gmail.com', 'Get Your Dream Website', 'Hi Aditya, \nWe\'d love to help you develop a stunning website. Our team offers custom WordPress development, e-commerce solutions, and more. \nLet\'s discuss your project. Book a free consultation today!', 'smart_reply', 1, 'sent', '', '2026-03-20 05:19:59', NULL, NULL),
(2, 9, 2, 7, 'contactkokler@gmail.com', 'Get Your Dream Website', 'Hi Aditya, \nWe\'d love to help you with your website development. Our team can create a custom website that meets your business needs. \nLet\'s schedule a call to discuss further. \nBest, Sushant', 'smart_reply', 7, 'sent', '', '2026-03-20 05:49:56', NULL, NULL),
(3, 10, 2, 7, 'contactaadi@gmail.com', 'Get Your Dream Website', 'Hi Aditya, \nWe\'d love to help you with website design. Our team offers custom WordPress development and e-commerce solutions. \nBook a free consultation today!', 'smart_reply', 13, 'sent', '', '2026-03-20 06:13:46', NULL, NULL),
(4, 12, 2, 7, 'qwkqivfctjgrqfnnii@nespj.com', 'Unlock Your Online Potential', 'Hi Sharad, \nThanks for your interest in Grow Online. We\'d love to discuss how our website development services can help your business thrive. \nLet\'s schedule a call to explore further.', 'smart_reply', 19, 'sent', '', '2026-03-20 06:19:49', NULL, NULL),
(5, 12, 2, 7, 'qwkqivfctjgrqfnnii@nespj.com', 'Get Started with a Free Trial', 'Hi Sharad, \r\nReady to unlock your online potential? Start your free trial today and experience our website development services. Reply to this email or call us at 9219222255 to get started.', 'smart_reply', 0, 'sent', '', '2026-03-20 06:19:56', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `lead_forms`
--

DROP TABLE IF EXISTS `lead_forms`;
CREATE TABLE `lead_forms` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `domain_id` int(10) UNSIGNED NOT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `form_token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `is_active` tinyint(1) DEFAULT '1',
  `submission_count` int(10) UNSIGNED DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ai_auto_limit` tinyint(4) DEFAULT '3' COMMENT '0=off, 1-10=max replies, -1=unlimited'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lead_forms`
--

INSERT INTO `lead_forms` (`id`, `account_id`, `domain_id`, `created_by`, `name`, `slug`, `description`, `form_token`, `settings`, `is_active`, `submission_count`, `created_at`, `updated_at`, `ai_auto_limit`) VALUES
(6, 2, 7, 7, 'Test Form', 'test-form', '', '0abfef0356152347e26e8993a85fb9d73383ce436baae1fa01edb6a9aefe2071', '{\"redirect_url\":\"\",\"success_msg\":\"Thank you! We will be in touch soon.\",\"notify_email\":\"contactaadi@gmail.com\"}', 1, 7, '2026-03-19 13:31:05', '2026-03-20 07:03:28', 3);

-- --------------------------------------------------------

--
-- Table structure for table `lead_form_email_templates`
--

DROP TABLE IF EXISTS `lead_form_email_templates`;
CREATE TABLE `lead_form_email_templates` (
  `id` int(10) UNSIGNED NOT NULL,
  `form_id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `type` enum('auto_reply','notify','follow_up_1','follow_up_2','follow_up_3') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'auto_reply=sent to lead on submit, notify=sent to staff, follow_up_N=automated sequences',
  `is_active` tinyint(1) DEFAULT '1',
  `subject` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Supports {{name}} {{email}} {{phone}} {{message}} {{form_name}} {{campaign_name}} {{booking_url}} {{lead_ref}} {{submitted_date}} {{service}}',
  `delay_hours` smallint(5) UNSIGNED DEFAULT '0' COMMENT 'For follow_up templates: hours after submission to send (0=immediate)',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lead_form_email_templates`
--

INSERT INTO `lead_form_email_templates` (`id`, `form_id`, `account_id`, `type`, `is_active`, `subject`, `body`, `delay_hours`, `created_at`, `updated_at`) VALUES
(1, 6, 2, 'auto_reply', 1, 'Thanks for reaching out, {{name}}!', 'Hi {{name}},\r\n\r\nThank you for getting in touch with us via {{form_name}}.\r\n\r\nWe\'ve received your enquiry and a member of our team will be in touch with you shortly.\r\n\r\n{{booking_url}}\r\n\r\nBest regards,\r\n{{app_name}}', 0, '2026-03-20 05:50:45', '2026-03-20 06:50:30'),
(2, 6, 2, 'notify', 1, '[New Lead] {{lead_ref}} — {{form_name}}', 'New lead submitted via {{form_name}}.\r\n\r\nName: {{name}}\r\nEmail: {{email}}\r\nPhone: {{phone}}\r\nMessage: {{message}}\r\n\r\nSubmitted: {{submitted_date}}\r\nRef: {{lead_ref}}', 0, '2026-03-20 05:50:45', '2026-03-20 06:50:30'),
(3, 6, 2, 'follow_up_1', 1, 'Following up on your enquiry, {{name}}', 'Hi {{name}},\r\n\r\nI wanted to follow up on your recent enquiry about {{service}}.\r\n\r\nWe\'d love to help you — would you be free for a quick call?\r\n\r\n{{booking_url}}\r\n\r\nBest regards,\r\n{{app_name}}', 24, '2026-03-20 05:50:45', '2026-03-20 06:50:30'),
(4, 6, 2, 'follow_up_2', 1, 'Still interested, {{name}}?', 'Hi {{name}},\r\n\r\nJust checking in — we haven\'t heard back from you yet.\r\n\r\nIf you\'re still interested in {{service}}, we\'d be happy to answer any questions.\r\n\r\n{{booking_url}}\r\n\r\nBest regards,\r\n{{app_name}}', 72, '2026-03-20 05:50:45', '2026-03-20 06:50:30'),
(5, 6, 2, 'follow_up_3', 1, 'Last chance to connect, {{name}}', 'Hi {{name}},\r\n\r\nThis is our final follow-up regarding your enquiry.\r\n\r\nIf now isn\'t the right time, no problem at all — feel free to reach back out whenever you\'re ready.\r\n\r\n{{booking_url}}\r\n\r\nBest wishes,\r\n{{app_name}}', 168, '2026-03-20 05:50:45', '2026-03-20 06:50:30');

-- --------------------------------------------------------

--
-- Table structure for table `lead_imports`
--

DROP TABLE IF EXISTS `lead_imports`;
CREATE TABLE `lead_imports` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `form_id` int(10) UNSIGNED NOT NULL,
  `imported_by` int(10) UNSIGNED NOT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_rows` int(10) UNSIGNED DEFAULT '0',
  `imported` int(10) UNSIGNED DEFAULT '0',
  `skipped` int(10) UNSIGNED DEFAULT '0',
  `merged` int(10) UNSIGNED DEFAULT '0',
  `failed` int(10) UNSIGNED DEFAULT '0',
  `status` enum('pending','processing','done','failed') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `mapping` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `errors` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `started_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `finished_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lead_merge_log`
--

DROP TABLE IF EXISTS `lead_merge_log`;
CREATE TABLE `lead_merge_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `primary_id` int(10) UNSIGNED NOT NULL,
  `merged_id` int(10) UNSIGNED NOT NULL,
  `merged_by` int(10) UNSIGNED DEFAULT NULL,
  `merged_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lead_merge_log`
--

INSERT INTO `lead_merge_log` (`id`, `primary_id`, `merged_id`, `merged_by`, `merged_at`) VALUES
(1, 5, 4, 7, '2026-03-12 09:45:09');

-- --------------------------------------------------------

--
-- Table structure for table `lead_ownership_log`
--

DROP TABLE IF EXISTS `lead_ownership_log`;
CREATE TABLE `lead_ownership_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `lead_id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `from_user_id` int(10) UNSIGNED DEFAULT NULL,
  `to_user_id` int(10) UNSIGNED DEFAULT NULL,
  `transferred_by` int(10) UNSIGNED NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `transferred_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lead_ownership_log`
--

INSERT INTO `lead_ownership_log` (`id`, `lead_id`, `account_id`, `from_user_id`, `to_user_id`, `transferred_by`, `reason`, `transferred_at`) VALUES
(1, 14, 2, NULL, 7, 7, '', '2026-03-23 17:47:14'),
(2, 13, 2, NULL, 7, 7, 'Quick assign', '2026-03-24 10:48:48');

-- --------------------------------------------------------

--
-- Table structure for table `lead_reminders`
--

DROP TABLE IF EXISTS `lead_reminders`;
CREATE TABLE `lead_reminders` (
  `id` int(10) UNSIGNED NOT NULL,
  `lead_id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `type` enum('manual','no_contact','overdue','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'manual',
  `message` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remind_at` datetime NOT NULL,
  `is_done` tinyint(1) DEFAULT '0',
  `done_at` datetime DEFAULT NULL,
  `notified` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `snoozed_until` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lead_reminders`
--

INSERT INTO `lead_reminders` (`id`, `lead_id`, `account_id`, `user_id`, `created_by`, `type`, `message`, `remind_at`, `is_done`, `done_at`, `notified`, `created_at`, `snoozed_until`) VALUES
(1, 6, 2, 7, 0, 'no_contact', 'Lead has not been contacted for 24 hours.', '2026-03-13 12:49:41', 1, '2026-03-15 14:12:17', 0, '2026-03-14 02:53:03', NULL),
(2, 6, 2, 8, 0, 'no_contact', 'Lead has not been contacted for 24 hours.', '2026-03-13 12:49:41', 0, NULL, 0, '2026-03-14 02:53:03', NULL),
(3, 6, 2, 7, 0, 'no_contact', 'Lead has not been contacted for 24 hours.', '2026-03-13 12:49:41', 0, NULL, 0, '2026-03-15 14:19:36', NULL),
(4, 5, 2, 8, 0, 'inactive', 'Lead has been inactive for 7 days — needs attention.', '2026-03-19 11:35:50', 0, NULL, 0, '2026-03-19 17:05:50', NULL),
(5, 14, 2, 7, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-20 08:03:28', 0, NULL, 0, '2026-03-21 07:30:49', NULL),
(6, 14, 2, 8, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-20 08:03:28', 0, NULL, 0, '2026-03-21 07:30:49', NULL),
(7, 13, 2, 7, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-20 07:50:56', 0, NULL, 0, '2026-03-21 07:30:49', NULL),
(8, 13, 2, 8, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-20 07:50:56', 0, NULL, 0, '2026-03-21 07:30:49', NULL),
(9, 12, 2, 7, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-20 07:19:13', 0, NULL, 0, '2026-03-21 07:30:49', NULL),
(10, 12, 2, 8, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-20 07:19:13', 0, NULL, 0, '2026-03-21 07:30:49', NULL),
(11, 11, 2, 7, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-20 07:14:30', 0, NULL, 0, '2026-03-21 07:30:49', NULL),
(12, 11, 2, 8, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-20 07:14:30', 0, NULL, 0, '2026-03-21 07:30:49', NULL),
(13, 10, 2, 7, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-20 06:51:56', 0, NULL, 0, '2026-03-21 07:30:49', NULL),
(14, 10, 2, 8, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-20 06:51:56', 0, NULL, 0, '2026-03-21 07:30:49', NULL),
(15, 9, 2, 7, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-19 14:51:54', 0, NULL, 0, '2026-03-21 07:30:49', NULL),
(16, 9, 2, 8, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-19 14:51:54', 0, NULL, 0, '2026-03-21 07:30:49', NULL),
(17, 8, 2, 7, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-19 14:32:33', 0, NULL, 0, '2026-03-21 07:30:49', NULL),
(18, 8, 2, 7, 0, 'inactive', 'Lead has been inactive for 2 days — needs attention.', '2026-03-21 02:00:49', 0, NULL, 0, '2026-03-21 07:30:49', NULL),
(19, 8, 2, 8, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-19 14:32:33', 0, NULL, 0, '2026-03-21 07:30:49', NULL),
(20, 8, 2, 8, 0, 'inactive', 'Lead has been inactive for 2 days — needs attention.', '2026-03-21 02:00:49', 0, NULL, 0, '2026-03-21 07:30:49', NULL),
(21, 10, 2, 7, 0, 'inactive', 'Lead has been inactive for 1 days — needs attention.', '2026-03-21 06:14:12', 0, NULL, 0, '2026-03-21 11:44:12', NULL),
(22, 10, 2, 8, 0, 'inactive', 'Lead has been inactive for 1 days — needs attention.', '2026-03-21 06:14:12', 0, NULL, 0, '2026-03-21 11:44:12', NULL),
(23, 9, 2, 7, 0, 'inactive', 'Lead has been inactive for 1 days — needs attention.', '2026-03-21 06:14:12', 0, NULL, 0, '2026-03-21 11:44:12', NULL),
(24, 9, 2, 8, 0, 'inactive', 'Lead has been inactive for 1 days — needs attention.', '2026-03-21 06:14:12', 0, NULL, 0, '2026-03-21 11:44:12', NULL),
(25, 14, 2, 7, 0, 'inactive', 'Lead has been inactive for 1 days — needs attention.', '2026-03-21 12:06:11', 0, NULL, 0, '2026-03-21 17:36:11', NULL),
(26, 14, 2, 8, 0, 'inactive', 'Lead has been inactive for 1 days — needs attention.', '2026-03-21 12:06:11', 0, NULL, 0, '2026-03-21 17:36:11', NULL),
(27, 13, 2, 7, 0, 'inactive', 'Lead has been inactive for 1 days — needs attention.', '2026-03-21 12:06:11', 0, NULL, 0, '2026-03-21 17:36:11', NULL),
(28, 13, 2, 8, 0, 'inactive', 'Lead has been inactive for 1 days — needs attention.', '2026-03-21 12:06:11', 0, NULL, 0, '2026-03-21 17:36:11', NULL),
(29, 12, 2, 7, 0, 'inactive', 'Lead has been inactive for 1 days — needs attention.', '2026-03-21 12:06:11', 0, NULL, 0, '2026-03-21 17:36:11', NULL),
(30, 12, 2, 8, 0, 'inactive', 'Lead has been inactive for 1 days — needs attention.', '2026-03-21 12:06:11', 0, NULL, 0, '2026-03-21 17:36:11', NULL),
(31, 11, 2, 7, 0, 'inactive', 'Lead has been inactive for 1 days — needs attention.', '2026-03-21 12:06:11', 0, NULL, 0, '2026-03-21 17:36:11', NULL),
(32, 11, 2, 8, 0, 'inactive', 'Lead has been inactive for 1 days — needs attention.', '2026-03-21 12:06:11', 0, NULL, 0, '2026-03-21 17:36:11', NULL),
(33, 14, 2, 10, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-20 08:03:28', 0, NULL, 0, '2026-03-23 16:18:18', NULL),
(34, 14, 2, 10, 0, 'inactive', 'Lead has been inactive for 3 days — needs attention.', '2026-03-23 10:48:18', 0, NULL, 0, '2026-03-23 16:18:18', NULL),
(35, 13, 2, 10, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-20 07:50:56', 0, NULL, 0, '2026-03-23 16:18:18', NULL),
(36, 13, 2, 10, 0, 'inactive', 'Lead has been inactive for 3 days — needs attention.', '2026-03-23 10:48:18', 0, NULL, 0, '2026-03-23 16:18:18', NULL),
(37, 12, 2, 10, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-20 07:19:13', 0, NULL, 0, '2026-03-23 16:18:18', NULL),
(38, 12, 2, 10, 0, 'inactive', 'Lead has been inactive for 3 days — needs attention.', '2026-03-23 10:48:18', 0, NULL, 0, '2026-03-23 16:18:18', NULL),
(39, 11, 2, 10, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-20 07:14:30', 0, NULL, 0, '2026-03-23 16:18:18', NULL),
(40, 11, 2, 10, 0, 'inactive', 'Lead has been inactive for 3 days — needs attention.', '2026-03-23 10:48:18', 0, NULL, 0, '2026-03-23 16:18:18', NULL),
(41, 10, 2, 10, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-20 06:51:56', 0, NULL, 0, '2026-03-23 16:18:18', NULL),
(42, 10, 2, 10, 0, 'inactive', 'Lead has been inactive for 3 days — needs attention.', '2026-03-23 10:48:18', 0, NULL, 0, '2026-03-23 16:18:18', NULL),
(43, 9, 2, 10, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-19 14:51:54', 0, NULL, 0, '2026-03-23 16:18:18', NULL),
(44, 9, 2, 10, 0, 'inactive', 'Lead has been inactive for 3 days — needs attention.', '2026-03-23 10:48:18', 0, NULL, 0, '2026-03-23 16:18:18', NULL),
(45, 8, 2, 10, 0, 'no_contact', 'Lead has not been contacted for 1 hours.', '2026-03-19 14:32:33', 0, NULL, 0, '2026-03-23 16:18:18', NULL),
(46, 8, 2, 10, 0, 'inactive', 'Lead has been inactive for 4 days — needs attention.', '2026-03-23 10:48:18', 0, NULL, 0, '2026-03-23 16:18:18', NULL),
(47, 12, 2, 7, 0, 'overdue', 'Follow-up overdue — last activity 170 hours ago.', '2026-03-27 08:27:10', 0, NULL, 0, '2026-03-27 13:57:10', NULL),
(48, 8, 2, 7, 0, 'overdue', 'Follow-up overdue — last activity 187 hours ago.', '2026-03-27 08:27:10', 0, NULL, 0, '2026-03-27 13:57:10', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `lead_score_rules`
--

DROP TABLE IF EXISTS `lead_score_rules`;
CREATE TABLE `lead_score_rules` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operator` enum('equals','contains','not_equals','not_contains','greater_than','less_than','is_business_email','is_free_email','in_list','not_in_list') COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `score` smallint(6) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `sort_order` smallint(6) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lead_score_rules`
--

INSERT INTO `lead_score_rules` (`id`, `account_id`, `name`, `field`, `operator`, `value`, `score`, `is_active`, `sort_order`, `created_at`) VALUES
(1, NULL, 'Business Email', 'email', 'is_business_email', NULL, 25, 1, 1, '2026-03-10 06:32:36'),
(2, NULL, 'Free Email', 'email', 'is_free_email', NULL, -10, 1, 2, '2026-03-10 06:32:36'),
(3, NULL, 'Has Phone Number', 'phone', 'not_equals', '', 15, 1, 3, '2026-03-10 06:32:36'),
(4, NULL, 'Has Company Name', 'company', 'not_equals', '', 10, 1, 4, '2026-03-10 06:32:36'),
(5, NULL, 'Long Message (>50)', 'message_length', 'greater_than', '50', 20, 1, 5, '2026-03-10 06:32:36'),
(6, NULL, 'Short Message (<10)', 'message_length', 'less_than', '10', -15, 1, 6, '2026-03-10 06:32:36'),
(7, NULL, 'Organic Traffic', 'utm_medium', 'equals', 'organic', 10, 1, 7, '2026-03-10 06:32:36'),
(8, NULL, 'Paid Traffic', 'utm_medium', 'equals', 'cpc', 15, 1, 8, '2026-03-10 06:32:36'),
(9, NULL, 'Direct Traffic', 'utm_source', 'equals', 'direct', 5, 1, 9, '2026-03-10 06:32:36'),
(10, NULL, 'Business Email', 'email', 'is_business_email', NULL, 25, 1, 1, '2026-03-13 04:03:01'),
(11, NULL, 'Free Email', 'email', 'is_free_email', NULL, -10, 1, 2, '2026-03-13 04:03:01'),
(12, NULL, 'Has Phone Number', 'phone', 'not_equals', '', 15, 1, 3, '2026-03-13 04:03:01'),
(13, NULL, 'Has Company Name', 'company', 'not_equals', '', 10, 1, 4, '2026-03-13 04:03:01'),
(14, NULL, 'Long Message (>50)', 'message_length', 'greater_than', '50', 20, 1, 5, '2026-03-13 04:03:01'),
(15, NULL, 'Short Message (<10)', 'message_length', 'less_than', '10', -15, 1, 6, '2026-03-13 04:03:01'),
(16, NULL, 'Organic Traffic', 'utm_medium', 'equals', 'organic', 10, 1, 7, '2026-03-13 04:03:01'),
(17, NULL, 'Paid Traffic', 'utm_medium', 'equals', 'cpc', 15, 1, 8, '2026-03-13 04:03:01'),
(18, NULL, 'Direct Traffic', 'utm_source', 'equals', 'direct', 5, 1, 9, '2026-03-13 04:03:01');

-- --------------------------------------------------------

--
-- Table structure for table `lead_values`
--

DROP TABLE IF EXISTS `lead_values`;
CREATE TABLE `lead_values` (
  `id` int(10) UNSIGNED NOT NULL,
  `lead_id` int(10) UNSIGNED NOT NULL,
  `field_id` int(10) UNSIGNED DEFAULT NULL,
  `field_key` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_label` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lead_values`
--

INSERT INTO `lead_values` (`id`, `lead_id`, `field_id`, `field_key`, `field_label`, `value`) VALUES
(18, 8, NULL, 'name', 'Name', 'test'),
(19, 8, NULL, 'email', 'Email', 'test@test.com'),
(20, 8, NULL, 'message', 'Message', 'sajkda asdyas da dsag ash'),
(21, 9, NULL, 'name', 'Name', 'aditya singhal'),
(22, 9, NULL, 'email', 'Email', 'contactkokler@gmail.com'),
(23, 9, NULL, 'message', 'Message', 'i need a website developed'),
(24, 10, NULL, 'name', 'Name', 'aditya'),
(25, 10, NULL, 'email', 'Email', 'contactaadi@gmail.com'),
(26, 10, NULL, 'message', 'Message', 'i need website design'),
(27, 11, NULL, 'name', 'Name', 'rahul'),
(28, 11, NULL, 'email', 'Email', 'contactaadi@gmail.com'),
(29, 11, NULL, 'message', 'Message', 'i need a website'),
(30, 12, NULL, 'name', 'Name', 'sharad'),
(31, 12, NULL, 'email', 'Email', 'qwkqivfctjgrqfnnii@nespj.com'),
(32, 12, NULL, 'message', 'Message', 'asdiu asdj asdhw dsf'),
(33, 13, 31, 'name', 'Name', 'umesh'),
(34, 13, 32, 'email', 'Email', 'qwkqivfctjgrqfnnii@nespj.com'),
(35, 13, 33, 'message', 'Message', 'i need a website'),
(36, 14, 31, 'name', 'Name', 'rohan'),
(37, 14, 32, 'email', 'Email', 'hawjtlvkycvrjaygwa@nespj.com'),
(38, 14, 33, 'message', 'Message', 'i need some cash');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED DEFAULT NULL,
  `type` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'bell',
  `color` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'blue',
  `is_read` tinyint(1) DEFAULT '0',
  `is_archived` tinyint(1) DEFAULT '0',
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `account_id`, `type`, `title`, `body`, `url`, `icon`, `color`, `is_read`, `is_archived`, `meta`, `created_at`) VALUES
(1, 7, 2, 'lead.new', 'New lead from landing page: Test', 'Ref LD-20260318-00001', '/lead_view.php?id=7', 'lead', 'blue', 0, 0, '{\"lead_id\":7,\"campaign_id\":1}', '2026-03-18 17:15:12'),
(2, 7, 2, 'lead.new', 'New lead from landing page: Unlock Your Online Potential', 'Ref LD-20260319-00001', '/lead_view.php?id=8', 'lead', 'blue', 0, 0, '{\"lead_id\":8,\"campaign_id\":11}', '2026-03-19 13:32:33'),
(3, 7, 2, 'lead.new', 'New lead from landing page: Unlock Your Online Potential', 'Ref LD-20260319-00002', '/lead_view.php?id=9', 'lead', 'blue', 0, 0, '{\"lead_id\":9,\"campaign_id\":11}', '2026-03-19 13:51:54'),
(4, 7, 2, 'lead.new', 'New lead from landing page: Unlock Your Online Potential', 'Ref LD-20260320-00001', '/lead_view.php?id=10', 'lead', 'blue', 0, 0, '{\"lead_id\":10,\"campaign_id\":11}', '2026-03-20 05:51:56'),
(5, 7, 2, 'lead.new', 'New lead from landing page: Unlock Your Online Potential', 'Ref LD-20260320-00002', '/lead_view.php?id=11', 'lead', 'blue', 0, 0, '{\"lead_id\":11,\"campaign_id\":11}', '2026-03-20 06:14:30'),
(6, 7, 2, 'lead.new', 'New lead from landing page: Unlock Your Online Potential', 'Ref LD-20260320-00003', '/lead_view.php?id=12', 'lead', 'blue', 0, 0, '{\"lead_id\":12,\"campaign_id\":11}', '2026-03-20 06:19:13'),
(7, 7, 2, 'lead.new', 'New lead from landing page: Unlock Your Online Potential', 'Ref LD-20260320-00004', '/lead_view.php?id=13', 'lead', 'blue', 0, 0, '{\"lead_id\":13,\"campaign_id\":11}', '2026-03-20 06:50:56'),
(8, 7, 2, 'lead.new', 'New lead from landing page: Unlock Your Online Potential', 'Ref LD-20260320-00005', '/lead_view.php?id=14', 'lead', 'blue', 0, 0, '{\"lead_id\":14,\"campaign_id\":11}', '2026-03-20 07:03:28'),
(9, 7, 2, 'lead.assigned', 'Lead assigned to you', 'Lead LD-20260320-00005 was transferred to you by Sushant Gupta', '/lead_view.php?id=14', 'user', 'purple', 0, 0, '{\"lead_id\":14}', '2026-03-23 17:47:14');

-- --------------------------------------------------------

--
-- Table structure for table `notification_prefs`
--

DROP TABLE IF EXISTS `notification_prefs`;
CREATE TABLE `notification_prefs` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `pref_lead_new` tinyint(1) DEFAULT '1',
  `pref_lead_assigned` tinyint(1) DEFAULT '1',
  `pref_lead_comment` tinyint(1) DEFAULT '1',
  `pref_lead_status` tinyint(1) DEFAULT '1',
  `pref_team_invite` tinyint(1) DEFAULT '1',
  `pref_system` tinyint(1) DEFAULT '1',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notification_prefs`
--

INSERT INTO `notification_prefs` (`id`, `user_id`, `pref_lead_new`, `pref_lead_assigned`, `pref_lead_comment`, `pref_lead_status`, `pref_team_invite`, `pref_system`, `updated_at`) VALUES
(1, 1, 1, 1, 1, 1, 1, 1, '2026-03-13 04:01:52'),
(7, 7, 1, 1, 1, 1, 1, 1, '2026-03-13 04:01:52');

-- --------------------------------------------------------

--
-- Table structure for table `page_assets`
--

DROP TABLE IF EXISTS `page_assets`;
CREATE TABLE `page_assets` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED DEFAULT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` int(10) UNSIGNED DEFAULT '0',
  `mime_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploaded_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_gateways`
--

DROP TABLE IF EXISTS `payment_gateways`;
CREATE TABLE `payment_gateways` (
  `id` int(10) UNSIGNED NOT NULL,
  `gateway_name` varchar(50) NOT NULL,
  `is_enabled` tinyint(1) DEFAULT '0',
  `config_key` varchar(255) DEFAULT NULL,
  `config_secret` varchar(255) DEFAULT NULL,
  `config_webhook` varchar(255) DEFAULT NULL,
  `config_mode` enum('test','live') DEFAULT 'test',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment_gateways`
--

INSERT INTO `payment_gateways` (`id`, `gateway_name`, `is_enabled`, `config_key`, `config_secret`, `config_webhook`, `config_mode`, `created_at`, `updated_at`) VALUES
(1, 'Stripe', 0, NULL, NULL, NULL, 'test', '2026-03-27 12:34:51', '2026-03-27 12:34:51'),
(2, 'PhonePe', 1, '', '', '', 'test', '2026-03-27 12:34:51', '2026-03-27 12:39:35');

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

DROP TABLE IF EXISTS `payment_methods`;
CREATE TABLE `payment_methods` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `provider` varchar(50) DEFAULT NULL,
  `provider_customer_id` varchar(255) DEFAULT NULL,
  `provider_payment_method_id` varchar(255) DEFAULT NULL,
  `card_last_four` varchar(4) DEFAULT NULL,
  `card_brand` varchar(20) DEFAULT NULL,
  `card_exp_month` int(11) DEFAULT NULL,
  `card_exp_year` int(11) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `module` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `module`, `action`, `label`, `description`) VALUES
(1, 'dashboard', 'view', 'View Dashboard', NULL),
(2, 'leads', 'view', 'View Leads', NULL),
(3, 'leads', 'view_all', 'View All Leads (not just assigned)', NULL),
(4, 'leads', 'create', 'Create Lead', NULL),
(5, 'leads', 'edit', 'Edit Lead', NULL),
(6, 'leads', 'delete', 'Delete Lead', NULL),
(7, 'leads', 'export', 'Export Leads', NULL),
(8, 'leads', 'assign', 'Assign Lead to Agent', NULL),
(9, 'leads', 'comment', 'Comment on Lead', NULL),
(10, 'forms', 'view', 'View Forms', NULL),
(11, 'forms', 'create', 'Create Form', NULL),
(12, 'forms', 'edit', 'Edit Form', NULL),
(13, 'forms', 'delete', 'Delete Form', NULL),
(14, 'domains', 'view', 'View Domains', NULL),
(15, 'domains', 'create', 'Add Domain', NULL),
(16, 'domains', 'edit', 'Edit Domain', NULL),
(17, 'domains', 'delete', 'Delete Domain', NULL),
(18, 'reports', 'view', 'View Reports', NULL),
(19, 'reports', 'export', 'Export Reports', NULL),
(20, 'team', 'view', 'View Team Members', NULL),
(21, 'team', 'invite', 'Invite Team Members', NULL),
(22, 'team', 'edit', 'Edit Team Members', NULL),
(23, 'team', 'remove', 'Remove Team Members', NULL),
(24, 'team', 'manage_roles', 'Manage Roles & Permissions', NULL),
(25, 'spam', 'view', 'View Spam Settings', NULL),
(26, 'spam', 'manage', 'Manage Spam Settings', NULL),
(27, 'settings', 'view', 'View Account Settings', NULL),
(28, 'settings', 'edit', 'Edit Account Settings', NULL),
(29, 'settings', 'billing', 'Access Billing', NULL),
(30, 'platform', 'manage_accounts', 'Manage All Accounts', NULL),
(31, 'platform', 'impersonate', 'Impersonate Users', NULL),
(32, 'platform', 'system_settings', 'System Settings', NULL),
(33, 'leads', 'archive', 'Archive Leads', NULL),
(34, 'leads', 'merge', 'Merge Duplicate Leads', NULL),
(35, 'leads', 'gdpr_erase', 'GDPR Erase Lead Data', NULL),
(36, 'leads', 'ai', 'Use AI Features', NULL),
(37, 'leads', 'score', 'View Lead Scores', NULL),
(38, 'leads', 'manage_score', 'Manage Scoring Rules', NULL),
(39, 'platform', 'ai_config', 'Configure AI Settings', NULL),
(47, 'campaigns', 'view', 'View Campaigns', NULL),
(48, 'campaigns', 'create', 'Create Campaign', NULL),
(49, 'campaigns', 'edit', 'Edit Campaign', NULL),
(50, 'campaigns', 'delete', 'Delete Campaign', NULL),
(51, 'auditor', 'run', 'Run SEO Audit', 'Can run SEO and AI audits on URLs'),
(52, 'auditor', 'export', 'Export Audit Report', 'Can export audit reports'),
(55, 'auditor', 'email', 'Email Audit Report', 'Can send audit reports by email to clients'),
(58, 'billing', 'manage_pricing', 'Manage Pricing Plans', 'Create, edit, and manage pricing plans'),
(59, 'billing', 'manage_payments', 'Manage Payment Gateways', 'Configure Stripe and PhonePe payment gateways'),
(60, 'billing', 'manage_accounts', 'Manage Account Subscriptions', 'Manage account subscriptions and plans'),
(61, 'billing', 'view_reports', 'View Billing Reports', 'View billing reports and analytics'),
(62, 'billing', 'view', 'View Billing Dashboard', 'View own billing dashboard'),
(63, 'billing', 'view_invoices', 'View Invoices', 'View own invoices and payment history'),
(64, 'billing', 'manage_payment_methods', 'Manage Payment Methods', 'Add and remove payment methods'),
(65, 'billing', 'upgrade_plan', 'Upgrade Plan', 'Upgrade or downgrade subscription plan'),
(66, 'billing', 'view_usage', 'View Usage', 'View usage limits and tracking');

-- --------------------------------------------------------

--
-- Table structure for table `plan_services`
--

DROP TABLE IF EXISTS `plan_services`;
CREATE TABLE `plan_services` (
  `id` int(10) UNSIGNED NOT NULL,
  `plan_id` int(10) UNSIGNED NOT NULL,
  `service_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `plan_services`
--

INSERT INTO `plan_services` (`id`, `plan_id`, `service_id`, `created_at`) VALUES
(18, 2, 4, '2026-03-27 13:47:12'),
(19, 2, 6, '2026-03-27 13:47:12'),
(20, 2, 7, '2026-03-27 13:47:12'),
(21, 4, 3, '2026-03-27 13:47:25'),
(22, 4, 4, '2026-03-27 13:47:25'),
(23, 4, 5, '2026-03-27 13:47:25'),
(24, 4, 6, '2026-03-27 13:47:25'),
(25, 4, 7, '2026-03-27 13:47:25'),
(26, 11, 1, '2026-03-27 13:47:30'),
(27, 11, 2, '2026-03-27 13:47:30'),
(28, 11, 3, '2026-03-27 13:47:30'),
(29, 11, 4, '2026-03-27 13:47:30'),
(30, 11, 5, '2026-03-27 13:47:30'),
(31, 11, 6, '2026-03-27 13:47:30'),
(32, 11, 7, '2026-03-27 13:47:30');

-- --------------------------------------------------------

--
-- Table structure for table `platform_settings`
--

DROP TABLE IF EXISTS `platform_settings`;
CREATE TABLE `platform_settings` (
  `key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `platform_settings`
--

INSERT INTO `platform_settings` (`key`, `value`, `updated_at`) VALUES
('ai_api_key', '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', '2026-03-27 10:37:43'),
('ai_auto_analyze', '1', '2026-03-27 10:37:43'),
('ai_business_context', '', '2026-03-27 10:37:43'),
('ai_business_location', '', '2026-03-27 10:37:43'),
('ai_business_name', '', '2026-03-27 10:37:43'),
('ai_business_type', '', '2026-03-27 10:37:43'),
('ai_email_enabled', '1', '2026-03-27 10:37:43'),
('ai_enabled', '1', '2026-03-27 10:37:43'),
('ai_enrich_enabled', '1', '2026-03-27 10:37:43'),
('ai_followup_enabled', '1', '2026-03-27 10:37:43'),
('ai_model', 'meta-llama/llama-3.3-70b-instruct:free', '2026-03-27 10:37:43'),
('ai_pricing_info', '', '2026-03-27 10:37:43'),
('ai_provider', 'openrouter', '2026-03-10 06:32:36'),
('ai_qualify_enabled', '1', '2026-03-27 10:37:43'),
('ai_scoring_enabled', '1', '2026-03-27 10:37:43'),
('ai_services_offered', '', '2026-03-27 10:37:43'),
('ai_smart_reply_enabled', '1', '2026-03-27 10:37:43'),
('ai_summary_enabled', '1', '2026-03-27 10:37:43'),
('app_badge_text', 'V2', '2026-03-27 11:40:46'),
('app_docs_url', '', '2026-03-27 11:40:46'),
('app_favicon_url', '', '2026-03-27 11:40:46'),
('app_logo_url', '', '2026-03-27 11:40:46'),
('app_name', 'Leverage', '2026-03-27 11:40:46'),
('app_status_url', '', '2026-03-27 11:40:46'),
('app_support_url', '', '2026-03-27 11:40:46'),
('app_tagline', 'Turn leads into customers', '2026-03-27 11:40:46'),
('brand_color_100', '#3a6ea5', '2026-03-27 11:40:46'),
('brand_color_50', '#9381ff', '2026-03-27 11:40:46'),
('brand_color_500', '#1c40ab', '2026-03-27 11:40:46'),
('brand_color_600', '#7209b7', '2026-03-27 11:40:46'),
('brand_color_700', '#1e95b3', '2026-03-27 11:40:46'),
('builder_brand_color', '#2563eb', '2026-03-15 03:16:04'),
('builder_global_font', 'Sora', '2026-03-15 03:16:04'),
('custom_css', '', '2026-03-27 11:40:46'),
('eng_last_run_2', '2026-03-24 05:18:43', '2026-03-24 10:48:43'),
('eng_last_run_4', '2026-03-27 07:55:23', '2026-03-27 13:25:23'),
('feature_api', '1', '2026-03-27 11:40:46'),
('feature_domains', '1', '2026-03-27 11:40:46'),
('feature_kanban', '1', '2026-03-27 11:40:46'),
('feature_reports', '1', '2026-03-27 11:40:46'),
('feature_scoring', '1', '2026-03-27 11:40:46'),
('feature_spam', '1', '2026-03-27 11:40:46'),
('font_body', 'Google Sans', '2026-03-27 11:40:46'),
('font_mono', 'JetBrains Mono', '2026-03-27 11:40:46'),
('footer_copyright', '© {year} Leverage. All rights reserved.', '2026-03-27 11:40:46'),
('footer_credits_text', 'Powered by Leverage', '2026-03-27 11:40:46'),
('footer_credits_url', 'https://leverage.app', '2026-03-27 11:40:46'),
('footer_links', '', '2026-03-27 11:40:46'),
('footer_show_credits', '1', '2026-03-27 11:40:46'),
('gemini_api_key', '', '2026-03-27 10:37:43'),
('gemini_model', 'gemini-2.0-flash-lite', '2026-03-27 10:37:43'),
('groq_api_key', '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', '2026-03-27 10:37:43'),
('groq_model', 'llama-3.3-70b-versatile', '2026-03-27 10:37:43'),
('login_headline', 'Close more deals,\r\nfaster.', '2026-03-27 11:40:46'),
('login_hero_color_from', '#613dc1', '2026-03-27 11:40:46'),
('login_hero_color_to', '#166088', '2026-03-27 11:40:46'),
('login_subtext', 'The all-in-one CRM for modern sales teams.', '2026-03-27 11:40:46'),
('maintenance_message', 'We are performing scheduled maintenance. We will be back shortly.', '2026-03-27 11:40:46'),
('maintenance_mode', '0', '2026-03-27 11:40:46'),
('meta_description', 'Leverage — Smart Business CRM', '2026-03-27 11:40:46'),
('meta_og_image', '', '2026-03-27 11:40:46'),
('pexels_api_key', '', '2026-03-15 03:16:04'),
('pixabay_api_key', '', '2026-03-15 03:39:48'),
('registration_open', '0', '2026-03-27 11:40:46'),
('reminder_cfg_2', '{\"enabled\":1,\"no_contact_hrs\":1,\"overdue_hrs\":2,\"inactive_days\":1}', '2026-03-22 08:50:03'),
('reminder_last_run_2', '2026-03-27 11:54:16', '2026-03-27 17:24:16'),
('reminder_last_run_4', '2026-03-27 07:48:11', '2026-03-27 13:18:11'),
('sidebar_active_bg', '#283352', '2026-03-27 11:40:46'),
('sidebar_bg', '#1e2743', '2026-03-27 11:40:46'),
('sidebar_text', '#ffffff', '2026-03-27 11:40:46'),
('smtp_encryption', 'ssl', '2026-03-27 11:40:46'),
('smtp_from_email', 'leads@sitecanvas.in', '2026-03-27 11:40:46'),
('smtp_from_name', 'Leverage', '2026-03-27 11:40:46'),
('smtp_host', 'smtp.hostinger.com', '2026-03-27 11:40:46'),
('smtp_pass', 'h#Z8a61]V', '2026-03-27 11:40:46'),
('smtp_port', '465', '2026-03-27 11:40:46'),
('smtp_user', 'leads@sitecanvas.in', '2026-03-27 11:40:46'),
('unsplash_api_key', '', '2026-03-15 03:16:04');

-- --------------------------------------------------------

--
-- Table structure for table `pricing_plans`
--

DROP TABLE IF EXISTS `pricing_plans`;
CREATE TABLE `pricing_plans` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `description` text,
  `price_monthly` decimal(10,2) NOT NULL,
  `domains_limit` int(11) NOT NULL,
  `forms_limit` int(11) NOT NULL,
  `leads_per_month` int(11) NOT NULL,
  `team_members_limit` int(11) NOT NULL,
  `trial_days` int(11) DEFAULT '14',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pricing_plans`
--

INSERT INTO `pricing_plans` (`id`, `name`, `slug`, `description`, `price_monthly`, `domains_limit`, `forms_limit`, `leads_per_month`, `team_members_limit`, `trial_days`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Personal', 'personal', 'Perfect for small businesses', '9.00', 1, 3, 300, 2, 14, 1, '2026-03-27 07:33:21', '2026-03-27 13:43:25'),
(2, 'Pro', 'pro', 'For growing agencies', '19.00', 5, 10, 500, 5, 14, 1, '2026-03-27 07:33:21', '2026-03-27 13:44:13'),
(4, 'Agency', 'agency', 'Custom Business solutions', '29.00', 10, 25, 1000, 20, 14, 1, '2026-03-27 07:33:21', '2026-03-27 13:46:11'),
(11, 'Enterprise', 'enterprise', '', '49.00', 25, 50, 2000, 50, 14, 1, '2026-03-27 13:46:34', '2026-03-27 13:46:34');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_system` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `label`, `description`, `is_system`, `created_at`) VALUES
(1, 'super_admin', 'Super Admin', 'Full platform access. Manages all accounts, billing, and system settings.', 1, '2026-03-09 11:02:28'),
(2, 'account_owner', 'Account Owner', 'Full access within their account. Can manage team, billing, domains and all data.', 1, '2026-03-09 11:02:28'),
(3, 'manager', 'Manager', 'Can manage leads, forms, domains and team members. Cannot access billing or account settings.', 1, '2026-03-09 11:02:28'),
(4, 'agent', 'Agent', 'Can view and action leads assigned to them. Cannot access settings or team management.', 1, '2026-03-09 11:02:28');

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
CREATE TABLE `role_permissions` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `permission_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_permissions`
--

INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(1, 2),
(2, 2),
(3, 2),
(4, 2),
(1, 3),
(2, 3),
(3, 3),
(1, 4),
(2, 4),
(3, 4),
(1, 5),
(2, 5),
(3, 5),
(4, 5),
(1, 6),
(2, 6),
(3, 6),
(1, 7),
(2, 7),
(3, 7),
(1, 8),
(2, 8),
(3, 8),
(1, 9),
(2, 9),
(3, 9),
(4, 9),
(1, 10),
(2, 10),
(3, 10),
(4, 10),
(1, 11),
(2, 11),
(3, 11),
(1, 12),
(2, 12),
(3, 12),
(1, 13),
(2, 13),
(3, 13),
(1, 14),
(2, 14),
(3, 14),
(4, 14),
(1, 15),
(2, 15),
(3, 15),
(1, 16),
(2, 16),
(3, 16),
(1, 17),
(2, 17),
(3, 17),
(1, 18),
(2, 18),
(3, 18),
(1, 19),
(2, 19),
(3, 19),
(1, 20),
(2, 20),
(3, 20),
(1, 21),
(2, 21),
(3, 21),
(1, 22),
(2, 22),
(3, 22),
(1, 23),
(2, 23),
(3, 23),
(1, 24),
(2, 24),
(1, 25),
(2, 25),
(3, 25),
(1, 26),
(2, 26),
(3, 26),
(1, 27),
(2, 27),
(1, 28),
(2, 28),
(1, 29),
(2, 29),
(1, 30),
(1, 31),
(1, 32),
(2, 33),
(3, 33),
(2, 34),
(2, 35),
(2, 36),
(3, 36),
(4, 36),
(2, 37),
(3, 37),
(2, 38),
(1, 39),
(2, 47),
(3, 47),
(2, 48),
(3, 48),
(2, 49),
(3, 49),
(2, 50),
(1, 51),
(2, 51),
(3, 51),
(1, 52),
(2, 52),
(3, 52),
(1, 55),
(2, 55),
(1, 58),
(1, 59),
(1, 60),
(1, 61),
(2, 62),
(2, 63),
(2, 64),
(2, 65),
(2, 66),
(3, 66);

-- --------------------------------------------------------

--
-- Table structure for table `seo_audits`
--

DROP TABLE IF EXISTS `seo_audits`;
CREATE TABLE `seo_audits` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `score_overall` tinyint(3) UNSIGNED DEFAULT '0',
  `result_json` longtext COLLATE utf8mb4_unicode_ci,
  `public_token` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emailed_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `seo_audits`
--

INSERT INTO `seo_audits` (`id`, `account_id`, `user_id`, `url`, `score_overall`, `result_json`, `public_token`, `emailed_at`, `created_at`) VALUES
(15, 2, 7, '0', 88, '0', '966d31b4900ab3ec60222b701bc317b5ef2144ade8323023', NULL, '2026-03-26 08:10:34'),
(16, 2, 7, '0', 88, '0', '2850d31dfbddbefb3104e1e2ec09782614220b555a805c1d', NULL, '2026-03-26 09:54:10'),
(17, 2, 7, '0', 88, '0', '1a3f30fa8b8b0df29ba49f7a3c7819f21a61d40a0fe8880a', NULL, '2026-03-26 10:33:47'),
(18, 2, 7, '0', 88, '0', 'd614dd6410287c35a1b28f11e7bebb0ca62521bec08bcaee', NULL, '2026-03-26 10:37:43'),
(19, 2, 7, 'https://kokler.in/', 88, '0', '9625f4252fe9e81b9bba603b81d2ea070ebc346edb09d960', NULL, '2026-03-26 15:12:01'),
(20, 2, 7, 'https://kokler.in/', 88, '{\"target\":{\"requested_url\":\"https://kokler.in\",\"final_url\":\"https://kokler.in/\",\"host\":\"kokler.in\",\"audited_at\":\"2026-03-26T09:45:06+00:00\",\"competitor_urls\":[]},\"response\":{\"status_code\":200,\"content_type\":\"text/html; charset=UTF-8\",\"response_time_ms\":715,\"redirect_count\":0,\"html_size_kb\":131.4,\"headers\":{\"date\":\"Thu, 26 Mar 2026 09:45:01 GMT\",\"content-type\":\"text/html; charset=UTF-8\",\"cf-ray\":\"9e2538542a24b237-DEL\",\"cf-cache-status\":\"DYNAMIC\",\"retry-after\":\"60\",\"cache-control\":\"no-store, no-cache, must-revalidate\",\"expires\":\"Thu, 19 Nov 1981 08:52:00 GMT\",\"link\":\"<https://kokler.in/wp-json/>; rel=\\\"https://api.w.org/\\\", <https://kokler.in/wp-json/wp/v2/pages/69>; rel=\\\"alternate\\\"; title=\\\"JSON\\\"; type=\\\"application/json\\\", <https://kokler.in/>; rel=shortlink\",\"server\":\"cloudflare\",\"set-cookie\":\"PHPSESSID=v79672ornp17utkuhb8pe2v392; path=/; secure\",\"vary\":\"Accept-Encoding\",\"pragma\":\"no-cache\",\"alt-svc\":\"h3=\\\":443\\\"; ma=86400\",\"content-security-policy\":\"upgrade-insecure-requests\",\"panel\":\"hpanel\",\"platform\":\"hostinger\",\"x-powered-by\":\"PHP/8.2.30\",\"x-turbo-charged-by\":\"LiteSpeed\",\"server-timing\":[\"cfCacheStatus;desc=\\\"DYNAMIC\\\"\",\"cfEdge;dur=520,cfOrigin;dur=0\"],\"report-to\":\"{\\\"group\\\":\\\"cf-nel\\\",\\\"max_age\\\":604800,\\\"endpoints\\\":[{\\\"url\\\":\\\"https://a.nel.cloudflare.com/report/v4?s=stovGdlqPWejgPFiMHmMp4rRtUlvmB4d%2BP2dffhTGKB2gAQvy%2Fp6IpWzwx1iNUKImbhzqL00K%2Btdlcb6Mt00urlGiE4Cwgvs4ax7DMj4gKdjKwYKVXIM0hULCuA%3D\\\"}]}\",\"nel\":\"{\\\"report_to\\\":\\\"cf-nel\\\",\\\"success_fraction\\\":0.0,\\\"max_age\\\":604800}\",\"content-encoding\":\"gzip\"}},\"metrics\":{\"page\":{\"title\":{\"text\":\"Kokler | Organic Hair & Body Care Products\",\"length\":42},\"description\":{\"text\":\"Experience Kokler’s organic, chemical-free hair and skin care. Pure herbal beauty with our Hair Cure Shampoo and 100% Herbal Ubtan Powder.\",\"length\":138},\"canonical\":\"https://kokler.in/\",\"lang\":\"\",\"viewport\":\"width=device-width, initial-scale=1, maximum-scale=5, viewport-fit=cover\",\"meta_robots\":\"index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1\",\"x_robots_tag\":\"\",\"charset\":\"UTF-8\",\"h1\":[],\"h2\":[\"Herbal Power. Happy Hair.\",\"Glow, NaturallyEveryday\"],\"url\":\"https://kokler.in/\"},\"content\":{\"word_count\":471,\"paragraph_count\":20,\"heading_counts\":{\"h1\":0,\"h2\":2,\"h3\":7,\"h4\":0,\"h5\":19,\"h6\":0},\"text_excerpt\":\"Warning: Constant WP_DEBUG already defined in /home/u963423741/domains/kokler.in/public_html/wp-config.php on line 102 Kokler | Organic Hair & Body Care Products Skip to content Menu Herbal Ubtan Powder Hair Cure Shampoo Our Story Contact Us Username or Email Address Password Rem...\",\"keywords\":[\"hair\",\"kokler\",\"herbal\",\"organic\",\"care\",\"body\",\"products\",\"cure\",\"shampoo\",\"ubtan\",\"powder\",\"experience\"]},\"media\":{\"total\":19,\"missing_alt\":13,\"missing_alt_samples\":[\"https://kokler.in/wp-content/uploads/2025/04/003-enviroment.png\",\"https://kokler.in/wp-content/uploads/2025/04/002-rabbit.png\",\"https://kokler.in/wp-content/uploads/2025/04/001-hand.png\",\"https://kokler.in/wp-content/uploads/2026/02/flask.png\",\"https://kokler.in/wp-content/uploads/2025/08/organic-hair-and-skin-care-3.jpg\"],\"lazy_loaded\":8},\"links\":{\"total\":31,\"internal\":28,\"external\":3,\"nofollow\":0,\"empty_anchor_text\":2,\"internal_details\":[{\"url\":\"https://kokler.in/product/herbal-ubtan-powder/\",\"anchor\":\"Herbal Ubtan Powder\",\"bucket\":\"product\"},{\"url\":\"https://kokler.in/product/hair-cure-amla-reetha-shikakai-shampoo/\",\"anchor\":\"Hair Cure Shampoo\",\"bucket\":\"product\"},{\"url\":\"https://kokler.in/our-story/\",\"anchor\":\"Our Story\",\"bucket\":\"other\"},{\"url\":\"https://kokler.in/contact-us/\",\"anchor\":\"Contact Us\",\"bucket\":\"contact\"},{\"url\":\"https://kokler.in/product/herbal-ubtan-powder/\",\"anchor\":\"Herbal Ubtan Powder\",\"bucket\":\"product\"},{\"url\":\"https://kokler.in/product/hair-cure-amla-reetha-shikakai-shampoo/\",\"anchor\":\"Hair Cure Shampoo\",\"bucket\":\"product\"},{\"url\":\"https://kokler.in/our-story/\",\"anchor\":\"Our Story\",\"bucket\":\"other\"},{\"url\":\"https://kokler.in/\",\"anchor\":\"\",\"bucket\":\"other\"},{\"url\":\"https://kokler.in/cart/\",\"anchor\":\"Shopping cart 0\",\"bucket\":\"cart\"},{\"url\":\"https://kokler.in/\",\"anchor\":\"\",\"bucket\":\"other\"},{\"url\":\"https://kokler.in/cart/\",\"anchor\":\"Shopping cart 0\",\"bucket\":\"cart\"},{\"url\":\"https://kokler.in/index.php/product/hair-cure-amla-reetha-shikakai-shampoo/\",\"anchor\":\"Buy Now\",\"bucket\":\"product\"},{\"url\":\"https://kokler.in/index.php/product/herbal-ubtan-powder/\",\"anchor\":\"Buy Now\",\"bucket\":\"product\"},{\"url\":\"https://kokler.in/index.php/product/hair-cure-amla-reetha-shikakai-shampoo/\",\"anchor\":\"Shop Now\",\"bucket\":\"product\"},{\"url\":\"https://kokler.in/index.php/product/herbal-ubtan-powder/\",\"anchor\":\"Shop Now\",\"bucket\":\"product\"},{\"url\":\"https://kokler.in/index.php/product/hair-cure-amla-reetha-shikakai-shampoo/\",\"anchor\":\"Shop Hair Care\",\"bucket\":\"product\"},{\"url\":\"https://kokler.in/index.php/product/herbal-ubtan-powder/\",\"anchor\":\"Shop Body Care\",\"bucket\":\"product\"},{\"url\":\"https://kokler.in/index.php/product/hair-cure-amla-reetha-shikakai-shampoo/\",\"anchor\":\"Shop Hair Care\",\"bucket\":\"product\"},{\"url\":\"https://kokler.in/index.php/product/herbal-ubtan-powder/\",\"anchor\":\"Shop Body Care\",\"bucket\":\"product\"},{\"url\":\"https://kokler.in/our-story/\",\"anchor\":\"Our Story\",\"bucket\":\"other\"},{\"url\":\"https://kokler.in/contact-us/\",\"anchor\":\"Contact Us\",\"bucket\":\"contact\"},{\"url\":\"https://kokler.in/product/herbal-ubtan-powder/\",\"anchor\":\"Body Care\",\"bucket\":\"product\"},{\"url\":\"https://kokler.in/product/hair-cure-amla-reetha-shikakai-shampoo/\",\"anchor\":\"Hair Care\",\"bucket\":\"product\"},{\"url\":\"https://kokler.in/index.php/my-account/\",\"anchor\":\"My Account\",\"bucket\":\"other\"},{\"url\":\"https://kokler.in/index.php/my-account/orders/\",\"anchor\":\"Manage Orders\",\"bucket\":\"other\"},{\"url\":\"https://kokler.in/terms-conditions/\",\"anchor\":\"Terms & Conditions\",\"bucket\":\"other\"},{\"url\":\"https://kokler.in/privacy-policy/\",\"anchor\":\"Privacy Policy\",\"bucket\":\"other\"},{\"url\":\"https://kokler.in/refund_returns/\",\"anchor\":\"Refund & Returns Policy\",\"bucket\":\"other\"}],\"external_domains\":[\"www.instagram.com\",\"www.facebook.com\",\"www.icarry.in\"]},\"assets\":{\"script_files\":20,\"inline_scripts\":21,\"stylesheets\":52,\"style_blocks\":9,\"script_sources\":[\"https://kokler.in/wp-includes/js/jquery/jquery.min.js?ver=3.7.1\",\"https://kokler.in/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1\",\"https://kokler.in/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.10.6.1\",\"https://kokler.in/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=10.6.1\",\"https://kokler.in/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4-wc.10.6.1\",\"https://kokler.in/wp-content/plugins/slicewp/assets/js/script-trk.js?ver=1.2.6\",\"https://kokler.in/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=10.6.1\",\"https://stats.wp.com/s-202613.js\",\"https://www.googletagmanager.com/gtag/js?id=GT-MKBGS3V\",\"https://kokler.in/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=10.6.1\",\"https://kokler.in/wp-content/plugins/ai-commerce-chatbot/assets/chatbot.js?ver=3.8.0\",\"https://kokler.in/wp-content/plugins/elementor/assets/lib/swiper/v8/swiper.min.js?ver=8.4.5\",\"https://kokler.in/wp-includes/js/imagesloaded.min.js?ver=5.0.0\",\"https://kokler.in/wp-content/plugins/bdthemes-element-pack-lite/assets/js/bdt-uikit.min.js?ver=3.21.7\",\"https://kokler.in/wp-content/plugins/bdthemes-element-pack-lite/assets/js/modules/ep-slider.min.js?ver=8.4.2\",\"https://kokler.in/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.35.7\",\"https://kokler.in/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.35.7\",\"https://kokler.in/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3\",\"https://kokler.in/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.35.7\",\"https://kokler.in/wp-content/themes/blocksy/static/bundle/main.js?ver=2.1.35\"]},\"enhancements\":{\"structured_data_count\":1,\"structured_data_types\":[\"BreadcrumbList\",\"EntryPoint\",\"ImageObject\",\"ListItem\",\"Organization\",\"PropertyValueSpecification\",\"ReadAction\",\"SearchAction\",\"WebPage\",\"WebSite\"],\"open_graph\":{\"present\":true,\"coverage\":{\"og:title\":true,\"og:description\":true,\"og:image\":true,\"og:url\":true}},\"twitter_cards\":{\"present\":true,\"coverage\":{\"twitter:card\":true,\"twitter:title\":false,\"twitter:description\":false}},\"favicon\":true},\"forms\":{\"total\":2,\"lead_forms\":0,\"search_forms\":0,\"email_fields\":0,\"phone_fields\":0,\"password_fields\":1,\"field_count\":6,\"sample_actions\":[\"#\",\"#\"],\"submit_texts\":[\"Log In\",\"Get New Password\"]},\"tracking\":{\"tools\":[\"Google Tag Manager\"],\"events\":[\"gtm_js\"],\"conversion_events\":[],\"data_layer_present\":true},\"commerce\":{\"is_product_like\":true,\"product_schema\":false,\"has_add_to_cart\":true,\"price_samples\":[],\"price_count\":0,\"cart_links\":2,\"checkout_links\":0,\"review_mentions\":false,\"trust_mentions\":false,\"shipping_mentions\":true,\"return_mentions\":true,\"guest_checkout_mentions\":false,\"coupon_mentions\":false,\"compare_at_price\":false,\"discount_mentions\":true,\"bundle_mentions\":false},\"chatbot\":{\"detected\":true,\"vendors\":[\"Crisp\"],\"lead_capture_ctas\":[],\"detected_intents\":[\"contact sales\",\"support\",\"shipping\",\"returns\",\"order tracking\",\"product help\",\"payment\"],\"knowledge_base_signals\":false,\"human_handoff\":true},\"buttons\":[\"Log In\",\"Get New Password\",\"Menu\",\"Buy Now\",\"Shop Now\",\"Shop Hair Care\",\"Shop Body Care\",\"🛒\",\"↺\",\"−\",\"Track\",\"Cancel\",\"Place Order\",\"Quick Actions ▾\"],\"contact\":{\"emails\":[\"contact@kokler.in\"],\"phones\":[\"918101161985\"],\"whatsapp\":false}},\"checks\":{\"https\":true,\"robots_txt\":{\"found\":true,\"url\":\"https://kokler.in/robots.txt\",\"status\":200},\"sitemap\":{\"found\":true,\"url\":\"https://kokler.in/sitemap_index.xml\",\"status\":200}},\"crawl\":{\"enabled\":false,\"scope\":\"page\",\"limit\":1,\"pages_crawled\":1,\"failed_fetches\":0,\"summary\":{\"pages_analyzed\":1,\"missing_titles\":0,\"missing_descriptions\":0,\"missing_h1_pages\":1,\"thin_content_pages\":0,\"noindex_pages\":0,\"canonical_gaps\":0,\"average_word_count\":471,\"top_keywords\":[\"hair\",\"kokler\",\"herbal\",\"organic\",\"care\",\"body\",\"products\",\"cure\"],\"pages_with_most_gaps\":[{\"url\":\"https://kokler.in/\",\"title\":\"Kokler | Organic Hair & Body Care Products\",\"issue_count\":1,\"word_count\":471}]},\"top_keywords\":[\"hair\",\"kokler\",\"herbal\",\"organic\",\"care\",\"body\",\"products\",\"cure\"],\"pages\":[{\"url\":\"https://kokler.in/\",\"title\":\"Kokler | Organic Hair & Body Care Products\",\"status_code\":200,\"response_time_ms\":715,\"word_count\":471,\"h1_count\":0,\"h2_count\":2,\"internal_links\":28,\"keywords\":[\"hair\",\"kokler\",\"herbal\",\"organic\",\"care\",\"body\",\"products\",\"cure\"],\"missing_title\":false,\"missing_description\":false,\"missing_h1\":true,\"noindex\":false,\"canonical_missing\":false,\"thin_content\":false,\"issue_count\":1}]},\"modules\":{\"analytics\":{\"score\":38,\"headline\":\"Tracking coverage has gaps that can distort attribution or hide conversion leaks.\",\"detected_tools\":[\"Google Tag Manager\"],\"detected_events\":[\"gtm_js\"],\"conversion_events\":[],\"missing_events\":[\"generate_lead\",\"view_item\",\"add_to_cart\",\"begin_checkout\",\"purchase\",\"chat_start\",\"chatbot_lead\"],\"requires_conversion_tracking\":true,\"pages_checked\":[\"https://kokler.in/\",\"https://kokler.in/cart/\",\"https://kokler.in/contact-us/\"],\"findings\":[\"Detected tracking stack: Google Tag Manager.\",\"Meta Pixel was not detected on a site that appears to rely on lead generation or ecommerce actions.\",\"No explicit conversion event was detected even though the site shows lead or commerce intent.\",\"Expected funnel events appear to be missing: generate_lead, view_item, add_to_cart, begin_checkout, purchase, chat_start, chatbot_lead.\"],\"recommendations\":[\"If paid social matters for this funnel, add Meta Pixel and mirror the core conversion events there.\",\"Track the final conversion moments such as generate_lead, begin_checkout, purchase, or chatbot-qualified lead.\",\"Create a clear event map and push each funnel step into GTM or your analytics library with a normalized naming convention.\",\"Use one canonical event taxonomy across analytics, ad pixels, CRM handoffs, and server-side conversions to keep attribution clean.\"],\"ai_recommendations\":[\"If paid social matters for this funnel, add Meta Pixel and mirror the core conversion events there.\",\"Track the final conversion moments such as generate_lead, begin_checkout, purchase, or chatbot-qualified lead.\",\"Create a clear event map and push each funnel step into GTM or your analytics library with a normalized naming convention.\",\"Use one canonical event taxonomy across analytics, ad pixels, CRM handoffs, and server-side conversions to keep attribution clean.\"]},\"ecommerce\":{\"applicable\":true,\"score\":52,\"headline\":\"The ecommerce flow shows copy, trust, or checkout friction issues that can suppress conversion rate.\",\"pages\":{\"product\":{\"found\":true,\"url\":\"https://kokler.in/\",\"status\":200},\"cart\":{\"found\":true,\"url\":\"https://kokler.in/cart/\",\"status\":200},\"checkout\":{\"found\":false,\"url\":\"https://kokler.in/checkout\",\"status\":200},\"pricing\":{\"found\":false,\"url\":\"https://kokler.in/plans\",\"status\":404},\"contact\":{\"found\":true,\"url\":\"https://kokler.in/contact-us/\",\"status\":200},\"faq\":{\"found\":false,\"url\":\"https://kokler.in/faq\",\"status\":404}},\"signals\":{\"price_samples\":[],\"compare_at_price\":false,\"discount_mentions\":true,\"bundle_mentions\":false},\"product_description_gaps\":[\"Product schema was not detected on the product-like page.\",\"No price signal was detected on the main commerce page.\",\"Review or testimonial proof is not obvious on the inspected product page.\"],\"checkout_friction_points\":[\"Cart page does not clearly surface trust or security reassurance.\",\"No checkout page was discovered, so checkout UX could not be reviewed directly.\"],\"pricing_signals\":[\"Discount language or savings messaging is present.\"],\"findings\":[\"Product-page persuasion is underdeveloped in one or more key areas.\",\"The cart or checkout flow shows friction risks that can raise abandonment.\",\"Pricing presentation was reviewed using static page cues.\"],\"recommendations\":[\"Expand product copy around outcomes, objections, use cases, proof, shipping, and returns so the page sells before checkout begins.\",\"Trim checkout inputs, make guest checkout obvious, and surface secure-payment reassurance near the primary CTA.\",\"Test pricing anchors such as compare-at prices, bundles, or savings framing where commercially appropriate.\",\"Add Product schema with price, availability, brand, and review fields where possible.\"],\"ai_recommendations\":[\"Expand product copy around outcomes, objections, use cases, proof, shipping, and returns so the page sells before checkout begins.\",\"Trim checkout inputs, make guest checkout obvious, and surface secure-payment reassurance near the primary CTA.\",\"Test pricing anchors such as compare-at prices, bundles, or savings framing where commercially appropriate.\",\"Add Product schema with price, availability, brand, and review fields where possible.\"]},\"chatbot\":{\"applicable\":true,\"score\":88,\"headline\":\"Customer-experience signals are solid, but intent coverage and lead routing can still be tightened.\",\"chatbot_detected\":true,\"detected_vendors\":[\"Crisp\"],\"response_accuracy_estimate\":\"Moderate readiness\",\"lead_capture_effectiveness\":\"Moderate\",\"knowledge_base_signals\":false,\"human_handoff_available\":true,\"known_intents\":[\"contact sales\",\"support\",\"shipping\",\"returns\",\"order tracking\",\"product help\",\"payment\"],\"missing_intents\":[],\"lead_capture_ctas\":[],\"findings\":[\"Detected conversational stack: Crisp.\",\"A chatbot was detected, but FAQ or support content signals are weak.\"],\"recommendations\":[\"Back the chatbot with FAQ, policy, pricing, and troubleshooting content so responses stay accurate.\",\"Map conversation flows around high-intent paths such as pricing, returns, shipping, support, and qualified lead capture.\"],\"ai_recommendations\":[\"Back the chatbot with FAQ, policy, pricing, and troubleshooting content so responses stay accurate.\",\"Map conversation flows around high-intent paths such as pricing, returns, shipping, support, and qualified lead capture.\"]},\"competitor\":{\"status\":\"requires_input\",\"score\":null,\"headline\":\"Add competitor URLs to unlock keyword, depth, and proxy-authority comparisons.\",\"note\":\"Backlink comparison stays disabled until competitor pages are supplied.\",\"target_keywords\":[\"hair\",\"kokler\",\"herbal\",\"organic\",\"care\",\"body\",\"products\",\"cure\",\"shampoo\",\"ubtan\",\"powder\",\"experience\"],\"authority_proxy_note\":\"Authority is benchmarked with an on-page heuristic because no external backlink index is configured.\",\"comparison_rows\":[],\"outrank_reasons\":[],\"recommendations\":[],\"ai_recommendations\":[],\"ai_outrank_reasons\":[]}},\"issues\":[{\"severity\":\"high\",\"category\":\"analytics\",\"title\":\"Conversion tracking appears incomplete\",\"details\":\"Lead or ecommerce flows need conversion events to support attribution and optimization.\",\"recommendation\":\"Track final lead, chat, and checkout conversion points with normalized event names.\",\"evidence\":\"Detected conversion events: \",\"penalty\":16,\"how_to_fix\":[\"Create an event map for every critical action in the funnel, then implement each event where that action actually completes.\",\"Pass the same event names into analytics, ads, and CRM workflows so reporting stays consistent.\",\"Validate each event in a live debugger using the real funnel path before calling the setup complete.\"],\"example_fix\":\"gtag(\'event\', \'generate_lead\', {});\\ngtag(\'event\', \'view_item\', {});\\ngtag(\'event\', \'add_to_cart\', {});\\ngtag(\'event\', \'begin_checkout\', {});\"},{\"severity\":\"high\",\"category\":\"ecommerce\",\"title\":\"Checkout flow shows friction risk\",\"details\":\"Checkout complexity or weak trust signals can increase abandonment.\",\"recommendation\":\"Reduce unnecessary fields, make guest checkout obvious, and surface trust cues near checkout CTAs.\",\"evidence\":\"Checkout friction: Cart page does not clearly surface trust or security reassurance. | No checkout page was discovered, so checkout UX could not be reviewed directly.\",\"penalty\":16,\"how_to_fix\":[\"Reduce the number of fields and remove anything not essential to complete the transaction.\",\"Surface trust, payment, shipping, and guest-checkout reassurance next to the primary checkout CTA.\",\"Watch the checkout event flow after the changes so you can confirm drop-off improves at the right step.\"],\"example_fix\":\"Checkout checklist:\\n- Keep guest checkout visible\\n- Show payment security reassurance\\n- Minimize fields above the fold\\n- Delay coupon fields if they hurt completion\"},{\"severity\":\"high\",\"category\":\"ecommerce\",\"title\":\"Product-page persuasion is underdeveloped\",\"details\":\"Product or offer pages need stronger copy, proof, and reassurance to convert search traffic.\",\"recommendation\":\"Strengthen benefits, objections, proof, shipping, return copy, and structured data on product pages.\",\"evidence\":\"Key gaps: Product schema was not detected on the product-like page. | No price signal was detected on the main commerce page. | Review or testimonial proof is not obvious on the inspected product page.\",\"penalty\":14,\"how_to_fix\":[\"Rewrite the product or offer page so it explains outcomes, objections, proof, pricing context, shipping, and returns in one place.\",\"Add visible trust elements such as reviews, policy reassurance, and structured data where appropriate.\",\"Make the primary CTA clearer and place it next to the strongest persuasion blocks, not just at the top of the page.\"],\"example_fix\":\"Suggested product sections:\\n- Benefits and outcomes\\n- Pricing and value explanation\\n- Reviews and proof\\n- Shipping and returns\\n- FAQs before purchase\"},{\"severity\":\"high\",\"category\":\"content\",\"title\":\"Missing H1 heading\",\"details\":\"Search engines and users both rely on a clear primary heading.\",\"recommendation\":\"Add one descriptive H1 that matches the page topic and search intent.\",\"evidence\":\"No `<h1>` detected.\",\"penalty\":12,\"how_to_fix\":[\"Keep exactly one H1 that matches the main topic of the page.\",\"Move supporting headings down to H2 or H3 so the structure is clear for users and crawlers.\",\"Make sure the H1 stays visible in the rendered page body and is not hidden behind a script or widget.\"],\"example_fix\":\"<h1>Kokler</h1>\"},{\"severity\":\"high\",\"category\":\"media\",\"title\":\"Some images are missing alt text\",\"details\":\"Alt text improves accessibility and helps image search understand page assets.\",\"recommendation\":\"Add descriptive alt text to meaningful images and leave decorative assets empty on purpose.\",\"evidence\":\"Missing alt text on 13 of 19 images.\",\"penalty\":10,\"how_to_fix\":[\"Write concise alt text for every meaningful image based on what the user needs to understand from it.\",\"Leave decorative images with empty alt text on purpose instead of stuffing keywords into them.\",\"Update the CMS media library or template so the missing-alt pattern does not repeat on future pages.\"],\"example_fix\":\"Example alt text: `SEO audit dashboard showing crawl issues and recommended fixes`\"},{\"severity\":\"medium\",\"category\":\"analytics\",\"title\":\"Funnel events appear to be missing\",\"details\":\"Missing event steps make it hard to diagnose where visitors drop out of the funnel.\",\"recommendation\":\"Instrument the missing funnel events and validate them in a live analytics debugger.\",\"evidence\":\"Missing events: generate_lead, view_item, add_to_cart, begin_checkout, purchase, chat_start, chatbot_lead\",\"penalty\":14,\"how_to_fix\":[\"Create an event map for every critical action in the funnel, then implement each event where that action actually completes.\",\"Pass the same event names into analytics, ads, and CRM workflows so reporting stays consistent.\",\"Validate each event in a live debugger using the real funnel path before calling the setup complete.\"],\"example_fix\":\"gtag(\'event\', \'generate_lead\', {});\\ngtag(\'event\', \'view_item\', {});\\ngtag(\'event\', \'add_to_cart\', {});\\ngtag(\'event\', \'begin_checkout\', {});\"},{\"severity\":\"medium\",\"category\":\"media\",\"title\":\"Some links have empty anchor text\",\"details\":\"Empty links weaken accessibility and reduce topical relevance signals.\",\"recommendation\":\"Give icon-only or image links a readable text alternative.\",\"evidence\":\"Empty anchor count: 2\",\"penalty\":5,\"how_to_fix\":[\"Find icon-only or empty links in the template and replace them with readable anchor text or an accessible label.\",\"If the link is an image, give the image meaningful alt text so the destination still has context.\",\"Re-test with a DOM inspector to confirm no empty anchors remain in the rendered markup.\"],\"example_fix\":\"<a href=\\\"/contact\\\">Contact sales</a>\"},{\"severity\":\"medium\",\"category\":\"metadata\",\"title\":\"HTML lang attribute is missing\",\"details\":\"Language metadata helps search engines and assistive technology interpret the page.\",\"recommendation\":\"Set the `<html lang=\\\"...\\\">` attribute to the primary page language.\",\"evidence\":\"No language attribute found on the root HTML element.\",\"penalty\":4,\"how_to_fix\":[\"Set the language on the root HTML element of the page template.\",\"Use the primary language of the content, not the market name or country code by itself.\",\"If the site is multilingual, make sure each language template sets its own correct lang value.\"],\"example_fix\":\"<html lang=\\\"en\\\">\"},{\"severity\":\"low\",\"category\":\"enhancements\",\"title\":\"Page loads many external scripts\",\"details\":\"Heavy script usage can slow page experience and reduce crawl efficiency.\",\"recommendation\":\"Audit non-essential third-party scripts and defer what is not critical.\",\"evidence\":\"External script files: 20\",\"penalty\":3,\"how_to_fix\":[\"List every third-party script on the page and remove the ones that are not essential for this template.\",\"Defer or delay non-critical tags until consent, interaction, or later page stages where possible.\",\"Consolidate overlapping marketing and analytics tags through GTM or another tag manager.\"],\"example_fix\":\"Review these script sources first: https://kokler.in/wp-includes/js/jquery/jquery.min.js?ver=3.7.1 | https://kokler.in/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1 | https://kokler.in/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.10.6.1 | https://kokler.in/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=10.6.1\"}],\"scores\":{\"overall\":88,\"grade\":\"B\",\"categories\":{\"crawlability\":100,\"metadata\":96,\"content\":88,\"media\":85,\"enhancements\":97,\"analytics\":70,\"competition\":null,\"ecommerce\":70,\"chatbot\":100},\"issue_summary\":{\"critical\":0,\"high\":5,\"medium\":3,\"low\":1}},\"highlights\":[\"The page resolves successfully with HTTP 200.\",\"The audited URL resolves over HTTPS.\",\"The title length is within the ideal search snippet range.\",\"The page has enough body copy to support topical relevance.\",\"A robots.txt file is present at the site root.\",\"An XML sitemap is discoverable from the site root.\",\"Structured data markup is present on the page.\",\"Tracking tools were detected: Google Tag Manager.\",\"Conversational support appears to have a human escalation path.\"],\"ai\":{\"executive_summary\":\"The site is workable, but the highest-impact SEO, tracking, funnel, and customer-experience gaps should be tightened before further scaling.\",\"top_priorities\":[{\"title\":\"Conversion tracking appears incomplete\",\"why_it_matters\":\"Lead or ecommerce flows need conversion events to support attribution and optimization.\",\"action\":\"Track final lead, chat, and checkout conversion points with normalized event names.\"},{\"title\":\"Checkout flow shows friction risk\",\"why_it_matters\":\"Checkout complexity or weak trust signals can increase abandonment.\",\"action\":\"Reduce unnecessary fields, make guest checkout obvious, and surface trust cues near checkout CTAs.\"},{\"title\":\"Product-page persuasion is underdeveloped\",\"why_it_matters\":\"Product or offer pages need stronger copy, proof, and reassurance to convert search traffic.\",\"action\":\"Strengthen benefits, objections, proof, shipping, return copy, and structured data on product pages.\"}],\"quick_wins\":[\"Instrument the missing funnel events and validate them in a live analytics debugger.\",\"Give icon-only or image links a readable text alternative.\",\"Set the `<html lang=\\\"...\\\">` attribute to the primary page language.\",\"Audit non-essential third-party scripts and defer what is not critical.\"],\"content_strategy\":[\"Align title, H1, and supporting copy around one primary intent instead of broad generic wording.\"],\"analytics_strategy\":[\"If paid social matters for this funnel, add Meta Pixel and mirror the core conversion events there.\",\"Track the final conversion moments such as generate_lead, begin_checkout, purchase, or chatbot-qualified lead.\",\"Create a clear event map and push each funnel step into GTM or your analytics library with a normalized naming convention.\",\"Use one canonical event taxonomy across analytics, ad pixels, CRM handoffs, and server-side conversions to keep attribution clean.\"],\"competitor_outrank_reasons\":[],\"competitor_strategy\":[],\"ecommerce_strategy\":[\"Expand product copy around outcomes, objections, use cases, proof, shipping, and returns so the page sells before checkout begins.\",\"Trim checkout inputs, make guest checkout obvious, and surface secure-payment reassurance near the primary CTA.\",\"Test pricing anchors such as compare-at prices, bundles, or savings framing where commercially appropriate.\",\"Add Product schema with price, availability, brand, and review fields where possible.\"],\"chatbot_strategy\":[\"Back the chatbot with FAQ, policy, pricing, and troubleshooting content so responses stay accurate.\",\"Map conversation flows around high-intent paths such as pricing, returns, shipping, support, and qualified lead capture.\"],\"keyword_opportunities\":[\"Build or expand intent-matched sections around \\\"hair\\\" using original examples, objections, and decision-stage detail.\",\"Build or expand intent-matched sections around \\\"kokler\\\" using original examples, objections, and decision-stage detail.\",\"Build or expand intent-matched sections around \\\"herbal\\\" using original examples, objections, and decision-stage detail.\",\"Build or expand intent-matched sections around \\\"organic\\\" using original examples, objections, and decision-stage detail.\"],\"content_suggestions\":[\"Rewrite product or offer copy around benefits, objections, shipping, returns, and proof instead of surface-level feature language.\",\"Favor specific claims, examples, and practical language over generic marketing filler so the page feels useful and credible.\"],\"important_suggestions\":[\"Track final lead, chat, and checkout conversion points with normalized event names.\",\"Reduce unnecessary fields, make guest checkout obvious, and surface trust cues near checkout CTAs.\",\"Strengthen benefits, objections, proof, shipping, return copy, and structured data on product pages.\",\"Fix the analytics event map before judging content performance so attribution is based on real conversion data.\"],\"growth_plan\":[{\"week\":\"Week 1\",\"focus\":\"Fix technical SEO and indexability\",\"tasks\":[\"Resolve the highest-severity crawlability and metadata issues on the audited money pages first.\",\"Fix canonical, noindex, robots.txt, sitemap, title, and meta description gaps before expanding content.\",\"Re-run the audit after deployment so the technical baseline is verified, not assumed.\"],\"goal\":\"Make the site crawlable, indexable, and technically consistent.\"},{\"week\":\"Week 2\",\"focus\":\"Repair tracking and conversion measurement\",\"tasks\":[\"Deploy or validate GA4 or GTM on all key templates and confirm the base pageview is firing.\",\"Map and implement the missing conversion events so form, chat, cart, and checkout actions are measurable.\",\"Test events in a live debugger and document a single naming convention for reporting.\"],\"goal\":\"Make traffic and conversion data reliable enough to guide the next decisions.\"},{\"week\":\"Week 3\",\"focus\":\"Upgrade core page content and publish supporting assets\",\"tasks\":[\"Rewrite the weakest titles, descriptions, H1s, and H2 structures on the pages with the biggest content gaps.\",\"Publish or expand supporting pages around the top keyword opportunities surfaced in the audit.\",\"Use competitor and crawl findings to add proof, FAQs, internal links, and deeper subtopic coverage.\"],\"goal\":\"Increase topical depth, intent coverage, and internal authority flow.\"},{\"week\":\"Week 4\",\"focus\":\"Improve conversion, lead capture, and growth loops\",\"tasks\":[\"Improve product, cart, and checkout persuasion with clearer trust, shipping, return, and CTA copy.\",\"Trim visible checkout friction and test stronger pricing or offer framing where appropriate.\",\"Review conversion data weekly and prioritize the step with the largest drop-off.\"],\"goal\":\"Turn stronger visibility into more qualified leads, sales, or conversations.\"}],\"stakeholder_note\":\"Fix data integrity and crawl/index fundamentals first, then move into competitor-informed content expansion and funnel refinement so improvements compound instead of masking root causes.\",\"available\":false,\"source\":\"local-fallback\",\"error\":\"Provider returned error\"},\"content_lab\":{\"keyword_opportunities\":[\"Build or expand intent-matched sections around \\\"hair\\\" using original examples, objections, and decision-stage detail.\",\"Build or expand intent-matched sections around \\\"kokler\\\" using original examples, objections, and decision-stage detail.\",\"Build or expand intent-matched sections around \\\"herbal\\\" using original examples, objections, and decision-stage detail.\",\"Build or expand intent-matched sections around \\\"organic\\\" using original examples, objections, and decision-stage detail.\"],\"content_suggestions\":[\"Rewrite product or offer copy around benefits, objections, shipping, returns, and proof instead of surface-level feature language.\",\"Favor specific claims, examples, and practical language over generic marketing filler so the page feels useful and credible.\"],\"important_suggestions\":[\"Track final lead, chat, and checkout conversion points with normalized event names.\",\"Reduce unnecessary fields, make guest checkout obvious, and surface trust cues near checkout CTAs.\",\"Strengthen benefits, objections, proof, shipping, return copy, and structured data on product pages.\",\"Fix the analytics event map before judging content performance so attribution is based on real conversion data.\"],\"generator_defaults\":{\"page_type\":\"product page\",\"primary_keyword\":\"hair\",\"secondary_keywords\":[\"kokler\",\"herbal\",\"organic\",\"care\"],\"tone\":\"specific, persuasive, trustworthy\",\"target_word_count\":600,\"audience\":\"buyers comparing options\",\"brief\":\"Reduce buyer friction with clearer reassurance and stronger explanation of value.\"},\"crawl\":{\"enabled\":false,\"scope\":\"page\",\"limit\":1,\"pages_crawled\":1,\"failed_fetches\":0,\"summary\":{\"pages_analyzed\":1,\"missing_titles\":0,\"missing_descriptions\":0,\"missing_h1_pages\":1,\"thin_content_pages\":0,\"noindex_pages\":0,\"canonical_gaps\":0,\"average_word_count\":471,\"top_keywords\":[\"hair\",\"kokler\",\"herbal\",\"organic\",\"care\",\"body\",\"products\",\"cure\"],\"pages_with_most_gaps\":[{\"url\":\"https://kokler.in/\",\"title\":\"Kokler | Organic Hair & Body Care Products\",\"issue_count\":1,\"word_count\":471}]},\"top_keywords\":[\"hair\",\"kokler\",\"herbal\",\"organic\",\"care\",\"body\",\"products\",\"cure\"],\"pages\":[{\"url\":\"https://kokler.in/\",\"title\":\"Kokler | Organic Hair & Body Care Products\",\"status_code\":200,\"response_time_ms\":715,\"word_count\":471,\"h1_count\":0,\"h2_count\":2,\"internal_links\":28,\"keywords\":[\"hair\",\"kokler\",\"herbal\",\"organic\",\"care\",\"body\",\"products\",\"cure\"],\"missing_title\":false,\"missing_description\":false,\"missing_h1\":true,\"noindex\":false,\"canonical_missing\":false,\"thin_content\":false,\"issue_count\":1}]}}}', '98b5359a228b83ab972bc42cf8ec46dd2cb641b700405656', NULL, '2026-03-26 15:15:09');
INSERT INTO `seo_audits` (`id`, `account_id`, `user_id`, `url`, `score_overall`, `result_json`, `public_token`, `emailed_at`, `created_at`) VALUES
(21, 2, 7, 'https://ebrandist.com/', 92, '{\"target\":{\"requested_url\":\"https://ebrandist.com/\",\"final_url\":\"https://ebrandist.com/\",\"host\":\"ebrandist.com\",\"audited_at\":\"2026-03-27T05:03:27+00:00\",\"competitor_urls\":[]},\"response\":{\"status_code\":200,\"content_type\":\"text/html; charset=UTF-8\",\"response_time_ms\":3132,\"redirect_count\":0,\"html_size_kb\":157.3,\"headers\":{\"date\":\"Fri, 27 Mar 2026 05:03:19 GMT\",\"content-type\":\"text/html; charset=UTF-8\",\"vary\":\"Accept-Encoding\",\"x-powered-by\":\"PHP/8.3.19\",\"link\":[\"<https://ebrandist.com/wp-json/>; rel=\\\"https://api.w.org/\\\"\",\"<https://ebrandist.com/wp-json/wp/v2/pages/565>; rel=\\\"alternate\\\"; title=\\\"JSON\\\"; type=\\\"application/json\\\"\",\"<https://ebrandist.com/>; rel=shortlink\"],\"content-encoding\":\"gzip\",\"platform\":\"hostinger\",\"panel\":\"hpanel\",\"retry-after\":\"60\",\"content-security-policy\":\"upgrade-insecure-requests\",\"server\":\"hcdn\",\"alt-svc\":\"h3=\\\":443\\\"; ma=86400\",\"x-hcdn-request-id\":\"b695e4bdd8def4f02fe05f8d3299b307-mum-edge9\",\"x-hcdn-cache-status\":\"DYNAMIC\",\"x-hcdn-upstream-rt\":\"1.745\"}},\"metrics\":{\"page\":{\"title\":{\"text\":\"eBrandist - Best Digital Marketing Agency Delhi NCR | Growth Experts\",\"length\":68},\"description\":{\"text\":\"eBrandist is a top digital marketing agency in Delhi NCR, offering expert SEO, PPC, social media marketing, branding, and growth marketing strategies to scale your business.\",\"length\":173},\"canonical\":\"https://ebrandist.com/\",\"lang\":\"en-US\",\"viewport\":\"width=device-width, initial-scale=1, maximum-scale=5, viewport-fit=cover\",\"meta_robots\":\"index, follow, max-snippet:-1, max-video-preview:-1, max-image-preview:large\",\"x_robots_tag\":\"\",\"charset\":\"UTF-8\",\"h1\":[\"Your Growth-Focused Digital Marketing Agency\"],\"h2\":[\"Revenue-Driving Digital Marketing Agency In Delhi NCR\",\"Our Result-Driven Digital Marketing Services\",\"Why Choose eBrandist as your Digital Marketing Agency Delhi NCR?\",\"Industries we served\",\"Elevate Your Brand with eBrandist – A Premier Web Design & Digital Marketing Agency In Delhi NCR\",\"Let’s grow your business online! Contact us today for a FREE Website or Account Audit!\"],\"url\":\"https://ebrandist.com/\"},\"content\":{\"word_count\":662,\"paragraph_count\":22,\"heading_counts\":{\"h1\":1,\"h2\":6,\"h3\":8,\"h4\":2,\"h5\":15,\"h6\":0},\"text_excerpt\":\"eBrandist - Best Digital Marketing Agency Delhi NCR | Growth Experts Skip to content ABOUT SERVICES Website Development SEO Services Google Ads Facebook Marketing Shopify PPC Services PORTFOLIO CONTACT +91 9013609389Call or Whatsapp Now! ABOUT SERVICES Website Development SEO Ser...\",\"keywords\":[\"marketing\",\"digital\",\"agency\",\"delhi\",\"ncr\",\"ebrandist\",\"services\",\"growth\",\"seo\",\"website\",\"experts\",\"ppc\"]},\"media\":{\"total\":16,\"missing_alt\":13,\"missing_alt_samples\":[\"https://ebrandist.com/wp-content/uploads/2025/03/Consultative-sales-bro-768x768.png\",\"https://www.gstatic.com/partners/badge/images/2025/PartnerBadgeClickable.svg\",\"https://ebrandist.com/wp-content/uploads/2025/03/brand-creation-amico.svg\",\"https://ebrandist.com/wp-content/uploads/2025/03/005-ecommerce.png\",\"https://ebrandist.com/wp-content/uploads/2025/03/004-production.png\"],\"lazy_loaded\":11},\"links\":{\"total\":32,\"internal\":28,\"external\":4,\"nofollow\":0,\"empty_anchor_text\":5,\"internal_details\":[{\"url\":\"https://ebrandist.com/\",\"anchor\":\"\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/about/\",\"anchor\":\"ABOUT\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/website-development-company-delhi-ncr/\",\"anchor\":\"Website Development\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/seo-company-delhi-ncr/\",\"anchor\":\"SEO Services\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/ppc-company-delhi-ncr/\",\"anchor\":\"Google Ads\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/facebook-marketing-company-delhi-ncr/\",\"anchor\":\"Facebook Marketing\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/shopify-ppc-services/\",\"anchor\":\"Shopify PPC Services\",\"bucket\":\"product\"},{\"url\":\"https://ebrandist.com/portfolio/\",\"anchor\":\"PORTFOLIO\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/contact/\",\"anchor\":\"CONTACT\",\"bucket\":\"contact\"},{\"url\":\"https://ebrandist.com/\",\"anchor\":\"\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/about/\",\"anchor\":\"ABOUT\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/website-development-company-delhi-ncr/\",\"anchor\":\"Website Development\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/seo-company-delhi-ncr/\",\"anchor\":\"SEO Services\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/ppc-company-delhi-ncr/\",\"anchor\":\"Google Ads\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/facebook-marketing-company-delhi-ncr/\",\"anchor\":\"Facebook Marketing\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/shopify-ppc-services/\",\"anchor\":\"Shopify PPC Services\",\"bucket\":\"product\"},{\"url\":\"https://ebrandist.com/portfolio/\",\"anchor\":\"PORTFOLIO\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/contact/\",\"anchor\":\"CONTACT\",\"bucket\":\"contact\"},{\"url\":\"https://ebrandist.com/\",\"anchor\":\"\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/about/\",\"anchor\":\"About\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/portfolio/\",\"anchor\":\"Portfolio\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/blog/\",\"anchor\":\"Blog\",\"bucket\":\"blog\"},{\"url\":\"https://ebrandist.com/contact/\",\"anchor\":\"Contact\",\"bucket\":\"contact\"},{\"url\":\"https://ebrandist.com/website-development-company-delhi-ncr/\",\"anchor\":\"Website Development\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/seo-company-delhi-ncr/\",\"anchor\":\"SEO Services\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/ppc-company-delhi-ncr/\",\"anchor\":\"Google Ads\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/facebook-marketing-company-delhi-ncr/\",\"anchor\":\"Facebook Marketing\",\"bucket\":\"other\"},{\"url\":\"https://ebrandist.com/shopify-ppc-services/\",\"anchor\":\"Shopify PPC Services\",\"bucket\":\"product\"}],\"external_domains\":[\"wa.me\",\"www.google.com\"]},\"assets\":{\"script_files\":12,\"inline_scripts\":11,\"stylesheets\":29,\"style_blocks\":5,\"script_sources\":[\"https://ebrandist.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1\",\"https://ebrandist.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1\",\"https://ebrandist.com/wp-content/plugins/fluentform/assets/js/fluent-forms-elementor-widget.js?ver=6.1.17\",\"https://ebrandist.com/wp-content/plugins/fluentform/assets/js/form-submission.js?ver=6.1.17\",\"https://ebrandist.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.35.3\",\"https://ebrandist.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.35.3\",\"https://ebrandist.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3\",\"https://ebrandist.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.35.3\",\"https://ebrandist.com/wp-content/plugins/elementor/assets/lib/jquery-numerator/jquery-numerator.min.js?ver=0.2.1\",\"https://ebrandist.com/wp-content/themes/blocksy/static/bundle/main.js?ver=2.0.96\",\"https://ebrandist.com/wp-content/plugins/essential-addons-for-elementor-lite/assets/front-end/js/view/general.min.js?ver=6.5.11\",\"https://www.google.com/recaptcha/api.js?render=6LeZlfoqAAAAAFpOICm55fMQHe61v6HSC7z-G32V&ver=6.1.17\"]},\"enhancements\":{\"structured_data_count\":1,\"structured_data_types\":[\"ImageObject\",\"Organization\",\"ProfessionalService\",\"SearchAction\",\"WebPage\",\"WebSite\"],\"open_graph\":{\"present\":true,\"coverage\":{\"og:title\":true,\"og:description\":true,\"og:image\":true,\"og:url\":true}},\"twitter_cards\":{\"present\":true,\"coverage\":{\"twitter:card\":true,\"twitter:title\":true,\"twitter:description\":true}},\"favicon\":true},\"forms\":{\"total\":1,\"lead_forms\":1,\"search_forms\":0,\"email_fields\":1,\"phone_fields\":0,\"password_fields\":0,\"field_count\":8,\"sample_actions\":[],\"submit_texts\":[\"Submit Request\"]},\"tracking\":{\"tools\":[\"Google Analytics 4\"],\"events\":[],\"conversion_events\":[],\"data_layer_present\":false},\"commerce\":{\"is_product_like\":false,\"product_schema\":false,\"has_add_to_cart\":false,\"price_samples\":[],\"price_count\":0,\"cart_links\":0,\"checkout_links\":0,\"review_mentions\":true,\"trust_mentions\":false,\"shipping_mentions\":false,\"return_mentions\":false,\"guest_checkout_mentions\":false,\"coupon_mentions\":false,\"compare_at_price\":false,\"discount_mentions\":true,\"bundle_mentions\":false},\"chatbot\":{\"detected\":true,\"vendors\":[\"Crisp\"],\"lead_capture_ctas\":[\"+91 9013609389Call or Whatsapp Now!\",\"Submit Request\"],\"detected_intents\":[\"pricing\",\"demo\",\"contact sales\",\"support\",\"order tracking\"],\"knowledge_base_signals\":true,\"human_handoff\":true},\"buttons\":[\"+91 9013609389Call or Whatsapp Now!\",\"Menu\",\"Get a Free Consultation Today!\",\"Contact Now\",\"Submit Request\"],\"contact\":{\"emails\":[],\"phones\":[\"6479870087\",\"9013609389\"],\"whatsapp\":true}},\"checks\":{\"https\":true,\"robots_txt\":{\"found\":true,\"url\":\"https://ebrandist.com/robots.txt\",\"status\":200},\"sitemap\":{\"found\":true,\"url\":\"https://ebrandist.com/sitemap_index.xml\",\"status\":200}},\"crawl\":{\"enabled\":false,\"scope\":\"page\",\"limit\":1,\"pages_crawled\":1,\"failed_fetches\":0,\"summary\":{\"pages_analyzed\":1,\"missing_titles\":0,\"missing_descriptions\":0,\"missing_h1_pages\":0,\"thin_content_pages\":0,\"noindex_pages\":0,\"canonical_gaps\":0,\"average_word_count\":662,\"top_keywords\":[\"marketing\",\"digital\",\"agency\",\"delhi\",\"ncr\",\"ebrandist\",\"services\",\"growth\"],\"pages_with_most_gaps\":[{\"url\":\"https://ebrandist.com/\",\"title\":\"eBrandist - Best Digital Marketing Agency Delhi NCR | Growth Experts\",\"issue_count\":0,\"word_count\":662}]},\"top_keywords\":[\"marketing\",\"digital\",\"agency\",\"delhi\",\"ncr\",\"ebrandist\",\"services\",\"growth\"],\"pages\":[{\"url\":\"https://ebrandist.com/\",\"title\":\"eBrandist - Best Digital Marketing Agency Delhi NCR | Growth Experts\",\"status_code\":200,\"response_time_ms\":3132,\"word_count\":662,\"h1_count\":1,\"h2_count\":6,\"internal_links\":28,\"keywords\":[\"marketing\",\"digital\",\"agency\",\"delhi\",\"ncr\",\"ebrandist\",\"services\",\"growth\"],\"missing_title\":false,\"missing_description\":false,\"missing_h1\":false,\"noindex\":false,\"canonical_missing\":false,\"thin_content\":false,\"issue_count\":0}]},\"modules\":{\"analytics\":{\"score\":37,\"headline\":\"Tracking coverage has gaps that can distort attribution or hide conversion leaks.\",\"detected_tools\":[\"Google Analytics 4\"],\"detected_events\":[],\"conversion_events\":[],\"missing_events\":[\"generate_lead\",\"chat_start\",\"chatbot_lead\"],\"requires_conversion_tracking\":true,\"pages_checked\":[\"https://ebrandist.com/\"],\"findings\":[\"Detected tracking stack: Google Analytics 4.\",\"Meta Pixel was not detected on a site that appears to rely on lead generation or ecommerce actions.\",\"No explicit conversion event was detected even though the site shows lead or commerce intent.\",\"Expected funnel events appear to be missing: generate_lead, chat_start, chatbot_lead.\",\"Tracking libraries were found, but no explicit custom event calls were detected in the inspected markup.\"],\"recommendations\":[\"If paid social matters for this funnel, add Meta Pixel and mirror the core conversion events there.\",\"Track the final conversion moments such as generate_lead, begin_checkout, purchase, or chatbot-qualified lead.\",\"Create a clear event map and push each funnel step into GTM or your analytics library with a normalized naming convention.\",\"Audit the live data layer and add custom event instrumentation for forms, clicks, chat starts, and checkout steps.\",\"Use one canonical event taxonomy across analytics, ad pixels, CRM handoffs, and server-side conversions to keep attribution clean.\"],\"ai_recommendations\":[\"If paid social matters for this funnel, add Meta Pixel and mirror the core conversion events there.\",\"Track the final conversion moments such as generate_lead, begin_checkout, purchase, or chatbot-qualified lead.\",\"Create a clear event map and push each funnel step into GTM or your analytics library with a normalized naming convention.\",\"Audit the live data layer and add custom event instrumentation for forms, clicks, chat starts, and checkout steps.\"]},\"ecommerce\":{\"applicable\":false,\"score\":null,\"headline\":\"No strong ecommerce signals were detected on the audited page set.\",\"pages\":{\"product\":{\"found\":false,\"url\":\"https://ebrandist.com/store\",\"status\":404},\"cart\":{\"found\":false,\"url\":\"https://ebrandist.com/cart\",\"status\":404},\"checkout\":{\"found\":false,\"url\":\"https://ebrandist.com/checkout\",\"status\":404},\"pricing\":{\"found\":false,\"url\":\"https://ebrandist.com/pricing\",\"status\":0},\"contact\":{\"found\":false,\"url\":\"https://ebrandist.com/contact/\",\"status\":0},\"faq\":{\"found\":false,\"url\":\"https://ebrandist.com/faq\",\"status\":0}},\"signals\":{\"price_samples\":[],\"compare_at_price\":false,\"discount_mentions\":false,\"bundle_mentions\":false},\"product_description_gaps\":[],\"checkout_friction_points\":[],\"pricing_signals\":[],\"findings\":[],\"recommendations\":[],\"ai_recommendations\":[]},\"chatbot\":{\"applicable\":true,\"score\":95,\"headline\":\"Customer-experience signals are solid, but intent coverage and lead routing can still be tightened.\",\"chatbot_detected\":true,\"detected_vendors\":[\"Crisp\"],\"response_accuracy_estimate\":\"High readiness\",\"lead_capture_effectiveness\":\"Strong\",\"knowledge_base_signals\":true,\"human_handoff_available\":true,\"known_intents\":[\"pricing\",\"demo\",\"contact sales\",\"support\",\"order tracking\"],\"missing_intents\":[\"implementation\"],\"lead_capture_ctas\":[\"+91 9013609389Call or Whatsapp Now!\",\"Submit Request\"],\"findings\":[\"Detected conversational stack: Crisp.\",\"The site does not clearly expose coverage for these intents: implementation.\"],\"recommendations\":[\"Train the chatbot and supporting knowledge base around the missing intents so visitors do not dead-end in chat.\",\"Map conversation flows around high-intent paths such as pricing, returns, shipping, support, and qualified lead capture.\"],\"ai_recommendations\":[\"Train the chatbot and supporting knowledge base around the missing intents so visitors do not dead-end in chat.\",\"Map conversation flows around high-intent paths such as pricing, returns, shipping, support, and qualified lead capture.\"]},\"competitor\":{\"status\":\"requires_input\",\"score\":null,\"headline\":\"Add competitor URLs to unlock keyword, depth, and proxy-authority comparisons.\",\"note\":\"Backlink comparison stays disabled until competitor pages are supplied.\",\"target_keywords\":[\"marketing\",\"digital\",\"agency\",\"delhi\",\"ncr\",\"ebrandist\",\"services\",\"growth\",\"seo\",\"website\",\"experts\",\"ppc\"],\"authority_proxy_note\":\"Authority is benchmarked with an on-page heuristic because no external backlink index is configured.\",\"comparison_rows\":[],\"outrank_reasons\":[],\"recommendations\":[],\"ai_recommendations\":[],\"ai_outrank_reasons\":[]}},\"issues\":[{\"severity\":\"high\",\"category\":\"analytics\",\"title\":\"Conversion tracking appears incomplete\",\"details\":\"Lead or ecommerce flows need conversion events to support attribution and optimization.\",\"recommendation\":\"Track final lead, chat, and checkout conversion points with normalized event names.\",\"evidence\":\"Detected conversion events: \",\"penalty\":16,\"how_to_fix\":[\"Create an event map for every critical action in the funnel, then implement each event where that action actually completes.\",\"Pass the same event names into analytics, ads, and CRM workflows so reporting stays consistent.\",\"Validate each event in a live debugger using the real funnel path before calling the setup complete.\"],\"example_fix\":\"gtag(\'event\', \'generate_lead\', {});\\ngtag(\'event\', \'chat_start\', {});\\ngtag(\'event\', \'chatbot_lead\', {});\"},{\"severity\":\"high\",\"category\":\"media\",\"title\":\"Some images are missing alt text\",\"details\":\"Alt text improves accessibility and helps image search understand page assets.\",\"recommendation\":\"Add descriptive alt text to meaningful images and leave decorative assets empty on purpose.\",\"evidence\":\"Missing alt text on 13 of 16 images.\",\"penalty\":10,\"how_to_fix\":[\"Write concise alt text for every meaningful image based on what the user needs to understand from it.\",\"Leave decorative images with empty alt text on purpose instead of stuffing keywords into them.\",\"Update the CMS media library or template so the missing-alt pattern does not repeat on future pages.\"],\"example_fix\":\"Example alt text: `SEO audit dashboard showing crawl issues and recommended fixes`\"},{\"severity\":\"medium\",\"category\":\"analytics\",\"title\":\"Funnel events appear to be missing\",\"details\":\"Missing event steps make it hard to diagnose where visitors drop out of the funnel.\",\"recommendation\":\"Instrument the missing funnel events and validate them in a live analytics debugger.\",\"evidence\":\"Missing events: generate_lead, chat_start, chatbot_lead\",\"penalty\":12,\"how_to_fix\":[\"Create an event map for every critical action in the funnel, then implement each event where that action actually completes.\",\"Pass the same event names into analytics, ads, and CRM workflows so reporting stays consistent.\",\"Validate each event in a live debugger using the real funnel path before calling the setup complete.\"],\"example_fix\":\"gtag(\'event\', \'generate_lead\', {});\\ngtag(\'event\', \'chat_start\', {});\\ngtag(\'event\', \'chatbot_lead\', {});\"},{\"severity\":\"medium\",\"category\":\"metadata\",\"title\":\"Title length is outside the ideal range\",\"details\":\"Titles that are too short or too long reduce clarity in search results.\",\"recommendation\":\"Aim for a focused title between 30 and 60 characters.\",\"evidence\":\"Title length: 68 characters.\",\"penalty\":7,\"how_to_fix\":[\"Write a single 30 to 60 character title that leads with the main topic and adds the brand only if space remains.\",\"Place the tag inside the page head and make sure no duplicate title tags are being injected by the CMS or template.\",\"Re-check the rendered source after publishing so the final HTML contains the exact title you intended.\"],\"example_fix\":\"<title>Your Growth-Focused Digital Marketing Agency | Ebrandist</title>\"},{\"severity\":\"medium\",\"category\":\"metadata\",\"title\":\"Meta description length is off target\",\"details\":\"Poor snippet length reduces message control in SERPs.\",\"recommendation\":\"Keep the description concise and informative, ideally 140 to 160 characters.\",\"evidence\":\"Description length: 173 characters.\",\"penalty\":5,\"how_to_fix\":[\"Write one unique 140 to 160 character description that explains the page value and intent clearly.\",\"Mention the core topic once, add a concrete benefit, and end with a soft action or trust cue.\",\"Place it in the head and preview the final length before publishing.\"],\"example_fix\":\"<meta name=\\\"description\\\" content=\\\"Get Your Growth-Focused Digital Marketing Agency with clear next steps, practical fixes, and a smoother path to stronger visibility, cleaner tracking, and\\\">\"},{\"severity\":\"medium\",\"category\":\"media\",\"title\":\"Some links have empty anchor text\",\"details\":\"Empty links weaken accessibility and reduce topical relevance signals.\",\"recommendation\":\"Give icon-only or image links a readable text alternative.\",\"evidence\":\"Empty anchor count: 5\",\"penalty\":5,\"how_to_fix\":[\"Find icon-only or empty links in the template and replace them with readable anchor text or an accessible label.\",\"If the link is an image, give the image meaningful alt text so the destination still has context.\",\"Re-test with a DOM inspector to confirm no empty anchors remain in the rendered markup.\"],\"example_fix\":\"<a href=\\\"/contact\\\">Contact sales</a>\"},{\"severity\":\"medium\",\"category\":\"chatbot\",\"title\":\"Important chatbot or support intents are not clearly covered\",\"details\":\"Visitors need clear support for the questions they ask most often.\",\"recommendation\":\"Train the chatbot and supporting knowledge base around the missing intents.\",\"evidence\":\"Missing intents: implementation\",\"penalty\":3,\"how_to_fix\":[\"List the missing intents and create direct answers for each one in the chatbot, FAQ, or help content.\",\"Link those intents to the right destination, such as pricing, returns, support, or contact-sales pages.\",\"Review real conversations weekly so new missing intents are added before they become dead ends.\"],\"example_fix\":\"Create chatbot or FAQ coverage for: implementation\"}],\"scores\":{\"overall\":92,\"grade\":\"A\",\"categories\":{\"crawlability\":100,\"metadata\":88,\"content\":100,\"media\":85,\"enhancements\":100,\"analytics\":72,\"competition\":null,\"ecommerce\":null,\"chatbot\":97},\"issue_summary\":{\"critical\":0,\"high\":2,\"medium\":5,\"low\":0}},\"highlights\":[\"The page resolves successfully with HTTP 200.\",\"The audited URL resolves over HTTPS.\",\"The page uses a single H1 heading.\",\"The page has enough body copy to support topical relevance.\",\"A robots.txt file is present at the site root.\",\"An XML sitemap is discoverable from the site root.\",\"Structured data markup is present on the page.\",\"Tracking tools were detected: Google Analytics 4.\",\"Conversational support appears to have a human escalation path.\"],\"ai\":{\"executive_summary\":\"The site is workable, but the highest-impact SEO, tracking, funnel, and customer-experience gaps should be tightened before further scaling.\",\"top_priorities\":[{\"title\":\"Conversion tracking appears incomplete\",\"why_it_matters\":\"Lead or ecommerce flows need conversion events to support attribution and optimization.\",\"action\":\"Track final lead, chat, and checkout conversion points with normalized event names.\"},{\"title\":\"Some images are missing alt text\",\"why_it_matters\":\"Alt text improves accessibility and helps image search understand page assets.\",\"action\":\"Add descriptive alt text to meaningful images and leave decorative assets empty on purpose.\"},{\"title\":\"Funnel events appear to be missing\",\"why_it_matters\":\"Missing event steps make it hard to diagnose where visitors drop out of the funnel.\",\"action\":\"Instrument the missing funnel events and validate them in a live analytics debugger.\"}],\"quick_wins\":[\"Instrument the missing funnel events and validate them in a live analytics debugger.\",\"Aim for a focused title between 30 and 60 characters.\",\"Keep the description concise and informative, ideally 140 to 160 characters.\",\"Give icon-only or image links a readable text alternative.\",\"Train the chatbot and supporting knowledge base around the missing intents.\"],\"content_strategy\":[\"Align title, H1, and supporting copy around one primary intent instead of broad generic wording.\"],\"analytics_strategy\":[\"If paid social matters for this funnel, add Meta Pixel and mirror the core conversion events there.\",\"Track the final conversion moments such as generate_lead, begin_checkout, purchase, or chatbot-qualified lead.\",\"Create a clear event map and push each funnel step into GTM or your analytics library with a normalized naming convention.\",\"Audit the live data layer and add custom event instrumentation for forms, clicks, chat starts, and checkout steps.\"],\"competitor_outrank_reasons\":[],\"competitor_strategy\":[],\"ecommerce_strategy\":[],\"chatbot_strategy\":[\"Train the chatbot and supporting knowledge base around the missing intents so visitors do not dead-end in chat.\",\"Map conversation flows around high-intent paths such as pricing, returns, shipping, support, and qualified lead capture.\"],\"keyword_opportunities\":[\"Build or expand intent-matched sections around \\\"marketing\\\" using original examples, objections, and decision-stage detail.\",\"Build or expand intent-matched sections around \\\"digital\\\" using original examples, objections, and decision-stage detail.\",\"Build or expand intent-matched sections around \\\"agency\\\" using original examples, objections, and decision-stage detail.\",\"Build or expand intent-matched sections around \\\"delhi\\\" using original examples, objections, and decision-stage detail.\"],\"content_suggestions\":[\"Turn missing chatbot intents into FAQ blocks, support content, or sales-enablement sections that reduce dead-end conversations.\",\"Favor specific claims, examples, and practical language over generic marketing filler so the page feels useful and credible.\"],\"important_suggestions\":[\"Track final lead, chat, and checkout conversion points with normalized event names.\",\"Add descriptive alt text to meaningful images and leave decorative assets empty on purpose.\",\"Instrument the missing funnel events and validate them in a live analytics debugger.\",\"Fix the analytics event map before judging content performance so attribution is based on real conversion data.\"],\"growth_plan\":[{\"week\":\"Week 1\",\"focus\":\"Fix technical SEO and indexability\",\"tasks\":[\"Resolve the highest-severity crawlability and metadata issues on the audited money pages first.\",\"Fix canonical, noindex, robots.txt, sitemap, title, and meta description gaps before expanding content.\",\"Re-run the audit after deployment so the technical baseline is verified, not assumed.\"],\"goal\":\"Make the site crawlable, indexable, and technically consistent.\"},{\"week\":\"Week 2\",\"focus\":\"Repair tracking and conversion measurement\",\"tasks\":[\"Deploy or validate GA4 or GTM on all key templates and confirm the base pageview is firing.\",\"Map and implement the missing conversion events so form, chat, cart, and checkout actions are measurable.\",\"Test events in a live debugger and document a single naming convention for reporting.\"],\"goal\":\"Make traffic and conversion data reliable enough to guide the next decisions.\"},{\"week\":\"Week 3\",\"focus\":\"Upgrade core page content and publish supporting assets\",\"tasks\":[\"Rewrite the weakest titles, descriptions, H1s, and H2 structures on the pages with the biggest content gaps.\",\"Publish or expand supporting pages around the top keyword opportunities surfaced in the audit.\",\"Use competitor and crawl findings to add proof, FAQs, internal links, and deeper subtopic coverage.\"],\"goal\":\"Increase topical depth, intent coverage, and internal authority flow.\"},{\"week\":\"Week 4\",\"focus\":\"Improve conversion, lead capture, and growth loops\",\"tasks\":[\"Tighten landing-page CTAs, lead capture paths, and contact prompts on high-intent pages.\",\"Add or improve chatbot, FAQ, and human handoff flows for the missing support or sales intents.\",\"Review weekly lead quality and adjust page copy, form friction, and CTA placement based on actual behavior.\"],\"goal\":\"Turn stronger visibility into more qualified leads, sales, or conversations.\"}],\"stakeholder_note\":\"Fix data integrity and crawl/index fundamentals first, then move into competitor-informed content expansion and funnel refinement so improvements compound instead of masking root causes.\",\"available\":false,\"source\":\"local-fallback\",\"error\":\"Provider returned error\"},\"content_lab\":{\"keyword_opportunities\":[\"Build or expand intent-matched sections around \\\"marketing\\\" using original examples, objections, and decision-stage detail.\",\"Build or expand intent-matched sections around \\\"digital\\\" using original examples, objections, and decision-stage detail.\",\"Build or expand intent-matched sections around \\\"agency\\\" using original examples, objections, and decision-stage detail.\",\"Build or expand intent-matched sections around \\\"delhi\\\" using original examples, objections, and decision-stage detail.\"],\"content_suggestions\":[\"Turn missing chatbot intents into FAQ blocks, support content, or sales-enablement sections that reduce dead-end conversations.\",\"Favor specific claims, examples, and practical language over generic marketing filler so the page feels useful and credible.\"],\"important_suggestions\":[\"Track final lead, chat, and checkout conversion points with normalized event names.\",\"Add descriptive alt text to meaningful images and leave decorative assets empty on purpose.\",\"Instrument the missing funnel events and validate them in a live analytics debugger.\",\"Fix the analytics event map before judging content performance so attribution is based on real conversion data.\"],\"generator_defaults\":{\"page_type\":\"homepage\",\"primary_keyword\":\"marketing\",\"secondary_keywords\":[\"digital\",\"agency\",\"delhi\",\"ncr\"],\"tone\":\"clear, expert, human\",\"target_word_count\":800,\"audience\":\"high-intent visitors researching a solution\",\"brief\":\"Answer the missing support or sales intents directly in the copy.\"},\"crawl\":{\"enabled\":false,\"scope\":\"page\",\"limit\":1,\"pages_crawled\":1,\"failed_fetches\":0,\"summary\":{\"pages_analyzed\":1,\"missing_titles\":0,\"missing_descriptions\":0,\"missing_h1_pages\":0,\"thin_content_pages\":0,\"noindex_pages\":0,\"canonical_gaps\":0,\"average_word_count\":662,\"top_keywords\":[\"marketing\",\"digital\",\"agency\",\"delhi\",\"ncr\",\"ebrandist\",\"services\",\"growth\"],\"pages_with_most_gaps\":[{\"url\":\"https://ebrandist.com/\",\"title\":\"eBrandist - Best Digital Marketing Agency Delhi NCR | Growth Experts\",\"issue_count\":0,\"word_count\":662}]},\"top_keywords\":[\"marketing\",\"digital\",\"agency\",\"delhi\",\"ncr\",\"ebrandist\",\"services\",\"growth\"],\"pages\":[{\"url\":\"https://ebrandist.com/\",\"title\":\"eBrandist - Best Digital Marketing Agency Delhi NCR | Growth Experts\",\"status_code\":200,\"response_time_ms\":3132,\"word_count\":662,\"h1_count\":1,\"h2_count\":6,\"internal_links\":28,\"keywords\":[\"marketing\",\"digital\",\"agency\",\"delhi\",\"ncr\",\"ebrandist\",\"services\",\"growth\"],\"missing_title\":false,\"missing_description\":false,\"missing_h1\":false,\"noindex\":false,\"canonical_missing\":false,\"thin_content\":false,\"issue_count\":0}]}}}', 'dc6738e991d581a364895633e509bcc7ba214f547b483231', NULL, '2026-03-27 10:33:32');

-- --------------------------------------------------------

--
-- Table structure for table `services_catalog`
--

DROP TABLE IF EXISTS `services_catalog`;
CREATE TABLE `services_catalog` (
  `id` int(10) UNSIGNED NOT NULL,
  `service_key` varchar(60) NOT NULL,
  `label` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `services_catalog`
--

INSERT INTO `services_catalog` (`id`, `service_key`, `label`) VALUES
(1, 'campaigns', 'Campaigns'),
(2, 'landing_pages', 'Landing Pages'),
(3, 'seo_auditor', 'SEO Auditor'),
(4, 'reports', 'Reports'),
(5, 'sales_reports', 'Sales Reports'),
(6, 'lead_scoring', 'Lead Scoring'),
(7, 'spam_protection', 'Spam Protection');

-- --------------------------------------------------------

--
-- Table structure for table `spam_keyword_rules`
--

DROP TABLE IF EXISTS `spam_keyword_rules`;
CREATE TABLE `spam_keyword_rules` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED DEFAULT NULL,
  `keyword` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` enum('flag','block') COLLATE utf8mb4_unicode_ci DEFAULT 'flag',
  `blocked_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `spam_keyword_rules`
--

INSERT INTO `spam_keyword_rules` (`id`, `account_id`, `keyword`, `action`, `blocked_by`, `created_at`) VALUES
(1, NULL, '<script', 'block', NULL, '2026-03-10 05:11:58'),
(2, NULL, 'javascript:', 'block', NULL, '2026-03-10 05:11:58'),
(3, NULL, 'onclick=', 'block', NULL, '2026-03-10 05:11:58'),
(4, NULL, 'onerror=', 'block', NULL, '2026-03-10 05:11:58'),
(5, NULL, 'eval(', 'block', NULL, '2026-03-10 05:11:58'),
(6, NULL, '\'; drop', 'block', NULL, '2026-03-10 05:11:58'),
(7, NULL, 'union select', 'block', NULL, '2026-03-10 05:11:58'),
(8, NULL, 'casino', 'flag', NULL, '2026-03-10 05:11:58'),
(9, NULL, 'poker', 'flag', NULL, '2026-03-10 05:11:58'),
(10, NULL, 'viagra', 'flag', NULL, '2026-03-10 05:11:58'),
(11, NULL, 'cialis', 'flag', NULL, '2026-03-10 05:11:58'),
(12, NULL, 'crypto', 'flag', NULL, '2026-03-10 05:11:58'),
(13, NULL, 'wire transfer', 'flag', NULL, '2026-03-10 05:11:58'),
(14, NULL, 'make money fast', 'flag', NULL, '2026-03-10 05:11:58'),
(15, NULL, 'click here', 'flag', NULL, '2026-03-10 05:11:58'),
(16, NULL, '<script', 'block', NULL, '2026-03-13 04:02:20'),
(17, NULL, 'javascript:', 'block', NULL, '2026-03-13 04:02:20'),
(18, NULL, 'onclick=', 'block', NULL, '2026-03-13 04:02:20'),
(19, NULL, 'onerror=', 'block', NULL, '2026-03-13 04:02:20'),
(20, NULL, 'eval(', 'block', NULL, '2026-03-13 04:02:20'),
(21, NULL, '\'; drop', 'block', NULL, '2026-03-13 04:02:20'),
(22, NULL, 'union select', 'block', NULL, '2026-03-13 04:02:20'),
(23, NULL, 'casino', 'flag', NULL, '2026-03-13 04:02:20'),
(24, NULL, 'poker', 'flag', NULL, '2026-03-13 04:02:20'),
(25, NULL, 'viagra', 'flag', NULL, '2026-03-13 04:02:20'),
(26, NULL, 'cialis', 'flag', NULL, '2026-03-13 04:02:20'),
(27, NULL, 'crypto', 'flag', NULL, '2026-03-13 04:02:20'),
(28, NULL, 'wire transfer', 'flag', NULL, '2026-03-13 04:02:20'),
(29, NULL, 'make money fast', 'flag', NULL, '2026-03-13 04:02:20'),
(30, NULL, 'click here', 'flag', NULL, '2026-03-13 04:02:20');

-- --------------------------------------------------------

--
-- Table structure for table `usage_tracking`
--

DROP TABLE IF EXISTS `usage_tracking`;
CREATE TABLE `usage_tracking` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `billing_month` varchar(7) DEFAULT NULL,
  `domains_used` int(11) DEFAULT '0',
  `forms_created` int(11) DEFAULT '0',
  `leads_count` int(11) DEFAULT '0',
  `team_members_added` int(11) DEFAULT '0',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED DEFAULT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive','invited','suspended') COLLATE utf8mb4_unicode_ci DEFAULT 'invited',
  `email_verified` tinyint(1) DEFAULT '0',
  `last_login_at` datetime DEFAULT NULL,
  `last_login_ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invited_by` int(10) UNSIGNED DEFAULT NULL,
  `invited_at` datetime DEFAULT NULL,
  `activation_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_expires_at` datetime DEFAULT NULL,
  `two_fa_secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_fa_enabled` tinyint(1) DEFAULT '0',
  `preferences` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `account_id`, `role_id`, `first_name`, `last_name`, `email`, `password_hash`, `phone`, `avatar`, `designation`, `status`, `email_verified`, `last_login_at`, `last_login_ip`, `invited_by`, `invited_at`, `activation_token`, `reset_token`, `reset_expires_at`, `two_fa_secret`, `two_fa_enabled`, `preferences`, `created_at`, `updated_at`) VALUES
(1, NULL, 1, 'Leverage2', 'Admin', 'admin@leadpro.com', '$2y$10$hn0DS/1OK5aC5tCH/U8QJuf8iu0LGpSD6LNHtdepeahu/fD3nrPai', '', NULL, '', 'active', 1, '2026-03-27 17:24:22', '::1', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2026-03-09 11:02:28', '2026-03-27 17:24:22'),
(7, 2, 2, 'Sushant', 'Gupta', 'ebrandist@gmail.com', '$2y$10$nI857IO8n8SEjbSokDeL3.xzqBDlVdN47FIfvK4qndHAtlbHZj8HO', NULL, NULL, NULL, 'active', 1, '2026-03-27 16:33:41', '::1', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2026-03-10 07:07:51', '2026-03-27 16:33:41');

-- --------------------------------------------------------

--
-- Table structure for table `user_sessions`
--

DROP TABLE IF EXISTS `user_sessions`;
CREATE TABLE `user_sessions` (
  `id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `expires_at` datetime NOT NULL,
  `last_seen` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `account_plans`
--
ALTER TABLE `account_plans`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_account` (`account_id`),
  ADD KEY `plan_id` (`plan_id`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `account_subscriptions`
--
ALTER TABLE `account_subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_account` (`account_id`),
  ADD KEY `plan_id` (`plan_id`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `account_usage`
--
ALTER TABLE `account_usage`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_account_month` (`account_id`,`billing_month`);

--
-- Indexes for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `account_id` (`account_id`);

--
-- Indexes for table `billing_emails`
--
ALTER TABLE `billing_emails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_account_type` (`account_id`,`email_type`);

--
-- Indexes for table `campaigns`
--
ALTER TABLE `campaigns`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_account` (`account_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `owner_id` (`owner_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `campaign_knowledge_faqs`
--
ALTER TABLE `campaign_knowledge_faqs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_kf_campaign` (`campaign_id`);
ALTER TABLE `campaign_knowledge_faqs` ADD FULLTEXT KEY `ft_faq` (`question`,`answer`);

--
-- Indexes for table `campaign_knowledge_pages`
--
ALTER TABLE `campaign_knowledge_pages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_pg_campaign` (`campaign_id`),
  ADD KEY `idx_pg_status` (`status`);
ALTER TABLE `campaign_knowledge_pages` ADD FULLTEXT KEY `ft_pages` (`page_title`,`content`);

--
-- Indexes for table `campaign_knowledge_policies`
--
ALTER TABLE `campaign_knowledge_policies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_pol_campaign` (`campaign_id`);

--
-- Indexes for table `campaign_knowledge_pricing`
--
ALTER TABLE `campaign_knowledge_pricing`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_kp_campaign` (`campaign_id`);

--
-- Indexes for table `campaign_knowledge_profile`
--
ALTER TABLE `campaign_knowledge_profile`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_campaign_profile` (`campaign_id`);

--
-- Indexes for table `campaign_knowledge_services`
--
ALTER TABLE `campaign_knowledge_services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ks_campaign` (`campaign_id`),
  ADD KEY `idx_ks_active` (`is_active`);

--
-- Indexes for table `campaign_knowledge_usage`
--
ALTER TABLE `campaign_knowledge_usage`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ku_campaign` (`campaign_id`),
  ADD KEY `idx_ku_lead` (`lead_id`),
  ADD KEY `idx_ku_source` (`source_type`),
  ADD KEY `idx_ku_created` (`created_at`);

--
-- Indexes for table `campaign_pages`
--
ALTER TABLE `campaign_pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `account_slug` (`account_id`,`slug`),
  ADD KEY `idx_campaign` (`campaign_id`),
  ADD KEY `form_id` (`form_id`);

--
-- Indexes for table `campaign_templates`
--
ALTER TABLE `campaign_templates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `is_system` (`is_system`),
  ADD KEY `category` (`category`);

--
-- Indexes for table `domains`
--
ALTER TABLE `domains`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `account_domain` (`account_id`,`domain`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `email_domain_blocklist`
--
ALTER TABLE `email_domain_blocklist`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `account_domain` (`account_id`,`domain`),
  ADD KEY `blocked_by` (`blocked_by`);

--
-- Indexes for table `form_fields`
--
ALTER TABLE `form_fields`
  ADD PRIMARY KEY (`id`),
  ADD KEY `form_id` (`form_id`);

--
-- Indexes for table `invitations`
--
ALTER TABLE `invitations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `invited_by` (`invited_by`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invoice_number` (`invoice_number`),
  ADD KEY `plan_id` (`plan_id`),
  ADD KEY `idx_account_status` (`account_id`,`status`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `ip_blocklist`
--
ALTER TABLE `ip_blocklist`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `account_ip` (`account_id`,`ip_address`),
  ADD KEY `idx_ip` (`ip_address`),
  ADD KEY `blocked_by` (`blocked_by`);

--
-- Indexes for table `leads`
--
ALTER TABLE `leads`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reference_no` (`reference_no`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `form_id` (`form_id`),
  ADD KEY `domain_id` (`domain_id`),
  ADD KEY `assigned_to` (`assigned_to`),
  ADD KEY `idx_score` (`score`),
  ADD KEY `idx_ai_score` (`ai_score`),
  ADD KEY `idx_deleted` (`is_deleted`),
  ADD KEY `idx_country` (`country`),
  ADD KEY `idx_utm_source` (`utm_source`),
  ADD KEY `idx_utm_medium` (`utm_medium`),
  ADD KEY `idx_utm_campaign` (`utm_campaign`),
  ADD KEY `idx_city` (`city`),
  ADD KEY `idx_engagement` (`engagement_level`,`engagement_at`),
  ADD KEY `idx_campaign_id` (`campaign_id`),
  ADD KEY `idx_ai_intent` (`ai_intent`),
  ADD KEY `idx_ai_sentiment` (`ai_sentiment`),
  ADD KEY `idx_ai_category` (`ai_lead_category`);

--
-- Indexes for table `lead_ai_replies`
--
ALTER TABLE `lead_ai_replies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_lar_lead` (`lead_id`),
  ADD KEY `idx_lar_account` (`account_id`),
  ADD KEY `idx_lar_sent` (`was_sent`);

--
-- Indexes for table `lead_ai_results`
--
ALTER TABLE `lead_ai_results`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `lead_id` (`lead_id`);

--
-- Indexes for table `lead_comments`
--
ALTER TABLE `lead_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lead_id` (`lead_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_lc_type` (`comment_type`);

--
-- Indexes for table `lead_duplicates`
--
ALTER TABLE `lead_duplicates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_pair` (`lead_id_a`,`lead_id_b`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `lead_id_a` (`lead_id_a`),
  ADD KEY `lead_id_b` (`lead_id_b`);

--
-- Indexes for table `lead_emails_sent`
--
ALTER TABLE `lead_emails_sent`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_les_lead` (`lead_id`),
  ADD KEY `idx_les_account` (`account_id`);

--
-- Indexes for table `lead_forms`
--
ALTER TABLE `lead_forms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `form_token` (`form_token`),
  ADD UNIQUE KEY `account_slug` (`account_id`,`slug`),
  ADD KEY `domain_id` (`domain_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `lead_form_email_templates`
--
ALTER TABLE `lead_form_email_templates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_fet_form` (`form_id`),
  ADD KEY `idx_fet_type` (`type`);

--
-- Indexes for table `lead_imports`
--
ALTER TABLE `lead_imports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `form_id` (`form_id`);

--
-- Indexes for table `lead_merge_log`
--
ALTER TABLE `lead_merge_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `merged_by` (`merged_by`);

--
-- Indexes for table `lead_ownership_log`
--
ALTER TABLE `lead_ownership_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lead_id` (`lead_id`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `to_user_id` (`to_user_id`);

--
-- Indexes for table `lead_reminders`
--
ALTER TABLE `lead_reminders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lead_id` (`lead_id`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `user_id` (`user_id`,`is_done`,`remind_at`),
  ADD KEY `remind_at` (`remind_at`,`notified`,`is_done`);

--
-- Indexes for table `lead_score_rules`
--
ALTER TABLE `lead_score_rules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_account` (`account_id`);

--
-- Indexes for table `lead_values`
--
ALTER TABLE `lead_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lead_id` (`lead_id`),
  ADD KEY `field_id` (`field_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_unread` (`user_id`,`is_read`,`is_archived`,`created_at`),
  ADD KEY `idx_user_type` (`user_id`,`type`);

--
-- Indexes for table `notification_prefs`
--
ALTER TABLE `notification_prefs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `page_assets`
--
ALTER TABLE `page_assets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `uploaded_by` (`uploaded_by`);

--
-- Indexes for table `payment_gateways`
--
ALTER TABLE `payment_gateways`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `gateway_name` (`gateway_name`),
  ADD KEY `idx_enabled` (`is_enabled`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_account_default` (`account_id`,`is_default`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `module_action` (`module`,`action`);

--
-- Indexes for table `plan_services`
--
ALTER TABLE `plan_services`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_plan_service` (`plan_id`,`service_id`),
  ADD KEY `plan_services_ibfk_2` (`service_id`);

--
-- Indexes for table `platform_settings`
--
ALTER TABLE `platform_settings`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `pricing_plans`
--
ALTER TABLE `pricing_plans`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `idx_slug` (`slug`),
  ADD KEY `idx_active` (`is_active`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD PRIMARY KEY (`role_id`,`permission_id`),
  ADD KEY `permission_id` (`permission_id`);

--
-- Indexes for table `seo_audits`
--
ALTER TABLE `seo_audits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_sa_account` (`account_id`),
  ADD KEY `idx_sa_user` (`user_id`),
  ADD KEY `idx_sa_created` (`created_at`),
  ADD KEY `idx_sa_token` (`public_token`);

--
-- Indexes for table `services_catalog`
--
ALTER TABLE `services_catalog`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_service_key` (`service_key`);

--
-- Indexes for table `spam_keyword_rules`
--
ALTER TABLE `spam_keyword_rules`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `account_keyword` (`account_id`,`keyword`),
  ADD KEY `blocked_by` (`blocked_by`);

--
-- Indexes for table `usage_tracking`
--
ALTER TABLE `usage_tracking`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_account_month` (`account_id`,`billing_month`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `role_id` (`role_id`),
  ADD KEY `invited_by` (`invited_by`);

--
-- Indexes for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `account_plans`
--
ALTER TABLE `account_plans`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `account_subscriptions`
--
ALTER TABLE `account_subscriptions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `account_usage`
--
ALTER TABLE `account_usage`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `audit_log`
--
ALTER TABLE `audit_log`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=551;

--
-- AUTO_INCREMENT for table `billing_emails`
--
ALTER TABLE `billing_emails`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `campaigns`
--
ALTER TABLE `campaigns`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `campaign_knowledge_faqs`
--
ALTER TABLE `campaign_knowledge_faqs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `campaign_knowledge_pages`
--
ALTER TABLE `campaign_knowledge_pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `campaign_knowledge_policies`
--
ALTER TABLE `campaign_knowledge_policies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `campaign_knowledge_pricing`
--
ALTER TABLE `campaign_knowledge_pricing`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `campaign_knowledge_profile`
--
ALTER TABLE `campaign_knowledge_profile`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `campaign_knowledge_services`
--
ALTER TABLE `campaign_knowledge_services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `campaign_knowledge_usage`
--
ALTER TABLE `campaign_knowledge_usage`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `campaign_pages`
--
ALTER TABLE `campaign_pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `campaign_templates`
--
ALTER TABLE `campaign_templates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `domains`
--
ALTER TABLE `domains`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `email_domain_blocklist`
--
ALTER TABLE `email_domain_blocklist`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `form_fields`
--
ALTER TABLE `form_fields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `invitations`
--
ALTER TABLE `invitations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ip_blocklist`
--
ALTER TABLE `ip_blocklist`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `leads`
--
ALTER TABLE `leads`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `lead_ai_replies`
--
ALTER TABLE `lead_ai_replies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `lead_ai_results`
--
ALTER TABLE `lead_ai_results`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `lead_comments`
--
ALTER TABLE `lead_comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `lead_duplicates`
--
ALTER TABLE `lead_duplicates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lead_emails_sent`
--
ALTER TABLE `lead_emails_sent`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `lead_forms`
--
ALTER TABLE `lead_forms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `lead_form_email_templates`
--
ALTER TABLE `lead_form_email_templates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `lead_imports`
--
ALTER TABLE `lead_imports`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lead_merge_log`
--
ALTER TABLE `lead_merge_log`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lead_ownership_log`
--
ALTER TABLE `lead_ownership_log`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lead_reminders`
--
ALTER TABLE `lead_reminders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `lead_score_rules`
--
ALTER TABLE `lead_score_rules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `lead_values`
--
ALTER TABLE `lead_values`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `notification_prefs`
--
ALTER TABLE `notification_prefs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `page_assets`
--
ALTER TABLE `page_assets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_gateways`
--
ALTER TABLE `payment_gateways`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `plan_services`
--
ALTER TABLE `plan_services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `pricing_plans`
--
ALTER TABLE `pricing_plans`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `seo_audits`
--
ALTER TABLE `seo_audits`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `services_catalog`
--
ALTER TABLE `services_catalog`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=239;

--
-- AUTO_INCREMENT for table `spam_keyword_rules`
--
ALTER TABLE `spam_keyword_rules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `usage_tracking`
--
ALTER TABLE `usage_tracking`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `account_plans`
--
ALTER TABLE `account_plans`
  ADD CONSTRAINT `account_plans_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `account_plans_ibfk_2` FOREIGN KEY (`plan_id`) REFERENCES `pricing_plans` (`id`);

--
-- Constraints for table `account_subscriptions`
--
ALTER TABLE `account_subscriptions`
  ADD CONSTRAINT `account_subscriptions_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `account_subscriptions_ibfk_2` FOREIGN KEY (`plan_id`) REFERENCES `pricing_plans` (`id`);

--
-- Constraints for table `account_usage`
--
ALTER TABLE `account_usage`
  ADD CONSTRAINT `account_usage_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD CONSTRAINT `audit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `audit_log_ibfk_2` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `billing_emails`
--
ALTER TABLE `billing_emails`
  ADD CONSTRAINT `billing_emails_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `campaigns`
--
ALTER TABLE `campaigns`
  ADD CONSTRAINT `campaigns_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `campaigns_ibfk_2` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `campaigns_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `campaign_pages`
--
ALTER TABLE `campaign_pages`
  ADD CONSTRAINT `campaign_pages_ibfk_1` FOREIGN KEY (`campaign_id`) REFERENCES `campaigns` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `campaign_pages_ibfk_2` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `campaign_pages_ibfk_3` FOREIGN KEY (`form_id`) REFERENCES `lead_forms` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `domains`
--
ALTER TABLE `domains`
  ADD CONSTRAINT `domains_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `domains_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `email_domain_blocklist`
--
ALTER TABLE `email_domain_blocklist`
  ADD CONSTRAINT `email_domain_blocklist_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `email_domain_blocklist_ibfk_2` FOREIGN KEY (`blocked_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `form_fields`
--
ALTER TABLE `form_fields`
  ADD CONSTRAINT `form_fields_ibfk_1` FOREIGN KEY (`form_id`) REFERENCES `lead_forms` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `invitations`
--
ALTER TABLE `invitations`
  ADD CONSTRAINT `invitations_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `invitations_ibfk_2` FOREIGN KEY (`invited_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `invitations_ibfk_3` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);

--
-- Constraints for table `invoices`
--
ALTER TABLE `invoices`
  ADD CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `invoices_ibfk_2` FOREIGN KEY (`plan_id`) REFERENCES `pricing_plans` (`id`);

--
-- Constraints for table `ip_blocklist`
--
ALTER TABLE `ip_blocklist`
  ADD CONSTRAINT `ip_blocklist_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ip_blocklist_ibfk_2` FOREIGN KEY (`blocked_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `leads`
--
ALTER TABLE `leads`
  ADD CONSTRAINT `leads_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `leads_ibfk_2` FOREIGN KEY (`form_id`) REFERENCES `lead_forms` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `leads_ibfk_3` FOREIGN KEY (`domain_id`) REFERENCES `domains` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `leads_ibfk_4` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `lead_ai_results`
--
ALTER TABLE `lead_ai_results`
  ADD CONSTRAINT `lead_ai_results_ibfk_1` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lead_comments`
--
ALTER TABLE `lead_comments`
  ADD CONSTRAINT `lead_comments_ibfk_1` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lead_comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `lead_forms`
--
ALTER TABLE `lead_forms`
  ADD CONSTRAINT `lead_forms_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lead_forms_ibfk_2` FOREIGN KEY (`domain_id`) REFERENCES `domains` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lead_forms_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `lead_merge_log`
--
ALTER TABLE `lead_merge_log`
  ADD CONSTRAINT `lead_merge_log_ibfk_1` FOREIGN KEY (`merged_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `lead_score_rules`
--
ALTER TABLE `lead_score_rules`
  ADD CONSTRAINT `lead_score_rules_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lead_values`
--
ALTER TABLE `lead_values`
  ADD CONSTRAINT `lead_values_ibfk_1` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lead_values_ibfk_2` FOREIGN KEY (`field_id`) REFERENCES `form_fields` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notification_prefs`
--
ALTER TABLE `notification_prefs`
  ADD CONSTRAINT `notification_prefs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD CONSTRAINT `payment_methods_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `plan_services`
--
ALTER TABLE `plan_services`
  ADD CONSTRAINT `plan_services_ibfk_1` FOREIGN KEY (`plan_id`) REFERENCES `pricing_plans` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `plan_services_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `services_catalog` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `spam_keyword_rules`
--
ALTER TABLE `spam_keyword_rules`
  ADD CONSTRAINT `spam_keyword_rules_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `spam_keyword_rules_ibfk_2` FOREIGN KEY (`blocked_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `usage_tracking`
--
ALTER TABLE `usage_tracking`
  ADD CONSTRAINT `usage_tracking_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  ADD CONSTRAINT `users_ibfk_3` FOREIGN KEY (`invited_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD CONSTRAINT `user_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
