<?php
require_once __DIR__ . '/config/auth.php';
require_permission('dashboard', 'view');
$user = auth_user();

$page_title    = 'Dashboard';
$page_subtitle = 'Welcome back, ' . $user['first_name'];
$active_nav    = 'dashboard';

$account_id = $user['account_id'];

// Handle reminder AJAX actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['_reminder_action'])) {
    header('Content-Type: application/json');
    if (!csrf_verify()) { echo json_encode(['ok'=>false]); exit; }
    require_once __DIR__ . '/config/reminders.php';
    $rid = (int)($_POST['reminder_id'] ?? 0);
    $act_r = $_POST['_reminder_action'];
    if ($act_r === 'done') {
        reminder_mark_done($rid, (int)$user['id']);
        echo json_encode(['ok'=>true]);
    } elseif ($act_r === 'snooze') {
        $mins = (int)($_POST['minutes'] ?? 60);
        reminder_snooze($rid, (int)$user['id'], $mins);
        echo json_encode(['ok'=>true]);
    } else {
        echo json_encode(['ok'=>false]);
    }
    exit;
}

// For super admin, show platform-wide stats
if (is_super_admin()) {
    $stats = [
        'accounts' => db_fetch('SELECT COUNT(*) AS n FROM accounts WHERE status = "active"')['n'] ?? 0,
        'users'    => db_fetch('SELECT COUNT(*) AS n FROM users WHERE status = "active"')['n'] ?? 0,
        'leads'    => 0,
        'forms'    => 0,
    ];
} else {
    $stats = [
        'leads'     => db_fetch('SELECT COUNT(*) AS n FROM leads WHERE account_id = ?', 'i', $account_id)['n'] ?? 0,
        'forms'     => db_fetch('SELECT COUNT(*) AS n FROM lead_forms WHERE account_id = ?', 'i', $account_id)['n'] ?? 0,
        'domains'   => db_fetch('SELECT COUNT(*) AS n FROM domains WHERE account_id = ?', 'i', $account_id)['n'] ?? 0,
        'team'      => db_fetch('SELECT COUNT(*) AS n FROM users WHERE account_id = ? AND status = "active"', 'i', $account_id)['n'] ?? 0,
        'campaigns' => db_fetch('SELECT COUNT(*) AS n FROM campaigns WHERE account_id = ? AND status != "archived"', 'i', $account_id)['n'] ?? 0,
    ];
}

// Recent campaigns (non-super)
$recent_campaigns = (!is_super_admin() && $account_id) ? db_fetch_all(
    "SELECT c.id, c.name, c.status, c.color,
            COUNT(DISTINCT cp.id) AS page_count,
            COUNT(DISTINCT l.id)  AS lead_count
     FROM campaigns c
     LEFT JOIN campaign_pages cp ON cp.campaign_id = c.id
     LEFT JOIN leads l ON l.campaign_id = c.id
     WHERE c.account_id = ? AND c.status != 'archived'
     GROUP BY c.id ORDER BY c.created_at DESC LIMIT 5",
    'i', $account_id
) : [];

// Recent team members
$recent_members = db_fetch_all(
    'SELECT u.first_name, u.last_name, u.email, u.status, u.created_at, r.label AS role_label, r.name AS role_name
     FROM users u JOIN roles r ON r.id = u.role_id
     WHERE u.account_id = ? ORDER BY u.created_at DESC LIMIT 5',
    'i', $account_id
);

// Recent audit activity
$recent_activity = db_fetch_all(
    'SELECT al.action, al.target, al.created_at, al.ip_address,
            u.first_name, u.last_name
     FROM audit_log al
     LEFT JOIN users u ON u.id = al.user_id
     WHERE al.account_id = ? OR (al.user_id = ? AND al.account_id IS NULL)
     ORDER BY al.created_at DESC LIMIT 8',
    'ii', $account_id, $user['id']
);

// Reminder engine — load pending and trigger throttled scan (non-super only)
$pending_reminders = [];
if (!is_super_admin() && $account_id) {
    require_once __DIR__ . '/config/reminders.php';
    try { reminder_process_account($account_id); } catch (\Throwable $e) {}
    $pending_reminders = reminder_get_pending((int)$user['id'], $account_id, 10);
}

include __DIR__ . '/layouts/header.php';

$role_badge = [
    'account_owner' => 'badge-info',
    'manager'       => 'badge-success',
    'agent'         => 'badge-warning',
    'super_admin'   => 'badge-purple',
];
$status_badge = [
    'active'   => 'badge-success',
    'inactive' => 'badge-gray',
    'invited'  => 'badge-warning',
    'suspended'=> 'badge-danger',
];
?>

<!-- Welcome Banner -->
<div style="background: linear-gradient(135deg, var(--b2) 0%, var(--b5-70) 100%);
            border-radius: var(--radius-lg); padding: 28px 32px; margin-bottom: 24px;
            display: flex; align-items: center; justify-content: space-between; overflow: hidden; position: relative;">
    <div style="position:absolute; top:-60px; right:-60px; width:200px; height:200px;
              background: radial-gradient(circle, var(--b4) 0%, transparent 70%); pointer-events:none;"></div>
    <div style="position:absolute; bottom:-0px; left:200px; width:450px; height:250px;
              background: radial-gradient(circle, var(--b3-70) 0%, transparent 70%); pointer-events:none;"></div>
    <div style="position:relative; z-index:1;">
        <div class="text-white text-xs mb-2 font-semibold">
            <?= format_dt(gmdate('Y-m-d H:i:s'), 'l, d F Y') ?>
        </div>
        <h2 class="text-white font-bold">
            Good <?php
        $local_hour = (int)format_dt(gmdate('Y-m-d H:i:s'), 'G');
        echo ($local_hour < 12) ? 'morning' : (($local_hour < 17) ? 'afternoon' : 'evening');
      ?>, <?= htmlspecialchars($user['first_name']) ?> 👋
        </h2>
        <p class="text-white">
            <span class="text-muted"><?= htmlspecialchars($user['role_label']) ?></span>
            <?php $tz = get_account_tz(); if ($tz !== 'UTC'): ?>
            &nbsp;·&nbsp; <span class="text-muted"><i class="hgi hgi-stroke hgi-clock-01 mr-1"></i><?= h($tz) ?></span>
            <?php endif; ?>
        </p>
    </div>
    <div style="position:relative; z-index:1;">
        <div style="width:64px; height:64px; border-radius:50%; background:rgba(255,255,255,.1);
                border: 2px solid rgba(255,255,255,.15); display:flex; align-items:center;
                justify-content:center; font-size:1.4rem; font-weight:700; color:#fff;">
            <?= strtoupper(substr($user['first_name'],0,1) . substr($user['last_name'],0,1)) ?>
        </div>
    </div>
</div>

<!-- Stats Grid -->
<div class="grid grid-cols-4 gap-4 mb-6">
    <?php
  if (is_super_admin()):
    $cards = [
      ['Accounts',      $stats['accounts'], 'card-b2',  'user-multiple'],
      ['Active Users',  $stats['users'],    'card-b3',  'user-multiple-02'],
      ['Total Leads',   0,                  'card-b4',  'user-account'],
      ['System',        'OK',               'card-b5',  'computer-settings'],
    ];
  else:
    $cards = [
      ['Total Leads',  $stats['leads'],     'card-b2',  'user-account'],
      ['Active Forms', $stats['forms'],     'card-b3',  'database-01'],
      ['Campaigns',    $stats['campaigns'], 'card-b4',  'megaphone-02'],
      ['Team Members', $stats['team'],      'card-b5',  'user-multiple-02'],
    ];
  endif;
  foreach ($cards as [$label, $val, $color, $icon]):
  ?>

    <div class="card card-stat <?= $color ?>">        
        <div>
            <div class="card-label"><?= $label ?></div>
            <div class="card-value mt-1"><?= $val ?></div>
        </div>
        <i class="hgi hgi-stroke hgi-<?= $icon ?>"></i>
    </div>

    <?php endforeach; ?>
</div>


<!-- Reminders Widget -->
<div class="card mb-6 border-0 border-l3 border-l-warning">
    <div class="card-header">
        <div class="flex gap-2 items-center">
            <i class="hgi hgi-stroke hgi-notification-01 text-warning"></i>
            <div class="card-title">Reminders <span class="badge badge-warning ml-1"><?= count($pending_reminders) ?> pending</span></div>
        </div>
        <a href="<?= APP_URL ?>/settings.php?tab=reminders" class="btn btn-sm btn-secondary">Settings</a>
    </div>
    <div id="reminderList">
        <?php foreach ($pending_reminders as $r):
          $typeColor = reminder_type_color($r['type']);
          $typeLabel = reminder_type_label($r['type']);
          $leadName  = trim($r['lead_name'] ?? '') ?: ('Lead #' . $r['reference_no']);
          $dueLabel  = strtotime($r['remind_at']) <= time() ? 'Now' : format_dt($r['remind_at'], 'd M, g:ia');
          $isPast    = strtotime($r['remind_at']) <= time();
        ?>
        <div class="card-body">
            <div id="rem_<?= $r['id'] ?>" style="display:flex;align-items:center;gap:10px;padding:10px 12px;border-bottom:1px solid var(--gray-100);transition:opacity .3s;">
                <span style="width:8px;height:8px;border-radius:50%;background:<?= $typeColor ?>;flex-shrink:0;"></span>
                <div style="flex:1;min-width:0;">
                    <a href="<?= APP_URL ?>/lead_view.php?id=<?= $r['lead_id'] ?>" style="font-size:.8rem;font-weight:600;color:var(--gray-800);text-decoration:none;"><?= h($leadName) ?></a>
                    <div style="font-size:.72rem;color:var(--gray-500);"><?= h($r['message'] ?? $typeLabel) ?></div>
                </div>
                <div style="flex-shrink:0;text-align:right;">
                    <div style="font-size:.7rem;font-weight:600;color:<?= $isPast ? '#ef4444' : 'var(--gray-400)' ?>;"><?= $dueLabel ?></div>
                    <span style="font-size:.65rem;background:<?= $typeColor ?>22;color:<?= $typeColor ?>;padding:1px 5px;border-radius:4px;"><?= h($typeLabel) ?></span>
                </div>
                <div style="display:flex;gap:4px;flex-shrink:0;">
                    <button onclick="reminderDone(<?= $r['id'] ?>)" title="Mark done" style="width:26px;height:26px;border:1px solid #bbf7d0;background:#f0fdf4;border-radius:6px;cursor:pointer;display:flex;align-items:center;justify-content:center;">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#16a34a" stroke-width="2.5">
                            <polyline points="20 6 9 17 4 12" />
                        </svg>
                    </button>
                    <div style="position:relative;">
                        <button onclick="toggleSnooze(<?= $r['id'] ?>)" title="Snooze" style="width:26px;height:26px;border:1px solid var(--gray-200);background:var(--gray-50);border-radius:6px;cursor:pointer;display:flex;align-items:center;justify-content:center;">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--gray-500)" stroke-width="2">
                                <circle cx="12" cy="12" r="10" />
                                <path d="M12 6v6l4 2" />
                            </svg>
                        </button>
                        <div id="snoozeMenu_<?= $r['id'] ?>" style="display:none;position:absolute;right:0;top:30px;background:#fff;border:1px solid var(--gray-200);border-radius:8px;box-shadow:0 4px 16px rgba(0,0,0,.1);z-index:99;min-width:130px;">
                            <?php foreach ([30=>'30 minutes',60=>'1 hour',180=>'3 hours',1440=>'Tomorrow'] as $mins => $label): ?>
                            <button onclick="reminderSnooze(<?= $r['id'] ?>, <?= $mins ?>)" style="display:block;width:100%;text-align:left;padding:8px 14px;font-size:.75rem;color:var(--gray-700);background:none;border:none;cursor:pointer;" onmouseover="this.style.background='var(--gray-50)'" onmouseout="this.style.background=''">
                                <?= $label ?>
                            </button>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<script>
    var _csrf_token = '<?= csrf_token() ?>';

    function reminderDone(id) {
        var el = document.getElementById('rem_' + id);
        if (el) el.style.opacity = '.4';
        fetch(window.location.href, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: '_reminder_action=done&reminder_id=' + id + '&_csrf=' + encodeURIComponent(_csrf_token)
        }).then(function() {
            if (el) el.remove();
            var list = document.getElementById('reminderList');
            if (list && !list.children.length) document.querySelector('.card[style*="f59e0b"]').remove();
        });
    }

    function reminderSnooze(id, mins) {
        var el = document.getElementById('rem_' + id);
        if (el) el.style.opacity = '.4';
        fetch(window.location.href, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: '_reminder_action=snooze&reminder_id=' + id + '&minutes=' + mins + '&_csrf=' + encodeURIComponent(_csrf_token)
        }).then(function() {
            if (el) el.remove();
        });
        closeAllSnoozeMenus();
    }

    function toggleSnooze(id) {
        closeAllSnoozeMenus();
        var m = document.getElementById('snoozeMenu_' + id);
        if (m) m.style.display = m.style.display === 'none' ? 'block' : 'none';
    }

    function closeAllSnoozeMenus() {
        document.querySelectorAll('[id^="snoozeMenu_"]').forEach(function(m) {
            m.style.display = 'none';
        });
    }
    document.addEventListener('click', function(e) {
        if (!e.target.closest('[onclick^="toggleSnooze"]')) closeAllSnoozeMenus();
    });
</script>


<div class="grid grid-cols-2 gap-4">

    <?php if (!is_super_admin() && $recent_campaigns): ?>
    <!-- Recent Campaigns -->
    <div class="card" style="margin-bottom:0;">
        <div class="card-header">
            <div>
                <div class="card-title">Campaigns</div>
                <div class="card-subtitle">Active &amp; recent</div>
            </div>
            <a href="<?= APP_URL ?>/campaigns.php" class="btn btn-secondary btn-sm ml-auto">View All</a>
        </div>
        <div class="card-body">
            <?php
              $cstatus_colors = [
                'draft'    => ['bg'=>'var(--color-info-bg)',    'text'=>'var(--color-info-text)'],
                'active'   => ['bg'=>'var(--color-success-bg)', 'text'=>'var(--color-success-text)'],
                'paused'   => ['bg'=>'var(--color-warning-bg)', 'text'=>'var(--color-warning-text)'],
                'archived' => ['bg'=>'var(--color-danger-bg)',  'text'=>'var(--color-danger-text)'],
              ];
              foreach ($recent_campaigns as $rc):
                $rcs = $cstatus_colors[$rc['status']] ?? $cstatus_colors['draft'];
            ?>
            <a href="<?= APP_URL ?>/campaign_view.php?id=<?= $rc['id'] ?>" class="row-item">
                <div class="icon-thumb bg-brand-50">
                    <i class="hgi hgi-stroke hgi-megaphone-02"></i>
                </div>
                <div style="flex:1;min-width:0;">
                    <div class="font-semibold">
                        <?= h($rc['name']) ?>
                    </div>
                    <div class="text-xs">
                        <?= $rc['page_count'] ?> page<?= $rc['page_count'] != 1 ? 's' : '' ?> &middot;
                        <?= $rc['lead_count'] ?> lead<?= $rc['lead_count'] != 1 ? 's' : '' ?>
                    </div>
                </div>
                <span class="badge" style="background:<?= $rcs['bg'] ?>;color:<?= $rcs['text'] ?>;">
                    <?= ucfirst($rc['status']) ?>
                </span>
            </a>
            <?php endforeach; ?>
        </div>
        <div class="card-footer">
            <a href="<?= APP_URL ?>/campaigns.php" class="btn btn-primary btn-sm"><i class="hgi hgi-stroke hgi-plus-sign"></i>New Campaign</a>
        </div>
    </div>
    <?php endif; ?>

    <!-- Recent Team Members -->
    <div class="card">
        <div class="card-header">
            <div>
                <div class="card-title">Team Members</div>
                <div class="card-subtitle">Most recently added</div>
            </div>
            <?php if (can('team', 'view')): ?>
            <a href="<?= APP_URL ?>/team.php" class="btn btn-secondary btn-sm">View All</a>
            <?php endif; ?>
        </div>
        
        <div class="card-body">
            <?php if (empty($recent_members)): ?>
            <div class="text-xs text-muted p-8 text-center">
                <p>No team members yet.</p>
                <?php if (can('team', 'invite')): ?>
                <a href="team.php" class="btn btn-sm mt-3">Invite someone</a>
                <?php endif; ?>
            </div>
            <?php else: ?>
            <div>
                <?php foreach ($recent_members as $m):
                    $initials = strtoupper(substr($m['first_name'],0,1) . substr($m['last_name'],0,1));
                    static $ci = 0;
                    $colors = ['var(--color-info-text)','var(--brand-500)','var(--brand-700)','var(--color-success-text)','var(--color-warning-text)'];
                    $color  = $colors[($ci++) % count($colors)];
                ?>
                <div class="row-item">
                    <div class="avatar" style="background:<?= $color ?>;"><?= $initials ?></div>
                    <div class="flex-1 min-w-0">
                        <div class="font-semibold">
                            <?= htmlspecialchars($m['first_name'] . ' ' . $m['last_name']) ?>
                        </div>
                        <div class="text-xs text-muted truncate"><?= htmlspecialchars($m['email']) ?></div>
                    </div>
                    <span class="badge <?= $role_badge[$m['role_name']] ?? 'badge-gray' ?>">
                        <?= htmlspecialchars($m['role_label']) ?>
                    </span>
                    <span class="badge <?= $status_badge[$m['status']] ?? 'badge-gray' ?>">
                        <span class="badge-dot"></span>
                        <?= ucfirst($m['status']) ?>
                    </span>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        <div class="card-footer">
            <a href="team.php" class="btn btn-sm"><i class="hgi hgi-stroke hgi-plus-sign"></i>Invite Members</a>
        </div>
        
    </div>

    <!-- Recent Activity -->
    <div class="card">
        <div class="card-header">
            <div>
                <div class="card-title">Recent Activity</div>
                <div class="card-subtitle">Latest audit events</div>
            </div>
        </div>
        
        <div class="card-body">
            <?php if (empty($recent_activity)): ?>
            <div class="text-xs text-muted p-8 text-center">
                No activity recorded yet.
            </div>
            <?php else: ?>
            <div>
                <?php foreach ($recent_activity as $a):
                    // Format action label nicely
                    $parts  = explode('.', $a['action']);
                    $module = ucfirst($parts[0] ?? '');
                    $event  = ucfirst(str_replace('_', ' ', $parts[1] ?? ''));
                    $actor  = trim(($a['first_name'] ?? '') . ' ' . ($a['last_name'] ?? '')) ?: 'System';
                    $time   = $a['created_at'] ? format_dt($a['created_at'], 'd M, g:ia') : '';
                ?>
                <div class="row-item">
                    <div class="icon-thumb bg-brand-50">
                        <i class="hgi hgi-stroke hgi-clock-01"></i>
                    </div>
                    <div class="flex-1">
                        <div>
                            <div class="text-xs"><?= htmlspecialchars($actor) ?></div>
                            <div class="text-2xs text-muted"><?= htmlspecialchars("$module: $event") ?></div>
                        </div>
                        <?php if ($a['target']): ?>
                        <div class="text-xs text-muted mt-1"><?= htmlspecialchars($a['target']) ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="badge badge-brand badge-sm"><?= $time ?></div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

</div>



<?php include __DIR__ . '/layouts/footer.php'; ?>