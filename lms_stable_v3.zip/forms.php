<?php
require_once __DIR__ . '/config/auth.php';
$user       = require_permission('forms', 'view');
$is_super   = is_super_admin();
$account_id = (int)($user['account_id'] ?? 0);

$page_title    = 'Lead Forms';
$page_subtitle = 'Build forms and embed them on any website';
$active_nav    = 'forms';

// ── Actions ────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { http_response_code(403); die('CSRF'); }
    $fid = (int)($_POST['form_id'] ?? 0);

    // Scope check
    $form = db_fetch('SELECT * FROM lead_forms WHERE id = ? AND account_id = ?', 'ii', $fid, $account_id);
    if ($form) switch ($_POST['action'] ?? '') {
        case 'toggle':
            db_query('UPDATE lead_forms SET is_active = 1 - is_active WHERE id = ?', 'i', $fid);
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Form status updated.'];
            break;
        case 'delete':
            require_permission('forms', 'delete');
            db_query('DELETE FROM lead_forms WHERE id = ?', 'i', $fid);
            audit('form.deleted', "form:{$fid}");
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Form deleted.'];
            break;
        case 'regen':
            $tok = bin2hex(random_bytes(32));
            db_query('UPDATE lead_forms SET form_token = ? WHERE id = ?', 'si', $tok, $fid);
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Embed token regenerated. Update your embed codes.'];
            break;
    }
    header('Location: ' . APP_URL . '/forms.php'); exit;
}

$flash     = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$search    = trim($_GET['q'] ?? '');
$dom_filter = (int)($_GET['domain_id'] ?? 0);

$sql = 'SELECT f.*, d.domain, d.label AS domain_label, d.verified_at AS domain_verified,
        u.first_name, u.last_name,
        (SELECT COUNT(*) FROM leads l WHERE l.form_id = f.id) AS lead_count,
        (SELECT COUNT(*) FROM form_fields ff WHERE ff.form_id = f.id) AS field_count
        FROM lead_forms f
        JOIN domains d ON d.id = f.domain_id
        LEFT JOIN users u ON u.id = f.created_by';
$types  = '';
$params = [];
if ($is_super) {
    $sql .= ' WHERE 1=1';
} else {
    $sql .= ' WHERE f.account_id = ?';
    $types  = 'i';
    $params = [$account_id];
}

if ($dom_filter) { $sql .= ' AND f.domain_id = ?'; $types .= 'i'; $params[] = $dom_filter; }
if ($search)     { $sql .= ' AND (f.name LIKE ? OR d.domain LIKE ?)'; $types .= 'ss'; $params[] = "%$search%"; $params[] = "%$search%"; }
$sql .= ' ORDER BY f.created_at DESC';

$forms   = db_fetch_all($sql, $types, ...$params);
$domains = $is_super
    ? db_fetch_all('SELECT id, domain, label, verified_at FROM domains WHERE is_active = 1 ORDER BY domain')
    : db_fetch_all('SELECT id, domain, label, verified_at FROM domains WHERE account_id = ? AND is_active = 1 ORDER BY domain', 'i', $account_id);

include __DIR__ . '/layouts/header.php';
?>

<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type'] ?>" data-auto-dismiss><?= $flash['msg'] ?></div>
<?php endif; ?>

<div class="page-header">
  <div>
    <h1 class="page-title"><?= $page_title ?></h1>
    <p class="page-subtitle"><?= count($forms) ?> form<?= count($forms) !== 1 ? 's' : '' ?></p>
  </div>
  <?php if (can('forms', 'create')): ?>
  <a href="<?= APP_URL ?>/form_builder.php" class="btn btn-primary">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
    New Form
  </a>
  <?php endif; ?>
</div>

<!-- Filters -->
<div class="card" style="margin-bottom:20px;">
  <div class="card-body" style="padding:14px 20px;">
    <form method="GET" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
      <div class="search-wrap" style="flex:1;max-width:280px;">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <input name="q" type="search" placeholder="Search forms…" value="<?= h($search) ?>" class="search-input">
      </div>
      <select name="domain_id" class="form-control" style="width:200px;" onchange="this.form.submit()">
        <option value="">All domains</option>
        <?php foreach ($domains as $d): ?>
        <option value="<?= $d['id'] ?>" <?= $dom_filter == $d['id'] ? 'selected' : '' ?>><?= h($d['domain']) ?></option>
        <?php endforeach; ?>
      </select>
      <?php if ($search || $dom_filter): ?>
      <a href="forms.php" class="btn btn-secondary btn-sm">Clear</a>
      <?php endif; ?>
    </form>
  </div>
</div>

<!-- Forms table -->
<div class="card">
  <?php if ($forms): ?>
  <div style="overflow-x:auto;">
    <table class="table">
      <thead>
        <tr><th>Form</th><th>Domain</th><th>Fields</th><th>Leads</th><th>Status</th><th>Created</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php foreach ($forms as $f): ?>
        <tr>
          <td>
            <div style="font-weight:600;color:var(--gray-800);margin-bottom:2px;"><?= h($f['name']) ?></div>
            <div style="font-size:.75rem;color:var(--gray-400);"><?= h($f['description'] ?: 'No description') ?></div>
          </td>
          <td>
            <span style="font-family:var(--font-mono);font-size:.78rem;color:var(--gray-500);"><?= h($f['domain']) ?></span>
            <?php if (empty($f['domain_verified'])): ?>
            <a href="<?= APP_URL ?>/domains.php" style="display:inline-flex;align-items:center;gap:3px;font-size:.65rem;background:#fff7ed;color:#c2410c;border:1px solid #fed7aa;padding:1px 6px;border-radius:4px;text-decoration:none;margin-left:4px;" title="Domain not verified — form submissions may be blocked">
              <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
              Unverified
            </a>
            <?php endif; ?>
          </td>
          <td style="font-weight:600;"><?= $f['field_count'] ?></td>
          <td>
            <a href="leads.php?form_id=<?= $f['id'] ?>" style="font-weight:700;color:var(--brand-600);text-decoration:none;">
              <?= $f['lead_count'] ?>
            </a>
          </td>
          <td>
            <span class="badge <?= $f['is_active'] ? 'badge-green' : 'badge-gray' ?>">
              <span class="badge-dot"></span><?= $f['is_active'] ? 'Active' : 'Inactive' ?>
            </span>
          </td>
          <td style="font-size:.75rem;color:var(--gray-400);"><?= format_dt($f['created_at'], 'd M Y') ?></td>
          <td>
            <div style="display:flex;gap:5px;flex-wrap:wrap;">
              <?php if (can('forms', 'edit')): ?>
              <a href="form_builder.php?id=<?= $f['id'] ?>" class="btn btn-secondary btn-sm">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                Edit
              </a>
              <?php endif; ?>
              <button class="btn btn-secondary btn-sm" onclick="openModal('embedModal<?= $f['id'] ?>')">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
                Embed
              </button>
              <?php if (can('forms', 'edit')): ?>
              <form method="POST" style="display:inline;">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="toggle">
                <input type="hidden" name="form_id" value="<?= $f['id'] ?>">
                <button class="btn btn-secondary btn-sm"><?= $f['is_active'] ? 'Disable' : 'Enable' ?></button>
              </form>
              <?php endif; ?>
              <?php if (can('forms', 'delete')): ?>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this form? All leads will be lost.')">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="form_id" value="<?= $f['id'] ?>">
                <button class="btn btn-danger btn-sm">Delete</button>
              </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php else: ?>
  <div class="empty-state">
    <div class="empty-state-icon">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
    </div>
    <div class="empty-state-title"><?= ($search || $dom_filter) ? 'No forms match your search' : 'No forms yet' ?></div>
    <div class="empty-state-desc">Create a form, embed it on any website, and start collecting leads automatically.</div>
    <?php if (can('forms', 'create') && !$search && !$dom_filter): ?>
    <a href="form_builder.php" class="btn btn-primary">Create your first form</a>
    <?php endif; ?>
  </div>
  <?php endif; ?>
</div>

<!-- Embed modals -->
<?php foreach ($forms as $f):
    $embedUrl   = APP_URL . '/embed/form.php?token=' . urlencode($f['form_token']);
    $loaderSrc  = APP_URL . '/embed/loader.js';
    $scriptTag  = '<script src="' . $loaderSrc . '" data-form="' . $f['form_token'] . '"></script>';
    $iframeTag  = '<iframe src="' . $embedUrl . '" width="100%" height="520" frameborder="0" scrolling="no" style="border:none;width:100%;"></iframe>';
    $wpNote     = 'WordPress strips &lt;script&gt; tags from page content. Use the iFrame method instead, or add the JS snippet via your theme&apos;s footer.php or a plugin like &quot;Insert Headers and Footers&quot;.';
?>
<div class="modal-backdrop" id="embedModal<?= $f['id'] ?>">
  <div class="modal" style="max-width:640px;">
    <div class="modal-header">
      <div class="modal-title">Embed: <?= h($f['name']) ?></div>
      <button class="modal-close" onclick="closeModal('embedModal<?= $f['id'] ?>')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
    <div class="modal-body">
      <?php if (empty($f['domain_verified'])): ?>
      <div style="background:#fff7ed;border:1.5px solid #fed7aa;border-radius:9px;padding:11px 14px;margin-bottom:14px;display:flex;gap:10px;align-items:flex-start;font-size:.78rem;color:#92400e;">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#d97706" stroke-width="2" style="flex-shrink:0;margin-top:1px;"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
        <div>
          <strong>Domain not verified:</strong> <code><?= h($f['domain']) ?></code><br>
          Submissions from this domain will be blocked until you <a href="<?= APP_URL ?>/domains.php" style="color:#c2410c;font-weight:700;">verify ownership via DNS</a>.
          The embed code below is correct — verification only affects submission acceptance.
        </div>
      </div>
      <?php endif; ?>
      <div class="tabs" style="margin-bottom:16px;">
        <button class="tab active" onclick="switchEmbedTab(this,'esc-iframe-<?= $f['id'] ?>')">iFrame <span style="font-size:.65rem;background:#dcfce7;color:#166534;padding:1px 5px;border-radius:4px;margin-left:3px;">Recommended</span></button>
        <button class="tab" onclick="switchEmbedTab(this,'esc-js-<?= $f['id'] ?>')">JavaScript</button>
        <button class="tab" onclick="switchEmbedTab(this,'esc-api-<?= $f['id'] ?>')">API Token</button>
      </div>

      <!-- iFrame tab (recommended, works everywhere including WordPress) -->
      <div id="esc-iframe-<?= $f['id'] ?>">
        <p style="font-size:.8rem;color:var(--gray-500);margin-bottom:10px;">Works everywhere — paste directly into your page, WordPress block, or HTML widget:</p>
        <div style="background:var(--gray-900);border-radius:10px;padding:14px 16px;font-family:var(--font-mono);font-size:.73rem;color:#e2e8f0;word-break:break-all;line-height:1.7;">
          <?= h($iframeTag) ?>
        </div>
        <button class="btn btn-primary btn-sm" style="margin-top:10px;" onclick="copyToClipboard(<?= json_encode($iframeTag) ?>,this)">Copy iFrame Code</button>
        <p style="font-size:.73rem;color:var(--gray-400);margin-top:10px;">💡 In WordPress: use a <strong>Custom HTML</strong> block and paste this code directly.</p>
      </div>

      <!-- JS tab -->
      <div id="esc-js-<?= $f['id'] ?>" style="display:none;">
        <div style="background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:10px 12px;font-size:.78rem;color:#92400e;margin-bottom:12px;">
          ⚠ <strong>WordPress users:</strong> <?= $wpNote ?>
        </div>
        <p style="font-size:.8rem;color:var(--gray-500);margin-bottom:10px;">Add before <code>&lt;/body&gt;</code> — do <strong>not</strong> add the <code>async</code> attribute:</p>
        <div style="background:var(--gray-900);border-radius:10px;padding:14px 16px;font-family:var(--font-mono);font-size:.73rem;color:#e2e8f0;word-break:break-all;line-height:1.7;">
          <?= h($scriptTag) ?>
        </div>
        <button class="btn btn-secondary btn-sm" style="margin-top:10px;" onclick="copyToClipboard(<?= json_encode($scriptTag) ?>,this)">Copy JS Code</button>
      </div>

      <!-- API tab -->
      <div id="esc-api-<?= $f['id'] ?>" style="display:none;">
        <p style="font-size:.8rem;color:var(--gray-500);margin-bottom:10px;">POST to <code><?= h(APP_URL) ?>/submit.php</code> with this token:</p>
        <div style="background:var(--gray-900);border-radius:10px;padding:14px 16px;font-family:var(--font-mono);font-size:.73rem;color:#a5f3fc;word-break:break-all;">
          <?= h($f['form_token']) ?>
        </div>
        <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap;">
          <button class="btn btn-secondary btn-sm" onclick="copyToClipboard(<?= json_encode($f['form_token']) ?>,this)">Copy Token</button>
          <?php if (can('forms', 'edit')): ?>
          <form method="POST" style="display:inline;" onsubmit="return confirm('Regenerate? All current embeds will break until updated.')">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="regen">
            <input type="hidden" name="form_id" value="<?= $f['id'] ?>">
            <button class="btn btn-danger btn-sm">Regenerate Token</button>
          </form>
          <?php endif; ?>
        </div>
      </div>

    </div>
  </div>
</div>
<?php endforeach; ?>

<script>
function switchEmbedTab(btn, tabId) {
  const modal = btn.closest('.modal');
  modal.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  // Hide all tab panes in this modal
  const allPanes = modal.querySelectorAll('[id^="esc-"]');
  allPanes.forEach(p => p.style.display = 'none');
  document.getElementById(tabId).style.display = '';
}
</script>

<?php include __DIR__ . '/layouts/footer.php'; ?>
