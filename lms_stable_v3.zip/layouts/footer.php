    </div><!-- /page-content -->

    <!-- App footer -->
    <?php
    $__show_credits = ps('footer_show_credits', '1') === '1';
    $__credits_text = ps('footer_credits_text', 'Powered by LeadPro');
    $__credits_url  = ps('footer_credits_url', '');
    $__support_url  = ps('app_support_url', '');
    $__docs_url     = ps('app_docs_url', '');
    $__footer_links_raw = ps('footer_links', '');
    $__extra_links  = [];
    if ($__footer_links_raw) {
        $__decoded = json_decode($__footer_links_raw, true);
        if (is_array($__decoded)) $__extra_links = $__decoded;
    }
    $__has_footer = $__show_credits || $__support_url || $__docs_url || $__extra_links;
    if ($__has_footer):
    ?>
    <footer class="bg-white p-3 flex-between text-xs text-muted">
        <span><?= ps_copyright() ?></span>
        <div>
            <?php if ($__support_url): ?>
            <a href="<?= htmlspecialchars($__support_url) ?>" target="_blank" onmouseover="this.style.color='var(--brand-500)'" onmouseout="this.style.color='var(--gray-400)'">Support</a>
            <?php endif; ?>
            <?php if ($__docs_url): ?>
            <a href="<?= htmlspecialchars($__docs_url) ?>" target="_blank" onmouseover="this.style.color='var(--brand-500)'" onmouseout="this.style.color='var(--gray-400)'">Docs</a>
            <?php endif; ?>
            <?php foreach ($__extra_links as $__fl): ?>
            <?php if (!empty($__fl['label']) && !empty($__fl['url'])): ?>
            <a href="<?= htmlspecialchars($__fl['url']) ?>" target="_blank" onmouseover="this.style.color='var(--brand-500)'" onmouseout="this.style.color='var(--gray-400)'"><?= htmlspecialchars($__fl['label']) ?></a>
            <?php endif; ?>
            <?php endforeach; ?>
            <?php if ($__show_credits && $__credits_text): ?>
            <?php if ($__credits_url): ?>
            <a href="<?= htmlspecialchars($__credits_url) ?>" target="_blank" onmouseover="this.style.color='var(--brand-500)'" onmouseout="this.style.color='var(--gray-400)'"><?= htmlspecialchars($__credits_text) ?></a>
            <?php else: ?>
            <span><?= htmlspecialchars($__credits_text) ?></span>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </footer>
    <?php endif; ?>

    </div><!-- /main-content -->
    </div><!-- /app-layout -->

    <script>
        // ---- Dropdown ----
        function toggleDropdown(id) {
            const el = document.getElementById(id);
            el.classList.toggle('open');
        }
        document.addEventListener('click', e => {
            document.querySelectorAll('.dropdown.open').forEach(d => {
                if (!d.contains(e.target)) d.classList.remove('open');
            });
        });

        // ---- Sidebar Toggle (desktop + mobile) ----
        (function() {
            const layout = document.querySelector('.app-layout');
            const sidebar = document.getElementById('sidebar');
            const toggleBtn = document.getElementById('sidebar-toggle-btn');
            const backdrop = document.getElementById('sidebarBackdrop');
            const PREF_KEY = 'lp_sidebar_collapsed';

            if (!sidebar || !toggleBtn) return;

            const isMobile = () => window.innerWidth <= 1024;

            // Restore desktop preference
            if (!isMobile() && localStorage.getItem(PREF_KEY) === '1') {
                layout.classList.add('sidebar-collapsed');
            }

            toggleBtn.addEventListener('click', () => {
                if (isMobile()) {
                    // Mobile: toggle .open on sidebar
                    const isOpen = sidebar.classList.toggle('open');
                    if (backdrop) backdrop.style.display = isOpen ? 'block' : 'none';
                } else {
                    // Desktop: toggle collapse
                    const collapsed = layout.classList.toggle('sidebar-collapsed');
                    localStorage.setItem(PREF_KEY, collapsed ? '1' : '0');
                }
            });

            // Backdrop click closes mobile sidebar
            if (backdrop) {
                backdrop.addEventListener('click', () => {
                    sidebar.classList.remove('open');
                    backdrop.style.display = 'none';
                });
            }

            // Close mobile sidebar on outside click
            document.addEventListener('click', e => {
                if (isMobile() && sidebar.classList.contains('open') &&
                    !sidebar.contains(e.target) && !toggleBtn.contains(e.target)) {
                    sidebar.classList.remove('open');
                    if (backdrop) backdrop.style.display = 'none';
                }
            });

            // Old menu-toggle kept for compatibility
            const oldToggle = document.getElementById('menu-toggle');
            if (oldToggle) oldToggle.addEventListener('click', () => toggleBtn.click());
        })();

        // ---- Modal helpers ----
        function openModal(id) {
            document.getElementById(id).classList.add('open');
        }

        function closeModal(id) {
            document.getElementById(id).classList.remove('open');
        }
        document.querySelectorAll('.modal-backdrop').forEach(m => {
            m.addEventListener('click', e => {
                if (e.target === m) m.classList.remove('open');
            });
        });
        document.addEventListener('keydown', e => {
            if (e.key === 'Escape') {
                document.querySelectorAll('.modal-backdrop.open').forEach(m => m.classList.remove('open'));
            }
        });

        // ---- Alert auto-dismiss ----
        document.querySelectorAll('.alert[data-auto-dismiss], .alert[data-dismiss]').forEach(a => {
            const t = parseInt(a.dataset.dismiss) || 4000;
            setTimeout(() => {
                a.style.transition = 'opacity .3s';
                a.style.opacity = '0';
            }, t);
            setTimeout(() => a.remove(), t + 350);
        });

        // ---- Tab switching ----
        document.querySelectorAll('[data-tab]').forEach(btn => {
            btn.addEventListener('click', () => {
                const target = btn.dataset.tab;
                const parent = btn.closest('[data-tabs]') || document;
                parent.querySelectorAll('[data-tab]').forEach(b => b.classList.remove('active'));
                parent.querySelectorAll('[data-tab-pane]').forEach(p => p.classList.add('hidden'));
                btn.classList.add('active');
                const pane = parent.querySelector('[data-tab-pane="' + target + '"]');
                if (pane) pane.classList.remove('hidden');
            });
        });

        // ---- Confirm dialog (simple) ----
        function confirmAction(msg, callback) {
            if (window.confirm(msg)) callback();
        }

        // ---- Copy to clipboard ----
        function copyToClipboard(text, btn) {
            navigator.clipboard.writeText(text).then(() => {
                const orig = btn.innerHTML;
                btn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20,6 9,17 4,12"/></svg> Copied!`;
                setTimeout(() => btn.innerHTML = orig, 1800);
            });
        }


        // Close dropdowns when clicking outside
        window.onclick = function(event) {
            if (!event.target.closest('.dropdown')) {
                document.querySelectorAll('.dropdown-menu').forEach(menu => {
                    menu.classList.remove('show');
                });
            }
        }
    </script>
    </body>

    </html>