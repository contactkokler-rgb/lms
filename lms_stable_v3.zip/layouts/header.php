<?php
// layouts/header.php
// Usage: $page_title, $page_subtitle, $active_nav must be set before including
require_once __DIR__ . '/../config/auth.php';
$user = require_auth();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php
  $__app_name  = ps('app_name', 'LeadPro');
  $__favicon   = ps('app_favicon_url', '');
  $__meta_desc = ps('meta_description', '');
  $__font_body = ps('font_body', 'Sora');
  $__font_mono = ps('font_mono', 'JetBrains Mono');
  ?>
  <title><?= htmlspecialchars($page_title ?? 'Dashboard') ?> — <?= htmlspecialchars($__app_name) ?></title>
  <?php if ($__meta_desc): ?>
  <meta name="description" content="<?= htmlspecialchars($__meta_desc) ?>">
  <?php endif; ?>
  <?php if ($__favicon): ?>
  <link rel="icon" href="<?= htmlspecialchars($__favicon) ?>">
  <?php endif; ?>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=<?= urlencode($__font_body) ?>:wght@300;400;500;600;700&family=<?= urlencode($__font_mono) ?>:wght@400;500&display=swap">
  <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/nova.css">
  <?= ps_theme_css() ?>
</head>
<body class="<?= $body_class ?? '' ?>">
<div class="app-layout">

  <!-- Sidebar -->
  <aside class="sidebar" id="sidebar">
    <a href="<?= APP_URL ?>/index.php" class="sidebar-logo">
      <?php
      $__logo_url  = ps('app_logo_url', '');
      $__badge_txt = ps('app_badge_text', 'Beta');
      if ($__logo_url): ?>
      <img src="<?= htmlspecialchars($__logo_url) ?>" alt="<?= htmlspecialchars($__app_name) ?>"
           style="height:28px;max-width:140px;object-fit:contain;flex-shrink:0;">
      <?php else: ?>
      <div class="sidebar-logo-mark">
        <i class="hgi hgi-stroke hgi-database-lightning"></i>
      </div>
      <span class="sidebar-logo-text text-md uppercase font-bold"><?= htmlspecialchars($__app_name) ?></span>
      <?php endif; ?>
      <?php if ($__badge_txt): ?>
      <span class="sidebar-logo-badge"><?= htmlspecialchars($__badge_txt) ?></span>
      <?php endif; ?>
    </a>

    <div class="sidebar-section">

      <?php if (can('dashboard', 'view')): ?>
      <a href="<?= APP_URL ?>/index.php" class="sidebar-item <?= ($active_nav ?? '') === 'dashboard' ? 'active' : '' ?>">
        <i class="hgi hgi-stroke hgi-dashboard-speed-02"></i>
        Dashboard
      </a>
      <?php endif; ?>

      <?php if (can('leads', 'view')): ?>
      <div class="sidebar-label">Leads</div>
      <a href="<?= APP_URL ?>/priority_inbox.php" class="sidebar-item <?= ($active_nav ?? '') === 'priority_inbox' ? 'active' : '' ?>">
        <i class="hgi hgi-stroke hgi-notification-01"></i>
        Priority Inbox
      </a>
      <a href="<?= APP_URL ?>/leads.php" class="sidebar-item <?= ($active_nav ?? '') === 'leads' ? 'active' : '' ?>">
        <i class="hgi hgi-stroke hgi-user-account"></i>
        All Leads
      </a>
      <a href="<?= APP_URL ?>/leads.php?filter=mine" class="sidebar-item <?= ($active_nav ?? '') === 'my_leads' ? 'active' : '' ?>">
        <i class="hgi hgi-stroke hgi-user-warning-02"></i>
        My Leads
      </a>
      <a href="<?= APP_URL ?>/kanban.php" class="sidebar-item <?= ($active_nav ?? '') === 'kanban' ? 'active' : '' ?>">
        <i class="hgi hgi-stroke hgi-kanban"></i>
        Kanban Board
      </a>
      <?php if (can('leads','create')): ?>
      <a href="<?= APP_URL ?>/import.php" class="sidebar-item <?= ($active_nav ?? '') === 'import' ? 'active' : '' ?>">
        <i class="hgi hgi-stroke hgi-file-import"></i>
        Import Leads
      </a>
      <?php endif; ?>
      <?php endif; ?>

      <?php if (can('leads','manage_score')): ?>
      <a href="<?= APP_URL ?>/score_rules.php" class="sidebar-item <?= ($active_nav ?? '') === 'score_rules' ? 'active' : '' ?>">
        <i class="hgi hgi-stroke hgi-star-circle"></i>
        Lead Scoring
      </a>
      <?php endif; ?>

      <?php if (can('leads', 'edit')): ?>
      <a href="<?= APP_URL ?>/spam.php" class="sidebar-item <?= ($active_nav ?? '') === 'spam' ? 'active' : '' ?>">
        <i class="hgi hgi-stroke hgi-web-protection"></i>
        Spam Protection
      </a>
      <?php endif; ?>
      <?php if (can('campaigns', 'view')): ?>
      <div class="sidebar-label">Campaigns</div>
      <a href="<?= APP_URL ?>/campaigns.php" class="sidebar-item <?= ($active_nav ?? '') === 'campaigns' ? 'active' : '' ?>">
        <i class="hgi hgi-stroke hgi-megaphone-02"></i>
        All Campaigns
      </a>
      <?php endif; ?>

      <?php if (can('forms', 'view')): ?>
      <div class="sidebar-label">Setup</div>
      <a href="<?= APP_URL ?>/forms.php" class="sidebar-item <?= ($active_nav ?? '') === 'forms' ? 'active' : '' ?>">
        <i class="hgi hgi-stroke hgi-database-01"></i>
        Forms
      </a>
      <a href="<?= APP_URL ?>/domains.php" class="sidebar-item <?= ($active_nav ?? '') === 'domains' ? 'active' : '' ?>">
        <i class="hgi hgi-stroke hgi-globe-02"></i>
        Domains
      </a>
      <?php endif; ?>
        
      <?php if (can('auditor', 'run')): ?>
      <div class="sidebar-label">Tools</div>
      <a href="<?= APP_URL ?>/seo_auditor.php" class="sidebar-item <?= ($active_nav ?? '') === 'seo_auditor' ? 'active' : '' ?>">
        <i class="hgi hgi-stroke hgi-search-visual"></i>
        Ai/SEO Audit
      </a>
      <?php endif; ?>

      <?php if (can('reports', 'view')): ?>
      <div class="sidebar-label">Analytics</div>
      <a href="<?= APP_URL ?>/reports.php" class="sidebar-item <?= ($active_nav ?? '') === 'reports' ? 'active' : '' ?>">
        <i class="hgi hgi-stroke hgi-chart-line-data-01"></i>
        Reports
      </a>
      <a href="<?= APP_URL ?>/sales_report.php" class="sidebar-item <?= ($active_nav ?? '') === 'sales_report' ? 'active' : '' ?>">
        <i class="hgi hgi-stroke hgi-chart-line-data-02"></i>
        Sales Performance
      </a>
      <?php endif; ?>

      <?php if (can('team', 'view')): ?>
      <div class="sidebar-label">Management</div>
      <a href="<?= APP_URL ?>/team.php" class="sidebar-item <?= ($active_nav ?? '') === 'team' ? 'active' : '' ?>">
        <i class="hgi hgi-stroke hgi-user-multiple-02"></i>
        Team
      </a>
      <?php endif; ?>

      <?php if (is_super_admin()): ?>
      <a href="<?= APP_URL ?>/roles.php" class="sidebar-item <?= ($active_nav ?? '') === 'roles' ? 'active' : '' ?>">
        <i class="hgi hgi-stroke hgi-user-settings-01"></i>
        Roles & Permissions
      </a>
      <?php endif; ?>

      <?php if (is_super_admin()): ?>
      <div class="sidebar-label">Platform</div>
      <a href="<?= APP_URL ?>/accounts.php" class="sidebar-item <?= ($active_nav ?? '') === 'accounts' ? 'active' : '' ?>">
        <i class="hgi hgi-stroke hgi-briefcase-06"></i>
        Accounts
      </a>
      <a href="<?= APP_URL ?>/template_manager.php" class="sidebar-item <?= ($active_nav ?? '') === 'template_manager' ? 'active' : '' ?>">
        <i class="hgi hgi-stroke hgi-artboard-tool"></i>
        Templates
      </a>
      <?php endif; ?>

      <?php if (can('settings', 'view')): ?>
      <a href="<?= APP_URL ?>/settings.php" class="sidebar-item <?= ($active_nav ?? '') === 'settings' ? 'active' : '' ?>">
        <i class="hgi hgi-stroke hgi-computer-settings"></i>
        Settings
      </a>
      <?php endif; ?>

    </div>

    <div class="sidebar-footer">
      <a href="<?= APP_URL ?>/settings.php" class="user-card">
        <div class="user-avatar" style="background: <?= user_color($user['id']) ?>;">
          <?php if ($user['avatar']): ?>
            <img src="<?= htmlspecialchars($user['avatar']) ?>" alt="">
          <?php else: ?>
            <?= strtoupper(substr($user['first_name'],0,1) . substr($user['last_name'],0,1)) ?>
          <?php endif; ?>
        </div>
        <div class="user-info">
          <div class="user-name"><?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></div>
          <div class="text-muted text-2xs mt-1"><?= htmlspecialchars($user['role_label']) ?></div>
        </div>
        <i class="hgi hgi-stroke hgi-arrow-right-01 text-white"></i>
      </a>
    </div>
  </aside>
  <!-- Mobile sidebar backdrop -->
  <div class="sidebar-backdrop" id="sidebarBackdrop"></div>

  <!-- Main -->
  <div class="main-content">
    <header class="top-header">
      <!-- Unified sidebar toggle: works on both desktop and mobile -->
      

      <div class="top-header-title">
        <h1><?= htmlspecialchars($page_title ?? 'Dashboard') ?></h1>
        <?php if (!empty($page_subtitle)): ?>
          <p><?= htmlspecialchars($page_subtitle) ?></p>
        <?php endif; ?>
      </div>

      <div class="header-actions">
                
        <?php if (!empty($user['account_plan'])): ?><span class="badge badge-brand"><?= $user['account_plan'] ?></span><?php endif; ?>
          
        <!-- User dropdown -->
        <div class="dropdown">
            <div class="avatar" onclick="this.nextElementSibling.classList.toggle('show')">
                <div class="avatar" style="background: <?= user_color($user['id']) ?>;"><?= strtoupper(substr($user['first_name'],0,1) . substr($user['last_name'],0,1)) ?></div>
            </div>

            <div class="dropdown-menu dropdown-menu-right" style="min-width: 240px;">
                <div class="p-3 mb-1">
                    <div class="font-bold text-primary"><?= htmlspecialchars($user['first_name']) ?></div>
                    <div class="text-xs text-muted"><?= htmlspecialchars($user['email']) ?></div>
                    <span class="badge badge-brand mt-3"><?= htmlspecialchars($user['role_label']) ?></span>
                </div>
                <div class="dropdown-divider"></div>
                <a href="<?= APP_URL ?>/settings.php?tab=profile" class="dropdown-item">
                    <i class="hgi hgi-stroke hgi-user-circle-02"></i>
                    My Profile
                </a>
                <a href="<?= APP_URL ?>/settings.php?tab=password" class="dropdown-item">
                    <i class="hgi hgi-stroke hgi-lock-password"></i>
                    Change Password
                </a>
                <div class="dropdown-divider"></div>
                <a href="<?= APP_URL ?>/logout.php" class="dropdown-item">
                    <i class="hgi hgi-stroke hgi-logout-05"></i>
                    Sign Out
                </a>
            </div>
        </div>
      </div>
    </header>

    <div class="page-content">
<?php

function user_color(int $id): string {
    $colors = ['var(--b1)','var(--b2)','var(--b3)','var(--b4)','var(--b5)','var(--success)','var(--danger)','var(--warning)'];
    return $colors[$id % count($colors)];
}
?>
