<?php
// 403.php can be included from auth.php which already loaded config
$__app_name  = function_exists('ps') ? ps('app_name', 'LeadPro') : 'LeadPro';
$__brand     = function_exists('ps') ? ps('brand_color_500', '#2563eb') : '#2563eb';
$__favicon   = function_exists('ps') ? ps('app_favicon_url', '') : '';
$__font      = function_exists('ps') ? ps('font_body', 'Sora') : 'Sora';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access Denied — <?= htmlspecialchars($__app_name) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=<?= urlencode($__font) ?>:wght@400;600;700&display=swap" rel="stylesheet">
    <?php if ($__favicon): ?>
    <link rel="icon" href="<?= htmlspecialchars($__favicon) ?>"><?php endif; ?>
    <link rel="stylesheet" href="assets/css/nova.css">
    <style>
        body {
            font-family: '<?= htmlspecialchars($__font) ?>', sans-serif;
            background: #f8fafc;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
        }

        .wrap {
            text-align: center;
            max-width: 400px;
            padding: 40px 20px;
        }
    </style>
    <?= ps_theme_css() ?>
</head>

<body>
    <div class="wrap">
        <div class="empty-state">
            <div class="empty-state-icon bg-danger-5 text-danger" style="background: var(--danger-10);">
                <i class="hgi hgi-stroke hgi-lock-computer"></i>
            </div>
            <div class="empty-state-title text-danger">Access Denied</div>
            <div class="empty-state-desc">You don't have permission to view this page. Contact your account owner if you think this is a mistake.</div>
            <a class="btn" href="<?= defined('APP_URL') ? APP_URL : '..' ?>/index.php">
                <i class="hgi hgi-stroke hgi-arrow-turn-backward"></i>
                Back to Dashboard
            </a>
        </div>
    </div>
</body>

</html>