<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Report Not Found — <?= htmlspecialchars($__app_name ?? 'LeadPro') ?></title>
<meta name="robots" content="noindex,nofollow">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#f1f5f9;color:#1e293b;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:24px}
.card{background:#fff;border:1.5px solid #e2e8f0;border-radius:16px;padding:48px 40px;max-width:440px;width:100%;text-align:center;box-shadow:0 4px 24px rgba(0,0,0,.06)}
.icon{font-size:48px;margin-bottom:20px}
h1{font-size:20px;font-weight:800;color:#0f172a;margin-bottom:10px}
p{font-size:14px;color:#64748b;line-height:1.7}
.brand{margin-top:32px;font-size:12px;color:#cbd5e1}
</style>
</head>
<body>
<div class="card">
  <div class="icon">🔍</div>
  <h1>Report Not Found</h1>
  <p>This audit report link is invalid or has expired.<br>Please check the link and try again, or ask for a new report link.</p>
  <div class="brand"><?= htmlspecialchars($__app_name ?? 'LeadPro') ?></div>
</div>
</body>
</html>