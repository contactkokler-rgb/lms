<?php
ob_start();

define('NO_SESSION', true);
require_once __DIR__ . '/config/config.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Form-Token');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_end_clean();
    http_response_code(200);
    exit;
}

function json_exit(array $data, int $code = 200): void {
    $json = json_encode($data);
    ob_end_clean();
    http_response_code($code);
    echo $json;
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_exit(['ok' => false, 'error' => 'Method not allowed'], 405);
}

$body = json_decode(file_get_contents('php://input'), true);
if (!$body || !is_array($body)) {
    json_exit(['ok' => false, 'error' => 'Invalid JSON body'], 400);
}

$token        = trim($body['token']        ?? '');
$input        = (isset($body['fields']) && is_array($body['fields'])) ? $body['fields'] : [];
$source_url   = substr(trim($body['source_url']   ?? ''), 0, 500);
$utm_source   = substr(trim($body['utm_source']   ?? ''), 0, 100);
$utm_medium   = substr(trim($body['utm_medium']   ?? ''), 0, 100);
$utm_campaign = substr(trim($body['utm_campaign'] ?? ''), 0, 100);
$utm_term     = substr(trim($body['utm_term']     ?? ''), 0, 200);
$utm_content  = substr(trim($body['utm_content']  ?? ''), 0, 200);
$utm_device   = substr(trim($body['utm_device']   ?? ''), 0, 30);
$referrer     = substr(trim($body['referrer']     ?? ''), 0, 500);

// Real IP (Cloudflare → proxy headers → direct)
if (!empty($_SERVER['HTTP_CF_CONNECTING_IP']))      $ip = trim($_SERVER['HTTP_CF_CONNECTING_IP']);
elseif (!empty($_SERVER['HTTP_X_REAL_IP']))         $ip = trim($_SERVER['HTTP_X_REAL_IP']);
elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   $ip = trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
else                                                $ip = $_SERVER['REMOTE_ADDR'] ?? '';
$ip = substr($ip, 0, 45);
$ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500);

function detect_device(string $ua): string {
    $l = strtolower($ua);
    if (strpos($l,'bot')!==false || strpos($l,'spider')!==false || strpos($l,'crawl')!==false) return 'bot';
    if (strpos($l,'tablet')!==false || strpos($l,'ipad')!==false) return 'tablet';
    if (strpos($l,'mobile')!==false || strpos($l,'android')!==false || strpos($l,'iphone')!==false) return 'mobile';
    return $ua ? 'desktop' : 'unknown';
}
function detect_browser(string $ua): string {
    $l = strtolower($ua);
    if (strpos($l,'edg/')!==false||strpos($l,'edge/')!==false) return 'Edge';
    if (strpos($l,'opr/')!==false||strpos($l,'opera')!==false) return 'Opera';
    if (strpos($l,'chrome/')!==false) return 'Chrome';
    if (strpos($l,'firefox/')!==false) return 'Firefox';
    if (strpos($l,'safari/')!==false && strpos($l,'chrome/')===false) return 'Safari';
    if (strpos($l,'msie')!==false||strpos($l,'trident/')!==false) return 'IE';
    return 'Other';
}
function detect_country(): string {
    if (!empty($_SERVER['HTTP_CF_IPCOUNTRY'])) return strtoupper(substr($_SERVER['HTTP_CF_IPCOUNTRY'],0,2));
    if (!empty($_SERVER['HTTP_X_COUNTRY_CODE'])) return strtoupper(substr($_SERVER['HTTP_X_COUNTRY_CODE'],0,2));
    if (preg_match('/[a-z]{2}-([A-Z]{2})/', $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '', $m)) return $m[1];
    return '';
}
function detect_city(): string {
    return !empty($_SERVER['HTTP_CF_IPCITY']) ? substr(trim($_SERVER['HTTP_CF_IPCITY']),0,100) : '';
}

function geo_lookup_ip(string $ip): array {
    $empty = ['country'=>'','city'=>'','region'=>'','isp'=>'','org'=>''];
    if (!$ip || $ip === '127.0.0.1' || strpos($ip,'::') !== false) return $empty;
    // Private IP ranges — skip
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) return $empty;
    try {
        $url = 'http://ip-api.com/json/' . urlencode($ip) . '?fields=status,country,countryCode,regionName,city,isp,org&lang=en';
        $ctx = stream_context_create(['http'=>['timeout'=>3,'ignore_errors'=>true]]);
        $raw = @file_get_contents($url, false, $ctx);
        if (!$raw) return $empty;
        $d = json_decode($raw, true);
        if (!$d || ($d['status'] ?? '') !== 'success') return $empty;
        return [
            'country' => substr($d['countryCode'] ?? $d['country'] ?? '', 0, 80),
            'city'    => substr($d['city']        ?? '', 0, 100),
            'region'  => substr($d['regionName']  ?? '', 0, 100),
            'isp'     => substr($d['isp']         ?? '', 0, 150),
            'org'     => substr($d['org']         ?? '', 0, 150),
        ];
    } catch (\Throwable $e) { return $empty; }
}

$device_type = detect_device($ua);
$browser     = detect_browser($ua);
$country     = detect_country();
$city        = detect_city();

// Full geo lookup via ip-api.com
$_geo        = geo_lookup_ip($ip ?? '');
if ($_geo['country'])  $country = $_geo['country'];
if ($_geo['city'])     $city    = $_geo['city'];
$_geo_region = $_geo['region'] ?? '';
$_geo_isp    = $_geo['isp']    ?? '';

if (!$token) {
    json_exit(['ok' => false, 'error' => 'Form token required'], 400);
}

// ── Load form ─────────────────────────────────────────────────
$form = db_fetch(
    'SELECT f.*, d.domain AS allowed_domain, d.is_active AS domain_active
     FROM lead_forms f
     JOIN domains d ON d.id = f.domain_id
     WHERE f.form_token = ? AND f.is_active = 1',
    's', $token
);
if (!$form)               json_exit(['ok'=>false,'error'=>'Invalid or inactive form'], 403);
if (!$form['domain_active']) json_exit(['ok'=>false,'error'=>'Form domain is disabled'], 403);

$settings   = json_decode($form['settings'] ?? '{}', true);
if (!is_array($settings)) $settings = [];
$account_id = (int)$form['account_id'];

// ── Domain enforcement ────────────────────────────────────────
function extract_host(string $url): string {
    $h = strtolower(parse_url($url, PHP_URL_HOST) ?: $url);
    return preg_replace('/:\d+$/', '', $h);
}
function host_matches(string $req, string $allowed, string $ours): bool {
    if (!$req) return false;
    $no_www = static function(string $h): string { return (strpos($h,'www.')===0) ? substr($h,4) : $h; };
    $a = $no_www($allowed); $o = $no_www($ours);
    return in_array($req, array_filter([$a,'www.'.$a,$o,'www.'.$o]), true);
}

$allowed_domain = strtolower(trim($form['allowed_domain']));
$our_host       = strtolower(parse_url(APP_URL, PHP_URL_HOST) ?? '');
$request_origin = trim($_SERVER['HTTP_ORIGIN'] ?? '');
$request_host   = $request_origin ? extract_host($request_origin) : '';

if ($request_host && !host_matches($request_host, $allowed_domain, $our_host)) {
    json_exit(['ok'=>false,'error'=>'Form not allowed on this domain'], 403);
}
if ($source_url && !$request_host) {
    $sh = extract_host($source_url);
    if ($sh && !host_matches($sh, $allowed_domain, $our_host)) {
        json_exit(['ok'=>false,'error'=>'Form not allowed on this domain'], 403);
    }
}

function is_ip_blocked(string $ip, int $account_id): bool {
    $r = db_fetch('SELECT id FROM ip_blocklist WHERE ip_address=? AND account_id IS NULL AND (expires_at IS NULL OR expires_at>NOW())', 's', $ip);
    if ($r) { db_query('UPDATE ip_blocklist SET hit_count=hit_count+1 WHERE id=?','i',(int)$r['id']); return true; }
    $r2 = db_fetch('SELECT id FROM ip_blocklist WHERE ip_address=? AND account_id=? AND (expires_at IS NULL OR expires_at>NOW())', 'si', $ip, $account_id);
    if ($r2) { db_query('UPDATE ip_blocklist SET hit_count=hit_count+1 WHERE id=?','i',(int)$r2['id']); return true; }
    return false;
}
function check_honeypot(array $body, array $input): bool {
    return !empty($body['lp_website']) || !empty($input['lp_website']);
}
function check_too_fast(array $input): bool {
    $ts = (int)($input['_lp_ts'] ?? 0);
    return $ts > 0 && (time() - $ts) < 2;
}

$success_msg = $settings['success_msg'] ?? 'Thank you! We will be in touch soon.';

if (is_ip_blocked($ip, $account_id)) {
    json_exit(['ok'=>true,'message'=>$success_msg]);
}
if (check_honeypot($body, $input) || check_too_fast($input)) {
    json_exit(['ok'=>true,'message'=>$success_msg]);
}

function score_form_rate_limit(int $form_id, string $ip): int {
    $n = (int)(db_fetch('SELECT COUNT(*) AS n FROM leads WHERE form_id=? AND ip_address=? AND submitted_at>DATE_SUB(NOW(),INTERVAL 1 HOUR)','is',$form_id,$ip)['n'] ?? 0);
    return $n >= 10 ? 50 : ($n >= 5 ? 20 : 0);
}
function score_global_rate_limit(string $ip, int $account_id): int {
    $n = (int)(db_fetch('SELECT COUNT(*) AS n FROM leads WHERE ip_address=? AND submitted_at>DATE_SUB(NOW(),INTERVAL 1 HOUR)','s',$ip)['n'] ?? 0);
    if ($n >= 50) {
        if (!db_fetch('SELECT id FROM ip_blocklist WHERE ip_address=? AND account_id IS NULL','s',$ip))
            db_insert('INSERT INTO ip_blocklist (account_id,ip_address,reason,auto_blocked,hit_count) VALUES (NULL,?,?,1,?)','ssi',$ip,'Auto-blocked: '.$n.'/hour',$n);
        return 100;
    }
    return $n >= 30 ? 50 : ($n >= 15 ? 20 : 0);
}
function score_duplicate(int $form_id, array $input): int {
    $email = '';
    foreach ($input as $v) { if (filter_var((string)$v,FILTER_VALIDATE_EMAIL)) { $email=strtolower(trim((string)$v)); break; } }
    if (!$email) return 0;
    return db_fetch("SELECT l.id FROM leads l JOIN lead_values lv ON lv.lead_id=l.id WHERE l.form_id=? AND LOWER(lv.value)=? AND lv.field_key LIKE '%email%' AND l.submitted_at>DATE_SUB(NOW(),INTERVAL 5 MINUTE) LIMIT 1",'is',$form_id,$email) ? 40 : 0;
}
function score_email_domain(array $input, int $account_id): int {
    foreach ($input as $v) {
        $v = strtolower(trim((string)$v));
        if (!filter_var($v,FILTER_VALIDATE_EMAIL)) continue;
        $d = substr($v, strpos($v,'@')+1);
        if (db_fetch('SELECT id FROM email_domain_blocklist WHERE domain=? AND account_id IS NULL','s',$d)) return 60;
        if (db_fetch('SELECT id FROM email_domain_blocklist WHERE domain=? AND account_id=?','si',$d,$account_id)) return 60;
    }
    return 0;
}
function score_keywords(array $input, int $account_id): array {
    $text  = strtolower(implode(' ', array_map('strval', $input)));
    $rules = db_fetch_all('SELECT keyword,action FROM spam_keyword_rules WHERE account_id IS NULL OR account_id=? ORDER BY account_id IS NULL DESC','i',$account_id);
    foreach ($rules as $r) {
        if (strpos($text, strtolower($r['keyword'])) !== false)
            return [($r['action']==='block' ? 80 : 30), $r['action'], $r['keyword']];
    }
    return [0, 'flag', ''];
}
function score_all_same(array $input): int {
    $vals = array_values(array_filter(array_map(function($v){ return trim((string)$v); }, $input), function($v){ return strlen($v) > 3; }));
    return (count($vals) >= 3 && count(array_unique($vals)) === 1) ? 35 : 0;
}
function score_user_agent(string $ua): int {
    if (empty($ua)) return 20;
    foreach (['curl/','python-requests','libwww','wget/','scrapy','go-http','java/','php/'] as $p)
        if (strpos(strtolower($ua), $p) !== false) return 25;
    return 0;
}

$spam_score   = 0;
$spam_reasons = [];
$hard_block   = false;

$fr = score_form_rate_limit((int)$form['id'], $ip);
if ($fr > 0) { $spam_score += $fr; $spam_reasons[] = 'rate_limit_form'; }

$gr = score_global_rate_limit($ip, $account_id);
if ($gr >= 100) { $hard_block = true; $spam_reasons[] = 'auto_blocked'; }
elseif ($gr > 0) { $spam_score += $gr; $spam_reasons[] = 'rate_limit_global'; }

$dup = score_duplicate((int)$form['id'], $input);
if ($dup > 0) { $spam_score += $dup; $spam_reasons[] = 'duplicate'; }

$es = score_email_domain($input, $account_id);
if ($es > 0) { $spam_score += $es; $spam_reasons[] = 'blocked_email_domain'; }

[$ks, $ka, $km] = score_keywords($input, $account_id);
if ($ks > 0) { $spam_score += $ks; $spam_reasons[] = 'keyword:'.$km; if ($ka==='block') $hard_block=true; }

$ss = score_all_same($input);
if ($ss > 0) { $spam_score += $ss; $spam_reasons[] = 'all_same'; }

$us = score_user_agent($ua);
if ($us > 0) { $spam_score += $us; $spam_reasons[] = 'bot_ua'; }

if ($hard_block || $spam_score >= 100) {
    if (in_array('rate_limit_form',$spam_reasons) || in_array('rate_limit_global',$spam_reasons))
        json_exit(['ok'=>false,'error'=>'Too many submissions. Please try again later.'], 429);
    json_exit(['ok'=>true,'message'=>$success_msg]);
}

$status = ($spam_score >= 50) ? 'spam' : 'new';

// ── Validate fields ───────────────────────────────────────────
$form_fields = db_fetch_all('SELECT * FROM form_fields WHERE form_id=? AND is_visible=1 ORDER BY sort_order,id','i',(int)$form['id']);
$errors = []; $data = [];
foreach ($form_fields as $f) {
    $val = trim((string)($input[$f['field_key']] ?? ''));
    if ($f['is_required'] && $val==='')                                                 $errors[] = $f['field_label'].' is required.';
    if ($f['field_type']==='email' && $val && !filter_var($val,FILTER_VALIDATE_EMAIL)) $errors[] = $f['field_label'].' must be a valid email.';
    if ($f['field_type']==='url'   && $val && !filter_var($val,FILTER_VALIDATE_URL))   $errors[] = $f['field_label'].' must be a valid URL.';
    $data[$f['id']] = ['key'=>$f['field_key'], 'label'=>$f['field_label'], 'value'=>$val];
}
if ($errors) json_exit(['ok'=>false,'errors'=>$errors], 422);

// ── Save lead ─────────────────────────────────────────────────
// Core INSERT uses only columns guaranteed in base schema.sql.
// Extended columns (device_type, utm_term etc.) are added via UPDATE
// so missing migrations never prevent form submission.
$ref   = generate_reference($account_id);
$notes = !empty($spam_reasons) ? '[Spam flags: '.implode(', ',$spam_reasons).']' : null;

$lead_id = db_insert(
    'INSERT INTO leads
       (account_id, form_id, domain_id, reference_no, status, notes,
        source_url, ip_address, user_agent,
        utm_source, utm_medium, utm_campaign)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
    'iiisssssssss',
    $account_id, (int)$form['id'], (int)$form['domain_id'],
    $ref, $status, $notes,
    $source_url, $ip, $ua,
    $utm_source, $utm_medium, $utm_campaign
);

if (!$lead_id) {
    json_exit(['ok'=>false,'error'=>'Failed to save lead. Please check server error log.'], 500);
}

// Extended columns — each guarded individually so partial migrations work fine
// migrate_v2.sql: device_type, browser, country, referrer, spam_score
$db_tmp = db();
$has_v2 = $db_tmp->query("SHOW COLUMNS FROM leads LIKE 'device_type'")->num_rows > 0;
if ($has_v2) {
    db_query('UPDATE leads SET device_type=?,browser=?,country=?,referrer=?,spam_score=? WHERE id=?',
        'ssssii', $device_type, $browser, $country, $referrer, min($spam_score,255), $lead_id);
}

// migrate_utm_geo.sql: utm_term, utm_content, utm_device, city
$has_geo = $db_tmp->query("SHOW COLUMNS FROM leads LIKE 'utm_term'")->num_rows > 0;
if ($has_geo) {
    db_query('UPDATE leads SET utm_term=?,utm_content=?,utm_device=?,city=? WHERE id=?',
        'ssssi', $utm_term, $utm_content, $utm_device, $city, $lead_id);
}

// Save ISP from ip-api lookup if column exists
$has_isp = $db_tmp->query("SHOW COLUMNS FROM leads LIKE 'isp'")->num_rows > 0;
if ($has_isp && $_geo_isp) {
    db_query('UPDATE leads SET isp=? WHERE id=?', 'si', $_geo_isp, $lead_id);
}

// ── Field values ──────────────────────────────────────────────
foreach ($data as $field_id => $d) {
    if ($d['value'] !== '') {
        db_insert('INSERT INTO lead_values (lead_id,field_id,field_key,field_label,value) VALUES (?,?,?,?,?)',
            'iisss', $lead_id, $field_id, $d['key'], $d['label'], $d['value']);
    }
}

db_query('UPDATE lead_forms SET submission_count=submission_count+1 WHERE id=?','i',(int)$form['id']);

// Scoring (no-op if scoring table empty)
require_once __DIR__ . '/config/scoring.php';
apply_lead_score($lead_id, $account_id);

// ── Step 1: Auto AI Lead Intelligence ────────────────────────
// Runs after scoring. Gracefully skipped if AI is off or slow.
try {
    require_once __DIR__ . '/config/ai.php';
    if (ai_enabled() && ai_setting('ai_auto_analyze', '1') === '1') {
        $ai_lead = db_fetch('SELECT * FROM leads WHERE id = ?', 'i', $lead_id);
        $ai_fv   = db_fetch_all(
            'SELECT field_key, field_label, value FROM lead_values WHERE lead_id = ?', 'i', $lead_id
        );
        if ($ai_lead) {
            $ai_r = ai_analyze_lead($ai_lead, $ai_fv ?: []);
            if ($ai_r['ok']) {
                $db2 = db();
                // Always-present base columns
                db_query(
                    'UPDATE leads SET ai_score=?,ai_qualification=?,ai_summary=?,ai_next_action=?,ai_processed_at=NOW() WHERE id=?',
                    'isssi',
                    $ai_r['score'], $ai_r['qualification'],
                    $ai_r['summary'] ?? '', $ai_r['next_action'] ?? '', $lead_id
                );
                // Step 1 new columns (safe — only write if column exists)
                if ($db2->query("SHOW COLUMNS FROM leads LIKE 'ai_intent'")->num_rows)
                    db_query('UPDATE leads SET ai_intent=? WHERE id=?', 'si', $ai_r['intent'] ?? '', $lead_id);
                if ($db2->query("SHOW COLUMNS FROM leads LIKE 'ai_sentiment'")->num_rows)
                    db_query('UPDATE leads SET ai_sentiment=? WHERE id=?', 'si', $ai_r['sentiment'] ?? '', $lead_id);
                if ($db2->query("SHOW COLUMNS FROM leads LIKE 'ai_tags'")->num_rows)
                    db_query('UPDATE leads SET ai_tags=? WHERE id=?', 'si', json_encode($ai_r['tags'] ?? []), $lead_id);
                if ($db2->query("SHOW COLUMNS FROM leads LIKE 'ai_lead_category'")->num_rows)
                    db_query('UPDATE leads SET ai_lead_category=? WHERE id=?', 'si', $ai_r['lead_category'] ?? '', $lead_id);
                // Save to lead_ai_results
                $db2 = db();
                $has_intent = $db2->query("SHOW COLUMNS FROM lead_ai_results LIKE 'intent'")->num_rows > 0;
                $has_sent   = $db2->query("SHOW COLUMNS FROM lead_ai_results LIKE 'sentiment'")->num_rows > 0;
                $has_tags   = $db2->query("SHOW COLUMNS FROM lead_ai_results LIKE 'tags'")->num_rows > 0;
                $has_cat    = $db2->query("SHOW COLUMNS FROM lead_ai_results LIKE 'lead_category'")->num_rows > 0;
                $existing   = db_fetch('SELECT id FROM lead_ai_results WHERE lead_id=?', 'i', $lead_id);
                $intent_v   = $ai_r['intent']        ?? 'general_enquiry';
                $sent_v     = $ai_r['sentiment']      ?? 'neutral';
                $tags_v     = json_encode($ai_r['tags'] ?? []);
                $cat_v      = $ai_r['lead_category']  ?? 'new_lead';
                if ($existing) {
                    $extra_sql  = ($has_intent ? ',intent=?'        : '') . ($has_sent ? ',sentiment=?' : '')
                                . ($has_tags   ? ',tags=?'          : '') . ($has_cat  ? ',lead_category=?' : '');
                    $extra_types= ($has_intent ? 's' : '') . ($has_sent ? 's' : '') . ($has_tags ? 's' : '') . ($has_cat ? 's' : '');
                    $extra_vals = array_filter([$has_intent?$intent_v:null,$has_sent?$sent_v:null,$has_tags?$tags_v:null,$has_cat?$cat_v:null], fn($v)=>$v!==null);
                    db_query(
                        "UPDATE lead_ai_results SET score=?,qualification=?,summary=?,next_action=?,conversion_pct=?,reasoning=?,model_used=?,tokens_used=?,updated_at=NOW(){$extra_sql} WHERE lead_id=?",
                        'isssii ss' . $extra_types . 'i',
                        $ai_r['score'], $ai_r['qualification'], $ai_r['summary'] ?? '',
                        $ai_r['next_action'] ?? '', $ai_r['conversion_pct'] ?? 0,
                        $ai_r['reasoning'] ?? '', $ai_r['model'] ?? '', $ai_r['tokens'] ?? 0,
                        ...$extra_vals, $lead_id
                    );
                } else {
                    $ins_cols = 'lead_id,score,qualification,summary,next_action,conversion_pct,reasoning,model_used,tokens_used';
                    $ins_ph   = '?,?,?,?,?,?,?,?,?';
                    $ins_types= 'iissssssi';
                    $ins_vals = [$lead_id,$ai_r['score'],$ai_r['qualification'],$ai_r['summary']??'',$ai_r['next_action']??'',$ai_r['conversion_pct']??0,$ai_r['reasoning']??'',$ai_r['model']??'',$ai_r['tokens']??0];
                    if ($has_intent){ $ins_cols.=',intent';        $ins_ph.=',?'; $ins_types.='s'; $ins_vals[]=$intent_v; }
                    if ($has_sent)  { $ins_cols.=',sentiment';     $ins_ph.=',?'; $ins_types.='s'; $ins_vals[]=$sent_v; }
                    if ($has_tags)  { $ins_cols.=',tags';          $ins_ph.=',?'; $ins_types.='s'; $ins_vals[]=$tags_v; }
                    if ($has_cat)   { $ins_cols.=',lead_category'; $ins_ph.=',?'; $ins_types.='s'; $ins_vals[]=$cat_v; }
                    db_insert("INSERT INTO lead_ai_results ({$ins_cols}) VALUES ({$ins_ph})", $ins_types, ...$ins_vals);
                }
                // Auto-actions from AI result
                if (in_array($ai_r['lead_category'] ?? '', ['spam', 'bot']))
                    db_query("UPDATE leads SET status='spam' WHERE id=?", 'i', $lead_id);
                elseif (($ai_r['score'] ?? 0) >= 80)
                    db_query("UPDATE leads SET engagement_level='hot' WHERE id=? AND engagement_level != 'hot'", 'i', $lead_id);
            }
        }
    }
} catch (Throwable $ai_err) {
    error_log('[LeadPro AI] Auto-analyze failed: ' . $ai_err->getMessage());
}

// ── Notifications (in-app) ───────────────────────────────────
try {
    require_once __DIR__ . '/config/notifications.php';
    $fname = $form['name'] ?? 'a form';
    foreach (['account_owner','manager'] as $role) {
        notify_role($account_id, $role, 'lead.new',
            'New lead from '.$fname,
            'Ref '.$ref.($source_url ? ' via '.parse_url($source_url,PHP_URL_HOST) : ''),
            '/lead_view.php?id='.$lead_id,
            ['lead_id'=>$lead_id,'form_id'=>(int)$form['id'],'reference'=>$ref]
        );
    }
} catch (\Throwable $e) {
    error_log('[LeadPro] notify: '.$e->getMessage());
}

// ── Lead Notification Email + Auto-Reply to Lead ─────────────
try {
    require_once __DIR__ . '/config/mailer.php';

    $notify_email  = trim($settings['notify_email'] ?? '');
    $app_name      = ps('app_name', 'LeadPro');
    $form_name     = $form['name'] ?? 'Form';
    $lead_view_url = (defined('APP_URL') ? APP_URL : '') . '/lead_view.php?id=' . $lead_id;

    // Re-fetch lead for template vars
    $tpl_lead   = db_fetch('SELECT * FROM leads WHERE id=?', 'i', $lead_id) ?: [];
    $tpl_fields = db_fetch_all('SELECT field_key, field_label, value FROM lead_values WHERE lead_id=?', 'i', $lead_id) ?: [];

    // Fetch campaign for KB context (set by lp/index.php after insert)
    $tpl_campaign = [];
    $tpl_camp_id  = (int)($tpl_lead['campaign_id'] ?? 0);
    if ($tpl_camp_id) {
        $tpl_campaign = db_fetch('SELECT * FROM campaigns WHERE id=?', 'i', $tpl_camp_id) ?: [];
    }

    $tpl_vars = build_template_vars($tpl_lead, $tpl_fields, $form, $tpl_campaign);

    // ── 1. NOTIFY STAFF (to notify_email) ────────────────────
    $notify_subject = "[New Lead] {$tpl_vars['lead_ref']} — {$form_name}";
    $notify_body    = "A new lead has been submitted via {$form_name}.

";
    $notify_body   .= "Reference: {$tpl_vars['lead_ref']}
";
    if ($source_url) $notify_body .= "Source: {$source_url}
";
    $notify_body   .= "
LEAD DETAILS:
";
    foreach ($tpl_fields as $f2) {
        if ($f2['value'] !== '' && !in_array($f2['field_key'], ['_lp_ts','lp_website']))
            $notify_body .= $f2['field_label'] . ': ' . $f2['value'] . "
";
    }
    $notify_body .= "
View lead: {$lead_view_url}";

    // Check for custom notify template
    $notify_tpl = get_form_template((int)$form['id'], 'notify');
    if ($notify_tpl) {
        $notify_subject = template_replace($notify_tpl['subject'], $tpl_vars);
        $notify_body    = template_replace($notify_tpl['body'],    $tpl_vars);
    }

    // Collect notify recipients
    $notify_emails = [];
    if ($notify_email && filter_var($notify_email, FILTER_VALIDATE_EMAIL)) {
        $notify_emails[] = ['email' => $notify_email, 'name' => $app_name];
    }
    // Campaign owner
    if ($tpl_camp_id) {
        $camp_owner = db_fetch(
            'SELECT u.email, u.first_name, u.last_name FROM campaigns c JOIN users u ON u.id=c.owner_id WHERE c.id=? AND c.owner_id IS NOT NULL',
            'i', $tpl_camp_id
        );
        if ($camp_owner && filter_var($camp_owner['email'], FILTER_VALIDATE_EMAIL)) {
            $notify_emails[] = ['email'=>$camp_owner['email'], 'name'=>trim($camp_owner['first_name'].' '.$camp_owner['last_name'])];
        }
    }
    // Assigned user
    $assigned_row = db_fetch(
        'SELECT l.assigned_to, u.email, u.first_name, u.last_name FROM leads l JOIN users u ON u.id=l.assigned_to WHERE l.id=? AND l.assigned_to IS NOT NULL',
        'i', $lead_id
    );
    if ($assigned_row && filter_var($assigned_row['email'], FILTER_VALIDATE_EMAIL)) {
        $notify_emails[] = ['email'=>$assigned_row['email'], 'name'=>trim($assigned_row['first_name'].' '.$assigned_row['last_name'])];
    }

    $sent_to = [];
    foreach ($notify_emails as $recipient) {
        if (in_array($recipient['email'], $sent_to)) continue;
        $sent_to[] = $recipient['email'];
        send_email_from_form($recipient['email'], $recipient['name'], $notify_subject, $notify_body, $notify_email);
    }

    // ── 2. AUTO-REPLY to Lead ─────────────────────────────────
    $lead_to_email = '';
    $lead_to_name  = $tpl_vars['name'];
    foreach ($tpl_fields as $f2) {
        if ($f2['field_key'] === 'email' && $f2['value']) { $lead_to_email = $f2['value']; break; }
    }

    $auto_reply_tpl = get_form_template((int)$form['id'], 'auto_reply');
    if ($auto_reply_tpl && $lead_to_email && filter_var($lead_to_email, FILTER_VALIDATE_EMAIL)) {
        $ar_subject = template_replace($auto_reply_tpl['subject'], $tpl_vars);
        $ar_body    = template_replace($auto_reply_tpl['body'],    $tpl_vars);
        $ar_result  = send_email_from_form($lead_to_email, $lead_to_name, $ar_subject, $ar_body, $notify_email);
        // Log to activity
        if ($ar_result['ok']) {
            $db_ar = db();
            $has_ct = $db_ar->query("SHOW COLUMNS FROM lead_comments LIKE 'comment_type'")->num_rows > 0;
            if ($has_ct) {
                db_insert(
                    'INSERT INTO lead_comments (lead_id,user_id,comment,comment_type,email_subject,email_to,email_from) VALUES (?,?,?,?,?,?,?)',
                    'iissss',
                    $lead_id, 0, $ar_body, 'email_sent', $ar_subject, $lead_to_email, $ar_result['from'] ?? $notify_email
                );
            } else {
                db_insert('INSERT INTO lead_comments (lead_id,user_id,comment) VALUES (?,?,?)',
                    'iis', $lead_id, 0, "✉ Auto-reply sent to {$lead_to_email}\nSubject: {$ar_subject}");
            }
        }
    }

    // ── 3. LOG notify email to activity ──────────────────────
    if (!empty($sent_to)) {
        $db_notify = db();
        $has_ct2   = $db_notify->query("SHOW COLUMNS FROM lead_comments LIKE 'comment_type'")->num_rows > 0;
        $note_text = "📧 Lead notification sent to: " . implode(', ', $sent_to);
        if ($has_ct2) {
            db_insert('INSERT INTO lead_comments (lead_id,user_id,comment,comment_type,email_subject,email_to) VALUES (?,?,?,?,?,?)',
                'iissss', $lead_id, 0, $note_text, 'system', $notify_subject, implode(', ', $sent_to));
        } else {
            db_insert('INSERT INTO lead_comments (lead_id,user_id,comment) VALUES (?,?,?)', 'iis', $lead_id, 0, $note_text);
        }
    }
} catch (\Throwable $mail_err) {
    error_log('[LeadPro] Lead notify email failed: ' . $mail_err->getMessage());
}

// Deduplication — detect and flag duplicates after save
if ($status !== 'spam') {
    try {
        require_once __DIR__ . '/config/deduplication.php';
        $dupe_matches = dedupe_find($lead_id, $account_id);
        if ($dupe_matches) {
            dedupe_record($lead_id, $account_id, $dupe_matches);
        }
    } catch (\Throwable $e) {
        error_log('[LeadPro] dedupe: '.$e->getMessage());
    }
}

json_exit([
    'ok'           => true,
    'reference_no' => $ref,
    'message'      => $success_msg,
    'redirect_url' => $settings['redirect_url'] ?? null,
]);
