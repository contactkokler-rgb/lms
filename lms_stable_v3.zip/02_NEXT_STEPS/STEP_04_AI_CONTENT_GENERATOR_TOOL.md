Build AI Website Content Generator for account owners.

INPUT:
- business name
- industry
- services
- location
- target audience
- tone

Optional:
- competitor URL
- keywords
- brand voice

OUTPUT:

1) WEBSITE STRUCTURE
- Home
- About
- Services
- Service detail pages (per service)
- Contact

2) PAGE CONTENT (section-based)

Home:
- hero (headline + CTA)
- services overview
- why choose us
- testimonials
- CTA
- footer

Service Page:
- title
- intro
- benefits
- process
- pricing hint (optional)
- FAQs
- CTA

3) SEO (per page)
- H1/H2/H3
- keywords
- meta title
- meta description

AI REQUIREMENTS:
- use business + location + services context
- avoid generic content
- maintain tone consistency across pages
- generate conversion-focused copy (CTAs, trust)

AI FEATURES:
- regenerate / shorten / improve tone
- tone presets (professional, luxury, friendly, sales, minimal)
- section-level regeneration (e.g. only FAQs)

PLANNER (before generation):
- suggest pages
- suggest service structure
- suggest content strategy

COMPETITOR MODE:
- extract structure + topics
- generate improved version

MEMORY:
- store business context
- reuse across pages

SMART SUGGESTIONS:
- missing sections (e.g. testimonials, trust signals)

1-CLICK MODE:
Input → full website:
- structure
- all pages
- service pages
- SEO

SAVE:
- store all generated content in portal