PLANS/PRICING SYSTEM

- Monthly subscription based
- Usage visibility in account owner panel
- Upgrade plan nudges

After plan expires

- Landing pages stay live
- Forms keep collecting leads
- Restrict
-- no new edits allowed
-- no new campaigns
-- no new domains add
-- no new landing pages
-- no new forms creation
-- no new team member can be added
-- no tools services/tools can be used
  
  
- Plan/pricing to be managed and configured by superadmin (new menu in sidebar)

- FREE TRIAL
-- 14 days free trial for each plan


- Starter Plan
-- 1 domain
-- 3 Forms
-- 300 leads per month
-- 2 Team members
-- Selected Services & Tools (those configured by super admin)


- Pro Plan
-- 5 domains
-- 10 Forms
-- 500 leads per month (per domain)
-- 5 Team members
-- Selected Services & Tools (those configured by super admin)


- Agency Plan
-- 10 domains
-- 25 Forms
-- 700 leads per month (per domain)
-- 20 Team members
-- Selected Services & Tools (those configured by super admin)


- Enterprise Plan
-- 25 domains
-- 50 Forms
-- 1000 leads per month (per domain)
-- 50 Team members
-- Selected Services & Tools (those configured by super admin)


-----

BILING SYSTEM FOR ACCOUNT OWNERS

- Emails sent for payments and invoices
- Online payment methods incorporation

-----

