Build Client + Project Management system for account owners.

CLIENTS:
- add/edit client (name, email, phone, company, notes)
- link multiple projects to client
- view client history (projects, invoices, quotes)

PROJECTS:
- create project
  - client link
  - title, description
  - start date, deadline
  - budget (optional)

STATUS:
- predefined statuses:
  - Not Started
  - In Progress
  - On Hold
  - Completed
  - Cancelled
- allow status updates
- show status timeline/history

TASKS (simple):
- add tasks under project
- task fields: title, assignee, due date, status
- task status: Pending, In Progress, Done

DASHBOARD:
- total clients
- active projects
- completed projects
- overdue projects

PROJECT VIEW:
- project details
- task list
- status
- timeline (updates/logs)

INTEGRATION:
- link project to:
  - quotes
  - invoices

NOTES & FILES:
- add notes per client/project
- upload files (optional)

AUTOMATION:
- project created → default status "Not Started"
- deadline passed → mark overdue
- completed tasks → auto progress update (optional)

ACCESS:
- multi-user (optional)
- role-based (admin, team)

SEARCH & FILTER:
- search clients/projects
- filter by status, date, client

SAVE:
- persist all data in portal