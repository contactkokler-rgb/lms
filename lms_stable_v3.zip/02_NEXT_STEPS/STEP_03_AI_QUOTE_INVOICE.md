Build an Invoice & Quotation system for account owners.

CORE:
- Store company profile: name, logo, email, GST, services list
- Create Invoice / Quote:
  - select services OR add custom items
  - add pricing, tax, due date
- Send via email (from company email) with secure view लिंक
- Public view page (read-only, secure access)

QUOTE:
- Status: Draft, Sent, Viewed, Accepted, Rejected, Expired
- Track user action → update status
- Attach quote to lead

INVOICE:
- Status: Unpaid, Partial, Paid, Overdue
- Payment details editable by owner

TEMPLATES:
- Customizable invoice + quote templates

AI FEATURES:
Input: short service description
Output:
- line items
- descriptions
- price suggestions (based on industry + service)

AUTOMATION:
- Quote Accepted → auto-create Invoice
- Quote not viewed → reminder
- Invoice overdue → payment reminder

ANALYTICS:
- total quotes
- acceptance rate
- revenue
- pending payments
- avg deal value
- funnel: Sent → Accepted → Paid

COMPLIANCE (India):
- GST fields (business + client)
- tax breakdown
- valid invoice format

ADVANCED:
- recurring invoices
- partial payments (milestones)
- multi-currency
- multi-user access
- approval workflow

FLOW:
Lead → Quote Sent → Accepted → Invoice → Payment