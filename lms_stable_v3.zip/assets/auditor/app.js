const form = document.getElementById('audit-form');
const urlInput = document.getElementById('url');
const competitorInput = document.getElementById('competitor_urls');
const crawlScopeInput = document.getElementById('crawl_scope');
const crawlLimitInput = document.getElementById('crawl_limit');
const feedback = document.getElementById('form-feedback');
const loadingCard = document.getElementById('loading-card');
const loadingMessage = document.getElementById('loading-message');
const reportShell = document.getElementById('report-shell');
const reportSummary = document.getElementById('report-summary');
const reportAi = document.getElementById('report-ai');
const reportContentLab = document.getElementById('report-content-lab');
const reportModules = document.getElementById('report-modules');
const reportMetrics = document.getElementById('report-metrics');
const reportIssues = document.getElementById('report-issues');

const loadingMessages = [
    'Fetching the target URL and parsing the main page.',
    'Inspecting metadata, content depth, links, schema, and technical SEO signals.',
    'Checking analytics tags, event cues, and conversion instrumentation.',
    'Walking internal pages page-by-page when whole-site crawl is enabled.',
    'Turning the findings into an execution plan with OpenRouter.',
];

let loadingTimer = null;
let lastAudit = null;

form?.addEventListener('submit', async (event) => {
    event.preventDefault();

    let targetUrl = urlInput.value.trim();
    if (targetUrl === '') {
        setFeedback('Please enter a URL to audit.', 'error');
        urlInput.focus();
        return;
    }

    if (!/^https?:\/\//i.test(targetUrl)) {
        targetUrl = `https://${targetUrl}`;
        urlInput.value = targetUrl;
    }

    setLoadingState(true);
    setFeedback('Running audit...', 'muted');
    lastAudit = null;

    try {
        const endpoint = form.dataset.endpoint || form.action;
        const body = new FormData();
        body.append('url', targetUrl);
        body.append('competitor_urls', competitorInput?.value?.trim() || '');
        body.append('crawl_scope', crawlScopeInput?.value || 'page');
        body.append('crawl_limit', crawlLimitInput?.value || '12');
        // LMS CSRF token
        const _csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
        if (_csrf) body.append('_csrf', _csrf);

        const response = await fetch(endpoint, {
            method: 'POST',
            body,
        });

        const payload = await response.json();
        if (!response.ok || !payload.success) {
            throw new Error(payload.error || 'The audit request failed.');
        }

        lastAudit = payload.data;
        renderReport(payload.data);
        setFeedback('Audit complete.', 'success');
        showSaveBar(payload.data);
    } catch (error) {
        setFeedback(error.message || 'The audit failed.', 'error');
        reportShell.classList.add('is-hidden');
    } finally {
        setLoadingState(false);
    }
});

document.addEventListener('submit', async (event) => {
    const generatorForm = event.target.closest('#content-generator-form');
    if (!generatorForm) {
        return;
    }

    event.preventDefault();

    const primaryKeywordInput = generatorForm.querySelector('[name="primary_keyword"]');
    const primaryKeyword = primaryKeywordInput?.value?.trim() || '';
    if (primaryKeyword === '') {
        setGeneratorFeedback('Please enter a primary keyword first.', 'error');
        primaryKeywordInput?.focus();
        return;
    }

    setGeneratorState(true);
    setGeneratorFeedback('Generating content draft...', 'muted');

    try {
        const body = buildGeneratorPayload(generatorForm);
        const response = await fetch(generatorForm.action || 'generate-content.php', {
            method: 'POST',
            body,
        });

        const payload = await response.json();
        if (!response.ok || !payload.success) {
            throw new Error(payload.error || 'The content generator request failed.');
        }

        renderGeneratorResult(payload.data);
        setGeneratorFeedback(payload.data.available ? 'Content draft generated.' : 'Fallback content scaffold generated.', payload.data.available ? 'success' : 'muted');
    } catch (error) {
        setGeneratorFeedback(error.message || 'Content generation failed.', 'error');
    } finally {
        setGeneratorState(false);
    }
});

function buildGeneratorPayload(generatorForm) {
    const body = new FormData(generatorForm);
    const _csrfGen = document.querySelector('meta[name="csrf-token"]')?.content || '';
    if (_csrfGen) body.append('_csrf', _csrfGen);
    const audit = lastAudit || {};

    body.append('url', audit.target?.final_url || audit.target?.requested_url || urlInput?.value?.trim() || '');
    body.append('current_title', audit.metrics?.page?.title?.text || '');
    body.append('current_h1', (audit.metrics?.page?.h1 || []).join(' | '));
    body.append('page_keywords', (audit.metrics?.content?.keywords || []).join(', '));
    body.append('page_excerpt', audit.metrics?.content?.text_excerpt || '');
    body.append('crawl_keywords', (audit.content_lab?.crawl?.top_keywords || audit.crawl?.top_keywords || []).join(', '));
    body.append('competitor_notes', (audit.modules?.competitor?.outrank_reasons || []).join(' | '));
    body.append('important_suggestions', (audit.content_lab?.important_suggestions || []).join(' | '));

    return body;
}

function setLoadingState(isLoading) {
    if (isLoading) {
        let index = 0;
        loadingMessage.textContent = loadingMessages[index];
        loadingCard.classList.remove('is-hidden');
        reportShell.classList.add('is-hidden');

        clearInterval(loadingTimer);
        loadingTimer = window.setInterval(() => {
            index = (index + 1) % loadingMessages.length;
            loadingMessage.textContent = loadingMessages[index];
        }, 1700);
        return;
    }

    clearInterval(loadingTimer);
    loadingTimer = null;
    loadingCard.classList.add('is-hidden');
}

function setFeedback(message, tone) {
    feedback.textContent = message;
    feedback.dataset.tone = tone;
}

function renderReport(audit) {
    reportSummary.innerHTML = renderSummary(audit);
    reportAi.innerHTML = renderAiSection(audit);
    reportContentLab.innerHTML = renderContentLab(audit);
    reportModules.innerHTML = renderModules(audit);
    reportMetrics.innerHTML = renderMetrics(audit);
    reportIssues.innerHTML = renderIssues(audit.issues || []);

    reportShell.classList.remove('is-hidden');
    reportShell.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function renderSummary(audit) {
    const score = Number(audit.scores?.overall || 0);
    const grade = escapeHtml(audit.scores?.grade || 'F');
    const categoryCards = Object.entries(audit.scores?.categories || {})
        .filter(([, value]) => value !== null)
        .map(([name, value]) => `
            <article class="score-card ${scoreToneClass(value)}">
                <p>${escapeHtml(titleize(name))}</p>
                <strong>${escapeHtml(String(value))}</strong>
            </article>
        `)
        .join('');

    const issueSummary = audit.scores?.issue_summary || {};
    const highlights = renderSimpleList(audit.highlights || [], 'highlight-list');

    return `
        <section class="summary-hero card">
            <div class="summary-score">
                <div class="score-orb ${scoreToneClass(score)}">
                    <span class="score-number">${escapeHtml(String(score))}</span>
                    <span class="score-grade">${grade}</span>
                </div>
                <div>
                    <p class="eyebrow">Overall audit score</p>
                    <h2>${escapeHtml(audit.target?.final_url || audit.target?.requested_url || '')}</h2>
                    <p class="summary-copy">
                        HTTP ${escapeHtml(String(audit.response?.status_code || 0))} ·
                        ${escapeHtml(String(audit.response?.response_time_ms || 0))} ms ·
                        ${escapeHtml(String(audit.response?.html_size_kb || 0))} KB HTML
                    </p>
                    <div class="severity-strip">
                        <span>Critical ${escapeHtml(String(issueSummary.critical || 0))}</span>
                        <span>High ${escapeHtml(String(issueSummary.high || 0))}</span>
                        <span>Medium ${escapeHtml(String(issueSummary.medium || 0))}</span>
                        <span>Low ${escapeHtml(String(issueSummary.low || 0))}</span>
                    </div>
                </div>
            </div>

            <div class="summary-grid">
                ${categoryCards}
            </div>
        </section>

        <section class="card">
            <div class="section-heading">
                <p class="eyebrow">What is already working</p>
                <h3>Positive signals</h3>
            </div>
            ${highlights}
        </section>
    `;
}

function renderAiSection(audit) {
    const ai = audit.ai || {};
    const priorities = Array.isArray(ai.top_priorities) ? ai.top_priorities : [];
    const quickWins = Array.isArray(ai.quick_wins) ? ai.quick_wins : [];
    const contentStrategy = Array.isArray(ai.content_strategy) ? ai.content_strategy : [];
    const growthPlan = Array.isArray(ai.growth_plan) ? ai.growth_plan : [];
    const sourceLabel = ai.available
        ? `AI summary via ${escapeHtml(ai.model || ai.source || 'OpenRouter')}`
        : 'Strategic fallback summary';

    const priorityCards = priorities.length
        ? priorities.map((item) => `
            <article class="priority-card">
                <p class="priority-kicker">${escapeHtml(item.title || 'Priority')}</p>
                <p>${escapeHtml(item.why_it_matters || '')}</p>
                <strong>${escapeHtml(item.action || '')}</strong>
            </article>
        `).join('')
        : '<p class="muted-copy">No priority breakdown was generated.</p>';

    return `
        <section class="ai-grid">
            <article class="card">
                <div class="section-heading">
                    <p class="eyebrow">AI Growth Audit Platform</p>
                    <h3>${sourceLabel}</h3>
                </div>
                <p class="lead-copy">${escapeHtml(ai.executive_summary || 'No summary available.')}</p>
                ${ai.error ? `<p class="inline-note">OpenRouter note: ${escapeHtml(ai.error)}</p>` : ''}
                ${ai.stakeholder_note ? `<p class="muted-copy">${escapeHtml(ai.stakeholder_note)}</p>` : ''}
            </article>

            <article class="card">
                <div class="section-heading">
                    <p class="eyebrow">Top priorities</p>
                    <h3>Fix these first</h3>
                </div>
                <div class="priority-grid">${priorityCards}</div>
            </article>

            <article class="card">
                <div class="section-heading">
                    <p class="eyebrow">Execution cues</p>
                    <h3>Quick wins and content moves</h3>
                </div>
                <div class="two-column-list">
                    <div>
                        <h4>Quick wins</h4>
                        ${renderSimpleList(quickWins, 'compact-list')}
                    </div>
                    <div>
                        <h4>Content strategy</h4>
                        ${renderSimpleList(contentStrategy, 'compact-list')}
                    </div>
                </div>
            </article>

            <article class="card growth-plan-card">
                <div class="section-heading">
                    <p class="eyebrow">30-day growth plan</p>
                    <h3>What to do after the audit</h3>
                </div>
                ${renderGrowthPlan(growthPlan)}
            </article>
        </section>
    `;
}

function renderContentLab(audit) {
    const lab = audit.content_lab || {};
    const defaults = lab.generator_defaults || {};
    const crawl = lab.crawl || {};

    return `
        <section class="content-lab-grid">
            <article class="card">
                <div class="section-heading">
                    <p class="eyebrow">AI Growth Audit Platform</p>
                    <h3>Keyword, content, and execution direction</h3>
                </div>
                <div class="three-column-list">
                    <div class="soft-panel">
                        <h4>Keyword opportunities</h4>
                        ${renderSimpleList(lab.keyword_opportunities || [], 'compact-list')}
                    </div>
                    <div class="soft-panel">
                        <h4>Content suggestions</h4>
                        ${renderSimpleList(lab.content_suggestions || [], 'compact-list')}
                    </div>
                    <div class="soft-panel">
                        <h4>Important suggestions</h4>
                        ${renderSimpleList(lab.important_suggestions || [], 'compact-list')}
                    </div>
                </div>
            </article>

            ${renderCrawlCard(crawl)}

            <article class="card content-generator-card">
                <div class="section-heading">
                    <p class="eyebrow">Content generator</p>
                    <h3>Generate natural SEO-ready copy</h3>
                </div>
                <p class="muted-copy">The generator aims for natural, specific, human-sounding copy. No tool can honestly guarantee detector outcomes, so review and add real business detail before publishing.</p>
                <form id="content-generator-form" class="generator-form" action="auditor/generate.php" method="post" novalidate>
                    <div class="inline-fields">
                        <div>
                            <label class="input-label" for="primary_keyword">Primary keyword</label>
                            <input id="primary_keyword" name="primary_keyword" type="text" required value="${escapeHtml(defaults.primary_keyword || '')}">
                        </div>
                        <div>
                            <label class="input-label" for="page_type">Page type</label>
                            <input id="page_type" name="page_type" type="text" value="${escapeHtml(defaults.page_type || 'landing page')}">
                        </div>
                    </div>

                    <div class="inline-fields">
                        <div>
                            <label class="input-label" for="secondary_keywords">Secondary keywords</label>
                            <input id="secondary_keywords" name="secondary_keywords" type="text" value="${escapeHtml((defaults.secondary_keywords || []).join(', '))}">
                        </div>
                        <div>
                            <label class="input-label" for="tone">Tone</label>
                            <input id="tone" name="tone" type="text" value="${escapeHtml(defaults.tone || 'clear, expert, human')}">
                        </div>
                    </div>

                    <div class="inline-fields">
                        <div>
                            <label class="input-label" for="target_word_count">Target word count</label>
                            <input id="target_word_count" name="target_word_count" type="number" min="300" max="3000" value="${escapeHtml(String(defaults.target_word_count || 900))}">
                        </div>
                        <div>
                            <label class="input-label" for="audience">Audience</label>
                            <input id="audience" name="audience" type="text" value="${escapeHtml(defaults.audience || '')}">
                        </div>
                    </div>

                    <div class="stack-field">
                        <label class="input-label" for="brief">Brief or angle</label>
                        <textarea id="brief" name="brief" rows="4">${escapeHtml(defaults.brief || '')}</textarea>
                    </div>

                    <div class="generator-actions">
                        <button type="submit" id="content-generator-submit">Generate content</button>
                        <p id="content-generator-feedback" class="form-feedback" data-tone="muted">Use the audit suggestions above as a starting point, then refine the inputs for the exact page you want to write.</p>
                    </div>
                </form>

                <div id="content-generator-result"></div>
            </article>
        </section>
    `;
}

function renderCrawlCard(crawl) {
    if (!crawl.enabled) {
        return `
            <article class="card">
                <div class="section-heading">
                    <p class="eyebrow">Page-by-page crawler</p>
                    <h3>Whole-site crawl is available</h3>
                </div>
                <p class="muted-copy">Yes, the tool can crawl a site page by page. Switch the audit scope to <strong>Whole site crawl</strong> and it will walk internal URLs up to the selected page limit.</p>
                <div class="soft-panel">
                    <h4>Main page keyword baseline</h4>
                    ${renderChipList(crawl.top_keywords || [], 'Run a site crawl to collect a broader keyword set.')}
                </div>
            </article>
        `;
    }

    const summary = crawl.summary || {};

    return `
        <article class="card">
            <div class="section-heading">
                <p class="eyebrow">Page-by-page crawler</p>
                <h3>Whole-site crawl summary</h3>
            </div>
            <div class="mini-grid crawl-mini-grid">
                ${renderMiniStat('Pages crawled', crawl.pages_crawled || 0)}
                ${renderMiniStat('Thin pages', summary.thin_content_pages || 0)}
                ${renderMiniStat('Missing titles', summary.missing_titles || 0)}
                ${renderMiniStat('Missing descriptions', summary.missing_descriptions || 0)}
                ${renderMiniStat('Noindex pages', summary.noindex_pages || 0)}
                ${renderMiniStat('Avg. words', summary.average_word_count || 0)}
            </div>
            <div class="soft-panel">
                <h4>Sitewide keyword cluster</h4>
                ${renderChipList(crawl.top_keywords || [], 'No sitewide keyword signals were extracted.')}
            </div>
            <div class="soft-panel">
                <h4>Pages with the biggest gaps</h4>
                ${renderCrawlTable(crawl.pages || [])}
            </div>
            ${crawl.failed_fetches ? `<p class="muted-copy">Skipped or failed fetches during crawl: ${escapeHtml(String(crawl.failed_fetches))}</p>` : ''}
        </article>
    `;
}

function renderGeneratorResult(result) {
    const container = document.getElementById('content-generator-result');
    if (!container) {
        return;
    }

    const sourceLabel = result.available
        ? `Generated with ${escapeHtml(result.model || result.source || 'OpenRouter')}`
        : 'Generated with local fallback scaffold';

    container.innerHTML = `
        <section class="generated-result">
            <div class="module-header">
                <div>
                    <p class="eyebrow">Generated draft</p>
                    <h3>${sourceLabel}</h3>
                </div>
                ${result.error ? `<span class="status-pill">Fallback</span>` : ''}
            </div>
            ${result.error ? `<p class="inline-note">Generator note: ${escapeHtml(result.error)}</p>` : ''}
            <div class="two-column-list">
                <div class="soft-panel">
                    <h4>Title options</h4>
                    ${renderSimpleList(result.title_options || [], 'compact-list')}
                </div>
                <div class="soft-panel">
                    <h4>Meta description</h4>
                    <p class="muted-copy">${escapeHtml(result.meta_description || 'No meta description generated.')}</p>
                    <h4>Suggested slug</h4>
                    <p class="slug-chip">${escapeHtml(result.slug || '')}</p>
                </div>
            </div>
            <div class="three-column-list generated-support-grid">
                <div class="soft-panel">
                    <h4>Outline</h4>
                    ${renderSimpleList(result.outline || [], 'compact-list')}
                </div>
                <div class="soft-panel">
                    <h4>Keyword notes</h4>
                    ${renderSimpleList(result.keyword_usage_notes || [], 'compact-list')}
                </div>
                <div class="soft-panel">
                    <h4>FAQs</h4>
                    ${renderSimpleList(result.faq_questions || [], 'compact-list')}
                </div>
            </div>
            <div class="soft-panel">
                <h4>Content draft</h4>
                <pre class="generated-copy">${escapeHtml(result.content || '')}</pre>
            </div>
            <div class="soft-panel">
                <h4>Editor notes</h4>
                ${renderSimpleList(result.editor_notes || [], 'compact-list')}
            </div>
        </section>
    `;
}

function setGeneratorState(isLoading) {
    const submitButton = document.getElementById('content-generator-submit');
    if (!submitButton) {
        return;
    }

    submitButton.disabled = isLoading;
    submitButton.textContent = isLoading ? 'Generating...' : 'Generate content';
}

function setGeneratorFeedback(message, tone) {
    const feedbackNode = document.getElementById('content-generator-feedback');
    if (!feedbackNode) {
        return;
    }

    feedbackNode.textContent = message;
    feedbackNode.dataset.tone = tone;
}

function renderModules(audit) {
    const analytics = audit.modules?.analytics || {};
    const competitor = audit.modules?.competitor || {};
    const ecommerce = audit.modules?.ecommerce || {};
    const chatbot = audit.modules?.chatbot || {};

    return `
        <section class="module-grid">
            ${renderAnalyticsModule(analytics)}
            ${renderCompetitorModule(competitor)}
            ${renderEcommerceModule(ecommerce)}
            ${renderChatbotModule(chatbot)}
        </section>
    `;
}

function renderAnalyticsModule(module) {
    return `
        <article class="card module-card">
            <div class="module-header">
                <div>
                    <p class="eyebrow">Analytics & Tracking Audit</p>
                    <h3>${escapeHtml(module.headline || 'Tracking audit')}</h3>
                </div>
                ${renderScoreBadge(module.score)}
            </div>
            <div class="mini-grid">
                ${renderMiniStat('Tools', (module.detected_tools || []).length)}
                ${renderMiniStat('Events', (module.detected_events || []).length)}
                ${renderMiniStat('Conversions', (module.conversion_events || []).length)}
                ${renderMiniStat('Missing events', (module.missing_events || []).length)}
            </div>
            <div class="soft-panel">
                <h4>Detected stack</h4>
                ${renderChipList(module.detected_tools || [], 'No analytics or pixel stack detected.')}
            </div>
            <div class="soft-panel">
                <h4>Event coverage</h4>
                ${renderKeyValueList([
                    ['Detected events', (module.detected_events || []).join(', ') || 'None'],
                    ['Missing events', (module.missing_events || []).join(', ') || 'None'],
                    ['Conversion events', (module.conversion_events || []).join(', ') || 'None'],
                ])}
            </div>
            ${renderSimpleModuleSection('Findings', module.findings || [])}
            ${renderSimpleModuleSection('Recommendations', module.recommendations || [])}
            ${renderSimpleModuleSection('AI strategy', module.ai_recommendations || [])}
        </article>
    `;
}

function renderCompetitorModule(module) {
    if (module.status === 'requires_input') {
        return `
            <article class="card module-card">
                <div class="module-header">
                    <div>
                        <p class="eyebrow">Competitor Benchmark Audit</p>
                        <h3>${escapeHtml(module.headline || 'Competitor benchmark')}</h3>
                    </div>
                    ${renderStatusBadge('Needs input')}
                </div>
                <p class="muted-copy">${escapeHtml(module.note || 'Add competitor URLs to compare against rival pages.')}</p>
                <div class="soft-panel">
                    <h4>Target keywords</h4>
                    ${renderChipList(module.target_keywords || [], 'No keyword profile detected yet.')}
                </div>
            </article>
        `;
    }

    if (module.status === 'unavailable') {
        return `
            <article class="card module-card">
                <div class="module-header">
                    <div>
                        <p class="eyebrow">Competitor Benchmark Audit</p>
                        <h3>${escapeHtml(module.headline || 'Competitor benchmark')}</h3>
                    </div>
                    ${renderStatusBadge('Unavailable')}
                </div>
                <p class="muted-copy">${escapeHtml(module.note || 'Competitor pages could not be fetched.')}</p>
                ${renderCompetitorTable(module.comparison_rows || [])}
            </article>
        `;
    }

    return `
        <article class="card module-card module-wide">
            <div class="module-header">
                <div>
                    <p class="eyebrow">Competitor Benchmark Audit</p>
                    <h3>${escapeHtml(module.headline || 'Competitor benchmark')}</h3>
                </div>
                ${renderScoreBadge(module.score)}
            </div>
            <p class="muted-copy">${escapeHtml(module.note || '')}</p>
            ${renderCompetitorTable(module.comparison_rows || [])}
            <div class="soft-panel">
                <h4>Why competitors may outrank you</h4>
                ${renderSimpleList((module.ai_outrank_reasons || module.outrank_reasons || []), 'compact-list')}
            </div>
            ${renderSimpleModuleSection('Recommendations', module.recommendations || [])}
            ${renderSimpleModuleSection('AI strategy', module.ai_recommendations || [])}
        </article>
    `;
}

function renderEcommerceModule(module) {
    if (!module.applicable) {
        return `
            <article class="card module-card">
                <div class="module-header">
                    <div>
                        <p class="eyebrow">E-commerce Audit</p>
                        <h3>${escapeHtml(module.headline || 'E-commerce audit')}</h3>
                    </div>
                    ${renderStatusBadge('Not detected')}
                </div>
                <p class="muted-copy">The tool did not find strong store or product-flow signals in the inspected pages.</p>
            </article>
        `;
    }

    return `
        <article class="card module-card">
            <div class="module-header">
                <div>
                    <p class="eyebrow">E-commerce Audit</p>
                    <h3>${escapeHtml(module.headline || 'E-commerce audit')}</h3>
                </div>
                ${renderScoreBadge(module.score)}
            </div>
            <div class="soft-panel">
                <h4>Flow pages</h4>
                ${renderPageRefs(module.pages || {})}
            </div>
            <div class="soft-panel">
                <h4>Pricing cues</h4>
                ${renderChipList(module.pricing_signals || [], 'No obvious pricing psychology cues were detected.')}
            </div>
            ${renderSimpleModuleSection('Product-page gaps', module.product_description_gaps || [])}
            ${renderSimpleModuleSection('Checkout friction', module.checkout_friction_points || [])}
            ${renderSimpleModuleSection('Recommendations', module.recommendations || [])}
            ${renderSimpleModuleSection('AI strategy', module.ai_recommendations || [])}
        </article>
    `;
}

function renderChatbotModule(module) {
    return `
        <article class="card module-card">
            <div class="module-header">
                <div>
                    <p class="eyebrow">AI Chatbot / Customer Experience Audit</p>
                    <h3>${escapeHtml(module.headline || 'Chatbot and CX audit')}</h3>
                </div>
                ${renderScoreBadge(module.score)}
            </div>
            <div class="mini-grid">
                ${renderMiniStat('Chatbot', module.chatbot_detected ? 'Yes' : 'No')}
                ${renderMiniStat('Response readiness', module.response_accuracy_estimate || 'Unknown')}
                ${renderMiniStat('Lead capture', module.lead_capture_effectiveness || 'Unknown')}
                ${renderMiniStat('Missing intents', (module.missing_intents || []).length)}
            </div>
            <div class="soft-panel">
                <h4>Detected vendors</h4>
                ${renderChipList(module.detected_vendors || [], 'No chatbot vendor was detected.')}
            </div>
            <div class="soft-panel">
                <h4>Known intents</h4>
                ${renderChipList(module.known_intents || [], 'No clear intent coverage signals were detected.')}
            </div>
            ${renderSimpleModuleSection('Missing intents', module.missing_intents || [])}
            ${renderSimpleModuleSection('Recommendations', module.recommendations || [])}
            ${renderSimpleModuleSection('AI strategy', module.ai_recommendations || [])}
        </article>
    `;
}

function renderMetrics(audit) {
    const page = audit.metrics?.page || {};
    const content = audit.metrics?.content || {};
    const media = audit.metrics?.media || {};
    const links = audit.metrics?.links || {};
    const assets = audit.metrics?.assets || {};
    const enhancements = audit.metrics?.enhancements || {};
    const checks = audit.checks || {};

    return `
        <section class="metrics-grid">
            <article class="card">
                <div class="section-heading">
                    <p class="eyebrow">Page metadata</p>
                    <h3>Core tags</h3>
                </div>
                ${renderDefinitionRows([
                    ['Title length', String(page.title?.length || 0)],
                    ['Meta description length', String(page.description?.length || 0)],
                    ['Canonical', page.canonical || 'Missing'],
                    ['Meta robots', page.meta_robots || 'Not set'],
                    ['X-Robots-Tag', page.x_robots_tag || 'Not set'],
                    ['HTML lang', page.lang || 'Missing'],
                    ['Viewport', page.viewport || 'Missing'],
                    ['Charset', page.charset || 'Missing'],
                ])}
            </article>

            <article class="card">
                <div class="section-heading">
                    <p class="eyebrow">Content structure</p>
                    <h3>Relevance signals</h3>
                </div>
                ${renderDefinitionRows([
                    ['Word count', String(content.word_count || 0)],
                    ['Paragraph count', String(content.paragraph_count || 0)],
                    ['H1 count', String((page.h1 || []).length)],
                    ['H2 count', String((page.h2 || []).length)],
                    ['Heading outline', renderHeadingCounts(content.heading_counts || {}), true],
                    ['Primary H1', (page.h1 || []).slice(0, 2).join(' | ') || 'Missing'],
                    ['Keyword profile', (content.keywords || []).join(', ') || 'None detected'],
                ])}
            </article>

            <article class="card">
                <div class="section-heading">
                    <p class="eyebrow">Links, forms, and media</p>
                    <h3>Accessibility and conversion cues</h3>
                </div>
                ${renderDefinitionRows([
                    ['Internal links', String(links.internal || 0)],
                    ['External links', String(links.external || 0)],
                    ['Nofollow links', String(links.nofollow || 0)],
                    ['Empty anchors', String(links.empty_anchor_text || 0)],
                    ['Lead forms', String(audit.metrics?.forms?.lead_forms || 0)],
                    ['Form fields inspected', String(audit.metrics?.forms?.field_count || 0)],
                    ['Images found', String(media.total || 0)],
                    ['Images missing alt', String(media.missing_alt || 0)],
                ])}
            </article>

            <article class="card">
                <div class="section-heading">
                    <p class="eyebrow">Technical enhancements</p>
                    <h3>Site support signals</h3>
                </div>
                ${renderDefinitionRows([
                    ['HTTPS', yesNo(checks.https)],
                    ['robots.txt', checks.robots_txt?.found ? 'Found' : 'Missing'],
                    ['Sitemap', checks.sitemap?.found ? 'Found' : 'Missing'],
                    ['Structured data blocks', String(enhancements.structured_data_count || 0)],
                    ['Schema types', (enhancements.structured_data_types || []).join(', ') || 'None detected'],
                    ['Open Graph', enhancementCoverage(enhancements.open_graph?.coverage || {}), true],
                    ['Twitter cards', enhancementCoverage(enhancements.twitter_cards?.coverage || {}), true],
                    ['Favicon', yesNo(enhancements.favicon)],
                    ['Script files', String(assets.script_files || 0)],
                    ['Inline scripts', String(assets.inline_scripts || 0)],
                    ['Stylesheets', String(assets.stylesheets || 0)],
                ])}
            </article>
        </section>
    `;
}

function renderIssues(issues) {
    if (!issues.length) {
        return `
            <section class="card">
                <div class="section-heading">
                    <p class="eyebrow">Issues</p>
                    <h3>No blocking issues found</h3>
                </div>
                <p class="muted-copy">The page looks clean from the checks this tool ran.</p>
            </section>
        `;
    }

    const items = issues.map((issue) => `
        <article class="issue-card severity-${escapeHtml(issue.severity || 'low')}">
            <div class="issue-header">
                <span class="severity-pill">${escapeHtml(titleize(issue.severity || 'low'))}</span>
                <span class="category-pill">${escapeHtml(titleize(issue.category || 'issue'))}</span>
            </div>
            <h3>${escapeHtml(issue.title || 'Issue')}</h3>
            <p>${escapeHtml(issue.details || '')}</p>
            <p><strong>Recommendation:</strong> ${escapeHtml(issue.recommendation || '')}</p>
            <p class="muted-copy"><strong>Evidence:</strong> ${escapeHtml(issue.evidence || '')}</p>
            ${renderIssueFixHelp(issue)}
        </article>
    `).join('');

    return `
        <section class="card">
            <div class="section-heading">
                <p class="eyebrow">Issues</p>
                <h3>Prioritized findings</h3>
            </div>
            <div class="issues-grid">${items}</div>
        </section>
    `;
}

function renderSimpleModuleSection(title, items) {
    return `
        <div class="soft-panel">
            <h4>${escapeHtml(title)}</h4>
            ${renderSimpleList(items || [], 'compact-list')}
        </div>
    `;
}

function renderGrowthPlan(weeks) {
    if (!weeks.length) {
        return '<p class="muted-copy">No 30-day growth plan was generated.</p>';
    }

    return `
        <div class="growth-plan-grid">
            ${weeks.map((week) => `
                <article class="week-card">
                    <p class="week-kicker">${escapeHtml(week.week || 'Week')}</p>
                    <h4>${escapeHtml(week.focus || '')}</h4>
                    ${renderSimpleList(week.tasks || [], 'compact-list')}
                    ${week.goal ? `<p class="muted-copy"><strong>Goal:</strong> ${escapeHtml(week.goal)}</p>` : ''}
                </article>
            `).join('')}
        </div>
    `;
}

function renderIssueFixHelp(issue) {
    const steps = Array.isArray(issue.how_to_fix) ? issue.how_to_fix : [];
    const example = issue.example_fix || '';

    if (!steps.length && !example) {
        return '';
    }

    return `
        <div class="soft-panel issue-fix-panel">
            <h4>How to fix this</h4>
            ${renderSimpleList(steps, 'compact-list')}
            ${example ? renderIssueExample(example) : ''}
        </div>
    `;
}

function renderIssueExample(example) {
    const safeExample = escapeHtml(example);
    const useCodeBlock = example.includes('\n') || example.includes('<');

    if (useCodeBlock) {
        return `
            <div class="issue-example">
                <strong>Example fix</strong>
                <pre class="generated-copy issue-example-code">${safeExample}</pre>
            </div>
        `;
    }

    return `
        <div class="issue-example">
            <strong>Example fix</strong>
            <p class="muted-copy">${safeExample}</p>
        </div>
    `;
}

function renderChipList(items, emptyMessage) {
    if (!items.length) {
        return `<p class="muted-copy">${escapeHtml(emptyMessage)}</p>`;
    }

    return `<div class="chip-row">${items.map((item) => `<span class="chip">${escapeHtml(item)}</span>`).join('')}</div>`;
}

function renderPageRefs(pageRefs) {
    const rows = Object.entries(pageRefs)
        .map(([name, page]) => `
            <div class="page-ref">
                <strong>${escapeHtml(titleize(name))}</strong>
                <span>${page?.found ? 'Found' : 'Not found'}</span>
                <p>${escapeHtml(page?.url || 'No URL')}</p>
            </div>
        `)
        .join('');

    return `<div class="page-ref-grid">${rows}</div>`;
}

function renderCompetitorTable(rows) {
    if (!rows.length) {
        return '<p class="muted-copy">No competitor rows to show yet.</p>';
    }

    return `
        <div class="table-wrap">
            <table class="comparison-table">
                <thead>
                    <tr>
                        <th>Competitor</th>
                        <th>Keyword overlap</th>
                        <th>Words</th>
                        <th>H2s</th>
                        <th>Authority proxy</th>
                        <th>Content gap</th>
                    </tr>
                </thead>
                <tbody>
                    ${rows.map((row) => `
                        <tr>
                            <td>${escapeHtml(row.host || row.url || 'Unknown')}</td>
                            <td>${row.keyword_overlap_pct === null ? 'N/A' : `${escapeHtml(String(row.keyword_overlap_pct))}%`}</td>
                            <td>${row.word_count === null ? 'N/A' : escapeHtml(String(row.word_count))}</td>
                            <td>${row.h2_count === null ? 'N/A' : escapeHtml(String(row.h2_count))}</td>
                            <td>${row.authority_proxy === null ? 'N/A' : escapeHtml(String(row.authority_proxy))}</td>
                            <td>${row.content_gap === null ? 'N/A' : escapeHtml(String(row.content_gap))}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

function renderCrawlTable(rows) {
    if (!rows.length) {
        return '<p class="muted-copy">No crawled pages to show.</p>';
    }

    return `
        <div class="table-wrap">
            <table class="comparison-table crawl-table">
                <thead>
                    <tr>
                        <th>Page</th>
                        <th>Words</th>
                        <th>Gaps</th>
                        <th>Keywords</th>
                    </tr>
                </thead>
                <tbody>
                    ${rows.map((row) => `
                        <tr>
                            <td>
                                <strong>${escapeHtml(row.title || shortUrl(row.url || ''))}</strong>
                                <div class="table-subcopy">${escapeHtml(shortUrl(row.url || ''))}</div>
                            </td>
                            <td>${escapeHtml(String(row.word_count || 0))}</td>
                            <td>${escapeHtml(renderGapSummary(row))}</td>
                            <td>${escapeHtml((row.keywords || []).slice(0, 4).join(', ') || 'None')}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

function renderGapSummary(page) {
    const gaps = [];
    if (page.missing_title) gaps.push('title');
    if (page.missing_description) gaps.push('description');
    if (page.missing_h1) gaps.push('H1');
    if (page.canonical_missing) gaps.push('canonical');
    if (page.thin_content) gaps.push('thin copy');
    if (page.noindex) gaps.push('noindex');

    return gaps.length ? gaps.join(', ') : 'No major gaps';
}

function renderSimpleList(items, className) {
    if (!items.length) {
        return '<p class="muted-copy">No items to show.</p>';
    }

    const safeItems = items.map((item) => `<li>${escapeHtml(item)}</li>`).join('');
    return `<ul class="${className}">${safeItems}</ul>`;
}

function renderDefinitionRows(rows) {
    return `
        <dl class="definition-list">
            ${rows.map(([label, value, isHtml = false]) => `
                <div>
                    <dt>${escapeHtml(label)}</dt>
                    <dd>${isHtml ? value : escapeHtml(value)}</dd>
                </div>
            `).join('')}
        </dl>
    `;
}

function renderHeadingCounts(counts) {
    return Object.entries(counts)
        .map(([key, value]) => `<span class="chip">${escapeHtml(key.toUpperCase())}: ${escapeHtml(String(value))}</span>`)
        .join(' ');
}

function renderKeyValueList(rows) {
    return `
        <dl class="mini-list">
            ${rows.map(([label, value]) => `
                <div>
                    <dt>${escapeHtml(label)}</dt>
                    <dd>${escapeHtml(value)}</dd>
                </div>
            `).join('')}
        </dl>
    `;
}

function renderScoreBadge(score) {
    return `<span class="score-pill ${scoreToneClass(score)}">${escapeHtml(String(score ?? 'N/A'))}</span>`;
}

function renderStatusBadge(label) {
    return `<span class="status-pill">${escapeHtml(label)}</span>`;
}

function renderMiniStat(label, value) {
    return `
        <div class="mini-stat">
            <span>${escapeHtml(label)}</span>
            <strong>${escapeHtml(String(value))}</strong>
        </div>
    `;
}

function enhancementCoverage(coverage) {
    const active = Object.entries(coverage)
        .filter(([, present]) => Boolean(present))
        .map(([name]) => name);

    if (!active.length) {
        return 'Missing';
    }

    return active.map((name) => `<span class="chip">${escapeHtml(name)}</span>`).join(' ');
}

function yesNo(value) {
    return value ? 'Yes' : 'No';
}

function scoreToneClass(score) {
    const safeScore = Number(score ?? 0);
    if (safeScore >= 85) {
        return 'tone-excellent';
    }
    if (safeScore >= 70) {
        return 'tone-good';
    }
    if (safeScore >= 50) {
        return 'tone-warn';
    }
    return 'tone-risk';
}

function titleize(value) {
    return String(value)
        .replace(/[_-]+/g, ' ')
        .replace(/\b\w/g, (character) => character.toUpperCase());
}

function shortUrl(value) {
    try {
        const url = new URL(value);
        return `${url.host}${url.pathname === '/' ? '' : url.pathname}`;
    } catch {
        return value;
    }
}

function escapeHtml(value) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;',
    };

    return String(value).replace(/[&<>"']/g, (character) => map[character]);
}

// ── Save Report Bar ────────────────────────────────────────────
let _saveBarData = null;

function showSaveBar(auditData) {
    _saveBarData = auditData;
    let bar = document.getElementById('save-report-bar');
    if (!bar) return;
    // Reset to initial state
    bar.querySelector('#save-report-btn').disabled = false;
    bar.querySelector('#save-report-btn').innerHTML = '&#128190; Save Report';
    bar.querySelector('#save-report-status').textContent = '';
    bar.style.display = 'flex';
    bar.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function hideSaveBar() {
    const bar = document.getElementById('save-report-bar');
    if (bar) bar.style.display = 'none';
    _saveBarData = null;
}

async function saveReport() {
    if (!_saveBarData) return;

    const btn    = document.getElementById('save-report-btn');
    const status = document.getElementById('save-report-status');
    const appBase = document.querySelector('meta[name="app-url"]')?.content || window.location.origin;
    const csrf   = document.querySelector('meta[name="csrf-token"]')?.content || '';

    btn.disabled = true;
    btn.textContent = 'Saving…';
    status.textContent = '';
    status.style.color = '';

    try {
        const url   = _saveBarData.target?.final_url || _saveBarData.target?.requested_url || '';
        const score = _saveBarData.scores?.overall ?? 0;

        // Send as raw JSON body — avoids PHP post_max_size / max_input_vars
        // truncating large result payloads when sent as FormData fields.
        // Content-Type: application/json ensures PHP does NOT pre-parse the body
        // into $_POST, keeping php://input intact for the server to read.
        const payload = JSON.stringify({ url, score, result_json: _saveBarData });

        const res  = await fetch(appBase + '/auditor/save.php', {
            method: 'POST',
            body: payload,
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrf,
            },
        });
        const data = await res.json();

        if (!res.ok || !data.success) throw new Error(data.error || 'Save failed');

        const historyUrl = appBase + '/seo_audits.php?id=' + data.audit_id;
        const publicUrl  = appBase + '/seo_report.php?token=' + data.public_token;

        btn.innerHTML = '&#10003; Saved';
        status.innerHTML =
            '<a href="' + historyUrl + '" style="font-weight:700;">View in History →</a>' +
            ' &nbsp;|&nbsp; ' +
            '<a href="' + publicUrl + '" target="_blank" rel="noopener" style="font-weight:700;">Copy Public Link ↗</a>';
        status.style.color = '#16a34a';

        // Copy public link to clipboard automatically
        navigator.clipboard?.writeText(publicUrl).catch(() => {});

    } catch (err) {
        btn.disabled = false;
        btn.innerHTML = '&#128190; Save Report';
        status.textContent = err.message || 'Save failed. Please try again.';
        status.style.color = '#dc2626';
    }
}

document.getElementById('save-report-btn')?.addEventListener('click', saveReport);