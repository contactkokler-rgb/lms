<?php
// Catch ALL errors and show them cleanly instead of white 500 page
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    error_log("[LeadPro roles.php] E{$errno}: {$errstr} in {$errfile}:{$errline}");
    return false;
});
set_exception_handler(function($e) {
    error_log("[LeadPro roles.php] FATAL: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine());
    http_response_code(500);
    echo "<!DOCTYPE html><html><body style='font-family:sans-serif;padding:40px'>";
    echo "<h2 style='color:#dc2626'>Roles page error</h2>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p>File: " . htmlspecialchars(basename($e->getFile())) . " line " . (int)$e->getLine() . "</p>";
    exit;
});

require_once __DIR__ . '/config/auth.php';
$user     = require_auth();
$is_super = is_super_admin();

// Roles management is restricted to Super Admin only
if (!$is_super) {
    http_response_code(403);
    include __DIR__ . '/layouts/403.php';
    exit;
}

$account_id = (int)($user['account_id'] ?? 0);
$page_title = 'Roles & Permissions';
$active_nav = 'roles';

// ── POST Actions ─────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { http_response_code(403); die('CSRF check failed'); }
    $act = isset($_POST['action']) ? $_POST['action'] : '';

    // Create role
    if ($act === 'create_role') {
        $label = trim(isset($_POST['label']) ? $_POST['label'] : '');
        $desc  = trim(isset($_POST['description']) ? $_POST['description'] : '');
        $name  = strtolower(preg_replace('/[^a-z0-9]+/', '_', trim($label, '_')));
        $perms = isset($_POST['permissions']) ? array_filter(array_map('intval', (array)$_POST['permissions'])) : [];

        if (!$label) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Role name is required.'];
        } elseif (db_fetch('SELECT id FROM roles WHERE name = ?', 's', $name)) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'A role with that name slug already exists.'];
        } else {
            $role_id = db_insert('INSERT INTO roles (name, label, description, is_system) VALUES (?,?,?,0)', 'sss', $name, $label, $desc);
            if ($role_id && $perms) {
                $db = db();
                $stmt = $db->prepare('INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES (?,?)');
                if ($stmt) {
                    foreach ($perms as $pid) {
                        $pid_int = (int)$pid;
                        $stmt->bind_param('ii', $role_id, $pid_int);
                        $stmt->execute();
                    }
                    $stmt->close();
                }
            }
            audit('role.created', 'role:' . (int)$role_id);
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Role created.'];
            header('Location: ' . APP_URL . '/roles.php?role=' . (int)$role_id);
            exit;
        }
        header('Location: ' . APP_URL . '/roles.php');
        exit;

    // Save permissions
    } elseif ($act === 'update_permissions') {
        $role_id = (int)(isset($_POST['role_id']) ? $_POST['role_id'] : 0);
        $role    = $role_id ? db_fetch('SELECT * FROM roles WHERE id = ?', 'i', $role_id) : null;

        if (!$role) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Role not found.'];
        } elseif ((int)$role['is_system'] && !$is_super) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Cannot edit system roles.'];
        } else {
            $new_label = trim(isset($_POST['label']) ? $_POST['label'] : '');
            $new_desc  = trim(isset($_POST['description']) ? $_POST['description'] : '');
            $new_perms = isset($_POST['permissions']) ? array_filter(array_map('intval', (array)$_POST['permissions'])) : [];

            if ($new_label) {
                db_query('UPDATE roles SET label=?, description=? WHERE id=?', 'ssi', $new_label, $new_desc, $role_id);
            }

            $db = db();
            $db->begin_transaction();
            try {
                db_query('DELETE FROM role_permissions WHERE role_id = ?', 'i', $role_id);
                if ($new_perms) {
                    $stmt = $db->prepare('INSERT INTO role_permissions (role_id, permission_id) VALUES (?,?)');
                    if ($stmt) {
                        foreach ($new_perms as $pid) {
                            $pid_int = (int)$pid;
                            $stmt->bind_param('ii', $role_id, $pid_int);
                            $stmt->execute();
                        }
                        $stmt->close();
                    }
                }
                $db->commit();
                audit('role.updated', 'role:' . $role_id);
                $_SESSION['flash'] = ['type'=>'success','msg'=>'Role saved.'];
            } catch (Throwable $e) {
                $db->rollback();
                $_SESSION['flash'] = ['type'=>'error','msg'=>'Save failed: ' . $e->getMessage()];
            }
        }
        header('Location: ' . APP_URL . '/roles.php?role=' . $role_id . '&tab=permissions');
        exit;

    // Delete role
    } elseif ($act === 'delete_role') {
        $role_id = (int)(isset($_POST['role_id']) ? $_POST['role_id'] : 0);
        $role    = $role_id ? db_fetch('SELECT * FROM roles WHERE id = ?', 'i', $role_id) : null;

        if (!$role) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Role not found.'];
        } elseif ((int)$role['is_system'] && !$is_super) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Cannot delete system roles.'];
        } elseif (db_fetch('SELECT id FROM users WHERE role_id = ? LIMIT 1', 'i', $role_id)) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Reassign all users before deleting this role.'];
        } else {
            db_query('DELETE FROM roles WHERE id = ?', 'i', $role_id);
            audit('role.deleted', 'role:' . $role['name']);
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Role deleted.'];
        }
        header('Location: ' . APP_URL . '/roles.php');
        exit;

    // Assign user to role
    } elseif ($act === 'assign_role') {
        $uid     = (int)(isset($_POST['user_id'])  ? $_POST['user_id']  : 0);
        $role_id = (int)(isset($_POST['role_id'])  ? $_POST['role_id']  : 0);

        // Scope: super admin sees all users, others scoped to their account
        if ($is_super) {
            $tu = $uid ? db_fetch('SELECT * FROM users WHERE id = ?', 'i', $uid) : null;
        } else {
            $tu = $uid ? db_fetch('SELECT * FROM users WHERE id = ? AND account_id = ?', 'ii', $uid, $account_id) : null;
        }
        $tr = $role_id ? db_fetch('SELECT * FROM roles WHERE id = ?', 'i', $role_id) : null;

        if (!$tu || !$tr) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'User or role not found.'];
        } elseif ($tr['name'] === 'super_admin' && !$is_super) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Only Super Admins can assign the Super Admin role.'];
        } else {
            db_query('UPDATE users SET role_id = ? WHERE id = ?', 'ii', $role_id, $uid);
            audit('role.assigned', 'user:' . $uid);
            $_SESSION['flash'] = ['type'=>'success','msg'=>h($tu['first_name']) . ' assigned to ' . h($tr['label']) . '.'];
        }
        header('Location: ' . APP_URL . '/roles.php?role=' . $role_id . '&tab=users');
        exit;
    }

    header('Location: ' . APP_URL . '/roles.php');
    exit;
}

// ── Flash ────────────────────────────────────────────────────
$flash = isset($_SESSION['flash']) ? $_SESSION['flash'] : null;
unset($_SESSION['flash']);

// ── Data: load roles, permissions, role_perms ────────────────
// Separate queries for super admin vs account-scoped to avoid variadic spread issues
if ($is_super) {
    $roles = db_fetch_all(
        'SELECT r.*, COUNT(u.id) AS member_count
         FROM roles r
         LEFT JOIN users u ON u.role_id = r.id
         GROUP BY r.id
         ORDER BY r.is_system DESC, r.id ASC'
    );
} else {
    $roles = db_fetch_all(
        'SELECT r.*, COUNT(u.id) AS member_count
         FROM roles r
         LEFT JOIN users u ON u.role_id = r.id AND u.account_id = ?
         GROUP BY r.id
         ORDER BY r.is_system DESC, r.id ASC',
        'i', $account_id
    );
}

$all_permissions = db_fetch_all('SELECT * FROM permissions ORDER BY module, action');

// Group permissions by module
$by_module = [];
foreach ($all_permissions as $p) {
    $by_module[$p['module']][] = $p;
}

// Build role_perms map: [role_id] => ['module.action' => permission_id]
$role_perms = [];
$rp_rows = db_fetch_all(
    'SELECT rp.role_id, p.id AS pid, p.module, p.action
     FROM role_permissions rp
     JOIN permissions p ON p.id = rp.permission_id'
);
foreach ($rp_rows as $row) {
    $rid = (int)$row['role_id'];
    $role_perms[$rid][$row['module'] . '.' . $row['action']] = (int)$row['pid'];
}

// Determine which role is being viewed
$viewing_id = isset($_GET['role']) ? (int)$_GET['role'] : 0;
$active_tab = (isset($_GET['tab']) && $_GET['tab'] === 'users') ? 'users' : 'permissions';
$viewing    = null;
foreach ($roles as $r) {
    if ((int)$r['id'] === $viewing_id) {
        $viewing = $r;
        break;
    }
}
if (!$viewing && count($roles) > 0) {
    $viewing    = $roles[0];
    $viewing_id = (int)$viewing['id'];
}

// Users in this role
$role_users       = [];
$assignable_users = [];
if ($viewing) {
    if ($is_super) {
        $role_users = db_fetch_all(
            'SELECT u.id, u.first_name, u.last_name, u.email, u.status, u.designation, a.name AS account_name
             FROM users u
             LEFT JOIN accounts a ON a.id = u.account_id
             WHERE u.role_id = ?
             ORDER BY u.first_name',
            'i', $viewing_id
        );
        $assignable_users = db_fetch_all(
            "SELECT u.id, u.first_name, u.last_name, u.email, r.label AS `current_role`
             FROM users u
             JOIN roles r ON r.id = u.role_id
             WHERE u.role_id != ? AND u.status != 'invited'
             ORDER BY u.first_name",
            'i', $viewing_id
        );
    } else {
        $role_users = db_fetch_all(
            'SELECT u.id, u.first_name, u.last_name, u.email, u.status, u.designation, a.name AS account_name
             FROM users u
             LEFT JOIN accounts a ON a.id = u.account_id
             WHERE u.role_id = ? AND u.account_id = ?
             ORDER BY u.first_name',
            'ii', $viewing_id, $account_id
        );
        $assignable_users = db_fetch_all(
            "SELECT u.id, u.first_name, u.last_name, u.email, r.label AS `current_role`
             FROM users u
             JOIN roles r ON r.id = u.role_id
             WHERE u.role_id != ? AND u.account_id = ? AND u.status != 'invited'
             ORDER BY u.first_name",
            'ii', $viewing_id, $account_id
        );
    }
}

// Pre-build JS perm map (avoid arrow functions = PHP 7.4 safe)
$role_perm_js = [];
foreach ($roles as $r) {
    $rid  = (int)$r['id'];
    $pids = [];
    foreach ($all_permissions as $p) {
        $key = $p['module'] . '.' . $p['action'];
        if (isset($role_perms[$rid][$key])) {
            $pids[] = (int)$p['id'];
        }
    }
    $role_perm_js[$rid] = $pids;
}

// Module icons
$module_icons = [
    'dashboard' => 'M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z',
    'leads'     => 'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 7a4 4 0 1 0 0-8 4 4 0 0 0 0 8z',
    'forms'     => 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z',
    'domains'   => 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20z',
    'reports'   => 'M18 20V10M12 20V4M6 20v-6',
    'team'      => 'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75',
    'settings'  => 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
    'platform'  => 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',
];
$role_colors = [
    'super_admin'   => ['bg'=>'#faf5ff','color'=>'#7c3aed','badge'=>'badge-purple'],
    'account_owner' => ['bg'=>'#eff6ff','color'=>'#2563eb','badge'=>'badge-blue'],
    'manager'       => ['bg'=>'#f0fdf4','color'=>'#16a34a','badge'=>'badge-green'],
    'agent'         => ['bg'=>'#fffbeb','color'=>'#d97706','badge'=>'badge-yellow'],
];

include __DIR__ . '/layouts/header.php';
?>

<?php if ($flash): ?>
<div class="alert alert-<?= h($flash['type']) ?>" data-auto-dismiss><?= h($flash['msg']) ?></div>
<?php endif; ?>

<div class="page-header">
    <div>
        <h1 class="page-title">Roles &amp; Permissions</h1>
        <p class="page-subtitle">Manage what each role can access</p>
    </div>
    <button class="btn btn-primary" onclick="openModal('createRoleModal')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="12" y1="5" x2="12" y2="19" />
            <line x1="5" y1="12" x2="19" y2="12" />
        </svg>
        New Role
    </button>
</div>

<div style="display:flex;gap:20px;align-items:flex-start;">

    <!-- Sidebar: role list -->
    <div style="width:230px;flex-shrink:0;">
        <div class="card">
            <div style="padding:8px;">
                <?php foreach ($roles as $r):
                    $rc  = isset($role_colors[$r['name']]) ? $role_colors[$r['name']] : ['bg'=>'#f8fafc','color'=>'#64748b','badge'=>'badge-gray'];
                    $sel = ((int)$r['id'] === $viewing_id);
                ?>
                <a href="?role=<?= (int)$r['id'] ?>" style="display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:8px;
         background:<?= $sel ? h($rc['bg']) : 'transparent' ?>;text-decoration:none;margin-bottom:2px;">
                    <div style="width:32px;height:32px;border-radius:8px;background:<?= h($rc['bg']) ?>;display:flex;align-items:center;justify-content:center;flex-shrink:0;border:1.5px solid <?= $sel ? h($rc['color']) : 'transparent' ?>;">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="<?= h($rc['color']) ?>" stroke-width="2">
                            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                        </svg>
                    </div>
                    <div style="flex:1;min-width:0;">
                        <div style="font-size:.81rem;font-weight:600;color:<?= $sel ? h($rc['color']) : 'var(--gray-800)' ?>;">
                            <?= h($r['label']) ?>
                            <?php if ($r['is_system']): ?>
                            <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="var(--gray-400)" stroke-width="2">
                                <rect x="3" y="11" width="18" height="11" rx="2" />
                                <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                            </svg>
                            <?php endif; ?>
                        </div>
                        <div style="font-size:.69rem;color:var(--gray-400);"><?= (int)$r['member_count'] ?> member<?= ((int)$r['member_count'] !== 1) ? 's' : '' ?></div>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Main panel -->
    <div style="flex:1;min-width:0;">
        <?php if ($viewing):
          $rc       = isset($role_colors[$viewing['name']]) ? $role_colors[$viewing['name']] : ['bg'=>'#f8fafc','color'=>'#64748b','badge'=>'badge-gray'];
          $can_edit = $is_super || !(int)$viewing['is_system'];
        ?>
        <!-- Tabs -->
        <div style="display:flex;gap:2px;margin-bottom:16px;background:var(--gray-100);padding:3px;border-radius:10px;width:fit-content;">
            <?php foreach (['permissions' => 'Permissions', 'users' => 'Users (' . count($role_users) . ')'] as $tab => $lbl): ?>
            <a href="?role=<?= $viewing_id ?>&tab=<?= $tab ?>" style="padding:6px 18px;border-radius:8px;font-size:.8rem;font-weight:600;text-decoration:none;
            <?= ($active_tab === $tab) ? 'background:#fff;color:var(--gray-800);box-shadow:0 1px 3px rgba(0,0,0,.08);' : 'color:var(--gray-500);' ?>">
                <?= h($lbl) ?>
            </a>
            <?php endforeach; ?>
        </div>

        <?php if ($active_tab === 'permissions'): ?>
        <!-- Permissions tab -->
        <form method="POST">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="update_permissions">
            <input type="hidden" name="role_id" value="<?= $viewing_id ?>">

            <div class="card">
                <div class="card-header" style="flex-wrap:wrap;gap:12px;">
                    <div style="width:38px;height:38px;border-radius:9px;background:<?= h($rc['bg']) ?>;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="<?= h($rc['color']) ?>" stroke-width="2">
                            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                        </svg>
                    </div>
                    <div style="flex:1;min-width:120px;">
                        <?php if ($can_edit): ?>
                        <input type="text" name="label" value="<?= h($viewing['label']) ?>" class="form-control form-control-sm" style="font-weight:700;font-size:.93rem;border:1px solid transparent;padding:2px 6px;background:transparent;max-width:260px;" onfocus="this.style.borderColor='var(--brand-400)'" onblur="this.style.borderColor='transparent'">
                        <input type="text" name="description" value="<?= h($viewing['description'] ?? '') ?>" class="form-control form-control-sm" style="font-size:.75rem;color:var(--gray-500);border:1px solid transparent;padding:1px 6px;background:transparent;margin-top:1px;" onfocus="this.style.borderColor='var(--brand-400)'" onblur="this.style.borderColor='transparent'" placeholder="Description">
                        <?php else: ?>
                        <div style="font-weight:700;"><?= h($viewing['label']) ?></div>
                        <div style="font-size:.75rem;color:var(--gray-500);"><?= h($viewing['description'] ?? '') ?></div>
                        <?php endif; ?>
                    </div>
                    <div style="display:flex;align-items:center;gap:8px;flex-shrink:0;">
                        <span class="badge <?= h($rc['badge']) ?>"><?= (int)$viewing['member_count'] ?> members</span>
                        <?php if ((int)$viewing['is_system']): ?>
                        <span class="badge badge-blue">System</span>
                        <?php endif; ?>
                        <?php if ($can_edit): ?>
                        <button type="submit" class="btn btn-primary btn-sm">Save</button>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if (!$can_edit): ?>
                <div style="padding:10px 20px;background:#fffbeb;border-bottom:1px solid #fde68a;font-size:.78rem;color:#92400e;">
                    System role — read only. Only Super Admins can modify system role permissions.
                </div>
                <?php endif; ?>

                <?php foreach ($by_module as $module => $perms):
                  if ($module === 'platform' && !$is_super) continue;
                  $icon = isset($module_icons[$module]) ? $module_icons[$module] : 'M12 12h.01';
                  $granted = 0;
                  foreach ($perms as $p) {
                      if (isset($role_perms[$viewing_id][$p['module'] . '.' . $p['action']])) $granted++;
                  }
                ?>
                <div style="border-bottom:1px solid var(--gray-100);">
                    <div style="display:flex;align-items:center;gap:10px;padding:11px 20px;background:var(--gray-50);">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="var(--gray-500)" stroke-width="2">
                            <path d="<?= h($icon) ?>" />
                        </svg>
                        <span style="font-size:.73rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--gray-600);"><?= h(ucfirst($module)) ?></span>
                        <span style="margin-left:auto;font-size:.7rem;color:var(--gray-400);"><?= $granted ?>/<?= count($perms) ?></span>
                        <?php if ($can_edit): ?>
                        <label style="display:flex;align-items:center;gap:5px;font-size:.72rem;color:var(--gray-500);cursor:pointer;margin-left:8px;">
                            <input type="checkbox" class="module-all-cb" data-mod="<?= h($module) ?>" onchange="toggleModuleAll(this)" <?= ($granted === count($perms)) ? 'checked' : '' ?>>
                            All
                        </label>
                        <?php endif; ?>
                    </div>
                    <?php foreach ($perms as $p):
                        $has = isset($role_perms[$viewing_id][$p['module'] . '.' . $p['action']]);
                    ?>
                    <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 20px 10px 42px;">
                        <div>
                            <div style="font-size:.82rem;font-weight:500;color:var(--gray-700);"><?= h($p['label']) ?></div>
                            <?php if (!empty($p['description'])): ?>
                            <div style="font-size:.71rem;color:var(--gray-400);"><?= h($p['description']) ?></div>
                            <?php endif; ?>
                        </div>
                        <?php if ($can_edit): ?>
                        <label style="cursor:pointer;display:flex;align-items:center;gap:7px;flex-shrink:0;">
                            <span class="perm-lbl" style="font-size:.71rem;color:<?= $has ? '#16a34a' : 'var(--gray-300)' ?>;"><?= $has ? 'On' : 'Off' ?></span>
                            <input type="checkbox" name="permissions[]" value="<?= (int)$p['id'] ?>" class="perm-cb" data-mod="<?= h($module) ?>" onchange="onPermCbChange(this)" <?= $has ? 'checked' : '' ?> style="cursor:pointer;width:15px;height:15px;accent-color:var(--brand-500);">
                        </label>
                        <?php else: ?>
                        <div style="width:22px;height:22px;border-radius:6px;background:<?= $has ? '#dcfce7' : 'var(--gray-100)' ?>;display:flex;align-items:center;justify-content:center;">
                            <?php if ($has): ?>
                            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#16a34a" stroke-width="3">
                                <polyline points="20,6 9,17 4,12" />
                            </svg>
                            <?php else: ?>
                            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="var(--gray-300)" stroke-width="3">
                                <line x1="18" y1="6" x2="6" y2="18" />
                                <line x1="6" y1="6" x2="18" y2="18" />
                            </svg>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endforeach; ?>

                <?php if ($can_edit): ?>
                <div style="padding:14px 20px;display:flex;justify-content:flex-end;">
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
                <?php endif; ?>
            </div>
        </form>

        <?php elseif ($active_tab === 'users'): ?>
        <!-- Users tab -->
        <div class="card">
            <div class="card-header">
                <div>
                    <div class="card-title">Users in: <?= h($viewing['label']) ?></div>
                    <div class="card-subtitle"><?= count($role_users) ?> member<?= count($role_users) !== 1 ? 's' : '' ?></div>
                </div>
                <?php if (count($assignable_users) > 0): ?>
                <button class="btn btn-primary btn-sm" style="margin-left:auto;" onclick="openModal('assignModal')">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="12" y1="5" x2="12" y2="19" />
                        <line x1="5" y1="12" x2="19" y2="12" />
                    </svg>
                    Assign User
                </button>
                <?php endif; ?>
            </div>
            <?php if (count($role_users) > 0): ?>
            <table class="table" style="margin:0;">
                <thead>
                    <tr>
                        <th>User</th>
                        <?php if ($is_super): ?><th>Account</th><?php endif; ?>
                        <th>Status</th>
                        <th>Move to Role</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($role_users as $u):
                        $sc  = ['active'=>'badge-green','inactive'=>'badge-gray','invited'=>'badge-yellow','suspended'=>'badge-red'];
                        $badge = isset($sc[$u['status']]) ? $sc[$u['status']] : 'badge-gray';
                        $ini = strtoupper(substr($u['first_name'],0,1) . substr($u['last_name'],0,1));
                        $colors_arr = ['#2563eb','#7c3aed','#0891b2','#16a34a','#d97706'];
                        $ac  = $colors_arr[abs(crc32($u['email'])) % 5];
                    ?>
                    <tr>
                        <td>
                            <div style="display:flex;align-items:center;gap:10px;">
                                <div style="width:30px;height:30px;border-radius:50%;background:<?= h($ac) ?>;display:flex;align-items:center;justify-content:center;font-size:.62rem;font-weight:700;color:#fff;flex-shrink:0;"><?= h($ini) ?></div>
                                <div>
                                    <div style="font-size:.82rem;font-weight:600;"><?= h($u['first_name'] . ' ' . $u['last_name']) ?></div>
                                    <div style="font-size:.71rem;color:var(--gray-400);"><?= h($u['email']) ?></div>
                                </div>
                            </div>
                        </td>
                        <?php if ($is_super): ?><td style="font-size:.78rem;"><?= h($u['account_name'] ?? 'Platform') ?></td><?php endif; ?>
                        <td><span class="badge <?= $badge ?>"><span class="badge-dot"></span><?= h(ucfirst($u['status'])) ?></span></td>
                        <td>
                            <form method="POST" style="display:inline-flex;gap:6px;align-items:center;">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="assign_role">
                                <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                                <select name="role_id" class="form-control form-control-sm" style="font-size:.75rem;">
                                    <?php foreach ($roles as $ropt):
                                        if ($ropt['name'] === 'super_admin' && !$is_super) continue;
                                    ?>
                                    <option value="<?= (int)$ropt['id'] ?>" <?= ((int)$ropt['id'] === $viewing_id) ? 'selected' : '' ?>><?= h($ropt['label']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <button class="btn btn-secondary btn-sm" type="submit">Move</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div style="text-align:center;padding:40px;color:var(--gray-400);font-size:.82rem;">No users assigned to this role yet.</div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- Delete button (outside form, only when 0 members) -->
        <?php if ($can_edit && (int)$viewing['member_count'] === 0 && !(int)$viewing['is_system']): ?>
        <div style="margin-top:12px;text-align:right;">
            <form method="POST" onsubmit="return confirm('Delete role &quot;<?= h($viewing['label']) ?>&quot;? This cannot be undone.')">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete_role">
                <input type="hidden" name="role_id" value="<?= $viewing_id ?>">
                <button class="btn btn-danger btn-sm" type="submit">Delete This Role</button>
            </form>
        </div>
        <?php endif; ?>

        <?php endif; // $viewing ?>
    </div><!-- /main panel -->
</div><!-- /flex wrapper -->

<!-- Create Role Modal -->
<div id="createRoleModal" class="modal-overlay">
    <div class="modal">
        <div class="modal-header">
            <div class="modal-title">Create New Role</div>
        </div>
        <form method="POST">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create_role">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label form-label-required">Role Name</label>
                    <input type="text" name="label" class="form-control" required maxlength="60" placeholder="e.g. Senior Agent">
                </div>
                <div class="form-group">
                    <label class="form-label">Description</label>
                    <input type="text" name="description" class="form-control" maxlength="200" placeholder="What can this role do?">
                </div>
                <div class="form-group" style="margin-bottom:0;">
                    <label class="form-label">Starting Permissions</label>
                    <div class="flex gap-2 flex-wrap">
                        <?php foreach ($roles as $r): ?>
                        <button type="button" class="btn btn-outline btn-sm" onclick="copyFromRole(<?= (int)$r['id'] ?>)">Copy <?= h($r['label']) ?></button>
                        <?php endforeach; ?>
                        <button type="button" class="btn btn-outline btn-sm" onclick="clearNewPerms()">None</button>
                    </div>
                    <div>
                        <?php foreach ($by_module as $module => $perms):
                          if ($module === 'platform' && !$is_super) continue;
                          $icon = isset($module_icons[$module]) ? $module_icons[$module] : 'M12 12h.01';
                        ?>
                        <hr>
                        <div>
                            <div class="flex gap-2 items-center mb-3">
                                <i class="hgi hgi-stroke hgi-user-lock-01 icon-block"></i>
                                <span class="font-semibold text-base"><?= h(ucfirst($module)) ?></span>
                            </div>
                            <div class="grid grid-cols-2 gap-3">
                                <?php foreach ($perms as $p): ?>
                                <label class="">
                                    <input type="checkbox" name="permissions[]" value="<?= (int)$p['id'] ?>" class="new-perm-cb" data-mod="<?= h($module) ?>">
                                    <?= h($p['label']) ?>
                                </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-white" onclick="closeModal('createRoleModal')">Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="hgi hgi-stroke hgi-tick-02"></i>Create Role</button>
            </div>
        </form>
    </div>
</div>

<!-- Assign User Modal -->
<?php if ($viewing && count($assignable_users) > 0): ?>
<div id="assignModal" class="modal-overlay">
    <div class="modal">
        <div class="modal-header">
            <div class="modal-title">Assign User to <?= h($viewing['label']) ?></div>
        </div>
        <form method="POST">
            <div class="modal-body">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="assign_role">
                <input type="hidden" name="role_id" value="<?= $viewing_id ?>">
                <div class="form-group">
                    <label class="form-label">Select User</label>
                    <select name="user_id" class="form-control" required>
                        <option value="">— Choose —</option>
                        <?php foreach ($assignable_users as $u): ?>
                        <option value="<?= (int)$u['id'] ?>"><?= h($u['first_name'] . ' ' . $u['last_name']) ?> (<?= h($u['current_role']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-white" onclick="closeModal('assignModal')">Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="hgi hgi-stroke hgi-tick-02"></i>Assign</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<script>
    var ROLE_PERM_MAP = <?= json_encode($role_perm_js) ?>;

    function copyFromRole(roleId) {
        var pids = ROLE_PERM_MAP[roleId] || [];
        var cbs = document.querySelectorAll('.new-perm-cb');
        for (var i = 0; i < cbs.length; i++) {
            cbs[i].checked = pids.indexOf(parseInt(cbs[i].value)) !== -1;
        }
    }

    function clearNewPerms() {
        var cbs = document.querySelectorAll('.new-perm-cb');
        for (var i = 0; i < cbs.length; i++) cbs[i].checked = false;
    }

    function toggleModuleAll(allCb) {
        var mod = allCb.getAttribute('data-mod');
        var cbs = document.querySelectorAll('.perm-cb[data-mod="' + mod + '"]');
        for (var i = 0; i < cbs.length; i++) {
            cbs[i].checked = allCb.checked;
            var lbl = cbs[i].previousElementSibling;
            if (lbl) {
                lbl.textContent = allCb.checked ? 'On' : 'Off';
                lbl.style.color = allCb.checked ? '#16a34a' : 'var(--gray-300)';
            }
        }
    }

    function onPermCbChange(cb) {
        var lbl = cb.previousElementSibling;
        if (lbl) {
            lbl.textContent = cb.checked ? 'On' : 'Off';
            lbl.style.color = cb.checked ? '#16a34a' : 'var(--gray-300)';
        }
        var mod = cb.getAttribute('data-mod');
        var cbs = document.querySelectorAll('.perm-cb[data-mod="' + mod + '"]');
        var allCb = document.querySelector('.module-all-cb[data-mod="' + mod + '"]');
        if (!allCb) return;
        var allChecked = true,
            anyChecked = false;
        for (var i = 0; i < cbs.length; i++) {
            if (cbs[i].checked) anyChecked = true;
            else allChecked = false;
        }
        allCb.checked = allChecked;
        allCb.indeterminate = !allChecked && anyChecked;
    }
    // Init indeterminate on load
    (function() {
        var allCbs = document.querySelectorAll('.module-all-cb');
        for (var i = 0; i < allCbs.length; i++) {
            var mod = allCbs[i].getAttribute('data-mod');
            var cbs = document.querySelectorAll('.perm-cb[data-mod="' + mod + '"]');
            var allChecked = true,
                anyChecked = false;
            for (var j = 0; j < cbs.length; j++) {
                if (cbs[j].checked) anyChecked = true;
                else allChecked = false;
            }
            if (!allCbs[i].checked) allCbs[i].indeterminate = anyChecked;
        }
    })();
</script>

<?php include __DIR__ . '/layouts/footer.php'; ?>