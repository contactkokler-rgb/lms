<?php
/**
 * LeadPro — Billing Dashboard (Account Owner)
 */
require_once __DIR__ . '/config/auth.php';
require_once __DIR__ . '/config/BillingService.php';

// Account owner only
$user = require_auth();
if (is_super_admin()) {
    // Super admin can view any account's billing via ?account_id=X
    $account_id = (int)($_GET['account_id'] ?? $user['account_id'] ?? 0);
} else {
    // Must be account_owner role (role_id 2)
    if ((int)$user['role_id'] !== 2) {
        $_SESSION['flash'] = ['type'=>'error','msg'=>'Access denied — Account Owner only.'];
        header('Location: ' . APP_URL . '/index.php'); exit;
    }
    $account_id = (int)($user['account_id'] ?? 0);
}

if (!$account_id) {
    header('Location: ' . APP_URL . '/index.php'); exit;
}

$page_title = 'Billing & Subscription';
$active_nav = 'billing';

$plan_status = BillingService::getPlanStatus($account_id);
$usage = BillingService::getCurrentUsage($account_id);
$invoices = BillingService::getInvoices($account_id, 5);
$restrictions = BillingService::getRestrictions($account_id);

include __DIR__ . '/layouts/header.php';
?>

<div class="page-header">
    <div>
        <div class="page-title"><i class="hgi hgi-stroke hgi-credit-card-02"></i> Billing & Subscription</div>
        <div class="page-subtitle">Manage your plan and usage</div>
    </div>
</div>

<?php if (!$plan_status['has_plan']): ?>
<div style="background:#dbeafe;border:1px solid #bfdbfe;border-radius:8px;padding:12px 14px;margin-bottom:20px;color:#0c4a6e;font-size:.9rem;">
    <i class="hgi hgi-stroke hgi-alert-02"></i>
    No active plan. Contact support to activate a subscription.
</div>
<?php elseif ($plan_status['status'] === 'expired'): ?>
<div style="background:#fee2e2;border:1px solid #fecaca;border-radius:8px;padding:12px 14px;margin-bottom:20px;color:#991b1b;font-size:.9rem;">
    <i class="hgi hgi-stroke hgi-alert-triangle"></i>
    <strong>Plan Expired</strong> — Your <?= h($plan_status['plan_name']) ?> plan expired on <?= date('M d, Y', strtotime($plan_status['expires_at'])) ?>.
    <br><small>Most features are restricted. Contact support to renew.</small>
</div>
<?php elseif ($plan_status['days_remaining'] <= 7 && $plan_status['days_remaining'] > 0): ?>
<div style="background:#fef3c7;border:1px solid #fde68a;border-radius:8px;padding:12px 14px;margin-bottom:20px;color:#92400e;font-size:.9rem;">
    <i class="hgi hgi-stroke hgi-alert-02"></i>
    Your plan expires in <strong><?= $plan_status['days_remaining'] ?> days</strong> (<?= date('M d, Y', strtotime($plan_status['expires_at'])) ?>).
</div>
<?php endif; ?>

<!-- Plan Overview -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px;">
    <div class="card">
        <div class="card-header">
            <div class="card-title">Current Plan</div>
        </div>
        <div class="card-body">
            <?php if ($plan_status['has_plan']): ?>
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
                <div>
                    <div style="font-size:1.6rem;font-weight:700;color:var(--brand-500);"><?= h($plan_status['plan_name']) ?></div>
                    <div style="font-size:.85rem;color:var(--gray-500);">$<?= number_format($plan_status['price_monthly'], 2) ?>/month</div>
                </div>
                <span style="background:<?= $plan_status['status'] === 'active' ? '#dcfce7' : '#fee2e2' ?>;color:<?= $plan_status['status'] === 'active' ? '#166534' : '#991b1b' ?>;padding:4px 8px;border-radius:4px;font-size:.75rem;font-weight:600;">
                    <?= ucfirst($plan_status['status']) ?>
                </span>
            </div>

            <div style="border-top:1px solid var(--gray-200);padding-top:12px;font-size:.8rem;">
                <?php if ($plan_status['status'] === 'active'): ?>
                <p style="margin:0;">Renews on: <strong><?= date('M d, Y', strtotime($plan_status['expires_at'])) ?></strong></p>
                <?php else: ?>
                <p style="margin:0;color:var(--gray-500);">Expired: <?= date('M d, Y', strtotime($plan_status['expires_at'])) ?></p>
                <?php endif; ?>
            </div>
            <?php else: ?>
            <p style="color:var(--gray-500);">No active plan</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Usage Overview -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">Usage This Month</div>
        </div>
        <div class="card-body">
            <?php if ($plan_status['has_plan']): ?>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div style="text-align:center;padding:12px;background:#f8f9fa;border-radius:6px;">
                    <div style="font-size:1.4rem;font-weight:700;"><?= $usage['domains_created'] ?>/<?= $plan_status['limits']['domains'] ?></div>
                    <div style="font-size:.75rem;color:var(--gray-500);">Domains</div>
                </div>
                <div style="text-align:center;padding:12px;background:#f8f9fa;border-radius:6px;">
                    <div style="font-size:1.4rem;font-weight:700;"><?= $usage['forms_created'] ?>/<?= $plan_status['limits']['forms'] ?></div>
                    <div style="font-size:.75rem;color:var(--gray-500);">Forms</div>
                </div>
                <div style="text-align:center;padding:12px;background:#f8f9fa;border-radius:6px;">
                    <div style="font-size:1.4rem;font-weight:700;"><?= $usage['leads_count'] ?>/<?= $plan_status['limits']['leads'] ?></div>
                    <div style="font-size:.75rem;color:var(--gray-500);">Leads</div>
                </div>
                <div style="text-align:center;padding:12px;background:#f8f9fa;border-radius:6px;">
                    <div style="font-size:1.4rem;font-weight:700;"><?= $usage['team_members_added'] ?>/<?= $plan_status['limits']['team_members'] ?></div>
                    <div style="font-size:.75rem;color:var(--gray-500);">Team</div>
                </div>
            </div>
            <?php else: ?>
            <p style="color:var(--gray-500);">No plan data</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Upgrade Nudge (when on trial or near expiry) -->
<?php if ($plan_status['has_plan'] && $plan_status['status'] === 'active' && isset($plan_status['days_remaining']) && $plan_status['days_remaining'] <= 14): ?>
<div style="background:linear-gradient(135deg,#eff6ff,#dbeafe);border:1px solid #93c5fd;border-radius:10px;padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">
    <div>
        <div style="font-weight:700;font-size:.95rem;color:#1e40af;">⚡ Upgrade your plan</div>
        <div style="font-size:.82rem;color:#3b82f6;margin-top:3px;">Your <?= h($plan_status['plan_name']) ?> plan <?= $plan_status['days_remaining'] > 0 ? 'expires in <strong>' . $plan_status['days_remaining'] . ' days</strong>' : 'has expired' ?>. Upgrade to keep all features active.</div>
    </div>
    <a href="mailto:support@leadpro.com?subject=Plan Upgrade Request" class="btn btn-primary btn-sm" style="white-space:nowrap;">Contact to Upgrade</a>
</div>
<?php endif; ?>

<!-- Upgrade Nudge (expired) -->
<?php if ($plan_status['has_plan'] && $plan_status['status'] === 'expired'): ?>
<div style="background:linear-gradient(135deg,#fef2f2,#fee2e2);border:1px solid #fca5a5;border-radius:10px;padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">
    <div>
        <div style="font-weight:700;font-size:.95rem;color:#991b1b;">🔒 Plan Expired — Features Restricted</div>
        <div style="font-size:.82rem;color:#ef4444;margin-top:3px;">Your plan expired on <?= date('M d, Y', strtotime($plan_status['expires_at'])) ?>. Landing pages and forms are still live, but all editing and new creation is paused.</div>
    </div>
    <a href="mailto:support@leadpro.com?subject=Plan Renewal Request" class="btn btn-sm" style="background:#dc2626;color:#fff;white-space:nowrap;">Renew Plan</a>
</div>
<?php endif; ?>

<!-- Invoices -->
<div class="card" style="margin-bottom:20px;">
    <div class="card-header">
        <div class="card-title">Recent Invoices</div>
    </div>
    <div class="card-body" style="padding:0;">
        <?php if (!empty($invoices)): ?>
        <table style="width:100%;font-size:.85rem;border-collapse:collapse;">
            <thead>
                <tr style="border-bottom:2px solid var(--border);">
                    <th style="padding:12px;text-align:left;">Invoice #</th>
                    <th style="padding:12px;text-align:left;">Date</th>
                    <th style="padding:12px;text-align:right;">Amount</th>
                    <th style="padding:12px;text-align:center;">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($invoices as $inv): ?>
                <tr style="border-bottom:1px solid var(--border);">
                    <td style="padding:12px;"><strong><?= h($inv['invoice_number']) ?></strong></td>
                    <td style="padding:12px;"><?= date('M d, Y', strtotime($inv['billing_date'])) ?></td>
                    <td style="padding:12px;text-align:right;">$<?= number_format($inv['amount'], 2) ?></td>
                    <td style="padding:12px;text-align:center;">
                        <span style="background:<?= $inv['status'] === 'paid' ? '#dcfce7' : '#fef3c7' ?>;color:<?= $inv['status'] === 'paid' ? '#166534' : '#92400e' ?>;padding:2px 6px;border-radius:3px;font-size:.7rem;font-weight:600;">
                            <?= ucfirst($inv['status']) ?>
                        </span>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p style="padding:16px;margin:0;color:var(--gray-500);text-align:center;">No invoices yet</p>
        <?php endif; ?>
    </div>
</div>

<!-- Feature Availability -->
<?php if (!$restrictions['can_edit']): ?>
<div style="background:#fef3c7;border:1px solid #fde68a;border-radius:8px;padding:12px 14px;color:#92400e;font-size:.9rem;">
    <strong>⚠ Limited Access</strong> — Your plan has expired. The following are restricted until you renew:
    <ul style="margin:8px 0 0 0;padding-left:20px;font-size:.85rem;line-height:1.8;">
        <li>No new edits to existing content</li>
        <li>No new campaigns</li>
        <li>No new domains</li>
        <li>No new landing pages</li>
        <li>No new forms</li>
        <li>No new team members</li>
        <li>No tools or services</li>
    </ul>
    <p style="margin:8px 0 0 0;font-size:.82rem;"><strong>✓ Still working:</strong> Existing landing pages stay live and forms keep collecting leads.</p>
</div>
<?php endif; ?>

<?php include __DIR__ . '/layouts/footer.php'; ?>
