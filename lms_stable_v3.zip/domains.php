<?php
require_once __DIR__ . '/config/auth.php';
require_once __DIR__ . '/config/BillingService.php';
$user       = require_permission('domains', 'view');
$is_super   = is_super_admin();
$account_id = (int)($user['account_id'] ?? 0);

$page_title = 'Domains';
$active_nav = 'domains';

if (!$is_super && $account_id <= 0) {
    $_SESSION['flash'] = ['type'=>'error','msg'=>'Account configuration error. Please contact support.'];
    header('Location: ' . APP_URL . '/login.php'); exit;
}

$accounts = $is_super
    ? db_fetch_all('SELECT id, name FROM accounts WHERE status = "active" ORDER BY name')
    : [];

// ── Actions ──────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { http_response_code(403); die('CSRF mismatch'); }
    $act = $_POST['action'] ?? '';

    // ── Add domain ───────────────────────────────────────────
    if ($act === 'add' && can('domains', 'create')) {
        $raw_domain = strtolower(trim(preg_replace('#^https?://#', '', rtrim($_POST['domain'] ?? '', '/'))));
        // Strip path — keep only host (e.g. strip /path from domain/path)
        $raw_domain = strtolower(parse_url('https://' . $raw_domain, PHP_URL_HOST) ?? $raw_domain);
        $label      = trim($_POST['label'] ?? '');
        $target_aid = $is_super ? (int)($_POST['account_id'] ?? 0) : $account_id;

        // ── Plan enforcement (account owners only) ──────────
        if (!$is_super) {
            BillingService::enforce($target_aid, 'can_add_domain', 'add a new domain');
            if ($err = BillingService::enforceLimit($target_aid, 'domain')) {
                $_SESSION['flash'] = ['type'=>'error','msg'=>$err];
                header('Location: ' . APP_URL . '/domains.php'); exit;
            }
        }

        // Basic domain format validation
        $valid_domain = preg_match('/^([a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$/', $raw_domain);

        if (!$raw_domain || !$valid_domain) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Enter a valid domain name (e.g. <code>example.com</code>).'];
        } elseif (!$target_aid) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Please select an account.'];
        } else {
            $existing = db_fetch('SELECT id FROM domains WHERE account_id = ? AND domain = ?', 'is', $target_aid, $raw_domain);
            if ($existing) {
                $_SESSION['flash'] = ['type'=>'error','msg'=>'That domain already exists on this account.'];
            } else {
                // Generate a DNS TXT verification token
                $verify_token = 'lpv-' . bin2hex(random_bytes(16));
                db_insert(
                    'INSERT INTO domains (account_id, domain, label, verify_token, created_by) VALUES (?,?,?,?,?)',
                    'isssi', $target_aid, $raw_domain, $label, $verify_token, $user['id']
                );
                if (!$is_super) BillingService::trackUsage($target_aid, 'domain');
                audit('domain.created', "domain:{$raw_domain}");
                $_SESSION['flash'] = [
                    'type' => 'verify',
                    'domain' => $raw_domain,
                    'token'  => $verify_token,
                ];
            }
        }
        header('Location: ' . APP_URL . '/domains.php'); exit;
    }

    // ── Verify domain via DNS TXT ─────────────────────────────
    if ($act === 'verify' && can('domains', 'edit')) {
        $did = (int)($_POST['domain_id'] ?? 0);
        $scope = $is_super ? 'id = ?' : 'id = ? AND account_id = ?';
        $dtypes = $is_super ? 'i' : 'ii';
        $dparams = $is_super ? [$did] : [$did, $account_id];
        $dom = db_fetch("SELECT * FROM domains WHERE $scope", $dtypes, ...$dparams);

        if (!$dom) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Domain not found.'];
        } elseif ($dom['verified_at']) {
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Domain is already verified.'];
        } else {
            $token    = $dom['verify_token'];
            $hostname = $dom['domain'];
            $verified = false;
            $dns_error = '';

            // Check DNS TXT records (may include @ and www. prefixes)
            $lookups = [$hostname, 'www.' . $hostname];
            foreach ($lookups as $host) {
                $records = @dns_get_record($host, DNS_TXT);
                if (is_array($records)) {
                    foreach ($records as $rec) {
                        $txt = $rec['txt'] ?? $rec['entries'][0] ?? '';
                        if (trim($txt) === $token) {
                            $verified = true;
                            break 2;
                        }
                    }
                }
            }

            if ($verified) {
                db_query('UPDATE domains SET verified_at = NOW(), verify_method = "dns_txt" WHERE id = ?', 'i', $did);
                audit('domain.verified', "domain:{$hostname}");
                $_SESSION['flash'] = ['type'=>'success','msg'=>'<strong>' . h($hostname) . '</strong> verified successfully! ✓'];
            } else {
                $_SESSION['flash'] = [
                    'type'   => 'verify_fail',
                    'domain' => $hostname,
                    'token'  => $token,
                    'domain_id' => $did,
                    'msg'    => 'DNS TXT record not found yet for <strong>' . h($hostname) . '</strong>. DNS changes can take up to 48 hours to propagate.',
                ];
            }
        }
        header('Location: ' . APP_URL . '/domains.php'); exit;
    }

    // ── Toggle active ────────────────────────────────────────
    if ($act === 'toggle' && can('domains', 'edit')) {
        $did = (int)($_POST['domain_id'] ?? 0);
        $scope = $is_super ? 'id = ?' : 'id = ? AND account_id = ?';
        $dtypes = $is_super ? 'i' : 'ii';
        $dparams = $is_super ? [$did] : [$did, $account_id];
        db_query("UPDATE domains SET is_active = 1 - is_active WHERE $scope", $dtypes, ...$dparams);
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Domain status updated.'];
        header('Location: ' . APP_URL . '/domains.php'); exit;
    }

    // ── Delete ───────────────────────────────────────────────
    if ($act === 'delete' && can('domains', 'delete')) {
        $did = (int)($_POST['domain_id'] ?? 0);
        $scope = $is_super ? 'id = ?' : 'id = ? AND account_id = ?';
        $dtypes = $is_super ? 'i' : 'ii';
        $dparams = $is_super ? [$did] : [$did, $account_id];
        $dom = db_fetch("SELECT domain FROM domains WHERE $scope", $dtypes, ...$dparams);
        if ($dom) {
            db_query("DELETE FROM domains WHERE $scope", $dtypes, ...$dparams);
            audit('domain.deleted', "domain:{$dom['domain']}");
        }
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Domain deleted.'];
        header('Location: ' . APP_URL . '/domains.php'); exit;
    }

    header('Location: ' . APP_URL . '/domains.php'); exit;
}

$flash  = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$search = trim($_GET['q'] ?? '');

$where_parts = []; $types = ''; $params = [];
if (!$is_super) { $where_parts[] = 'd.account_id = ?'; $types .= 'i'; $params[] = $account_id; }
if ($search)    { $where_parts[] = '(d.domain LIKE ? OR d.label LIKE ?)'; $types .= 'ss'; $params[] = "%$search%"; $params[] = "%$search%"; }
$where = $where_parts ? 'WHERE ' . implode(' AND ', $where_parts) : '';

$domains = db_fetch_all(
    "SELECT d.*, a.name AS account_name,
            COUNT(DISTINCT f.id) AS form_count,
            COUNT(DISTINCT l.id) AS lead_count
     FROM domains d
     LEFT JOIN accounts a   ON a.id = d.account_id
     LEFT JOIN lead_forms f ON f.domain_id = d.id
     LEFT JOIN leads l      ON l.domain_id = d.id
     $where
     GROUP BY d.id ORDER BY d.created_at DESC",
    $types, ...$params
);

include __DIR__ . '/layouts/header.php';
?>

<?php
// ── Flash banners ─────────────────────────────────────────────
if ($flash):
  if ($flash['type'] === 'verify'): ?>
<div class="alert alert-big alert-info mb-6">
    <div class="flex gap-3 flex-1 items-start">
        <i class="hgi hgi-stroke hgi-cancel-square hgi-lg"></i>
        <div class="w-full">
            <div class="text-base font-semibold">
                Domain added — now verify ownership of <code style="background:#dbeafe;padding:1px 7px;border-radius:5px;"><?= h($flash['domain']) ?></code>
            </div>
            <div>
                Add a <strong>DNS TXT record</strong> to your domain to prove you own it. This prevents others from claiming your domain.
            </div>
            <div class="p-4 mt-4 mb-4 bg-white rounded">
                <div style="display:grid;grid-template-columns:80px 120px 1fr;gap:8px 16px;font-size:.78rem;">
                    <div style="font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.04em;font-size:.68rem;">Type</div>
                    <div style="font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.04em;font-size:.68rem;">Host / Name</div>
                    <div style="font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.04em;font-size:.68rem;">Value</div>
                    <div style="font-family:var(--font-mono);font-size:.8rem;font-weight:700;color:#1e3a8a;">TXT</div>
                    <div style="font-family:var(--font-mono);font-size:.8rem;color:#1e3a8a;">@ (root)</div>
                    <div style="display:flex;align-items:center;gap:8px;">
                        <code id="verifyTokenNew" style="font-family:var(--font-mono);background:#dbeafe;padding:3px 10px;border-radius:5px;color:#1e3a8a;word-break:break-all;user-select:all;"><?= h($flash['token']) ?></code>
                        <button type="button" onclick="copyText('verifyTokenNew',this)" class="btn btn-xs btn-info">Copy</button>
                    </div>
                </div>
            </div>
            <div class="text-xs mb-3">
                <i class="hgi hgi-stroke hgi-help-circle mr-2"></i><strong>Where to add it:</strong> Log in to your domain registrar (Namecheap, GoDaddy, Cloudflare, etc.) → DNS Management → Add TXT record. DNS propagation can take up to 48 hours.
            </div>
            <?php
        // Find the domain ID for the verify button
        $new_dom = db_fetch('SELECT id FROM domains WHERE verify_token = ?', 's', $flash['token']);
        if ($new_dom):
      ?>
            <form method="POST" style="display:inline;">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="verify">
                <input type="hidden" name="domain_id" value="<?= $new_dom['id'] ?>">
                <button type="submit" class="btn btn-secondary btn-sm">
                    <i class="hgi hgi-stroke hgi-tick-02"></i>
                    Check DNS Now
                </button>                
            </form>
            <div class="text-xs mt-2">You can also check later — find the domain in the list below.</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php elseif ($flash['type'] === 'verify_fail'): ?>
<div class="alert alert-big alert-danger mb-6">
    <div class="flex gap-3 flex-1 items-start">
        <i class="hgi hgi-stroke hgi-cancel-square hgi-lg"></i>
        <div class="w-full">
            <div class="text-base font-semibold">TXT record not found yet</div>
            <div><?= $flash['msg'] ?></div>
            <div class="p-4 mt-4 mb-4 bg-white rounded">
                <div class="text-sm mb-2 font-regular">Expected TXT record for <code><?= h($flash['domain']) ?></code>:</div>
                <div class="flex gap-2 items-center">
                    <code id="retryToken" style="font-family:var(--font-mono);background:#fee2e2;padding:3px 10px;border-radius:5px;color:#7f1d1d;word-break:break-all;user-select:all;"><?= h($flash['token']) ?></code>
                    <button type="button" onclick="copyText('retryToken',this)" class="btn btn-xs btn-danger">Copy</button>
                </div>
            </div>
            <form method="POST" style="display:inline;">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="verify">
                <input type="hidden" name="domain_id" value="<?= (int)$flash['domain_id'] ?>">
                <button type="submit" class="btn btn-secondary btn-sm"><i class="hgi hgi-stroke hgi-reload"></i> Try Again</button>
            </form>
        </div>
    </div>
</div>
<?php else: ?>
<div class="alert alert-<?= h($flash['type']) ?> mb-5" data-auto-dismiss><?= $flash['msg'] ?></div>
<?php endif; ?>
<?php endif; ?>


<div class="page-header">
    <div>
        <h1 class="page-title"><i class="hgi hgi-stroke hgi-globe-02"></i>Domains <span class="ml-2 badge badge-info"><?= count($domains) ?> domain<?= count($domains) !== 1 ? 's' : '' ?></span></h1>
    </div>
    <?php if (can('domains', 'create')): ?>
    <button class="btn btn-primary btn-sm" onclick="openModal('addDomainModal')">
        <i class="hgi hgi-stroke hgi-plus-sign"></i>
        Add Domain
    </button>
    <?php endif; ?>
</div>


<!-- Search filter -->

<div class="form-group mb-5">
    <form method="GET" class="flex gap-2 items-center">
        <div class="input-wrapper has-icon-left" style="max-width:320px;">
            <i class="input-icon-left hgi hgi-stroke hgi-search-01"></i>
            <input name="q" type="search" placeholder="Search domains…" value="<?= h($search) ?>" class="input input-sm">
        </div>
        <?php if ($search): ?><a href="domains.php" class="btn btn-secondary btn-sm">Clear</a><?php endif; ?>
    </form>
</div>


<div class="card">
    <?php if ($domains): ?>
    <div>
        <table class="table">
            <thead>
                <tr>
                    <th>Domain</th>
                    <?php if ($is_super): ?><th>Account</th><?php endif; ?>
                    <th>Label</th>
                    <th>Forms</th>
                    <th>Leads</th>
                    <th>Verified</th>
                    <th>Status</th>
                    <th>Added</th>
                    <th class="text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($domains as $d):
                  $is_verified = !empty($d['verified_at']);
                  $token = $d['verify_token'] ?? '';
                ?>
                <tr>
                    <td>
                        <div class="flex gap-2 items-center">
                            <div class="icon-thumb" style="background:<?= $is_verified ? 'var(--color-success-bg)' : 'var(--color-warning-bg)' ?>;">
                                <?php if ($is_verified): ?>
                                <i class="hgi hgi-stroke hgi-tick-02 text-success"></i>
                                <?php else: ?>
                                <i class="hgi hgi-stroke hgi-alert-02 text-warning"></i>
                                <?php endif; ?>
                            </div>
                            <div>
                                <span class="font-mono text-sm"><?= h($d['domain']) ?></span>
                                <?php if (!$is_verified): ?>
                                <div class="text-2xs text-warning">Pending verification</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                    <?php if ($is_super): ?>
                    <td><?= h($d['account_name'] ?? '—') ?></td>
                    <?php endif; ?>
                    <td><?= h($d['label'] ?: '—') ?></td>
                    <td class="font-bold"><?= (int)$d['form_count'] ?></td>
                    <td class="font-bold"><?= (int)$d['lead_count'] ?></td>
                    <td>
                        <?php if ($is_verified): ?>
                        <span class="badge badge-success" title="Verified <?= format_dt($d['verified_at']) ?>">
                            <span class="badge-dot"></span>Verified
                        </span>
                        <?php else: ?>
                        <div>
                            <span class="badge badge-warning"><span class="badge-dot"></span>Unverified</span>
                            <?php if (can('domains', 'edit') && $token): ?>
                            <button class="btn btn-white btn-xs" onclick="showVerifyInstructions(<?= $d['id'] ?>, '<?= h($d['domain']) ?>', '<?= h($token) ?>')" title="View DNS instructions">
                                <i class="hgi hgi-stroke hgi-help-square"></i>
                                How to verify
                            </button>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge <?= $d['is_active'] ? 'badge-success' : 'badge-danger' ?>">
                            <span class="badge-dot"></span><?= $d['is_active'] ? 'Active' : 'Inactive' ?>
                        </span>
                    </td>
                    <td class="text-xs"><i class="hgi hgi-stroke hgi-calendar-03 mr-1"></i><?= format_dt($d['created_at'], 'd M Y') ?></td>
                    <td>
                        <div class="flex items-center justify-end gap-1">
                            <?php if (!$is_verified && can('domains', 'edit')): ?>
                            <form method="POST" style="display:inline;">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="verify">
                                <input type="hidden" name="domain_id" value="<?= $d['id'] ?>">
                                <button class="btn btn-warning btn-xs" title="Check DNS TXT record">
                                    <i class="hgi hgi-stroke hgi-tick-02"></i>
                                    Verify
                                </button>
                            </form>
                            <?php endif; ?>
                            <a href="<?= APP_URL ?>/leads.php?domain_id=<?= $d['id'] ?>" class="btn btn-outline btn-xs btn-icon"><i class="hgi hgi-stroke hgi-user-warning-02"></i></a>
                            <a href="<?= APP_URL ?>/forms.php?domain_id=<?= $d['id'] ?>" class="btn btn-outline btn-xs btn-icon"><i class="hgi hgi-stroke hgi-database-01"></i></a>
                            <?php if (can('domains', 'edit')): ?>
                            <form method="POST" style="display:inline;">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="toggle">
                                <input type="hidden" name="domain_id" value="<?= $d['id'] ?>">
                                <button class="btn btn-outline btn-xs btn-icon"><?= $d['is_active'] ? '<i class="hgi hgi-stroke hgi-unavailable"></i>' : '<i class="hgi hgi-stroke hgi-checkmark-circle-02"></i>' ?></button>
                            </form>
                            <?php endif; ?>
                            <?php if (can('domains', 'delete')): ?>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Delete <?= h(addslashes($d['domain'])) ?>? All forms and leads will also be deleted.')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="domain_id" value="<?= $d['id'] ?>">
                                <button class="btn btn-danger btn-xs btn-icon"><i class="hgi hgi-stroke hgi-delete-02"></i></button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="empty-state">
        <div class="empty-state-icon">
            <i class="hgi hgi-stroke hgi-globe-02"></i>
        </div>
        <div class="empty-state-title"><?= $search ? 'No domains match your search' : 'No domains yet' ?></div>
        <div class="empty-state-desc">Add a domain to start building lead capture forms.</div>
        <?php if (can('domains', 'create') && !$search): ?>
        <button class="btn btn-primary btn-sm" onclick="openModal('addDomainModal')"><i class="hgi hgi-stroke hgi-plus-sign"></i>Add your first domain</button>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>


<!-- Add Domain Modal -->
<?php if (can('domains', 'create')): ?>
<div class="modal-overlay" id="addDomainModal">
    <form method="POST" action="<?= APP_URL ?>/domains.php" class="modal">
        <div class="modal-header">
            <div>
                <div class="modal-title">Add Domain</div>
                <div class="modal-subtitle text-xs text-muted mt-1">You'll verify ownership via DNS after adding</div>
            </div>
            <button class="modal-close" onclick="closeModal('addDomainModal')">
                <i class="hgi hgi-stroke hgi-cancel-01"></i>
            </button>
        </div>
        <div class="modal-body">
            
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add">

            <?php if ($is_super && $accounts): ?>
            <div class="form-group">
                <label class="form-label">Account <span style="color:#ef4444">*</span></label>
                <select name="account_id" class="form-control" required>
                    <option value="">— Select account —</option>
                    <?php foreach ($accounts as $a): ?>
                    <option value="<?= $a['id'] ?>"><?= h($a['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>

            <div class="form-group">
                <label class="form-label">Domain <span style="color:#ef4444">*</span></label>
                <div class="input-wrapper has-icon-left">
                    <span class="input-icon-left text-xs">https://</span>
                    <input name="domain" type="text" placeholder="example.com" required class="input input-sm" style="padding-left: 65px;">
                </div>
                <div class="text-xs text-muted mb-1">Root domain only — e.g. <code>example.com</code> or <code>subdomain.example.com</code></div>
            </div>
            <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">Label <span style="color:var(--gray-400);font-weight:400;">(optional)</span></label>
                <input name="label" type="text" class="input input-sm" placeholder="e.g. Main marketing site">
            </div>

            <!-- Verification info -->
            <div class="alert alert-info mt-2">
                <i class="hgi hgi-stroke hgi-information-circle"></i>
                <div>After adding, you'll get a <strong>DNS TXT record</strong> to add to your domain's DNS settings. Forms on unverified domains still accept test submissions, but the domain will be marked as unverified until you complete verification.</div>
            </div>

        </div>
        
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary btn-sm" onclick="closeModal('addDomainModal')">Cancel</button>
            <button type="submit" class="btn btn-primary btn-sm"><i class="hgi hgi-stroke hgi-plus-sign"></i>Add Domain</button>
        </div>
    </form>
</div>
<?php endif; ?>

<!-- Verify Instructions Modal (shown when clicking "How to verify") -->
<div class="modal-overlay" id="verifyModal">
    <div class="modal">
        <div class="modal-header">
            <div>
                <div class="modal-title" id="verifyModalTitle">Verify Domain</div>
                <div class="modal-subtitle text-xs text-muted mt-1">Add a TXT record to your DNS settings</div>
            </div>
            <button class="modal-close" onclick="closeModal('verifyModal')">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="18" y1="6" x2="6" y2="18" />
                    <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
            </button>
        </div>
        <div class="modal-body">
            <p style="font-size:.82rem;color:var(--gray-600);margin-bottom:16px;">
                Log in to your DNS provider (Cloudflare, Namecheap, GoDaddy, etc.) and add the following TXT record to prove you own this domain.
            </p>
            <div class="alert alert-info mb-3">
                <div style="display:grid;grid-template-columns:90px 120px 1fr;gap:6px 16px;font-size:.78rem;">
                    <div style="font-weight:700;color:var(--gray-400);text-transform:uppercase;font-size:.65rem;letter-spacing:.05em;">Type</div>
                    <div style="font-weight:700;color:var(--gray-400);text-transform:uppercase;font-size:.65rem;letter-spacing:.05em;">Host / Name</div>
                    <div style="font-weight:700;color:var(--gray-400);text-transform:uppercase;font-size:.65rem;letter-spacing:.05em;">Value</div>
                    <div style="font-family:var(--font-mono);font-weight:700;color:var(--gray-700);">TXT</div>
                    <div style="font-family:var(--font-mono);color:var(--gray-700);">@</div>
                    <div style="display:flex;align-items:center;gap:6px;">
                        <code id="verifyModalToken" style="font-family:var(--font-mono);font-size:.75rem;background:var(--gray-100);padding:3px 9px;border-radius:5px;word-break:break-all;user-select:all;"></code>
                        <button type="button" onclick="copyText('verifyModalToken',this)" class="btn btn-xs">Copy</button>
                    </div>
                </div>
            </div>
            <div style="font-size:.74rem;color:var(--gray-500);margin-bottom:18px;line-height:1.6;">
                <strong>TTL:</strong> Any (e.g. 300 or Auto)<br>
                <strong>Propagation:</strong> Can take up to 48 hours, but usually under 30 minutes.
            </div>
            
        </div>
        <form method="POST" id="verifyModalForm" class="modal-footer">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="verify">
            <input type="hidden" name="domain_id" id="verifyModalDomainId">
            <div style="display:flex;gap:10px;">
                <button type="button" class="btn btn-secondary btn-sm" onclick="closeModal('verifyModal')">Close</button>
                <button type="submit" class="btn btn-primary btn-sm">
                    <i class="hgi hgi-stroke hgi-plus-sign"></i>
                    Check DNS Now
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function showVerifyInstructions(domainId, domainName, token) {
        document.getElementById('verifyModalTitle').textContent = 'Verify — ' + domainName;
        document.getElementById('verifyModalToken').textContent = token;
        document.getElementById('verifyModalDomainId').value = domainId;
        openModal('verifyModal');
    }

    function copyText(id, btn) {
        var txt = document.getElementById(id).textContent;
        if (navigator.clipboard) {
            navigator.clipboard.writeText(txt).then(function() {
                var orig = btn.textContent;
                btn.textContent = 'Copied!';
                setTimeout(function() {
                    btn.textContent = orig;
                }, 2000);
            });
        }
    }
</script>

<?php include __DIR__ . '/layouts/footer.php'; ?>