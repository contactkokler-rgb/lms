<?php
if (!defined('APP_URL')) require_once __DIR__ . '/config.php';

function send_email(string $to_email, string $to_name, string $subject, string $body, array $options = []): array {
    if (!filter_var($to_email, FILTER_VALIDATE_EMAIL)) {
        return ['ok' => false, 'error' => 'Invalid recipient email: ' . $to_email];
    }

    // Load SMTP settings from platform_settings
    // Allow caller to override FROM (used by send_email_from_form)
    $override_from  = $options['override_from_email'] ?? '';
    $override_name  = $options['override_from_name']  ?? '';

    $smtp_host  = ps('smtp_host', '');
    $smtp_port  = (int) ps('smtp_port', '587');
    $smtp_user  = ps('smtp_user', '');
    $smtp_pass  = ps('smtp_pass', '');
    $from_name  = ps('smtp_from_name', ps('app_name', 'LeadPro'));
    $from_email = ps('smtp_from_email', '');
    $encryption = ps('smtp_encryption', 'tls');

    // If SMTP configured — use it
    if ($override_from) { $from_email = $override_from; $from_name = $override_name ?: $from_name; }
    if ($smtp_host && $smtp_user && $smtp_pass && $from_email) {
        return _send_smtp($to_email, $to_name, $subject, $body, [
            'host'       => $smtp_host,
            'port'       => $smtp_port,
            'user'       => $smtp_user,
            'pass'       => $smtp_pass,
            'from_email' => $from_email,
            'from_name'  => $from_name,
            'encryption' => $encryption,
            'reply_to'   => $options['reply_to'] ?? '',
            'is_html'    => $options['is_html']   ?? true,
        ]);
    }

    // Fallback: PHP mail()
    if (!$from_email) {
        $from_email = 'noreply@' . ($_SERVER['HTTP_HOST'] ?? 'leadpro.local');
    }
    if ($override_from) { $from_email = $override_from; $from_name = $override_name ?: $from_name; }
    return _send_php_mail($to_email, $to_name, $subject, $body, $from_email, $from_name, $options);
}

/**
 * Send via raw SMTP socket (no external library required).
 */
function _send_smtp(string $to, string $to_name, string $subject, string $body, array $cfg): array {
    $host       = $cfg['host'];
    $port       = $cfg['port'];
    $user       = $cfg['user'];
    $pass       = $cfg['pass'];
    $from_email = $cfg['from_email'];
    $from_name  = $cfg['from_name'];
    $encryption = $cfg['encryption'];
    $is_html    = $cfg['is_html'] ?? true;

    try {
        // Connect — use ssl:// wrapper for port 465, plain socket for 587/25
        $scheme    = ($encryption === 'ssl') ? 'ssl://' : '';
        $ctx_opts  = [
            'ssl' => [
                'verify_peer'       => false,
                'verify_peer_name'  => false,
                'allow_self_signed' => true,
            ],
        ];
        $ctx = stream_context_create($ctx_opts);
        $fp  = @stream_socket_client(
            $scheme . $host . ':' . $port,
            $errno, $errstr, 20,
            STREAM_CLIENT_CONNECT, $ctx
        );
        if (!$fp) throw new Exception("SMTP connect failed ({$errno}): {$errstr}");

        stream_set_timeout($fp, 20);

        // Read full multi-line SMTP response, return last code + text
        $recv = function() use ($fp): string {
            $r = '';
            while (!feof($fp)) {
                $line = fgets($fp, 512);
                if ($line === false) break;
                $r .= $line;
                // Last line of response: code followed by space (not dash)
                if (strlen($line) >= 4 && $line[3] === ' ') break;
            }
            return $r;
        };

        $send = function(string $cmd) use ($fp): void {
            fputs($fp, $cmd . "\r\n");
        };

        // Read greeting
        $greeting = $recv();
        if (strpos($greeting, '220') === false) {
            throw new Exception('Bad greeting: ' . trim($greeting));
        }

        // Use server hostname for EHLO — 'localhost' is safest across hosts
        $my_host = 'localhost';

        // EHLO
        $send('EHLO ' . $my_host);
        $ehlo = $recv();

        // STARTTLS upgrade (port 587)
        if ($encryption === 'tls') {
            if (strpos($ehlo, 'STARTTLS') === false) {
                throw new Exception('Server does not support STARTTLS. Try SSL (port 465) instead.');
            }
            $send('STARTTLS');
            $tls_resp = $recv();
            if (strpos($tls_resp, '220') === false) {
                throw new Exception('STARTTLS rejected: ' . trim($tls_resp));
            }
            // Upgrade the stream to TLS
            if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT)) {
                // Try TLS 1.1 fallback
                stream_socket_enable_crypto($fp, false);
                if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                    throw new Exception('TLS handshake failed — check SMTP host and port.');
                }
            }
            // Re-EHLO after TLS upgrade (required)
            $send('EHLO ' . $my_host);
            $ehlo = $recv();
        }

        // Determine supported AUTH mechanisms from EHLO response
        $supports_plain = stripos($ehlo, 'AUTH') !== false && stripos($ehlo, 'PLAIN') !== false;
        $supports_login = stripos($ehlo, 'AUTH') !== false && stripos($ehlo, 'LOGIN') !== false;

        // Try AUTH PLAIN first (single round-trip, more reliable)
        if ($supports_plain) {
            $auth_str = base64_encode("\0{$user}\0{$pass}");
            $send("AUTH PLAIN {$auth_str}");
            $auth_resp = $recv();
        } elseif ($supports_login) {
            // AUTH LOGIN (multi-step)
            $send('AUTH LOGIN');
            $recv();
            $send(base64_encode($user));
            $recv();
            $send(base64_encode($pass));
            $auth_resp = $recv();
        } else {
            // Try AUTH LOGIN anyway — some servers omit from EHLO but support it
            $send('AUTH LOGIN');
            $step1 = $recv();
            if (strpos($step1, '334') !== false) {
                $send(base64_encode($user));
                $recv();
                $send(base64_encode($pass));
                $auth_resp = $recv();
            } else {
                throw new Exception('Server does not support AUTH LOGIN or AUTH PLAIN. Check SMTP settings.');
            }
        }

        if (strpos($auth_resp, '235') === false) {
            throw new Exception('Authentication failed: ' . trim($auth_resp) . ' — check username/password.');
        }

        // MAIL FROM / RCPT TO
        $send("MAIL FROM:<{$from_email}>");
        $recv();
        $send("RCPT TO:<{$to}>");
        $recv();

        // DATA
        $send('DATA');
        $recv();

        // Build message
        $boundary = 'lp_' . md5(uniqid());
        $subject_encoded = '=?UTF-8?B?' . base64_encode($subject) . '?=';
        $from_encoded    = '=?UTF-8?B?' . base64_encode($from_name) . '?=';
        $to_encoded      = $to_name ? ('=?UTF-8?B?' . base64_encode($to_name) . '?= <' . $to . '>') : $to;
        $reply_to        = $cfg['reply_to'] ?? '';

        $headers  = "From: {$from_encoded} <{$from_email}>\r\n";
        $headers .= "To: {$to_encoded}\r\n";
        $headers .= "Subject: {$subject_encoded}\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        if ($reply_to) $headers .= "Reply-To: {$reply_to}\r\n";

        if ($is_html) {
            $plain   = strip_tags(str_replace(['<br>', '<br/>', '<br />','</p>'], "\n", $body));
            $headers .= "Content-Type: multipart/alternative; boundary=\"{$boundary}\"\r\n";
            $message  = "--{$boundary}\r\n";
            $message .= "Content-Type: text/plain; charset=UTF-8\r\n";
            $message .= "Content-Transfer-Encoding: base64\r\n\r\n";
            $message .= chunk_split(base64_encode($plain)) . "\r\n";
            $message .= "--{$boundary}\r\n";
            $message .= "Content-Type: text/html; charset=UTF-8\r\n";
            $message .= "Content-Transfer-Encoding: base64\r\n\r\n";
            $message .= chunk_split(base64_encode($body)) . "\r\n";
            $message .= "--{$boundary}--\r\n";
        } else {
            $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
            $headers .= "Content-Transfer-Encoding: base64\r\n";
            $message  = chunk_split(base64_encode($body)) . "\r\n";
        }

        $send($headers . "\r\n" . $message . "\r\n.");
        $data_resp = $recv();
        if (strpos($data_resp, '250') === false) {
            throw new Exception('Message rejected: ' . trim($data_resp));
        }

        $send('QUIT');
        fclose($fp);

        return ['ok' => true];

    } catch (Exception $e) {
        if (isset($fp) && is_resource($fp)) { try { fclose($fp); } catch(Exception $ignore){} }
        error_log('[LeadPro Mailer] SMTP error: ' . $e->getMessage());
        return ['ok' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Fallback: PHP mail()
 */
function _send_php_mail(string $to, string $to_name, string $subject, string $body,
                         string $from_email, string $from_name, array $options = []): array {
    $is_html   = $options['is_html'] ?? true;
    $reply_to  = $options['reply_to'] ?? '';
    $from_enc  = '=?UTF-8?B?' . base64_encode($from_name) . '?=';
    $subj_enc  = '=?UTF-8?B?' . base64_encode($subject)   . '?=';

    $headers   = "From: {$from_enc} <{$from_email}>\r\n";
    $headers  .= "MIME-Version: 1.0\r\n";
    if ($reply_to) $headers .= "Reply-To: {$reply_to}\r\n";

    if ($is_html) {
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    } else {
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    }

    $to_header = $to_name ? ('=?UTF-8?B?' . base64_encode($to_name) . '?= <' . $to . '>') : $to;
    $ok = @mail($to_header, $subj_enc, $body, $headers);
    return $ok ? ['ok' => true] : ['ok' => false, 'error' => 'php mail() returned false — check server mail config'];
}

/**
 * Get lead email from lead_values (field_key = 'email').
 */
function get_lead_email(int $lead_id): string {
    $row = db_fetch(
        "SELECT value FROM lead_values WHERE lead_id = ? AND field_key = 'email' LIMIT 1",
        'i', $lead_id
    );
    return trim($row['value'] ?? '');
}

/**
 * Get lead name from lead_values (field_key = 'name' or 'full_name').
 */
function get_lead_name(int $lead_id): string {
    $row = db_fetch(
        "SELECT value FROM lead_values WHERE lead_id = ? AND field_key IN ('name','full_name','first_name') ORDER BY id LIMIT 1",
        'i', $lead_id
    );
    return trim($row['value'] ?? 'there');
}

/**
 * Build a styled HTML email wrapper around plain text content.
 */
function email_wrap_html(string $body_text, string $subject, string $app_name = ''): string {
    $app_name  = $app_name ?: ps('app_name', 'LeadPro');
    $brand     = ps('brand_color_500', '#8914a9');
    $body_html = nl2br(htmlspecialchars($body_text, ENT_QUOTES, 'UTF-8'));
    return <<<HTML
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f4f4f7;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f7;padding:40px 0;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.08);">
        <tr><td style="background:{$brand};padding:20px 32px;">
          <span style="color:#fff;font-size:20px;font-weight:700;">{$app_name}</span>
        </td></tr>
        <tr><td style="padding:32px;color:#1a1a2e;font-size:15px;line-height:1.7;">
          {$body_html}
        </td></tr>
        <tr><td style="padding:16px 32px 24px;border-top:1px solid #eee;font-size:12px;color:#999;">
          This email was sent by {$app_name}. Please do not reply to this address.
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>
HTML;
}

// ─────────────────────────────────────────────────────────────
// STEP 3 — Template + Form-aware sending
// ─────────────────────────────────────────────────────────────

/**
 * Send email using form notify_email as FROM address.
 * Falls back to SMTP from_email if notify_email not set.
 *
 * @param string $to_email
 * @param string $to_name
 * @param string $subject
 * @param string $body        Plain text body (will be HTML-wrapped)
 * @param string $notify_email  Form's notify_email — used as FROM + Reply-To
 * @param string $notify_name   Display name for FROM
 * @return array ['ok'=>bool, 'error'=>string, 'from'=>string]
 */
function send_email_from_form(string $to_email, string $to_name, string $subject,
                               string $body, string $notify_email = '', string $notify_name = ''): array {
    $app_name  = ps('app_name', 'LeadPro');
    $html_body = email_wrap_html($body, $subject, $app_name);

    // Decide FROM address
    $smtp_from = ps('smtp_from_email', '');
    if ($notify_email && filter_var($notify_email, FILTER_VALIDATE_EMAIL)) {
        // Use notify_email as FROM + Reply-To (simplest, no-SMTP path)
        $from_name  = $notify_name ?: $app_name;
        $from_email = $notify_email;
        $reply_to   = $notify_email;
    } elseif ($smtp_from) {
        $from_email = $smtp_from;
        $from_name  = ps('smtp_from_name', $app_name);
        $reply_to   = $notify_email ?: '';
    } else {
        $from_email = 'noreply@' . ($_SERVER['HTTP_HOST'] ?? 'leadpro.local');
        $from_name  = $app_name;
        $reply_to   = $notify_email ?: '';
    }

    $result = send_email($to_email, $to_name, $subject, $html_body, [
        'reply_to' => $reply_to,
        'is_html'  => true,
        'override_from_email' => $from_email,
        'override_from_name'  => $from_name,
    ]);

    return array_merge($result, ['from' => $from_email, 'reply_to' => $reply_to]);
}

/**
 * Replace template variables in subject and body.
 *
 * Variables: {{name}} {{email}} {{phone}} {{message}}
 *            {{form_name}} {{campaign_name}} {{booking_url}}
 *            {{lead_ref}} {{submitted_date}} {{service}}
 *
 * @param string $text   Subject or body with {{variable}} placeholders
 * @param array  $vars   Key=>value map of variable values
 * @return string
 */
function template_replace(string $text, array $vars): string {
    foreach ($vars as $key => $value) {
        $text = str_replace('{{' . $key . '}}', (string)$value, $text);
    }
    // Remove any unreplaced variables
    $text = preg_replace('/\{\{[a-z_]+\}\}/', '', $text);
    return $text;
}

/**
 * Build template variable map from lead data.
 *
 * @param array $lead     Lead row
 * @param array $fields   lead_values rows
 * @param array $form     lead_forms row
 * @param array $campaign campaigns row (optional)
 * @return array
 */
function build_template_vars(array $lead, array $fields, array $form = [], array $campaign = []): array {
    // Extract common field values
    $name = $email = $phone = $message = '';
    foreach ($fields as $f) {
        $key = $f['field_key'] ?? '';
        $val = $f['value']     ?? '';
        if (in_array($key, ['name','full_name','first_name']) && !$name)    $name    = $val;
        if ($key === 'email'   && !$email)                                   $email   = $val;
        if (in_array($key, ['phone','mobile','tel']) && !$phone)             $phone   = $val;
        if (in_array($key, ['message','enquiry','description']) && !$message) $message = $val;
    }
    if (!$name && !empty($lead['assigned_name'])) $name = $lead['assigned_name'];

    $form_settings  = is_array($form['settings'] ?? null)
        ? $form['settings']
        : (json_decode($form['settings'] ?? '{}', true) ?: []);

    $booking_url = $campaign['ai_booking_url'] ?? '';
    $service     = $campaign['ai_service']     ?? '';

    return [
        'name'           => $name ?: 'there',
        'email'          => $email,
        'phone'          => $phone,
        'message'        => $message,
        'form_name'      => $form['name']           ?? '',
        'campaign_name'  => $campaign['name']       ?? '',
        'booking_url'    => $booking_url,
        'service'        => $service,
        'lead_ref'       => $lead['reference_no']   ?? '',
        'submitted_date' => isset($lead['submitted_at'])
                            ? date('d M Y, g:ia', strtotime($lead['submitted_at']))
                            : date('d M Y'),
        'app_name'       => ps('app_name', 'LeadPro'),
    ];
}

/**
 * Fetch active email template for a form + type.
 * Returns null if not found.
 */
function get_form_template(int $form_id, string $type): ?array {
    $db = db();
    if ($db->query("SHOW TABLES LIKE 'lead_form_email_templates'")->num_rows === 0) return null;
    return db_fetch(
        "SELECT * FROM lead_form_email_templates WHERE form_id = ? AND type = ? AND is_active = 1",
        'is', $form_id, $type
    ) ?: null;
}
