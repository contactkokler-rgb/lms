<?php
/**
 * Billing Email Templates
 */

class BillingEmails {

    /**
     * Invoice email template
     */
    public static function invoiceEmail($account, $invoice, $plan) {
        return [
            'subject' => 'Invoice #' . $invoice['invoice_number'],
            'body' => "
                <h2>Invoice #{$invoice['invoice_number']}</h2>
                <p>Dear {$account['owner_name']},</p>
                <p>Your invoice for {$plan['name']} plan is attached.</p>

                <table style='width:100%;border-collapse:collapse;'>
                    <tr>
                        <td style='padding:8px;'>Plan:</td>
                        <td style='padding:8px;font-weight:bold;'>{$plan['name']}</td>
                    </tr>
                    <tr style='background:#f5f5f5;'>
                        <td style='padding:8px;'>Amount Due:</td>
                        <td style='padding:8px;font-weight:bold;'>\${$invoice['amount']}</td>
                    </tr>
                    <tr>
                        <td style='padding:8px;'>Billing Date:</td>
                        <td style='padding:8px;'>" . date('M d, Y', strtotime($invoice['billing_date'])) . "</td>
                    </tr>
                    <tr>
                        <td style='padding:8px;'>Due Date:</td>
                        <td style='padding:8px;'>" . date('M d, Y', strtotime($invoice['due_date'])) . "</td>
                    </tr>
                </table>

                <p style='margin-top:20px;'>
                    <a href='[APP_URL]/billing.php' style='background:#007bff;color:white;padding:10px 20px;text-decoration:none;border-radius:4px;display:inline-block;'>View Invoice</a>
                </p>

                <p style='margin-top:20px;font-size:12px;color:#666;'>
                    If you have any questions, please contact our support team.
                </p>
            "
        ];
    }

    /**
     * Payment confirmation email
     */
    public static function paymentConfirmationEmail($account, $invoice, $plan) {
        return [
            'subject' => 'Payment Received - Invoice #' . $invoice['invoice_number'],
            'body' => "
                <h2>Payment Confirmed</h2>
                <p>Dear {$account['owner_name']},</p>
                <p>Thank you! We've received your payment for {$plan['name']} plan.</p>

                <table style='width:100%;border-collapse:collapse;'>
                    <tr>
                        <td style='padding:8px;'>Invoice #:</td>
                        <td style='padding:8px;font-weight:bold;'>{$invoice['invoice_number']}</td>
                    </tr>
                    <tr style='background:#f5f5f5;'>
                        <td style='padding:8px;'>Amount Paid:</td>
                        <td style='padding:8px;font-weight:bold;'>\${$invoice['amount']}</td>
                    </tr>
                    <tr>
                        <td style='padding:8px;'>Date:</td>
                        <td style='padding:8px;'>" . date('M d, Y H:i', strtotime($invoice['paid_at'])) . "</td>
                    </tr>
                </table>

                <p style='margin-top:20px;'>Your subscription is active and all features are available.</p>
            "
        ];
    }

    /**
     * Trial ending soon email
     */
    public static function trialEndingEmail($account, $subscription, $plan, $days_left) {
        return [
            'subject' => "Your {$plan['name']} trial ends in {$days_left} days",
            'body' => "
                <h2>Your Trial is Ending Soon</h2>
                <p>Dear {$account['owner_name']},</p>
                <p>Your {$plan['name']} plan trial will expire in <strong>{$days_left} days</strong>.</p>

                <p style='margin:20px 0;'>
                    <strong>Current Plan:</strong> {$plan['name']}<br>
                    <strong>Trial Expires:</strong> " . date('M d, Y', strtotime($subscription['trial_ends_at'])) . "
                </p>

                <p>To continue using all features:</p>
                <p style='margin-top:20px;'>
                    <a href='[APP_URL]/billing.php' style='background:#28a745;color:white;padding:10px 20px;text-decoration:none;border-radius:4px;display:inline-block;'>Add Payment Method</a>
                </p>

                <p style='margin-top:20px;color:#666;font-size:12px;'>
                    Without a valid payment method, your account will be downgraded to a free plan and you'll lose access to advanced features.
                </p>
            "
        ];
    }

    /**
     * Subscription expired email
     */
    public static function subscriptionExpiredEmail($account, $subscription, $plan) {
        $restrictions = [
            '❌ Cannot edit existing content',
            '❌ Cannot create new campaigns',
            '❌ Cannot add new domains',
            '❌ Cannot create forms',
            '❌ Cannot add team members',
            '✓ Landing pages still live',
            '✓ Forms still collecting leads'
        ];

        return [
            'subject' => 'Your subscription has expired',
            'body' => "
                <h2>Subscription Expired</h2>
                <p>Dear {$account['owner_name']},</p>
                <p>Your {$plan['name']} plan subscription has expired.</p>

                <p><strong>With expired subscription:</strong></p>
                <ul>
                    " . implode('', array_map(fn($r) => "<li>$r</li>", $restrictions)) . "
                </ul>

                <p style='margin-top:20px;'>
                    <a href='[APP_URL]/billing.php' style='background:#007bff;color:white;padding:10px 20px;text-decoration:none;border-radius:4px;display:inline-block;'>Renew Subscription</a>
                </p>

                <p style='margin-top:20px;color:#666;font-size:12px;'>
                    Your data is safe. Renew anytime to regain full access.
                </p>
            "
        ];
    }

    /**
     * Payment failed email
     */
    public static function paymentFailedEmail($account, $invoice, $plan) {
        return [
            'subject' => 'Payment Failed - Action Required',
            'body' => "
                <h2>Payment Failed</h2>
                <p>Dear {$account['owner_name']},</p>
                <p>We tried to charge your card for {$plan['name']} plan but the payment was declined.</p>

                <table style='width:100%;border-collapse:collapse;margin:20px 0;'>
                    <tr>
                        <td style='padding:8px;'>Invoice #:</td>
                        <td style='padding:8px;font-weight:bold;'>{$invoice['invoice_number']}</td>
                    </tr>
                    <tr style='background:#f5f5f5;'>
                        <td style='padding:8px;'>Amount:</td>
                        <td style='padding:8px;font-weight:bold;'>\${$invoice['amount']}</td>
                    </tr>
                </table>

                <p><strong>Please update your payment method:</strong></p>
                <p style='margin-top:20px;'>
                    <a href='[APP_URL]/billing.php' style='background:#dc3545;color:white;padding:10px 20px;text-decoration:none;border-radius:4px;display:inline-block;'>Update Payment Method</a>
                </p>

                <p style='margin-top:20px;color:#666;font-size:12px;'>
                    If the problem persists, please contact us at support@example.com
                </p>
            "
        ];
    }

    /**
     * Send email helper
     */
    public static function sendBillingEmail($account_id, $email_type, $recipient_email, $data) {
        require_once __DIR__ . '/../config/mailer.php';

        $templates = [
            'invoice' => 'invoiceEmail',
            'payment_confirmation' => 'paymentConfirmationEmail',
            'trial_ending' => 'trialEndingEmail',
            'subscription_expired' => 'subscriptionExpiredEmail',
            'payment_failed' => 'paymentFailedEmail'
        ];

        if (!isset($templates[$email_type])) return false;

        $method = $templates[$email_type];
        $email_data = self::$method(...array_values($data));

        // Replace placeholder
        $email_data['body'] = str_replace('[APP_URL]', APP_URL, $email_data['body']);

        // Send via mailer (configure in config/mailer.php)
        $result = sendEmail($recipient_email, $email_data['subject'], $email_data['body']);

        // Log the email
        if ($result) {
            require_once __DIR__ . '/../auditor/PricingService.php';
            PricingService::logBillingEmail($account_id, $email_type, $recipient_email);
        }

        return $result;
    }
}
