<?php
/**
 * BillingService — Portal-wide billing helper class
 * Handles plan management, usage tracking, enforces restrictions
 * Used by: domains, forms, campaigns, team, etc.
 */
class BillingService {

    /**
     * Get account current plan with all details
     */
    public static function getAccountPlan($account_id) {
        return db_fetch(
            'SELECT ap.*, p.* FROM account_plans ap
             JOIN pricing_plans p ON ap.plan_id = p.id
             WHERE ap.account_id = ?
             LIMIT 1',
            'i', $account_id
        );
    }

    /**
     * Check if plan is active (not expired)
     */
    public static function isPlanActive($account_id) {
        $plan = self::getAccountPlan($account_id);
        if (!$plan) return false;
        return strtotime($plan['plan_expires_at']) > time();
    }

    /**
     * Get current usage for account (this month)
     */
    public static function getCurrentUsage($account_id) {
        $month = date('Y-m');
        $usage = db_fetch(
            'SELECT * FROM account_usage WHERE account_id = ? AND billing_month = ?',
            'is', $account_id, $month
        );
        return $usage ?? [
            'domains_created' => 0,
            'forms_created' => 0,
            'leads_count' => 0,
            'team_members_added' => 0
        ];
    }

    /**
     * Check if usage limit exceeded for specific type
     * Returns: true if can add more, false if limit reached
     */
    public static function checkLimit($account_id, $type) {
        $plan = self::getAccountPlan($account_id);
        
        // No plan or plan expired = completely restricted
        if (!$plan || !self::isPlanActive($account_id)) {
            return false;
        }

        $usage = self::getCurrentUsage($account_id);

        $limits = [
            'domain' => $plan['domains_limit'],
            'form' => $plan['forms_limit'],
            'lead' => $plan['leads_per_month'],
            'team_member' => $plan['team_members_limit']
        ];

        $usage_fields = [
            'domain' => $usage['domains_created'],
            'form' => $usage['forms_created'],
            'lead' => $usage['leads_count'],
            'team_member' => $usage['team_members_added']
        ];

        if (!isset($limits[$type]) || !isset($usage_fields[$type])) {
            return true;
        }

        return $usage_fields[$type] < $limits[$type];
    }

    /**
     * Track usage - increment counter
     */
    public static function trackUsage($account_id, $type, $quantity = 1) {
        $month = date('Y-m');
        $field_map = [
            'domain' => 'domains_created',
            'form' => 'forms_created',
            'lead' => 'leads_count',
            'team_member' => 'team_members_added'
        ];

        if (!isset($field_map[$type])) return false;

        $field = $field_map[$type];

        $stmt = db()->prepare(
            "INSERT INTO account_usage (account_id, billing_month, $field)
             VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE $field = $field + ?"
        );

        $stmt->bind_param('isii', $account_id, $month, $quantity, $quantity);
        return $stmt->execute();
    }

    /**
     * Get plan restrictions when expired — covers all 04_PRICING.md rules
     */
    public static function getRestrictions($account_id) {
        $is_active = self::isPlanActive($account_id);

        if ($is_active) {
            return [
                'can_edit'            => true,
                'can_create_campaign' => true,
                'can_add_domain'      => true,
                'can_add_form'        => true,
                'can_add_team_member' => true,
                'can_use_tools'       => true,
                'can_use_seo_auditor' => true,
                'can_add_lp'          => true,
            ];
        } else {
            // Per 04_PRICING.md: landing pages stay live, forms keep collecting —
            // but NO new anything, NO edits, NO tools.
            return [
                'can_edit'            => false,
                'can_create_campaign' => false,
                'can_add_domain'      => false,
                'can_add_form'        => false,
                'can_add_team_member' => false,
                'can_use_tools'       => false,
                'can_use_seo_auditor' => false,
                'can_add_lp'          => false,
            ];
        }
    }

    /**
     * Enforce a restriction — die with a JSON error for AJAX, or set flash + redirect for normal requests.
     * Usage: BillingService::enforce($account_id, 'can_add_domain', 'add a new domain');
     */
    public static function enforce($account_id, string $cap, string $action_label = 'perform this action'): void {
        // Super admin bypass
        $user = auth_user();
        if ($user && $user['role_name'] === 'super_admin') return;

        $r = self::getRestrictions($account_id);
        if (!isset($r[$cap]) || !$r[$cap]) {
            $is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) ||
                       (($_SERVER['HTTP_ACCEPT'] ?? '') && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false);
            if ($is_ajax) {
                http_response_code(403);
                header('Content-Type: application/json');
                echo json_encode(['error' => 'plan_expired', 'message' => "Your plan has expired. Please renew to {$action_label}."]);
                exit;
            }
            $_SESSION['flash'] = [
                'type' => 'error',
                'msg'  => "⚠ Your plan has expired. Please renew to <strong>{$action_label}</strong>. <a href=\"" . APP_URL . "/billing.php\" style=\"color:inherit;font-weight:600;\">View Billing →</a>"
            ];
            header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? (APP_URL . '/billing.php')));
            exit;
        }
    }

    /**
     * Check usage limit and enforce — call before creating domain/form/team member/lead.
     * Returns error message string, or null if OK.
     */
    public static function enforceLimit($account_id, string $type): ?string {
        $user = auth_user();
        if ($user && $user['role_name'] === 'super_admin') return null;

        if (!self::isPlanActive($account_id)) {
            return "Your plan has expired. Renew to add more {$type}s.";
        }
        if (!self::checkLimit($account_id, $type)) {
            $plan = self::getAccountPlan($account_id);
            $map  = ['domain'=>'domains_limit','form'=>'forms_limit','lead'=>'leads_per_month','team_member'=>'team_members_limit'];
            $limit = $plan[$map[$type] ?? ''] ?? '?';
            return "You've reached your plan limit of {$limit} {$type}(s). Upgrade your plan to add more.";
        }
        return null;
    }

    /**
     * Get full plan status for display
     */
    public static function getPlanStatus($account_id) {
        $plan = self::getAccountPlan($account_id);
        if (!$plan) {
            return [
                'has_plan' => false,
                'plan_name' => 'None',
                'status' => 'no_plan',
                'expires_at' => null
            ];
        }

        $is_active = self::isPlanActive($account_id);
        $days_remaining = ceil((strtotime($plan['plan_expires_at']) - time()) / 86400);

        return [
            'has_plan' => true,
            'plan_name' => $plan['name'],
            'status' => $is_active ? 'active' : 'expired',
            'expires_at' => $plan['plan_expires_at'],
            'days_remaining' => $is_active ? $days_remaining : 0,
            'price_monthly' => $plan['price_monthly'],
            'limits' => [
                'domains' => $plan['domains_limit'],
                'forms' => $plan['forms_limit'],
                'leads' => $plan['leads_per_month'],
                'team_members' => $plan['team_members_limit']
            ]
        ];
    }

    /**
     * Assign plan to account (14 day trial)
     */
    public static function assignPlan($account_id, $plan_id, $is_trial = true) {
        $plan = db_fetch('SELECT * FROM pricing_plans WHERE id = ?', 'i', $plan_id);
        if (!$plan) return false;

        $now = date('Y-m-d H:i:s');
        $expires = $is_trial ? date('Y-m-d H:i:s', strtotime('+14 days')) : date('Y-m-d H:i:s', strtotime('+1 month'));

        $stmt = db()->prepare(
            'INSERT INTO account_plans (account_id, plan_id, status, plan_starts_at, plan_expires_at)
             VALUES (?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE 
             plan_id = VALUES(plan_id),
             plan_expires_at = VALUES(plan_expires_at),
             updated_at = NOW()'
        );

        $status = $is_trial ? 'trial' : 'active';
        $stmt->bind_param('iiss', $account_id, $plan_id, $status, $now, $expires);
        return $stmt->execute();
    }

    /**
     * Create invoice for account
     */
    public static function createInvoice($account_id, $plan_id, $amount) {
        $invoice_number = 'INV-' . date('Ym') . '-' . strtoupper(bin2hex(random_bytes(4)));
        $billing_date = date('Y-m-d');
        $due_date = date('Y-m-d', strtotime('+30 days'));

        $stmt = db()->prepare(
            'INSERT INTO invoices (account_id, invoice_number, plan_id, amount, billing_date, due_date, status)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );

        $status = 'pending';
        $stmt->bind_param('isidsss', $account_id, $invoice_number, $plan_id, $amount, $billing_date, $due_date, $status);

        if ($stmt->execute()) {
            return ['success' => true, 'invoice_number' => $invoice_number, 'id' => db()->insert_id];
        }
        return ['success' => false];
    }

    /**
     * Mark invoice as paid
     */
    public static function markInvoicePaid($invoice_id, $payment_method, $transaction_id = null) {
        $stmt = db()->prepare(
            'UPDATE invoices SET status = ?, paid_at = NOW(), payment_method = ?, transaction_id = ? WHERE id = ?'
        );

        $status = 'paid';
        $stmt->bind_param('sssi', $status, $payment_method, $transaction_id, $invoice_id);
        return $stmt->execute();
    }

    /**
     * Get invoices for account
     */
    public static function getInvoices($account_id, $limit = 10) {
        return db_fetch_all(
            'SELECT * FROM invoices WHERE account_id = ? ORDER BY created_at DESC LIMIT ?',
            'ii', $account_id, $limit
        );
    }

    /**
     * Get payment gateway settings
     */
    public static function getPaymentGateway($name) {
        return db_fetch(
            'SELECT * FROM payment_gateways WHERE gateway_name = ? AND is_enabled = 1',
            's', $name
        );
    }

    /**
     * Log billing email sent
     */
    public static function logBillingEmail($account_id, $email_type, $recipient_email) {
        $stmt = db()->prepare(
            'INSERT INTO billing_emails (account_id, email_type, recipient_email, sent_at)
             VALUES (?, ?, ?, NOW())'
        );

        $stmt->bind_param('iss', $account_id, $email_type, $recipient_email);
        return $stmt->execute();
    }
}
