<?php
if (!defined('APP_URL')) require_once __DIR__ . '/config.php';

/**
 * Calculate engagement score for a lead (read-only, no DB write).
 */
function engagement_calc(int $lead_id): array {
    $lead = db_fetch(
        'SELECT l.*, u.id AS owner_id FROM leads l LEFT JOIN users u ON u.id=l.assigned_to WHERE l.id=?',
        'i', $lead_id
    );
    if (!$lead) return ['score'=>0,'level'=>'cold','signals'=>[]];

    $score   = 0;
    $signals = [];

    $now = time();
    $age_days = ($now - strtotime($lead['submitted_at'])) / 86400;

    // ── Signal 1: Comment / activity count (0–40 pts) ────────
    $comment_count = (int)(db_fetch('SELECT COUNT(*) AS n FROM lead_comments WHERE lead_id=?','i',$lead_id)['n'] ?? 0);
    if ($comment_count >= 10)     { $pts = 40; }
    elseif ($comment_count >= 5)  { $pts = 30; }
    elseif ($comment_count >= 3)  { $pts = 22; }
    elseif ($comment_count >= 1)  { $pts = 12; }
    else                           { $pts = 0; }
    $score += $pts;
    $signals[] = ['label'=>'Activity','pts'=>$pts,'detail'=>"{$comment_count} comments"];

    // ── Signal 2: Recency of last comment (0–30 pts) ─────────
    $last = db_fetch('SELECT MAX(created_at) AS t FROM lead_comments WHERE lead_id=?','i',$lead_id);
    $last_ts = $last && $last['t'] ? strtotime($last['t']) : strtotime($lead['submitted_at']);
    $hrs_ago = ($now - $last_ts) / 3600;

    if ($hrs_ago <= 2)          { $pts = 30; }
    elseif ($hrs_ago <= 8)      { $pts = 25; }
    elseif ($hrs_ago <= 24)     { $pts = 20; }
    elseif ($hrs_ago <= 72)     { $pts = 13; }
    elseif ($hrs_ago <= 168)    { $pts = 6; }
    else                         { $pts = 0; }
    $score += $pts;

    if ($hrs_ago < 1)           $recency = 'just now';
    elseif ($hrs_ago < 24)      $recency = round($hrs_ago) . 'h ago';
    elseif ($hrs_ago < 168)     $recency = round($hrs_ago/24) . 'd ago';
    else                         $recency = round($hrs_ago/168) . 'w ago';
    $signals[] = ['label'=>'Recency','pts'=>$pts,'detail'=>"Last activity {$recency}"];

    // ── Signal 3: Status progression (0–20 pts) ──────────────
    $status_pts = [
        'new'       => 0,
        'contacted' => 8,
        'qualified' => 14,
        'converted' => 20,
        'lost'      => 0,
        'spam'      => 0,
    ];
    $pts = $status_pts[$lead['status']] ?? 0;
    $score += $pts;
    $signals[] = ['label'=>'Status','pts'=>$pts,'detail'=>ucfirst($lead['status'])];

    // ── Signal 4: Assignment & age bonus (0–10 pts) ──────────
    $pts = 0;
    if ($lead['owner_id'])                $pts += 5; // assigned
    if ($age_days <= 7  && $pts > 0)      $pts += 3; // fresh + assigned
    if ($age_days <= 1)                   $pts += 2; // very fresh
    $pts = min($pts, 10);
    $score += $pts;
    $signals[] = ['label'=>'Assignment','pts'=>$pts,'detail'=>$lead['owner_id']?'Assigned':'Unassigned'];

    // Penalties
    if (in_array($lead['status'], ['lost','spam'])) $score = max(0, $score - 20);
    if ($age_days > 30 && $comment_count === 0)     $score = max(0, $score - 10);

    $score = min(100, max(0, $score));
    $level = $score >= 65 ? 'hot' : ($score >= 30 ? 'warm' : 'cold');

    return ['score'=>$score,'level'=>$level,'signals'=>$signals];
}

/**
 * Calculate and persist engagement score to the leads table.
 */
function engagement_update(int $lead_id): array {
    $result = engagement_calc($lead_id);
    try {
        db_query(
            'UPDATE leads SET engagement_score=?, engagement_level=?, engagement_at=NOW() WHERE id=?',
            'isi', $result['score'], $result['level'], $lead_id
        );
    } catch (\Throwable $e) {
        // Column may not exist before migration
        error_log('[LeadPro] engagement_update: ' . $e->getMessage());
    }
    return $result;
}

/**
 * Batch-update engagement scores for an account.
 * Throttled: only processes leads not scored in last 6 hours.
 */
function engagement_update_bulk(int $account_id, int $limit = 200): int {
    try {
        $leads = db_fetch_all(
            "SELECT id FROM leads
             WHERE account_id=? AND is_deleted=0
             AND status NOT IN ('spam')
             AND (engagement_at IS NULL OR engagement_at < DATE_SUB(NOW(), INTERVAL 6 HOUR))
             ORDER BY submitted_at DESC LIMIT ?",
            'ii', $account_id, $limit
        );
    } catch (\Throwable $e) {
        return 0;
    }
    $n = 0;
    foreach ($leads as $l) {
        engagement_update((int)$l['id']);
        $n++;
    }
    return $n;
}

/**
 * Render an inline HTML heat badge.
 */
function engagement_badge(string $level, int $score = -1, bool $small = false): string {
    $cfg = [
        'hot'  => ['bg'=>'#fef2f2','border'=>'#fca5a5','dot'=>'#ef4444','text'=>'#991b1b','label'=>'Hot'],
        'warm' => ['bg'=>'#fffbeb','border'=>'#fde68a','dot'=>'#f59e0b','text'=>'#92400e','label'=>'Warm'],
        'cold' => ['bg'=>'#f0f9ff','border'=>'#bae6fd','dot'=>'#38bdf8','text'=>'#0c4a6e','label'=>'Cold'],
    ];
    $c     = $cfg[$level] ?? $cfg['cold'];
    $sz    = $small ? 'font-size:.65rem;padding:2px 6px;' : 'font-size:.7rem;padding:3px 8px;';
    $score_part = $score >= 0 ? " <span style='opacity:.6;'>{$score}</span>" : '';
    return "<span style='display:inline-flex;align-items:center;gap:4px;{$sz}background:{$c['bg']};border:1px solid {$c['border']};color:{$c['text']};border-radius:12px;font-weight:600;white-space:nowrap;'>"
         . "<span style='width:6px;height:6px;border-radius:50%;background:{$c['dot']};flex-shrink:0;'></span>"
         . $c['label'] . $score_part
         . "</span>";
}
