<?php
if (!function_exists('notify_user')) :

// ── Type → icon / color map ──────────────────────────────────
function notif_style(string $type): array {
    $map = [
        'lead.new'           => ['icon' => 'lead',    'color' => 'blue'],
        'lead.assigned'      => ['icon' => 'user',    'color' => 'purple'],
        'lead.comment'       => ['icon' => 'comment', 'color' => 'green'],
        'lead.status'        => ['icon' => 'star',    'color' => 'yellow'],
        'lead.spam'          => ['icon' => 'warning', 'color' => 'red'],
        'lead.reminder'      => ['icon' => 'bell',    'color' => 'yellow'],
        'team.invite'        => ['icon' => 'user',    'color' => 'blue'],
        'team.approved'      => ['icon' => 'user',    'color' => 'green'],
        'team.role_changed'  => ['icon' => 'shield',  'color' => 'purple'],
        'system'             => ['icon' => 'bell',    'color' => 'gray'],
    ];
    // Fallback: match prefix
    foreach ($map as $prefix => $style) {
        if (strpos($type, $prefix) === 0) return $style;
    }
    return ['icon' => 'bell', 'color' => 'gray'];
}

// ── Pref key for a given type ────────────────────────────────
function notif_pref_key(string $type): string {
    if (strpos($type, 'lead.reminder')   !== false) return 'pref_lead_assigned'; // reuse assigned pref
    if (strpos($type, 'lead.new')       !== false) return 'pref_lead_new';
    if (strpos($type, 'lead.assigned')  !== false) return 'pref_lead_assigned';
    if (strpos($type, 'lead.comment')   !== false) return 'pref_lead_comment';
    if (strpos($type, 'lead.status')    !== false) return 'pref_lead_status';
    if (strpos($type, 'team.')          !== false) return 'pref_team_invite';
    if (strpos($type, 'system')         !== false) return 'pref_system';
    return 'pref_system';
}

/**
 * Send a notification to a single user.
 * Respects that user's preferences — silently skips if pref is off.
 *
 * @param int    $user_id
 * @param string $type      e.g. 'lead.assigned'
 * @param string $title
 * @param string $body
 * @param string $url       Optional deep-link
 * @param array  $meta      Optional JSON metadata
 * @param int|null $account_id
 */
function notify_user(
    int $user_id,
    string $type,
    string $title,
    string $body = '',
    string $url = '',
    array $meta = [],
    ?int $account_id = null
): bool {
    try {
        // Check user pref
        $pref_key = notif_pref_key($type);
        $pref     = db_fetch(
            "SELECT `{$pref_key}` AS val FROM notification_prefs WHERE user_id = ?",
            'i', $user_id
        );
        // If no pref row yet, create defaults
        if (!$pref) {
            db_query('INSERT IGNORE INTO notification_prefs (user_id) VALUES (?)', 'i', $user_id);
            $pref = ['val' => 1];
        }
        if (!(int)$pref['val']) return false; // pref disabled

        $style     = notif_style($type);
        $meta_json = $meta ? json_encode($meta) : null;
        // account_id can be null — use 0 as sentinel (stored as NULL via SQL NULLIF or just 0 is fine)
        $acct = $account_id ?? 0;

        db_insert(
            'INSERT INTO notifications
               (user_id, account_id, type, title, body, url, icon, color, meta)
             VALUES (?,?,?,?,?,?,?,?,?)',
            'iisssssss',
            $user_id, $acct, $type,
            substr($title, 0, 255),
            substr($body,  0, 1000),
            substr($url,   0, 500),
            $style['icon'],
            $style['color'],
            $meta_json
        );
        return true;
    } catch (\Throwable $e) {
        error_log('[LeadPro] notify_user failed: ' . $e->getMessage());
        return false;
    }
}

/**
 * Send a notification to ALL active users on an account
 * (excluding one user, e.g. the actor who triggered it).
 *
 * @param int         $account_id
 * @param string      $type
 * @param string      $title
 * @param string      $body
 * @param string      $url
 * @param array       $meta
 * @param int|null    $exclude_user_id   Usually the actor — don't notify themselves
 */
function notify_account(
    int $account_id,
    string $type,
    string $title,
    string $body = '',
    string $url = '',
    array $meta = [],
    ?int $exclude_user_id = null
): void {
    try {
        $users = db_fetch_all(
            'SELECT id FROM users WHERE account_id = ? AND status = "active"',
            'i', $account_id
        );
        foreach ($users as $u) {
            if ($exclude_user_id && (int)$u['id'] === $exclude_user_id) continue;
            notify_user((int)$u['id'], $type, $title, $body, $url, $meta, $account_id);
        }
    } catch (\Throwable $e) {
        error_log('[LeadPro] notify_account failed: ' . $e->getMessage());
    }
}

/**
 * Send a notification to users with a specific role on an account.
 *
 * @param int      $account_id
 * @param string   $role_name   e.g. 'account_owner', 'manager'
 * @param string   $type
 * @param string   $title
 * @param string   $body
 * @param string   $url
 * @param array    $meta
 * @param int|null $exclude_user_id
 */
function notify_role(
    int $account_id,
    string $role_name,
    string $type,
    string $title,
    string $body = '',
    string $url = '',
    array $meta = [],
    ?int $exclude_user_id = null
): void {
    try {
        $users = db_fetch_all(
            'SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id
             WHERE u.account_id = ? AND r.name = ? AND u.status = "active"',
            'is', $account_id, $role_name
        );
        foreach ($users as $u) {
            if ($exclude_user_id && (int)$u['id'] === $exclude_user_id) continue;
            notify_user((int)$u['id'], $type, $title, $body, $url, $meta, $account_id);
        }
    } catch (\Throwable $e) {
        error_log('[LeadPro] notify_role failed: ' . $e->getMessage());
    }
}

/**
 * Broadcast to all users on a platform (super_admin use only).
 */
function notify_all_platform(
    string $type,
    string $title,
    string $body = '',
    string $url = '',
    array $meta = []
): void {
    try {
        $users = db_fetch_all('SELECT id, account_id FROM users WHERE status = "active"');
        foreach ($users as $u) {
            notify_user((int)$u['id'], $type, $title, $body, $url, $meta, $u['account_id'] ?: null);
        }
    } catch (\Throwable $e) {
        error_log('[LeadPro] notify_all_platform failed: ' . $e->getMessage());
    }
}

/**
 * Get unread count for the current user (cached per request).
 */
function notif_unread_count(?int $user_id = null): int {
    static $cache = [];
    if ($user_id === null) {
        $u = auth_user();
        $user_id = $u ? (int)$u['id'] : 0;
    }
    if (!$user_id) return 0;
    if (isset($cache[$user_id])) return $cache[$user_id];
    try {
        $row = db_fetch(
            'SELECT COUNT(*) AS n FROM notifications
             WHERE user_id = ? AND is_read = 0 AND is_archived = 0',
            'i', $user_id
        );
        $cache[$user_id] = (int)($row['n'] ?? 0);
    } catch (\Throwable $e) {
        $cache[$user_id] = 0;
    }
    return $cache[$user_id];
}

/**
 * Mark notifications as read.
 * $ids = [] means mark ALL unread for the user.
 */
function notif_mark_read(int $user_id, array $ids = []): void {
    try {
        if ($ids) {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $types = 'i' . str_repeat('i', count($ids));
            $params = array_merge([$user_id], array_map('intval', $ids));
            db_query(
                "UPDATE notifications SET is_read=1 WHERE user_id=? AND id IN ($placeholders)",
                $types, ...$params
            );
        } else {
            db_query('UPDATE notifications SET is_read=1 WHERE user_id=? AND is_read=0', 'i', $user_id);
        }
    } catch (\Throwable $e) {}
}

/**
 * Archive a notification.
 */
function notif_archive(int $user_id, int $id): void {
    try {
        db_query('UPDATE notifications SET is_archived=1 WHERE id=? AND user_id=?', 'ii', $id, $user_id);
    } catch (\Throwable $e) {}
}

// ── Human-readable time ago ──────────────────────────────────
function notif_time_ago(string $dt): string {
    try {
        $then = new DateTime($dt, new DateTimeZone('UTC'));
        $now  = new DateTime('now', new DateTimeZone('UTC'));
        $diff = $now->getTimestamp() - $then->getTimestamp();
        if ($diff < 60)     return 'just now';
        if ($diff < 3600)   return floor($diff / 60) . 'm ago';
        if ($diff < 86400)  return floor($diff / 3600) . 'h ago';
        if ($diff < 604800) return floor($diff / 86400) . 'd ago';
        return format_dt($dt, 'd M');
    } catch (\Throwable $e) {
        return '';
    }
}

endif;
