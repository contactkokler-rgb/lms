<?php
if (!defined('APP_URL')) require_once __DIR__ . '/config.php';

/**
 * Normalize a phone number to digits only for comparison.
 */
function dedupe_normalize_phone(string $v): string {
    return preg_replace('/\D/', '', $v);
}

/**
 * Check if a string looks like a phone number.
 */
function dedupe_is_phone(string $v): bool {
    $digits = preg_replace('/\D/', '', $v);
    return strlen($digits) >= 7 && strlen($digits) <= 15;
}

/**
 * Extract email, phone, and name from lead_values rows.
 * Returns ['email'=>..., 'phone'=>..., 'name'=>...]
 */
function dedupe_extract_signals(array $field_values): array {
    $out = ['email' => '', 'phone' => '', 'name' => ''];
    foreach ($field_values as $fv) {
        $k = strtolower($fv['field_key'] ?? '');
        $l = strtolower($fv['field_label'] ?? '');
        $v = trim($fv['value'] ?? '');
        if (!$v) continue;
        if (!$out['email'] && (strpos($k,'email')!==false || strpos($l,'email')!==false || filter_var($v,FILTER_VALIDATE_EMAIL)))
            $out['email'] = strtolower($v);
        if (!$out['phone'] && (strpos($k,'phone')!==false || strpos($l,'phone')!==false || strpos($k,'mobile')!==false || strpos($l,'mobile')!==false || dedupe_is_phone($v)))
            $out['phone'] = dedupe_normalize_phone($v);
        if (!$out['name'] && (strpos($k,'name')!==false || strpos($l,'name')!==false))
            $out['name'] = strtolower(trim($v));
    }
    return $out;
}

/**
 * Find duplicate leads for a given lead ID.
 * Returns array of matching leads with match metadata.
 * Does NOT insert into lead_duplicates — use dedupe_record() for that.
 */
function dedupe_find(int $lead_id, int $account_id): array {
    $fv = db_fetch_all('SELECT field_key, field_label, value FROM lead_values WHERE lead_id = ?', 'i', $lead_id);
    $signals = dedupe_extract_signals($fv);
    $matches = [];
    $seen    = [];

    // Match by email
    if ($signals['email']) {
        $rows = db_fetch_all(
            "SELECT l.id, l.reference_no, l.status, l.submitted_at, l.assigned_to,
             CONCAT(u.first_name,' ',u.last_name) AS assigned_name
             FROM leads l
             LEFT JOIN users u ON u.id = l.assigned_to
             JOIN lead_values lv ON lv.lead_id = l.id
             WHERE l.account_id = ? AND l.id != ? AND l.is_deleted = 0
             AND LOWER(lv.value) = ?
             AND (lv.field_key LIKE '%email%' OR lv.field_label LIKE '%email%'
                  OR ? REGEXP '^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}$')
             GROUP BY l.id ORDER BY l.submitted_at DESC LIMIT 10",
            'iiss', $account_id, $lead_id, $signals['email'], $signals['email']
        );
        foreach ($rows as $r) {
            if (!isset($seen[$r['id']])) {
                $r['match_type']  = 'email';
                $r['match_value'] = $signals['email'];
                $matches[] = $r;
                $seen[$r['id']] = true;
            }
        }
    }

    // Match by phone
    if ($signals['phone'] && strlen($signals['phone']) >= 7) {
        $rows = db_fetch_all(
            "SELECT l.id, l.reference_no, l.status, l.submitted_at, l.assigned_to,
             CONCAT(u.first_name,' ',u.last_name) AS assigned_name
             FROM leads l
             LEFT JOIN users u ON u.id = l.assigned_to
             JOIN lead_values lv ON lv.lead_id = l.id
             WHERE l.account_id = ? AND l.id != ? AND l.is_deleted = 0
             AND REGEXP_REPLACE(lv.value, '[^0-9]', '') = ?
             AND (lv.field_key LIKE '%phone%' OR lv.field_key LIKE '%mobile%'
                  OR lv.field_label LIKE '%phone%' OR lv.field_label LIKE '%mobile%')
             GROUP BY l.id ORDER BY l.submitted_at DESC LIMIT 10",
            'iis', $account_id, $lead_id, $signals['phone']
        );
        foreach ($rows as $r) {
            if (!isset($seen[$r['id']])) {
                $r['match_type']  = 'phone';
                $r['match_value'] = $signals['phone'];
                $matches[] = $r;
                $seen[$r['id']] = true;
            }
        }
    }

    return $matches;
}

/**
 * Record detected duplicates into lead_duplicates table.
 * Safe to call multiple times (uses INSERT IGNORE).
 */
function dedupe_record(int $lead_id, int $account_id, array $matches): void {
    foreach ($matches as $m) {
        $a = min($lead_id, (int)$m['id']);
        $b = max($lead_id, (int)$m['id']);
        $existing = db_fetch('SELECT id FROM lead_duplicates WHERE lead_id_a=? AND lead_id_b=?', 'ii', $a, $b);
        if (!$existing) {
            db_insert('INSERT INTO lead_duplicates (account_id,lead_id_a,lead_id_b,match_type,match_value) VALUES (?,?,?,?,?)',
                'iiiss', $account_id, $a, $b, $m['match_type'], $m['match_value']);
        }
        // Flag both leads
        db_query('UPDATE leads SET has_duplicates=1 WHERE id IN (?,?)', 'ii', $a, $b);
    }
}

/**
 * Merge $source_id INTO $primary_id.
 * - Moves all comments, values, activities to primary
 * - Marks source as deleted/merged
 * - Preserves pipeline stage (uses primary's status unless primary is 'new')
 * - Logs the merge
 */
function dedupe_merge(int $primary_id, int $source_id, int $merged_by, string $notes = ''): bool {
    $primary = db_fetch('SELECT * FROM leads WHERE id=? AND is_deleted=0', 'i', $primary_id);
    $source  = db_fetch('SELECT * FROM leads WHERE id=? AND is_deleted=0', 'i', $source_id);
    if (!$primary || !$source) return false;

    // Move comments
    db_query('UPDATE lead_comments SET lead_id=? WHERE lead_id=?', 'ii', $primary_id, $source_id);

    // Move lead values that don't already exist on primary
    $existing_keys = array_column(
        db_fetch_all('SELECT field_key FROM lead_values WHERE lead_id=?', 'i', $primary_id),
        'field_key'
    );
    $source_vals = db_fetch_all('SELECT * FROM lead_values WHERE lead_id=?', 'i', $source_id);
    foreach ($source_vals as $sv) {
        if (!in_array($sv['field_key'], $existing_keys)) {
            db_insert('INSERT INTO lead_values (lead_id,field_id,field_key,field_label,value) VALUES (?,?,?,?,?)',
                'iisss', $primary_id, $sv['field_id'] ?? 0, $sv['field_key'], $sv['field_label'], $sv['value']);
        }
    }

    // Preserve best pipeline stage (converted > qualified > contacted > new)
    $stage_rank = ['converted'=>5,'qualified'=>4,'contacted'=>3,'new'=>2,'lost'=>1,'spam'=>0];
    $p_rank = $stage_rank[$primary['status']] ?? 0;
    $s_rank = $stage_rank[$source['status']] ?? 0;
    if ($s_rank > $p_rank) {
        db_query('UPDATE leads SET status=? WHERE id=?', 'si', $source['status'], $primary_id);
    }

    // Mark source as merged
    db_query('UPDATE leads SET is_deleted=1, merged_into_id=?, deleted_at=NOW() WHERE id=?', 'ii', $primary_id, $source_id);

    // Resolve duplicate records
    db_query('UPDATE lead_duplicates SET resolved=1, resolved_at=NOW(), resolved_by=? WHERE (lead_id_a=? AND lead_id_b=?) OR (lead_id_a=? AND lead_id_b=?)',
        'iiiii', $merged_by, min($primary_id,$source_id), max($primary_id,$source_id), min($primary_id,$source_id), max($primary_id,$source_id));

    // Log
    db_insert('INSERT INTO lead_merge_log (primary_id,merged_id,merged_by,notes) VALUES (?,?,?,?)',
        'iiis', $primary_id, $source_id, $merged_by, $notes);

    // Clear dupe flag on primary if no more unresolved dupes
    $remaining = db_fetch('SELECT COUNT(*) AS n FROM lead_duplicates WHERE (lead_id_a=? OR lead_id_b=?) AND resolved=0', 'ii', $primary_id, $primary_id);
    if ((int)($remaining['n'] ?? 0) === 0) {
        db_query('UPDATE leads SET has_duplicates=0 WHERE id=?', 'i', $primary_id);
    }

    return true;
}
