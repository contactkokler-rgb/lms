<?php
if (!defined('APP_URL')) require_once __DIR__ . '/config.php';

// ── Table existence cache ─────────────────────────────────────
function kb_tables_exist(): bool {
    static $checked = null;
    if ($checked !== null) return $checked;
    $db = db();
    $checked = $db->query("SHOW TABLES LIKE 'campaign_knowledge_faqs'")->num_rows > 0;
    return $checked;
}

function kb_retrieve(int $campaign_id, string $query = '', array $options = []): array {
    if (!kb_tables_exist() || !$campaign_id) {
        return ['context' => '', 'types_used' => [], 'entry_ids' => []];
    }

    $max_faqs     = $options['max_faqs']     ?? 3;
    $max_services = $options['max_services'] ?? 3;
    $max_policies = $options['max_policies'] ?? 2;
    $max_pages    = $options['max_pages']    ?? 2;

    $context_parts = [];
    $types_used    = [];
    $entry_ids     = [];

    $profile = db_fetch(
        'SELECT * FROM campaign_knowledge_profile WHERE campaign_id = ?', 'i', $campaign_id
    );
    if ($profile) {
        $p = [];
        if ($profile['business_name'])        $p[] = 'Business: '        . $profile['business_name'];
        if ($profile['industry'])             $p[] = 'Industry: '         . $profile['industry'];
        if ($profile['business_description']) $p[] = 'About: '            . $profile['business_description'];
        if ($profile['service_locations'])    $p[] = 'Locations served: ' . $profile['service_locations'];
        if ($profile['working_hours'])        $p[] = 'Working hours: '    . $profile['working_hours'];
        if ($profile['phone'])                $p[] = 'Phone: '            . $profile['phone'];
        if ($profile['email'])                $p[] = 'Email: '            . $profile['email'];
        if ($profile['address'])              $p[] = 'Address: '          . $profile['address'];
        if ($profile['extra_context'])        $p[] = $profile['extra_context'];
        if ($p) {
            $context_parts[] = "BUSINESS PROFILE:\n" . implode("\n", $p);
            $types_used[]    = 'profile';
        }
    }

    $services = db_fetch_all(
        'SELECT * FROM campaign_knowledge_services
         WHERE campaign_id = ? AND is_active = 1
         ORDER BY sort_order, id LIMIT ?',
        'ii', $campaign_id, $max_services
    );
    if ($services) {
        $lines = [];
        foreach ($services as $s) {
            $line = '• ' . $s['name'];
            if ($s['description']) $line .= ': ' . $s['description'];
            if ($s['benefits'])    $line .= ' | Benefits: ' . str_replace("\n", ', ', trim($s['benefits']));
            if ($s['duration'])    $line .= ' | Duration: ' . $s['duration'];
            $lines[] = $line;
            $entry_ids['services'][] = $s['id'];
        }
        $context_parts[] = "SERVICES OFFERED:\n" . implode("\n", $lines);
        $types_used[]    = 'services';
    }

    $pricing = db_fetch_all(
        'SELECT * FROM campaign_knowledge_pricing
         WHERE campaign_id = ? AND is_active = 1
         ORDER BY sort_order, id',
        'i', $campaign_id
    );
    if ($pricing) {
        $lines = [];
        foreach ($pricing as $p) {
            $line = '• ' . $p['service_name'] . ': ' . ($p['price'] ?? 'Contact for pricing');
            if ($p['price_notes'])  $line .= ' (' . $p['price_notes'] . ')';
            if ($p['special_offer']) $line .= ' 🎯 OFFER: ' . $p['special_offer'];
            $lines[] = $line;
            $entry_ids['pricing'][] = $p['id'];
        }
        $context_parts[] = "PRICING:\n" . implode("\n", $lines);
        $types_used[]    = 'pricing';
    }

    $faqs = kb_search_faqs($campaign_id, $query, $max_faqs);
    if ($faqs) {
        $lines = [];
        foreach ($faqs as $f) {
            $lines[] = 'Q: ' . $f['question'] . "\nA: " . $f['answer'];
            $entry_ids['faq'][] = $f['id'];
            // Phase 12: track usage
            db_query('UPDATE campaign_knowledge_faqs SET times_used = times_used + 1 WHERE id = ?', 'i', $f['id']);
        }
        $context_parts[] = "FREQUENTLY ASKED QUESTIONS:\n" . implode("\n\n", $lines);
        $types_used[]    = 'faq';
    }

    $policies = db_fetch_all(
        'SELECT * FROM campaign_knowledge_policies
         WHERE campaign_id = ? AND is_active = 1
         ORDER BY sort_order, id LIMIT ?',
        'ii', $campaign_id, $max_policies
    );
    if ($policies) {
        $lines = [];
        foreach ($policies as $pol) {
            $lines[] = '• ' . $pol['title'] . ': ' . $pol['content'];
            $entry_ids['policy'][] = $pol['id'];
        }
        $context_parts[] = "POLICIES:\n" . implode("\n", $lines);
        $types_used[]    = 'policy';
    }

    if ($query) {
        $pages = kb_search_pages($campaign_id, $query, $max_pages);
        if ($pages) {
            $lines = [];
            foreach ($pages as $pg) {
                $snippet = mb_substr(strip_tags($pg['content'] ?? ''), 0, 400);
                if ($pg['page_title']) $lines[] = '[' . $pg['page_title'] . '] ' . $snippet . '…';
                else                  $lines[] = $snippet . '…';
                $entry_ids['page'][] = $pg['id'];
            }
            $context_parts[] = "FROM WEBSITE:\n" . implode("\n\n", $lines);
            $types_used[]    = 'page';
        }
    }

    return [
        'context'    => implode("\n\n", $context_parts),
        'types_used' => $types_used,
        'entry_ids'  => $entry_ids,
    ];
}

/**
 * Search FAQs — full-text search first, fallback to LIKE.
 */
function kb_search_faqs(int $campaign_id, string $query, int $limit = 3): array {
    if (!$query) {
        return db_fetch_all(
            'SELECT * FROM campaign_knowledge_faqs
             WHERE campaign_id = ? AND is_active = 1
             ORDER BY times_used DESC, sort_order, id LIMIT ?',
            'ii', $campaign_id, $limit
        );
    }
    // Full-text search
    $db = db();
    $q  = $db->real_escape_string($query);
    $ft = db_fetch_all(
        "SELECT *, MATCH(question,answer) AGAINST(? IN NATURAL LANGUAGE MODE) AS score
         FROM campaign_knowledge_faqs
         WHERE campaign_id = ? AND is_active = 1
           AND MATCH(question,answer) AGAINST(? IN NATURAL LANGUAGE MODE)
         ORDER BY score DESC LIMIT ?",
        'sisi', $query, $campaign_id, $query, $limit
    );
    if ($ft) return $ft;

    // Fallback: LIKE match on keywords
    $keywords = array_filter(explode(' ', preg_replace('/[^\w\s]/u', '', $query)));
    $keywords = array_slice(array_map('trim', $keywords), 0, 4);
    if (!$keywords) return [];
    $wheres = array_fill(0, count($keywords), '(question LIKE ? OR answer LIKE ?)');
    $types  = str_repeat('ss', count($keywords));
    $params = [];
    foreach ($keywords as $kw) { $params[] = "%{$kw}%"; $params[] = "%{$kw}%"; }
    return db_fetch_all(
        "SELECT * FROM campaign_knowledge_faqs
         WHERE campaign_id = ? AND is_active = 1
           AND (" . implode(' OR ', $wheres) . ")
         ORDER BY times_used DESC LIMIT ?",
        'i' . $types . 'i',
        ...array_merge([$campaign_id], $params, [$limit])
    );
}

/**
 * Search crawled pages — full-text first, fallback to LIKE.
 */
function kb_search_pages(int $campaign_id, string $query, int $limit = 2): array {
    if (!$query) return [];
    $ft = db_fetch_all(
        "SELECT id, url, page_title, LEFT(content, 600) AS content
         FROM campaign_knowledge_pages
         WHERE campaign_id = ? AND status = 'crawled'
           AND MATCH(page_title, content) AGAINST(? IN NATURAL LANGUAGE MODE)
         LIMIT ?",
        'isi', $campaign_id, $query, $limit
    );
    if ($ft) return $ft;
    // Fallback LIKE
    $kw = '%' . db()->real_escape_string(mb_substr($query, 0, 50)) . '%';
    return db_fetch_all(
        "SELECT id, url, page_title, LEFT(content, 600) AS content
         FROM campaign_knowledge_pages
         WHERE campaign_id = ? AND status = 'crawled'
           AND (page_title LIKE ? OR content LIKE ?)
         LIMIT ?",
        'issi', $campaign_id, $kw, $kw, $limit
    ) ?: [];
}

// ── Phase 12: Log KB usage ────────────────────────────────────
function kb_log_usage(int $campaign_id, int $account_id, string $source_type,
                       string $query, array $retrieval_result, ?int $lead_id = null): void {
    if (!kb_tables_exist()) return;
    try {
        db_insert(
            'INSERT INTO campaign_knowledge_usage
             (campaign_id, account_id, lead_id, source_type, query_text, kb_types_used, kb_entry_ids)
             VALUES (?,?,?,?,?,?,?)',
            'iiissss',
            $campaign_id, $account_id,
            $lead_id,
            $source_type,
            mb_substr($query, 0, 500),
            implode(',', $retrieval_result['types_used'] ?? []),
            json_encode($retrieval_result['entry_ids'] ?? [])
        );
    } catch (Throwable $e) {
        // Non-fatal — analytics should never break the main flow
    }
}

// ── Phase 12: Analytics summary ──────────────────────────────
function kb_analytics(int $campaign_id): array {
    if (!kb_tables_exist()) return [];
    try {
        $total_uses = db_fetch(
            'SELECT COUNT(*) AS n FROM campaign_knowledge_usage WHERE campaign_id = ?', 'i', $campaign_id
        )['n'] ?? 0;

        $by_type = db_fetch_all(
            'SELECT source_type, COUNT(*) AS n
             FROM campaign_knowledge_usage WHERE campaign_id = ?
             GROUP BY source_type ORDER BY n DESC', 'i', $campaign_id
        );

        $top_faqs = db_fetch_all(
            'SELECT question, answer, times_used
             FROM campaign_knowledge_faqs
             WHERE campaign_id = ? AND times_used > 0
             ORDER BY times_used DESC LIMIT 5', 'i', $campaign_id
        );

        $recent_queries = db_fetch_all(
            'SELECT query_text, source_type, created_at
             FROM campaign_knowledge_usage
             WHERE campaign_id = ? AND query_text IS NOT NULL
             ORDER BY id DESC LIMIT 10', 'i', $campaign_id
        );

        return compact('total_uses', 'by_type', 'top_faqs', 'recent_queries');
    } catch (Throwable $e) {
        return [];
    }
}

// ── Phase 7: URL Crawler helper ──────────────────────────────
/**
 * Fetch and extract plain text from a URL.
 * Called from ajax/kb_crawl.php
 */
function kb_crawl_url(string $url): array {
    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        return ['ok' => false, 'error' => 'Invalid URL'];
    }

    // Block internal/private URLs
    $host = parse_url($url, PHP_URL_HOST);
    if (preg_match('/^(localhost|127\.|192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/i', $host)) {
        return ['ok' => false, 'error' => 'Private/local URLs not allowed'];
    }

    $ctx = stream_context_create([
        'http' => [
            'method'          => 'GET',
            'timeout'         => 15,
            'follow_location' => 1,
            'max_redirects'   => 3,
            'header'          => [
                'User-Agent: Mozilla/5.0 (compatible; LeadPro-KB/1.0; +https://leadpro.ai/bot)',
                'Accept: text/html,application/xhtml+xml',
            ],
        ],
        'ssl' => ['verify_peer' => false, 'verify_peer_name' => false],
    ]);

    $html = @file_get_contents($url, false, $ctx);
    if ($html === false) {
        return ['ok' => false, 'error' => 'Could not fetch URL — check it is publicly accessible'];
    }

    // Extract title
    $title = '';
    if (preg_match('/<title[^>]*>(.*?)<\/title>/is', $html, $m)) {
        $title = trim(html_entity_decode(strip_tags($m[1]), ENT_QUOTES, 'UTF-8'));
    }

    // Remove scripts, styles, nav, footer, header elements
    $html = preg_replace('/<(script|style|nav|footer|header|aside|noscript)[^>]*>.*?<\/\1>/is', '', $html);
    // Remove HTML tags
    $text = strip_tags($html);
    // Normalise whitespace
    $text = preg_replace('/[ \t]+/', ' ', $text);
    $text = preg_replace('/\n{3,}/', "\n\n", $text);
    $text = trim($text);

    if (strlen($text) < 50) {
        return ['ok' => false, 'error' => 'Page has no usable text content'];
    }

    // Limit to 15,000 chars to keep DB manageable
    if (strlen($text) > 15000) $text = mb_substr($text, 0, 15000) . "\n…[truncated]";

    return [
        'ok'         => true,
        'title'      => mb_substr($title, 0, 500),
        'content'    => $text,
        'word_count' => str_word_count($text),
    ];
}
