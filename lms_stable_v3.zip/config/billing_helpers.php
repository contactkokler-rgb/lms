<?php
/**
 * Billing & Subscription Access Control Functions
 * Add these to config/auth.php
 */

/**
 * Check if action is allowed based on plan status
 */
function checkBillingRestriction($account_id, $action) {
    require_once __DIR__ . '/../auditor/BillingService.php';
    $restrictions = BillingService::getRestrictions($account_id);
    
    $action_map = [
        'edit' => 'can_edit',
        'create_campaign' => 'can_create_campaign',
        'add_domain' => 'can_add_domain',
        'add_form' => 'can_add_form',
        'add_team' => 'can_add_team_member',
        'use_tools' => 'can_use_tools',
        'use_seo' => 'can_use_seo_auditor'
    ];

    return $restrictions[$action_map[$action] ?? 'can_edit'] ?? false;
}

/**
 * Block action if billing restriction
 */
function requireBillingPermission($action) {
    if (!isset($_SESSION['account_id'])) {
        http_response_code(401);
        die(json_encode(['success' => false, 'error' => 'Not authenticated']));
    }

    $account_id = (int)$_SESSION['account_id'];
    
    if (!checkBillingRestriction($account_id, $action)) {
        http_response_code(403);
        die(json_encode([
            'success' => false,
            'error' => 'This action requires an active subscription.',
            'billing_blocked' => true
        ]));
    }
}

/**
 * Check usage limit before allowing action
 */
function checkUsageLimitBilling($account_id, $type) {
    require_once __DIR__ . '/../auditor/BillingService.php';
    return BillingService::checkLimit($account_id, $type);
}

/**
 * Track usage after action
 */
function trackUsageBilling($account_id, $type, $quantity = 1) {
    require_once __DIR__ . '/../auditor/BillingService.php';
    return BillingService::trackUsage($account_id, $type, $quantity);
}

/**
 * Get plan status for display
 */
function getPlanStatus($account_id) {
    require_once __DIR__ . '/../auditor/BillingService.php';
    return BillingService::getPlanStatus($account_id);
}

/**
 * Show billing banner if plan expired
 */
function renderBillingBanner($account_id) {
    require_once __DIR__ . '/../auditor/BillingService.php';
    $status = BillingService::getPlanStatus($account_id);

    if ($status['status'] === 'active') return '';

    $html = '<div style="background:#fee2e2;border:1px solid #fecaca;border-radius:8px;padding:12px;margin-bottom:16px;color:#991b1b;font-size:.9rem;">';
    $html .= '<strong>⚠ Plan Expired</strong> — Your plan expired on ' . date('M d, Y', strtotime($status['expires_at'])) . '. ';
    $html .= 'Most features are restricted. <a href="' . APP_URL . '/billing.php" style="font-weight:600;">View Billing →</a>';
    $html .= '</div>';

    return $html;
}
