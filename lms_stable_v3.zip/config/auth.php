<?php
require_once __DIR__ . '/../config/config.local.php';

function auth_user(): ?array {
    if (!isset($_SESSION['user_id'])) return null;
    static $user = null;
    if ($user === null) {
        $user = db_fetch(
            'SELECT u.*, r.name AS role_name, r.label AS role_label, a.name AS account_name, a.plan AS account_plan
             FROM users u
             JOIN roles r ON r.id = u.role_id
             LEFT JOIN accounts a ON a.id = u.account_id
             WHERE u.id = ? AND u.status = "active"',
            'i', $_SESSION['user_id']
        );
    }
    return $user;
}

function require_auth(): array {
    $user = auth_user();
    if (!$user) {
        header('Location: ' . APP_URL . '/login.php');
        exit;
    }
    // Maintenance mode — block everyone except super_admin
    if ($user['role_name'] !== 'super_admin') {
        $maint = ps('maintenance_mode', '0');
        if ($maint === '1') {
            $msg   = ps('maintenance_message', 'We are performing scheduled maintenance. We will be back shortly.');
            $brand = ps('brand_color_500', '#2563eb');
            $name  = ps('app_name', 'LeadPro');
            http_response_code(503);
            echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Maintenance — ' . htmlspecialchars($name) . '</title>'
               . '<link rel="stylesheet" href="assets/css/nova.css"></head><body class="grid items-center justify-center text-center">'
               . '<div class="w"><div class="icon-huge">'
               . '<i class="hhgi hgi-stroke hgi-alert-02 bg-neutral-200 text-warning"></i>'
               . '</div><h2 class="mt-8 mb-1">Under Maintenance</h2>'
               . '<p>' . htmlspecialchars($msg) . '</p>'
               . '<div class="mt-10 text-xs text-muted">' . ps_copyright() . '</div>'
               . '</div></body></html>';
            exit;
        }
    }
    return $user;
}

function can(string $module, string $action): bool {
    $user = auth_user();
    if (!$user) return false;
    // Super admin has unrestricted access to everything
    if ($user['role_name'] === 'super_admin') return true;
    static $perms = null;
    if ($perms === null) {
        $rows  = db_fetch_all(
            'SELECT p.module, p.action FROM permissions p
             JOIN role_permissions rp ON rp.permission_id = p.id
             WHERE rp.role_id = ?',
            'i', $user['role_id']
        );
        $perms = [];
        foreach ($rows as $row) {
            $perms[$row['module'] . '.' . $row['action']] = true;
        }
    }
    return isset($perms[$module . '.' . $action]);
}

function require_permission(string $module, string $action): array {
    $user = require_auth();
    if (!can($module, $action)) {
        http_response_code(403);
        include __DIR__ . '/../layouts/403.php';
        exit;
    }
    return $user;
}

function is_super_admin(): bool {
    $user = auth_user();
    return $user && $user['role_name'] === 'super_admin';
}

function login(string $email, string $password): array {
    $user = db_fetch(
        'SELECT u.*, r.name AS role_name FROM users u JOIN roles r ON r.id = u.role_id
         WHERE u.email = ?',
        's', $email
    );

    if (!$user) {
        return ['success' => false, 'error' => 'Invalid email or password.'];
    }
    if ($user['status'] === 'suspended') {
        return ['success' => false, 'error' => 'Your account has been suspended. Contact support.'];
    }
    if ($user['status'] === 'invited') {
        return ['success' => false, 'error' => 'Please accept your invitation and set a password first.'];
    }
    if (!password_verify($password, $user['password_hash'])) {
        return ['success' => false, 'error' => 'Invalid email or password.'];
    }

    // Set session
    session_regenerate_id(true);
    $_SESSION['user_id']    = $user['id'];
    $_SESSION['account_id'] = $user['account_id'];
    $_SESSION['role']       = $user['role_name'];

    // Update last login
    db_query(
        'UPDATE users SET last_login_at = NOW(), last_login_ip = ? WHERE id = ?',
        'si', $_SERVER['REMOTE_ADDR'] ?? '', $user['id']
    );

    audit('auth.login', null, ['email' => $email]);

    return ['success' => true, 'user' => $user];
}

function logout(): void {
    audit('auth.logout');
    session_destroy();
    header('Location: ' . APP_URL . '/login.php');
    exit;
}

function audit(string $action, ?string $target = null, array $meta = []): void {
    try {
        $user       = auth_user();
        $user_id    = $user['id']         ?? null;
        $account_id = $user['account_id'] ?? null;
        $meta_json  = $meta ? json_encode($meta) : null;
        $ip         = $_SERVER['REMOTE_ADDR'] ?? null;

        $db   = db();
        $stmt = $db->prepare(
            'INSERT INTO audit_log (user_id, account_id, action, target, meta, ip_address)
             VALUES (?, ?, ?, ?, ?, ?)'
        );
        $stmt->bind_param('iissss', $user_id, $account_id, $action, $target, $meta_json, $ip);
        $stmt->execute();
    } catch (\Throwable $e) {
        // Never let audit failure break the app
    }
}

function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_verify(): bool {
    $token = $_POST['_csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    return hash_equals($_SESSION['csrf_token'] ?? '', $token);
}

function csrf_field(): string {
    return '<input type="hidden" name="_csrf" value="' . csrf_token() . '">';
}