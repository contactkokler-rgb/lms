<?php
if (!defined('APP_URL')) require_once __DIR__ . '/config.php';

// ── Settings helpers ─────────────────────────────────────────

function ai_setting(string $key, string $default = '') {
    static $cache = null;
    if ($cache === null) {
        $rows  = db_fetch_all('SELECT `key`, `value` FROM platform_settings');
        $cache = [];
        foreach ($rows as $r) $cache[$r['key']] = $r['value'];
    }
    return isset($cache[$key]) ? $cache[$key] : $default;
}

function ai_enabled(): bool {
    // Enabled if master switch on AND at least one provider has a key
    if (ai_setting('ai_enabled', '0') !== '1') return false;
    return ai_setting('ai_api_key', '')    !== ''
        || ai_setting('groq_api_key', '')  !== ''
        || ai_setting('gemini_api_key', '') !== '';
}

function ai_save_setting(string $key, string $value): void {
    db_query(
        'INSERT INTO platform_settings (`key`, `value`) VALUES (?,?)
         ON DUPLICATE KEY UPDATE `value` = ?, updated_at = NOW()',
        'sss', $key, $value, $value
    );
}

// ── Provider registry ────────────────────────────────────────
// Returns ordered list of configured providers to try.
// Priority: Groq (fastest, 14400/day) → Gemini (1000/day) → OpenRouter (200/day)

function ai_get_providers(): array {
    $providers = [];

    // Groq — free, fast, 14,400 req/day
    $groq_key = ai_setting('groq_api_key', '');
    if ($groq_key) {
        $providers[] = [
            'name'     => 'Groq',
            'key'      => $groq_key,
            'base_url' => 'https://api.groq.com/openai/v1/chat/completions',
            'model'    => ai_setting('groq_model', 'llama-3.3-70b-versatile'),
            'type'     => 'openai',  // OpenAI-compatible
        ];
    }

    // Gemini — free, 250–1000 req/day depending on model
    $gem_key = ai_setting('gemini_api_key', '');
    if ($gem_key) {
        $gem_model = ai_setting('gemini_model', 'gemini-2.0-flash-lite');
        $providers[] = [
            'name'     => 'Gemini',
            'key'      => $gem_key,
            'base_url' => 'https://generativelanguage.googleapis.com/v1beta/models/' . $gem_model . ':generateContent?key=' . $gem_key,
            'model'    => $gem_model,
            'type'     => 'gemini',  // Different request/response format
        ];
    }

    // OpenRouter — 200 req/day free, many models
    $or_key = ai_setting('ai_api_key', '');
    if ($or_key) {
        $providers[] = [
            'name'     => 'OpenRouter',
            'key'      => $or_key,
            'base_url' => 'https://openrouter.ai/api/v1/chat/completions',
            'model'    => ai_setting('ai_model', 'meta-llama/llama-3.3-70b-instruct:free'),
            'type'     => 'openai',
        ];
    }

    return $providers;
}

// ── Single provider call ─────────────────────────────────────

function ai_call_provider(array $provider, array $messages, int $max_tokens): array {
    if ($provider['type'] === 'gemini') {
        return ai_call_gemini($provider, $messages, $max_tokens);
    }
    return ai_call_openai($provider, $messages, $max_tokens);
}

function ai_call_openai(array $provider, array $messages, int $max_tokens): array {
    $extra = [];
    // OpenRouter-specific extras
    if (strpos($provider['base_url'], 'openrouter') !== false) {
        $fallbacks = array_values(array_filter([
            'meta-llama/llama-4-scout:free',
            'qwen/qwen3-8b:free',
            'mistralai/mistral-7b-instruct:free',
        ], function($m) use ($provider) { return $m !== $provider['model']; }));
        $extra = [
            'models'   => array_merge([$provider['model']], array_slice($fallbacks, 0, 2)),
            'provider' => ['allow_fallbacks' => true, 'data_collection' => 'allow'],
        ];
    }

    $payload = json_encode(array_merge([
        'model'       => $provider['model'],
        'messages'    => $messages,
        'max_tokens'  => $max_tokens,
        'temperature' => 0.3,
    ], $extra));

    $headers = [
        'Authorization: Bearer ' . $provider['key'],
        'Content-Type: application/json',
        'HTTP-Referer: ' . APP_URL,
        'X-Title: LeadPro CRM',
    ];

    $ch = curl_init($provider['base_url']);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_HTTPHEADER     => $headers,
    ]);
    $resp = curl_exec($ch);
    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $cerr = curl_error($ch);
    curl_close($ch);

    if ($cerr) return ['ok' => false, 'error' => 'Network error: ' . $cerr, 'retry' => false];
    if (!$resp) return ['ok' => false, 'error' => 'Empty response', 'retry' => true];

    $data = json_decode($resp, true);

    if ($http === 429) {
        return ['ok' => false, 'error' => 'Rate limit hit on ' . $provider['name'], 'retry' => true];
    }
    if ($http !== 200 || !isset($data['choices'])) {
        $err_msg  = isset($data['error']['message']) ? $data['error']['message'] : ('HTTP ' . $http);
        $err_code = isset($data['error']['code'])    ? $data['error']['code']    : $http;
        $retry    = in_array($http, [429, 503, 529]);
        // Translate common errors
        if ($err_code == 401)                           $err_msg = 'Invalid API key for ' . $provider['name'];
        if (strpos($err_msg, 'Provider returned') !== false) { $err_msg = $provider['name'] . ' provider overloaded — trying next'; $retry = true; }
        if (strpos($err_msg, 'No endpoints') !== false)       { $err_msg = 'No free endpoints available on OpenRouter — check privacy settings at openrouter.ai/settings/privacy'; $retry = false; }
        return ['ok' => false, 'error' => $err_msg, 'retry' => $retry];
    }

    $text  = trim(isset($data['choices'][0]['message']['content']) ? $data['choices'][0]['message']['content'] : '');
    $tokens = (int)(isset($data['usage']['total_tokens']) ? $data['usage']['total_tokens'] : 0);
    $used   = isset($data['model']) ? $data['model'] : $provider['model'];
    return ['ok' => true, 'text' => $text, 'tokens' => $tokens, 'model' => $used, 'provider' => $provider['name']];
}

function ai_call_gemini(array $provider, array $messages, int $max_tokens): array {
    // Convert OpenAI message format → Gemini format
    $contents  = [];
    $sys_text  = '';
    foreach ($messages as $m) {
        if ($m['role'] === 'system') {
            $sys_text = $m['content'];
        } else {
            $contents[] = [
                'role'  => $m['role'] === 'assistant' ? 'model' : 'user',
                'parts' => [['text' => $m['content']]],
            ];
        }
    }
    // If only system message, wrap as user
    if (!$contents && $sys_text) {
        $contents[] = ['role' => 'user', 'parts' => [['text' => $sys_text]]];
        $sys_text   = '';
    }

    $payload_arr = [
        'contents'          => $contents,
        'generationConfig'  => ['maxOutputTokens' => $max_tokens, 'temperature' => 0.3],
    ];
    if ($sys_text) {
        $payload_arr['systemInstruction'] = ['parts' => [['text' => $sys_text]]];
    }

    $ch = curl_init($provider['base_url']);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload_arr),
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
    ]);
    $resp = curl_exec($ch);
    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $cerr = curl_error($ch);
    curl_close($ch);

    if ($cerr) return ['ok' => false, 'error' => 'Network error: ' . $cerr, 'retry' => false];

    $data = json_decode($resp, true);

    if ($http === 429) return ['ok' => false, 'error' => 'Gemini rate limit hit', 'retry' => true];
    if ($http !== 200 || !isset($data['candidates'])) {
        $err = isset($data['error']['message']) ? $data['error']['message'] : ('HTTP ' . $http);
        if ($http === 400) $err = 'Gemini: Invalid API key or bad request — ' . $err;
        return ['ok' => false, 'error' => $err, 'retry' => in_array($http, [429, 503])];
    }

    $text   = trim(isset($data['candidates'][0]['content']['parts'][0]['text']) ? $data['candidates'][0]['content']['parts'][0]['text'] : '');
    $tokens = (int)(isset($data['usageMetadata']['totalTokenCount']) ? $data['usageMetadata']['totalTokenCount'] : 0);
    return ['ok' => true, 'text' => $text, 'tokens' => $tokens, 'model' => $provider['model'], 'provider' => 'Gemini'];
}

// ── Main entry point ─────────────────────────────────────────
// Tries providers in priority order, auto-failover on rate limits.

function ai_call(array $messages, int $max_tokens = 600): array {
    $providers = ai_get_providers();

    if (!$providers) {
        return ['ok' => false, 'error' => 'No AI providers configured. Add at least one API key in Settings → AI & API.'];
    }

    $last_error = '';
    foreach ($providers as $provider) {
        $result = ai_call_provider($provider, $messages, $max_tokens);
        if ($result['ok']) return $result;

        $last_error = '[' . $provider['name'] . '] ' . $result['error'];
        // If not retryable (bad key, bad request), stop immediately
        if (!($result['retry'] ?? true)) break;
        // Otherwise try next provider
    }

    return ['ok' => false, 'error' => $last_error ?: 'All AI providers failed. Check your API keys.'];
}

// ── Lead context builder ─────────────────────────────────────

function ai_lead_context(array $lead, array $fields): string {
    $lines = ["Lead Reference: {$lead['reference_no']}"];
    foreach ($fields as $f) {
        if ($f['value'] !== '' && $f['field_key'] !== '_lp_ts' && $f['field_key'] !== 'lp_website') {
            $lines[] = "{$f['field_label']}: {$f['value']}";
        }
    }
    if (!empty($lead['source_url']))   $lines[] = "Source URL: {$lead['source_url']}";
    if (!empty($lead['utm_source']))   $lines[] = "UTM Source: {$lead['utm_source']}";
    if (!empty($lead['utm_medium']))   $lines[] = "UTM Medium: {$lead['utm_medium']}";
    if (!empty($lead['utm_campaign'])) $lines[] = "UTM Campaign: {$lead['utm_campaign']}";
    if (!empty($lead['country']))      $lines[] = "Country: {$lead['country']}";
    if (!empty($lead['device_type']))  $lines[] = "Device: {$lead['device_type']}";
    if (!empty($lead['referrer']))     $lines[] = "Referrer: {$lead['referrer']}";
    $lines[] = "Submitted: {$lead['submitted_at']}";
    return implode("\n", $lines);
}

// ── AI Features ──────────────────────────────────────────────

/**
 * Build business context block from platform settings.
 * Used in all AI prompts to give context about the business.
 */function ai_campaign_context(array $campaign, string $query = ''): string {
    if (empty($campaign)) return '';

    $cid   = (int)($campaign['id'] ?? 0);
    $parts = [];
    $parts[] = 'Campaign: ' . ($campaign['name'] ?? '');
    if (!empty($campaign['description']))  $parts[] = 'Campaign description: ' . $campaign['description'];
    if (!empty($campaign['objective']))    $parts[] = 'Campaign objective: '   . $campaign['objective'];

    // Try full knowledge base first (richer, more structured)
    if ($cid) {
        try {
            if (!function_exists('kb_retrieve') && file_exists(__DIR__ . '/knowledge.php')) require_once __DIR__ . '/knowledge.php';
            if (kb_tables_exist()) {
                $kb = kb_retrieve($cid, $query, [
                    'max_faqs'     => $query ? 3 : 2,
                    'max_services' => 3,
                    'max_policies' => 2,
                    'max_pages'    => $query ? 2 : 0,
                ]);
                if ($kb['context']) {
                    return "CAMPAIGN CONTEXT:\n" . implode("\n", $parts) . "\n\n" . $kb['context'];
                }
            }
        } catch (Throwable $e) {
            // KB not set up yet — fall through to quick fields
        }
    }

    // Fallback: quick fields from campaigns table
    if (!empty($campaign['ai_service']))         $parts[] = 'Service/product: '  . $campaign['ai_service'];
    if (!empty($campaign['ai_target_audience'])) $parts[] = 'Target audience: '  . $campaign['ai_target_audience'];
    if (!empty($campaign['ai_location']))        $parts[] = 'Location: '         . $campaign['ai_location'];
    if (!empty($campaign['ai_pricing']))         $parts[] = 'Pricing: '          . $campaign['ai_pricing'];
    if (!empty($campaign['ai_booking_url']))     $parts[] = 'Booking link: '     . $campaign['ai_booking_url'];
    if (!empty($campaign['ai_context']))         $parts[] = $campaign['ai_context'];

    return $parts ? "CAMPAIGN CONTEXT:\n" . implode("\n", $parts) . "\n\n" : '';
}

/**
 * STEP 1 — Full AI Lead Intelligence.
 * Returns: score, qualification, conversion_pct, intent, sentiment,
 *          lead_category, tags, summary, next_action, reasoning.
 */function ai_analyze_lead(array $lead, array $fields, array $campaign = []): array {
    $lead_ctx = ai_lead_context($lead, $fields);
    $camp_ctx = ai_campaign_context($campaign);

    $prompt = <<<PROMPT
You are an expert AI sales intelligence engine for a lead management system.
Analyze this lead completely and return ONLY valid JSON. No explanation, no markdown.

{$camp_ctx}LEAD DATA:
{$lead_ctx}

Return EXACTLY this JSON (all fields required):
{
  "score":         <integer 0-100, overall lead quality>,
  "qualification": "<unqualified|low|medium|high|hot>",
  "conversion_pct":<integer 0-100, probability this lead converts>,
  "intent":        "<appointment|pricing|consultation|treatment|emergency|general_enquiry|information|complaint|other>",
  "sentiment":     "<positive|neutral|negative|urgent>",
  "lead_category": "<new_lead|returning_lead|existing_customer|duplicate|spam|bot>",
  "tags":          ["<tag1>","<tag2>","<tag3>"],
  "summary":       "<2-3 sentence summary of what the lead wants and their urgency>",
  "next_action":   "<specific recommended action for the sales team>",
  "reasoning":     "<1-2 sentence scoring rationale>"
}

Tag examples: "urgent", "price-sensitive", "appointment-ready", "needs-follow-up",
"high-value", "local", "referral", "returning", "mobile-user", "evening-enquiry".
PROMPT;

    $result = ai_call([
        ['role' => 'system', 'content' => 'You are a sales intelligence AI. Respond with valid JSON only. No markdown, no explanation.'],
        ['role' => 'user',   'content' => $prompt],
    ], 520);

    if (!$result['ok']) return $result;

    // Parse — strip markdown fences, extract first JSON object
    $raw = preg_replace('/```json|```/', '', $result['text']);
    $s   = strpos($raw, '{'); $e = strrpos($raw, '}');
    if ($s !== false && $e !== false) $raw = substr($raw, $s, $e - $s + 1);
    $json = json_decode(trim($raw), true);
    if (!$json) return ['ok' => false, 'error' => 'Invalid JSON from AI: ' . substr($result['text'], 0, 120)];

    // Normalise and validate enum values
    $valid_intents    = ['appointment','pricing','consultation','treatment','emergency','general_enquiry','information','complaint','other'];
    $valid_sentiments = ['positive','neutral','negative','urgent'];
    $valid_categories = ['new_lead','returning_lead','existing_customer','duplicate','spam','bot'];

    $json['intent']        = in_array($json['intent']        ?? '', $valid_intents)    ? $json['intent']        : 'general_enquiry';
    $json['sentiment']     = in_array($json['sentiment']     ?? '', $valid_sentiments) ? $json['sentiment']     : 'neutral';
    $json['lead_category'] = in_array($json['lead_category'] ?? '', $valid_categories) ? $json['lead_category'] : 'new_lead';
    $json['tags']          = array_slice(
        array_filter((array)($json['tags'] ?? []), fn($t) => is_string($t) && strlen(trim($t)) > 0 && strlen($t) < 40),
        0, 8
    );
    $json['score']          = max(0, min(100, (int)($json['score']          ?? 0)));
    $json['conversion_pct'] = max(0, min(100, (int)($json['conversion_pct'] ?? 0)));

    return array_merge(['ok' => true, 'tokens' => $result['tokens'] ?? 0, 'model' => $result['model'] ?? ''], $json);
}


function ai_smart_replies(array $lead, array $fields, array $comments,
                           array $campaign = [], string $tone = 'professional'): array {
    // Build lead context
    $lead_ctx  = ai_lead_context($lead, $fields);

    // Build KB-aware campaign context, querying against lead message
    $lead_msg  = '';
    foreach ($fields as $f) {
        if (in_array($f['field_key'], ['message','enquiry','description','notes','comment'])) {
            $lead_msg = $f['value'] ?? '';
            break;
        }
    }
    if (!$lead_msg && !empty($fields)) {
        // Fall back to last field value as likely message
        $last = end($fields);
        $lead_msg = $last['value'] ?? '';
    }

    $camp_ctx  = ai_campaign_context($campaign, $lead_msg);

    // Build conversation history (last 10 comments)
    $thread = '';
    if ($comments) {
        $recent = array_slice(array_reverse($comments), 0, 10);
        $recent = array_reverse($recent);
        $lines  = array_map(fn($c) => "[{$c['created_at']}] {$c['author_name']}: {$c['comment']}", $recent);
        $thread = "\n\nPREVIOUS CONVERSATION:\n" . implode("\n", $lines);
    }

    // Intent from Step 1 analysis
    $intent    = $lead['ai_intent']    ?? '';
    $sentiment = $lead['ai_sentiment'] ?? '';
    $i_note    = $intent    ? "\nDetected intent: {$intent}"       : '';
    $s_note    = $sentiment ? "\nDetected sentiment: {$sentiment}" : '';

    $prompt = <<<PROMPT
You are a {$tone} sales representative generating reply options for an incoming lead.

{$camp_ctx}LEAD DATA:
{$lead_ctx}{$i_note}{$s_note}{$thread}

Generate EXACTLY 3 different reply options. Each reply should:
- Be suitable as a direct email response to this lead
- Be concise (under 100 words for body)
- Reference the specific service/product they asked about
- Include a clear call to action

Return ONLY valid JSON, no markdown:
{
  "replies": [
    {
      "subject": "<email subject line>",
      "body": "<reply body — use \\n for line breaks>",
      "label": "<1-3 word description e.g. Book Consultation, Share Pricing, Quick Follow-up>"
    },
    {
      "subject": "<email subject line>",
      "body": "<reply body>",
      "label": "<label>"
    },
    {
      "subject": "<email subject line>",
      "body": "<reply body>",
      "label": "<label>"
    }
  ]
}
PROMPT;

    $result = ai_call([
        ['role' => 'system', 'content' => 'You are a sales CRM assistant. Respond with valid JSON only. No markdown.'],
        ['role' => 'user',   'content' => $prompt],
    ], 700);

    if (!$result['ok']) return $result;

    $raw  = preg_replace('/```json|```/', '', $result['text']);
    $s    = strpos($raw, '{'); $e = strrpos($raw, '}');
    if ($s !== false && $e !== false) $raw = substr($raw, $s, $e - $s + 1);
    $json = json_decode(trim($raw), true);

    if (!$json || empty($json['replies']) || !is_array($json['replies'])) {
        return ['ok' => false, 'error' => 'AI returned invalid format'];
    }

    // Validate and clean each reply
    $replies = [];
    foreach (array_slice($json['replies'], 0, 3) as $r) {
        if (empty($r['body'])) continue;
        $replies[] = [
            'subject' => trim($r['subject'] ?? 'Following up on your enquiry'),
            'body'    => trim($r['body']),
            'label'   => trim($r['label']   ?? 'Reply Option'),
        ];
    }

    return [
        'ok'     => true,
        'replies' => $replies,
        'tokens'  => $result['tokens'] ?? 0,
        'model'   => $result['model']  ?? '',
    ];
}


function ai_generate_followup_email(array $lead, array $fields, array $comments = [],
                                     array $campaign = [], string $tone = 'professional',
                                     string $intent_override = ''): array {
    $lead_ctx  = ai_lead_context($lead, $fields);
    $camp_ctx  = ai_campaign_context($campaign);

    $intent    = $intent_override ?: ($lead['ai_intent'] ?? 'general_enquiry');
    $sentiment = $lead['ai_sentiment'] ?? 'neutral';

    $thread = '';
    if ($comments) {
        $recent = array_slice(array_reverse($comments), 0, 5);
        $recent = array_reverse($recent);
        $lines  = array_map(fn($c) => "[{$c['created_at']}] {$c['author_name']}: {$c['comment']}", $recent);
        $thread = "\n\nPREVIOUS CONVERSATION:\n" . implode("\n", $lines);
    }

    $prompt = <<<PROMPT
You are a {$tone} sales representative writing a follow-up email to a lead.

{$camp_ctx}LEAD DATA:
{$lead_ctx}
Lead intent: {$intent}
Lead sentiment: {$sentiment}{$thread}

Write a {$tone} follow-up email. Requirements:
- Personalised to the lead's specific enquiry
- Under 180 words for the body
- Clear subject line
- One specific call to action
- Natural, human-sounding tone

Return ONLY valid JSON, no markdown:
{
  "subject": "<compelling subject line>",
  "body": "<email body — use \\n for line breaks>",
  "preview_text": "<1 sentence email preview>"
}
PROMPT;

    $result = ai_call([
        ['role' => 'system', 'content' => 'You are a sales email writer. Respond with JSON only.'],
        ['role' => 'user',   'content' => $prompt],
    ], 500);

    if (!$result['ok']) return $result;

    $raw  = preg_replace('/```json|```/', '', $result['text']);
    $s    = strpos($raw, '{'); $e = strrpos($raw, '}');
    if ($s !== false && $e !== false) $raw = substr($raw, $s, $e - $s + 1);
    $json = json_decode(trim($raw), true);

    if (!$json || empty($json['subject']) || empty($json['body'])) {
        return ['ok' => false, 'error' => 'Invalid AI email response'];
    }

    return array_merge(['ok' => true, 'tokens' => $result['tokens'] ?? 0], $json);
}


function ai_summarize_lead(array $lead, array $fields, array $comments, array $campaign = []): array {
    if (!$comments) return ['ok' => false, 'error' => 'No conversation to summarize'];

    $thread = implode("\n", array_map(
        fn($c) => "[{$c['created_at']}] {$c['author_name']}: {$c['comment']}",
        $comments
    ));
    $camp_name = $campaign['name'] ?? '';

    $result = ai_call([
        ['role' => 'system', 'content' => 'You are a CRM assistant. Respond with JSON only.'],
        ['role' => 'user',   'content' => "Summarize this lead conversation in 3-4 sentences.\n" .
            ($camp_name ? "Campaign: {$camp_name}\n" : '') .
            "Lead: {$lead['reference_no']}\n\n{$thread}\n\n" .
            'Return JSON: {"summary":"<text>","stage":"<initial_enquiry|in_discussion|ready_to_book|closed>","key_points":["<point1>","<point2>"]}'
        ],
    ], 300);

    if (!$result['ok']) return $result;
    $raw  = preg_replace('/```json|```/', '', $result['text']);
    $s    = strpos($raw, '{'); $e = strrpos($raw, '}');
    if ($s !== false && $e !== false) $raw = substr($raw, $s, $e - $s + 1);
    $json = json_decode(trim($raw), true);
    return $json ? array_merge(['ok' => true], $json) : ['ok' => false, 'error' => 'Invalid response'];
}

function ai_generate_email(array $lead, array $fields, string $tone = 'professional'): array {
    $context = ai_lead_context($lead, $fields);
    $prompt  = <<<PROMPT
Write a {$tone} follow-up email for this lead. Keep it concise (under 150 words), personalized, and focused on next steps.

Lead data:
{$context}

Respond ONLY with JSON:
{
  "subject": "<email subject>",
  "body": "<email body with \\n for line breaks>"
}
PROMPT;

    $result = ai_call([
        ['role' => 'system', 'content' => 'You are a sales email writer. Respond with JSON only.'],
        ['role' => 'user',   'content' => $prompt],
    ], 350);

    if (!$result['ok']) return $result;
    $text = preg_replace('/```json|```/', '', $result['text']);
    $json = json_decode(trim($text), true);
    if (!$json) return ['ok' => false, 'error' => 'Invalid response'];
    return array_merge(['ok' => true, 'tokens' => $result['tokens']], $json);
}



function ai_generate_message(array $lead, array $fields): array {
    $context = ai_lead_context($lead, $fields);
    $result  = ai_call([
        ['role' => 'system', 'content' => 'You are a sales messaging assistant. Respond with JSON only.'],
        ['role' => 'user',   'content' => "Write a short WhatsApp/SMS follow-up message (max 50 words) for this lead.\n\n{$context}\n\nRespond with JSON: {\"message\": \"<text>\"}"],
    ], 150);
    if (!$result['ok']) return $result;
    $text = preg_replace('/```json|```/', '', $result['text']);
    $json = json_decode(trim($text), true);
    return $json ? array_merge(['ok' => true], $json) : ['ok' => false, 'error' => 'Invalid response'];
}


function ai_summarize_conversation(array $lead, array $comments): array {
    if (!$comments) return ['ok' => false, 'error' => 'No comments to summarize'];
    $thread = implode("\n", array_map(function($c) {
        return "[{$c['created_at']}] {$c['first_name']}: {$c['comment']}";
    }, $comments));
    $result = ai_call([
        ['role' => 'system', 'content' => 'You are a CRM assistant. Respond with JSON only.'],
        ['role' => 'user',   'content' => "Summarize this lead conversation in 2-3 sentences, highlighting key decisions and current status.\n\nLead: {$lead['reference_no']}\n\nConversation:\n{$thread}\n\nRespond with JSON: {\"summary\": \"<text>\", \"status\": \"<brief status>\"}"],
    ], 200);
    if (!$result['ok']) return $result;
    $text = preg_replace('/```json|```/', '', $result['text']);
    $json = json_decode(trim($text), true);
    return $json ? array_merge(['ok' => true], $json) : ['ok' => false, 'error' => 'Invalid response'];
}


function ai_enrich_lead(array $lead, array $fields): array {
    $context = ai_lead_context($lead, $fields);
    $result  = ai_call([
        ['role' => 'system', 'content' => 'You are a data enrichment AI. Respond with JSON only.'],
        ['role' => 'user',   'content' => "Analyze this lead and extract/infer any missing data. Fix formatting issues.\n\n{$context}\n\nRespond with JSON:\n{\"company\": \"<inferred or empty>\", \"industry\": \"<inferred or empty>\", \"job_title\": \"<inferred or empty>\", \"cleaned_phone\": \"<formatted or empty>\", \"notes\": \"<any useful observations>\"}"],
    ], 250);
    if (!$result['ok']) return $result;
    $text = preg_replace('/```json|```/', '', $result['text']);
    $json = json_decode(trim($text), true);
    return $json ? array_merge(['ok' => true], $json) : ['ok' => false, 'error' => 'Invalid response'];
}
