<?php
if (!defined('APP_URL')) require_once __DIR__ . '/config.php';

// Free email domains (business email detection)
function is_free_email_domain(string $domain): bool {
    static $free = [
        'gmail.com','yahoo.com','hotmail.com','outlook.com','icloud.com','me.com',
        'aol.com','msn.com','live.com','yahoo.co.in','yahoo.co.uk','yahoo.com.au',
        'rediffmail.com','protonmail.com','tutanota.com','zoho.com','gmx.com',
        'mail.com','inbox.com','yandex.com','fastmail.com','hey.com',
    ];
    return in_array(strtolower($domain), $free, true);
}

/**
 * Calculate rule-based score for a lead.
 * Returns ['score' => int, 'category' => 'cold|warm|hot', 'reasons' => [...]]
 */
function score_lead(array $lead, array $field_values, int $account_id): array {
    // Load rules: platform-wide (account_id IS NULL) + account-specific
    $rules = db_fetch_all(
        'SELECT * FROM lead_score_rules
         WHERE is_active = 1 AND (account_id IS NULL OR account_id = ?)
         ORDER BY sort_order, id',
        'i', $account_id
    );

    $score   = 0;
    $reasons = [];

    // Build a flat map of field values for easy lookup
    $vals = [];
    foreach ($field_values as $fv) {
        $vals[$fv['field_key']] = strtolower(trim((string)$fv['value']));
    }

    // Extract email for domain checks
    $email_domain = '';
    foreach ($field_values as $fv) {
        if (filter_var($fv['value'], FILTER_VALIDATE_EMAIL)) {
            $email_domain = substr($fv['value'], strpos($fv['value'], '@') + 1);
            break;
        }
    }

    // Find message/description length
    $msg_length = 0;
    foreach ($field_values as $fv) {
        $lbl = strtolower($fv['field_key'] . ' ' . $fv['field_label']);
        if ((strpos($lbl, 'message') !== false) || (strpos($lbl, 'description') !== false) || (strpos($lbl, 'comment') !== false)) {
            $msg_length = strlen($fv['value']);
            break;
        }
    }

    foreach ($rules as $rule) {
        $field    = $rule['field'];
        $op       = $rule['operator'];
        $rval     = strtolower(trim((string)$rule['value']));
        $pts      = (int)$rule['score'];
        $matched  = false;

        switch ($field) {
            case 'email':
                if ($op === 'is_business_email') $matched = $email_domain && !is_free_email_domain($email_domain);
                if ($op === 'is_free_email')     $matched = $email_domain && is_free_email_domain($email_domain);
                break;

            case 'message_length':
                if ($op === 'greater_than') $matched = $msg_length > (int)$rval;
                if ($op === 'less_than')    $matched = $msg_length > 0 && $msg_length < (int)$rval;
                break;

            case 'country':
                $c = strtolower(trim($lead['country'] ?? ''));
                if ($op === 'equals')      $matched = $c === $rval;
                if ($op === 'not_equals')  $matched = $c !== $rval && $c !== '';
                if ($op === 'in_list')     $matched = in_array($c, array_map('trim', explode(',', $rval)), true);
                if ($op === 'not_in_list') $matched = $c !== '' && !in_array($c, array_map('trim', explode(',', $rval)), true);
                break;

            case 'utm_source':
            case 'utm_medium':
            case 'utm_campaign':
                $lv = strtolower(trim($lead[$field] ?? ''));
                if ($op === 'equals')      $matched = $lv === $rval;
                if ($op === 'contains')    $matched = $rval !== '' && (strpos($lv, $rval) !== false);
                if ($op === 'not_equals')  $matched = $lv !== $rval;
                if ($op === 'not_contains')$matched = $rval === '' || (strpos($lv, $rval) === false);
                if ($op === 'in_list')     $matched = in_array($lv, array_map('trim', explode(',', $rval)), true);
                break;

            case 'interactions':
                // Number of comments on this lead
                $n = (int)(db_fetch('SELECT COUNT(*) AS n FROM lead_comments WHERE lead_id = ?', 'i', (int)$lead['id'])['n'] ?? 0);
                if ($op === 'greater_than') $matched = $n > (int)$rval;
                if ($op === 'less_than')    $matched = $n < (int)$rval;
                if ($op === 'equals')       $matched = $n === (int)$rval;
                break;

            default:
                // Generic: check field_values by key
                $v = isset($vals[$field]) ? $vals[$field] : '';
                if ($op === 'equals')       $matched = $v === $rval;
                if ($op === 'not_equals')   $matched = $v !== $rval && $v !== '';
                if ($op === 'contains')     $matched = $rval !== '' && (strpos($v, $rval) !== false);
                if ($op === 'not_contains') $matched = $rval === '' || (strpos($v, $rval) === false);
                if ($op === 'greater_than') $matched = is_numeric($v) && (float)$v > (float)$rval;
                if ($op === 'less_than')    $matched = is_numeric($v) && (float)$v < (float)$rval;
                // not_equals special: field exists and is not empty
                if ($op === 'not_equals' && $rval === '') $matched = $v !== '';
                break;
        }

        if ($matched) {
            $score  += $pts;
            $reasons[] = $rule['name'] . ' (' . ($pts >= 0 ? '+' : '') . $pts . ')';
        }
    }

    $score = max(0, min(100, $score));

    if ($score >= 70)      $category = 'hot';
    elseif ($score >= 35)  $category = 'warm';
    else                   $category = 'cold';

    return [
        'score'    => $score,
        'category' => $category,
        'reasons'  => $reasons,
    ];
}

/**
 * Apply score to a lead (update DB).
 */
function apply_lead_score(int $lead_id, int $account_id): array {
    $lead   = db_fetch('SELECT * FROM leads WHERE id = ?', 'i', $lead_id);
    if (!$lead) return ['ok' => false, 'error' => 'Lead not found'];
    $fields = db_fetch_all('SELECT * FROM lead_values WHERE lead_id = ?', 'i', $lead_id);
    $result = score_lead($lead, $fields, $account_id);
    db_query(
        'UPDATE leads SET score = ?, score_category = ? WHERE id = ?',
        'isi', $result['score'], $result['category'], $lead_id
    );
    return array_merge(['ok' => true], $result);
}
