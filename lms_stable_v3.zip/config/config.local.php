<?php
// LeadPro — Core Configuration. PHP 7.4+ compatible.
define('APP_NAME',    'LeadPro');
define('APP_VERSION', '1.0.0');
define('APP_URL', 'http://localhost:8888/lms41');

error_reporting(E_ALL);
ini_set('display_errors', 1);



// Database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'root');
define('DB_NAME', 'lms4');

// Session / Security
define('SESSION_LIFETIME', 60 * 60 * 8);
define('SESSION_COOKIE',   'lp_session');
define('BCRYPT_COST', 12);
define('INVITATION_TTL', 60 * 60 * 72);

// Start session
if (session_status() === PHP_SESSION_NONE && !defined('NO_SESSION')) {
    session_name(SESSION_COOKIE);
    @session_start([
        'cookie_lifetime' => SESSION_LIFETIME,
        'cookie_httponly' => true,
        //'cookie_secure'   => APP_HTTPS,
        'cookie_samesite' => 'Lax',
    ]);
}

// ── Database helpers (PHP 7.4 compatible — no union types) ───

function db() {
    static $link = null;
    if ($link === null) {
        $link = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($link->connect_error) {
            http_response_code(500);
            die('DB connection failed: ' . $link->connect_error);
        }
        $link->set_charset('utf8mb4');
    }
    return $link;
}

function db_query(string $sql, string $types = '', ...$params) {
    $db   = db();
    $stmt = $db->prepare($sql);
    if (!$stmt) {
        error_log('[LeadPro] db_query prepare failed: ' . $db->error . ' | SQL: ' . $sql);
        return false;
    }
    if ($types !== '' && count($params) > 0) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    return ($result !== false) ? $result : true;
}

function db_fetch(string $sql, string $types = '', ...$params) {
    $result = db_query($sql, $types, ...$params);
    if (!$result || $result === true) return null;
    $row = $result->fetch_assoc();
    return $row ? $row : null;
}

function db_fetch_all(string $sql, string $types = '', ...$params) {
    $result = db_query($sql, $types, ...$params);
    if (!$result || $result === true) return [];
    return $result->fetch_all(MYSQLI_ASSOC);
}

function db_insert(string $sql, string $types = '', ...$params) {
    $db   = db();
    $stmt = $db->prepare($sql);
    if (!$stmt) {
        error_log('[LeadPro] db_insert prepare failed: ' . $db->error . ' | SQL: ' . $sql);
        return false;
    }
    if ($types !== '' && count($params) > 0) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    return ($stmt->affected_rows > 0) ? (int)$db->insert_id : false;
}

function generate_form_slug(string $name, int $account_id) {
    $base = strtolower(trim(preg_replace('/[^a-zA-Z0-9]+/', '-', $name), '-'));
    $slug = $base;
    $i    = 1;
    while (db_fetch('SELECT id FROM lead_forms WHERE account_id = ? AND slug = ?', 'is', $account_id, $slug)) {
        $slug = $base . '-' . $i++;
    }
    return $slug;
}

function generate_reference(int $account_id) {
    $date  = date('Ymd');
    $row   = db_fetch('SELECT COUNT(*) AS n FROM leads WHERE account_id = ? AND DATE(submitted_at) = CURDATE()', 'i', $account_id);
    $count = (int)(isset($row['n']) ? $row['n'] : 0) + 1;
    return sprintf('LD-%s-%05d', $date, $count);
}

function h($s, bool $escape = true) {
    if (!$escape) return (string)$s;
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

/**
 * Get the timezone string for the current user's account.
 * Falls back to UTC if no account or no timezone set.
 */
function get_account_tz(): string {
    static $tz = null;
    if ($tz !== null) return $tz;
    // Avoid loading auth here (circular); read account_id from session directly
    $account_id = isset($_SESSION['account_id']) ? (int)$_SESSION['account_id'] : 0;
    if ($account_id > 0) {
        $row = db_fetch('SELECT timezone FROM accounts WHERE id = ?', 'i', $account_id);
        $tz  = ($row && !empty($row['timezone'])) ? $row['timezone'] : 'UTC';
    } else {
        $tz = 'UTC'; // super admin — no account
    }
    // Validate timezone string
    try {
        new DateTimeZone($tz);
    } catch (Exception $e) {
        $tz = 'UTC';
    }
    return $tz;
}

/**
 * Format a UTC datetime string in the account's local timezone.
 *
 * @param string|null $utc_datetime  MySQL DATETIME string (UTC)
 * @param string      $format        PHP date() format, default 'd M Y, g:ia'
 * @param string|null $tz            Timezone string; if null, uses get_account_tz()
 * @return string                    Formatted datetime, or '—' if input is null/empty
 */
function format_dt(?string $utc_datetime, string $format = 'd M Y, g:ia', ?string $tz = null): string {
    if (!$utc_datetime) return '—';
    try {
        $dt = new DateTime($utc_datetime, new DateTimeZone('UTC'));
        $dt->setTimezone(new DateTimeZone($tz ?? get_account_tz()));
        return $dt->format($format);
    } catch (Exception $e) {
        return '—';
    }
}

// ============================================================
// PLATFORM SETTINGS — white-label / customisation helpers
// ============================================================

/**
 * Read a single platform setting from DB (cached for the request).
 * Usage:  ps('app_name', 'LeadPro')
 */
function ps(string $key, string $default = ''): string {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            $rows = db_fetch_all('SELECT `key`, `value` FROM platform_settings');
            foreach ($rows as $r) {
                $cache[$r['key']] = (string)$r['value'];
            }
        } catch (Exception $e) {
            // Table may not exist yet on first run — fail silently
        }
    }
    return isset($cache[$key]) && $cache[$key] !== '' ? $cache[$key] : $default;
}

/**
 * Save a platform setting (upsert).
 */
function ps_save(string $key, string $value): void {
    db_query(
        'INSERT INTO platform_settings (`key`, `value`) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE `value` = VALUES(`value`), updated_at = NOW()',
        'ss', $key, $value
    );
}

/**
 * Returns all brand CSS custom-property overrides as a <style> block.
 * Called once from layouts/header.php.
 */
function ps_theme_css(): string {
    $b1   = ps('brand_color_500', '#2563eb');
    $b2   = ps('brand_color_600', '#1d4ed8');
    $b3   = ps('brand_color_50',  '#eef5ff');
    $b4   = ps('brand_color_100', '#d9e8ff');
    $b5   = ps('brand_color_700', '#1e3fa8');
    $sbg  = ps('sidebar_bg',      '#0f172a');
    $stxt = ps('sidebar_text',    '#111111');
    $sabg = ps('sidebar_active_bg','rgba(255,255,255,0.08)');
    $fb   = ps('font_body',       'Sora');
    $fm   = ps('font_mono',       'JetBrains Mono');
    $cc   = ps('custom_css',      '');

    // Derive tints from brand_color_500 if not set
    $out  = "<style id=\"lp-theme\">\n:root {\n";
    $out .= "  --b1         : {$b1};\n";
    $out .= "  --b2         : {$b2};\n";
    $out .= "  --b3         : {$b3};\n";
    $out .= "  --b4         : {$b4};\n";
    $out .= "  --b5         : {$b5};\n";
    $out .= "  --font-body  : '{$fb}', sans-serif;\n";
    $out .= "  --font-mono  : '{$fm}', monospace;\n";
    $out .= "}\n";
    $out .= ".sidebar { background: {$sbg} !important; }\n";
    $out .= ".sidebar-item { color: {$stxt} !important; }\n";
    $out .= ".sidebar-item:hover, .sidebar-item.active { background: {$sabg} !important; color: {$stxt} !important; }\n";
    if ($cc) {
        $out .= "\n/* Custom CSS */\n" . $cc . "\n";
    }
    $out .= "</style>\n";
    return $out;
}

/**
 * Return the rendered footer copyright string.
 * Replaces {year} token.
 */
function ps_copyright(): string {
    $tpl = ps('footer_copyright', '© {year} LeadPro. All rights reserved.');
    return str_replace('{year}', date('Y'), $tpl);
}
