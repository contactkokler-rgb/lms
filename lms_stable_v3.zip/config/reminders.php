<?php
if (!defined('APP_URL')) require_once __DIR__ . '/config.php';

// ── Settings helpers ─────────────────────────────────────────
function reminder_get_settings(int $account_id): array {
    $defaults = [
        'enabled'          => 1,
        'no_contact_hrs'   => 24,   // flag new lead not contacted within N hrs
        'overdue_hrs'      => 48,   // flag lead with no activity for N hrs if status=contacted
        'inactive_days'    => 7,    // flag any non-converted lead with no activity for N days
    ];
    try {
        $raw = db_fetch('SELECT value FROM platform_settings WHERE `key`=?', 's', "reminder_cfg_{$account_id}");
        if ($raw && $raw['value']) {
            $cfg = json_decode($raw['value'], true);
            if (is_array($cfg)) return array_merge($defaults, $cfg);
        }
    } catch (\Throwable $e) {}
    return $defaults;
}

function reminder_save_settings(int $account_id, array $cfg): void {
    $json = json_encode($cfg);
    db_query('INSERT INTO platform_settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`), updated_at=NOW()',
        'ss', "reminder_cfg_{$account_id}", $json);
}

// ── Check if a reminder already exists (to avoid duplicates) ─
function _reminder_exists(int $lead_id, int $user_id, string $type): bool {
    $row = db_fetch(
        'SELECT id FROM lead_reminders WHERE lead_id=? AND user_id=? AND type=? AND is_done=0',
        'iis', $lead_id, $user_id, $type
    );
    return (bool)$row;
}

// ── Auto-generate reminders for one lead ─────────────────────
function reminder_check_lead(int $lead_id, int $account_id): array {
    $created = [];
    try {
        $cfg  = reminder_get_settings($account_id);
        if (!$cfg['enabled']) return [];

        $lead = db_fetch(
            'SELECT l.*, u.id AS owner_id FROM leads l
             LEFT JOIN users u ON u.id=l.assigned_to
             WHERE l.id=? AND l.is_deleted=0',
            'i', $lead_id
        );
        if (!$lead) return [];
        if (in_array($lead['status'], ['converted','spam','lost'])) return [];

        $now     = new DateTime('now', new DateTimeZone('UTC'));
        $submitted = new DateTime($lead['submitted_at'], new DateTimeZone('UTC'));
        $hrs_since_submit = ($now->getTimestamp() - $submitted->getTimestamp()) / 3600;

        // Get last comment/activity time
        $last_comment = db_fetch('SELECT MAX(created_at) AS t FROM lead_comments WHERE lead_id=?','i',$lead_id);
        $last_update  = db_fetch('SELECT MAX(created_at) AS t FROM audit_log WHERE target=? AND action LIKE "lead.%"','s',"lead:{$lead_id}");
        $last_activity_ts = max(
            $submitted->getTimestamp(),
            $last_comment['t'] ? strtotime($last_comment['t']) : 0,
            $last_update['t']  ? strtotime($last_update['t'])  : 0,
            $lead['last_activity_at'] ? strtotime($lead['last_activity_at']) : 0
        );
        $hrs_inactive = ($now->getTimestamp() - $last_activity_ts) / 3600;

        // Determine who to notify: assigned agent, or all managers if unassigned
        $notify_users = [];
        if ($lead['owner_id']) {
            $notify_users[] = (int)$lead['owner_id'];
        } else {
            // Notify managers when lead is unassigned
            $managers = db_fetch_all(
                'SELECT u.id FROM users u JOIN roles r ON r.id=u.role_id
                 WHERE u.account_id=? AND r.name IN ("account_owner","manager") AND u.status="active"',
                'i', $account_id
            );
            foreach ($managers as $m) $notify_users[] = (int)$m['id'];
        }

        foreach ($notify_users as $uid) {
            // 1. No-contact reminder: new lead not contacted within threshold
            if ($lead['status'] === 'new'
                && $hrs_since_submit >= $cfg['no_contact_hrs']
                && !_reminder_exists($lead_id, $uid, 'no_contact')) {

                $remind_at = date('Y-m-d H:i:s', $submitted->getTimestamp() + ($cfg['no_contact_hrs'] * 3600));
                $msg = "Lead has not been contacted for " . (int)$cfg['no_contact_hrs'] . " hours.";
                $id = db_insert(
                    'INSERT INTO lead_reminders (lead_id,account_id,user_id,created_by,type,message,remind_at) VALUES (?,?,?,?,?,?,?)',
                    'iiiisss', $lead_id, $account_id, $uid, 0, 'no_contact', $msg, $remind_at
                );
                if ($id) $created[] = ['type'=>'no_contact','id'=>$id];
            }

            // 2. Overdue: contacted lead with no follow-up
            if ($lead['status'] === 'contacted'
                && $hrs_inactive >= $cfg['overdue_hrs']
                && !_reminder_exists($lead_id, $uid, 'overdue')) {

                $msg = "Follow-up overdue — last activity " . round($hrs_inactive) . " hours ago.";
                $id = db_insert(
                    'INSERT INTO lead_reminders (lead_id,account_id,user_id,created_by,type,message,remind_at) VALUES (?,?,?,?,?,?,?)',
                    'iiiisss', $lead_id, $account_id, $uid, 0, 'overdue', $msg, date('Y-m-d H:i:s')
                );
                if ($id) $created[] = ['type'=>'overdue','id'=>$id];
            }

            // 3. Inactive: any active lead silent for N days
            if (($hrs_inactive / 24) >= $cfg['inactive_days']
                && !in_array($lead['status'], ['converted','lost','spam'])
                && !_reminder_exists($lead_id, $uid, 'inactive')) {

                $days = round($hrs_inactive / 24);
                $msg  = "Lead has been inactive for {$days} days — needs attention.";
                $id = db_insert(
                    'INSERT INTO lead_reminders (lead_id,account_id,user_id,created_by,type,message,remind_at) VALUES (?,?,?,?,?,?,?)',
                    'iiiisss', $lead_id, $account_id, $uid, 0, 'inactive', $msg, date('Y-m-d H:i:s')
                );
                if ($id) $created[] = ['type'=>'inactive','id'=>$id];
            }
        }
    } catch (\Throwable $e) {
        error_log('[LeadPro] reminder_check_lead: ' . $e->getMessage());
    }
    return $created;
}

// ── Bulk scan account (throttled via platform_settings) ──────
function reminder_process_account(int $account_id): int {
    // Only run once per 30 minutes per account
    $lock_key = "reminder_last_run_{$account_id}";
    $last_run = db_fetch('SELECT value FROM platform_settings WHERE `key`=?', 's', $lock_key);
    if ($last_run && $last_run['value']) {
        $diff = time() - strtotime($last_run['value']);
        if ($diff < 1800) return 0; // throttled
    }
    db_query('INSERT INTO platform_settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)',
        'ss', $lock_key, date('Y-m-d H:i:s'));

    $leads = db_fetch_all(
        "SELECT id FROM leads
         WHERE account_id=? AND is_deleted=0
         AND status NOT IN ('converted','spam','lost')
         ORDER BY submitted_at DESC LIMIT 500",
        'i', $account_id
    );
    $total = 0;
    foreach ($leads as $l) {
        $created = reminder_check_lead((int)$l['id'], $account_id);
        $total += count($created);
    }
    return $total;
}

// ── Get pending reminders for a user ─────────────────────────
function reminder_get_pending(int $user_id, int $account_id, int $limit = 20): array {
    try {
        return db_fetch_all(
            "SELECT r.*, l.reference_no, l.status AS lead_status,
             lv.value AS lead_name
             FROM lead_reminders r
             JOIN leads l ON l.id = r.lead_id
             LEFT JOIN lead_values lv ON lv.lead_id = r.lead_id
                 AND lv.id = (SELECT MIN(id) FROM lead_values WHERE lead_id = r.lead_id)
             WHERE r.user_id=? AND r.account_id=? AND r.is_done=0
             AND (r.snoozed_until IS NULL OR r.snoozed_until <= NOW())
             ORDER BY r.remind_at ASC LIMIT ?",
            'iii', $user_id, $account_id, $limit
        );
    } catch (\Throwable $e) {
        return [];
    }
}

// ── Create a manual reminder ──────────────────────────────────
function reminder_create_manual(int $lead_id, int $user_id, int $account_id, string $message, string $remind_at, int $created_by): int {
    $id = db_insert(
        'INSERT INTO lead_reminders (lead_id,account_id,user_id,created_by,type,message,remind_at) VALUES (?,?,?,?,?,?,?)',
        'iiiisss', $lead_id, $account_id, $user_id, $created_by, 'manual', substr($message,0,500), $remind_at
    );
    return (int)($id ?: 0);
}

// ── Mark done ─────────────────────────────────────────────────
function reminder_mark_done(int $reminder_id, int $user_id): bool {
    $ok = db_query('UPDATE lead_reminders SET is_done=1, done_at=NOW() WHERE id=? AND user_id=?', 'ii', $reminder_id, $user_id);
    return (bool)$ok;
}

// ── Snooze ───────────────────────────────────────────────────
function reminder_snooze(int $reminder_id, int $user_id, int $minutes): bool {
    $until = date('Y-m-d H:i:s', time() + $minutes * 60);
    $ok = db_query('UPDATE lead_reminders SET snoozed_until=? WHERE id=? AND user_id=?', 'sii', $until, $reminder_id, $user_id);
    return (bool)$ok;
}

// ── Type labels & colors ──────────────────────────────────────
function reminder_type_label(string $type): string {
    return ['manual'=>'Manual Reminder','no_contact'=>'Not Contacted','overdue'=>'Follow-up Overdue','inactive'=>'Inactive Lead'][$type] ?? ucfirst($type);
}
function reminder_type_color(string $type): string {
    return ['manual'=>'#6366f1','no_contact'=>'#f59e0b','overdue'=>'#ef4444','inactive'=>'#94a3b8'][$type] ?? '#94a3b8';
}
