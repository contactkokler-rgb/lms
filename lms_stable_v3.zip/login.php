<?php
require_once __DIR__ . '/config/auth.php';

// Redirect if already logged in
if (auth_user()) {
    header('Location: ' . APP_URL . '/index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { $error = 'Security token mismatch. Please try again.'; }
    else {
        $result = login(trim($_POST['email'] ?? ''), $_POST['password'] ?? '');
        if ($result['success']) {
            header('Location: ' . APP_URL . '/index.php');
            exit;
        }
        $error = $result['error'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
      $__app_name    = ps('app_name',        'LeadPro');
      $__favicon     = ps('app_favicon_url', '');
      $__hero_from   = ps('login_hero_color_from', '#1e3a8a');
      $__hero_to     = ps('login_hero_color_to',   '#7c3aed');
      $__font_body   = ps('font_body', 'Sora');
      $__font_mono   = ps('font_mono', 'JetBrains Mono');
      $__headline    = ps('login_headline', "Close more deals,\nfaster.");
      $__subtext     = ps('login_subtext',  'The all-in-one CRM for modern sales teams.');
      $__logo_url    = ps('app_logo_url',   '');
    ?>
    <title>Sign In — <?= htmlspecialchars($__app_name) ?></title>
    <?php if ($__favicon): ?>
    <link rel="icon" href="<?= htmlspecialchars($__favicon) ?>">
    <?php endif; ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=<?= urlencode($__font_body) ?>:wght@300;400;500;600;700&family=<?= urlencode($__font_mono) ?>:wght@400;500&display=swap">
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/nova.css">
    <?= ps_theme_css() ?>
    <style>
        body {
            background: linear-gradient(60deg, var(--b1-20) 100%, var(--b3-20) 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            overflow: hidden;
        }

        .login-page {
            z-index: 1;
            display: flex;
            width: 100%;
            max-width: 960px;
            min-height: 580px;
            border-radius: var(--radius-xl);
            overflow: hidden;
            box-shadow: var(--shadow-lg);            
        }

        .login-panel {
            flex: 1;
            background: #fff;
            padding: 52px 48px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .login-container {
            min-width: 340px;
        }

        .login-hero {
            width: 380px;
            flex-shrink: 0;
            background: linear-gradient(45deg, var(--b1) 100%, var(--b3) 100%);
            padding: 52px 40px;
            display: flex;
            flex-direction: column;
            position: relative;
            overflow: hidden;
        }

        .login-hero::before {
            content: '';
            position: absolute;
            top: -150px;
            right: -300px;
            width: 600px;
            height: 600px;
            background: radial-gradient(circle, <?= $__hero_to ?> 0%, transparent 70%);
        }

        .login-hero::after {
            content: '';
            position: absolute;
            bottom: -200px;
            left: -200px;
            width: 450px;
            height: 450px;
            background: radial-gradient(circle, <?= $__hero_from ?> 0%, transparent 70%);
        }

        .login-logo {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: auto;
        }

        .login-logo-mark {
            width: 36px;
            height: 36px;
            background: var(--b1-80);
            border-radius: 9px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
        }

        .login-logo-text {
            font-size: 1.2rem;
            font-weight: 700;
            color: #fff;
        }

        .login-hero-content {
            position: relative;
            z-index: 1;
        }

        .login-hero-headline {
            font-size: 1.6rem;
            font-weight: 700;
            color: #fff;
            line-height: 1.3;
            margin-bottom: 14px;
        }

        .login-hero-sub {
            font-size: .85rem;
            color: #fff;
            line-height: 1.6;
            margin-bottom: 32px;
            opacity: 0.8;
        }

        .feature-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .feature-item {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: .8rem;
            color: #fff;
            opacity: 0.8;
        }

        .feature-item-dot {
            width: 20px;
            height: 20px;
            background: rgba(255,255,255, .2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .feature-item-dot svg {
            width: 10px;
            height: 10px;
            color: var(--brand-400);
        }

        .login-form-header {
            margin-bottom: var(--space-5);
        }

        .login-form-header h1 {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--gray-900);
            margin-bottom: 6px;
        }

        .login-form-header p {
            font-size: .85rem;
            color: var(--gray-500);
        }

        .login-footer {
            margin-top: auto;
            padding-top: 24px;
            font-size: var(--text-xs);
            color: var(--text-muted);
        }

        .login-footer a {
            color: var(--brand-500);
            text-decoration: none;
        }

        @media (max-width: 768px) {
            .login-hero {
                display: none;
            }

            .login-panel {
                padding: 32px 24px;
                border-radius: var(--radius-xl);
            }
        }
    </style>
</head>

<body class="gradient-bg">

    <div class="login-page animate-in">

        <!-- Hero side -->
        <div class="login-hero">
            <div class="login-logo">
                <?php if ($__logo_url): ?>
                <img src="<?= htmlspecialchars($__logo_url) ?>" alt="<?= htmlspecialchars($__app_name) ?>" style="height:28px;max-width:130px;object-fit:contain;">
                <?php else: ?>
                <div class="login-logo-mark">
                    <i class="hgi hgi-stroke hgi-database-lightning"></i>
                </div>
                <span class="login-logo-text"><?= htmlspecialchars($__app_name) ?></span>
                <?php endif; ?>
            </div>

            <div class="login-hero-content mt-4">
                <div class="login-hero-headline">
                    <?= nl2br(htmlspecialchars($__headline)) ?>
                </div>
                <div class="login-hero-sub">
                    <?= htmlspecialchars($__subtext) ?>
                </div>
                <div class="feature-list">
                    <?php foreach ([
                      'Multi-role team management',
                      'Real-time lead capture & tracking',
                      'Smart spam filtering',
                      'Analytics & reporting',
                      'Full audit trail',
                    ] as $f): ?>
                    <div class="feature-item">
                        <div class="feature-item-dot">
                            <i class="hgi hgi-stroke hgi-tick-02"></i>
                        </div>
                        <?= $f ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Form side -->
        <div class="login-panel">
            <div class="login-container">
                <div class="login-form-header">
                    <h1>Welcome back</h1>
                    <p>Sign in to your <?= htmlspecialchars($__app_name) ?> account</p>
                </div>

                <?php if ($error): ?>
                <div class="alert alert-danger mb-4">
                    <i class="hgi hgi-stroke hgi-setting-error-04"></i>
                    <?= htmlspecialchars($error) ?>
                </div>
                <?php endif; ?>

                <form method="POST" action="login.php">
                    <input type="hidden" name="_csrf" value="<?= csrf_token() ?>">

                    <div class="form-group">
                        <label class="form-label form-label-required">Email Address</label>
                        <input type="email" name="email" class="form-control" placeholder="you@company.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required autofocus>
                    </div>

                    <div class="form-group mb-5">
                        <label class="form-label">Password</label>
                        <div class="input-wrapper has-icon-right">
                            <input type="password" name="password" id="password-input" class="form-control" placeholder="••••••••" required>
                            <div type="button" class="input-icon-right text-muted" onclick="togglePassword()" id="pw-toggle-btn">
                                <i class="hgi hgi-stroke hgi-view"></i>
                            </div>
                        </div>
                    </div>


                    <div class="flex justify-between items-center" style="margin-bottom:24px;">
                        <label class="checkbox-item toggle toggle-sm">
                            <input type="checkbox" name="remember" class="checkbox-input" checked="">
                            <div class="toggle-track">
                                <div class="toggle-thumb"></div>
                            </div>
                            <span class="checkbox-label">Keep me signed in</span>
                        </label>

                        <a href="reset-password.php" class="text-xs">
                            Forgot password?
                        </a>
                    </div>

                    <button type="submit" class="btn btn-primary btn-lg w-full mt-2">
                        Sign In
                        <i class="hgi hgi-stroke hgi-arrow-right-03"></i>
                    </button>
                </form>

                <div class="login-footer">
                    <?= ps_copyright() ?>
                    <?php
                      $__lf_raw = ps('footer_links', '');
                      $__lf = $__lf_raw ? json_decode($__lf_raw, true) : [];
                      if (is_array($__lf) && $__lf) {
                          foreach ($__lf as $__lfl) {
                              if (!empty($__lfl['label']) && !empty($__lfl['url'])) {
                                  echo ' &nbsp;·&nbsp; <a href="' . htmlspecialchars($__lfl['url']) . '">' . htmlspecialchars($__lfl['label']) . '</a>';
                              }
                          }
                      }
                    ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        function togglePassword() {
            const input = document.getElementById('password-input');
            input.type = input.type === 'password' ? 'text' : 'password';
        }
    </script>
</body>

</html>