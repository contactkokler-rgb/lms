<?php
/**
 * LeadPro — Landing Page Builder  v2.0
 * page_builder.php
 *
 * NEW in v2.0:
 *  - Inline text editing (contenteditable on canvas)
 *  - Undo / Redo (30-state stack, Ctrl+Z / Ctrl+Y)
 *  - 3 new widgets: Reviews, Appointment CTA, FAQ Accordion
 *  - Per-widget: background colour, border, top/bottom margin
 *  - Keyboard shortcuts: Del, Ctrl+D, Ctrl+S, Escape
 *  - Block lock toggle
 */
require_once __DIR__ . '/config/auth.php';
require_once __DIR__ . '/config/ai.php';
$user       = require_permission('campaigns', 'edit');
$account_id = (int)($user['account_id'] ?? 0);
$uid        = (int)$user['id'];

$page_id     = (int)($_GET['id']          ?? 0);
$campaign_id = (int)($_GET['campaign_id'] ?? 0);

if ($page_id) {
    $page = db_fetch(
        'SELECT cp.*, c.name AS campaign_name, c.id AS cid
         FROM campaign_pages cp JOIN campaigns c ON c.id=cp.campaign_id
         WHERE cp.id=? AND cp.account_id=?',
        'ii', $page_id, $account_id
    );
    if (!$page) { header('Location:'.APP_URL.'/campaigns.php'); exit; }
    $campaign_id = (int)$page['cid'];
} else {
    $campaign = db_fetch('SELECT * FROM campaigns WHERE id=? AND account_id=?','ii',$campaign_id,$account_id);
    if (!$campaign) { header('Location:'.APP_URL.'/campaigns.php'); exit; }
    $page = null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { http_response_code(403); die('CSRF'); }
    $act = $_POST['action'] ?? '';

    if ($act === 'save') {
        header('Content-Type: application/json; charset=utf-8');
        $title    = trim($_POST['title']     ?? '');
        $pd       = $_POST['page_data']      ?? '[]';
        $meta_t   = trim($_POST['meta_title'] ?? '');
        $meta_d   = trim($_POST['meta_desc']  ?? '');
        $og_image = trim($_POST['og_image']   ?? '');
        $form_id  = (int)($_POST['form_id']  ?? 0) ?: null;
        // Slug edit: only if page exists and slug is valid
        $new_slug = '';
        if ($page_id && isset($_POST['page_slug'])) {
            $raw_slug = strtolower(trim(preg_replace('/[^a-zA-Z0-9\-]+/', '-', $_POST['page_slug']), '-'));
            if ($raw_slug && $raw_slug !== $page_slug) {
                // Check unique within account
                $conflict = db_fetch('SELECT id FROM campaign_pages WHERE account_id=? AND slug=? AND id!=?', 'isi', $account_id, $raw_slug, $page_id);
                if (!$conflict) $new_slug = $raw_slug;
            }
        }
        json_decode($pd);
        if (json_last_error() !== JSON_ERROR_NONE) $pd = '[]';

        if ($page_id) {
            $slug_sql    = $new_slug ? ',slug=?' : '';
            $slug_params = $new_slug ? [$new_slug] : [];
            db_query(
                "UPDATE campaign_pages SET title=?,page_data=?,meta_title=?,meta_desc=?,og_image=?,form_id=?,updated_at=NOW(){$slug_sql} WHERE id=? AND account_id=?",
                'sssssi' . ($new_slug ? 's' : '') . 'ii',
                ...array_merge([$title, $pd, $meta_t, $meta_d, $og_image, $form_id], $slug_params, [$page_id, $account_id])
            );
            $ret_slug = $new_slug ?: ($page ? $page['slug'] : '');
            echo json_encode(['ok'=>true,'id'=>$page_id,'slug'=>$ret_slug]);
        } else {
            $base = strtolower(trim(preg_replace('/[^a-zA-Z0-9]+/','-',$title),'-')) ?: 'page';
            $slug = $base; $i = 1;
            while (db_fetch('SELECT id FROM campaign_pages WHERE account_id=? AND slug=?','is',$account_id,$slug))
                $slug = $base.'-'.(++$i);
            $new_id = db_insert(
                'INSERT INTO campaign_pages (campaign_id,account_id,title,slug,page_data,meta_title,meta_desc,form_id,status) VALUES (?,?,?,?,?,?,?,?,?)',
                'iisssssis', $campaign_id,$account_id,$title,$slug,$pd,$meta_t,$meta_d,$form_id,'draft'
            );
            // Template picker form POST: open builder directly in this tab
            if (!empty($_GET['from_template']) && $new_id) {
                header('Location: ' . APP_URL . '/page_builder.php?id=' . $new_id);
                exit;
            }
            echo json_encode(['ok'=>true,'id'=>$new_id,'slug'=>$slug]);
        }
        exit;
    }
    if ($act === 'publish' && $page_id) {
        db_query('UPDATE campaign_pages SET status="published",published_at=NOW() WHERE id=? AND account_id=?','ii',$page_id,$account_id);
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Page published!'];
        header('Location:'.APP_URL.'/page_builder.php?id='.$page_id); exit;
    }
    if ($act === 'unpublish' && $page_id) {
        db_query('UPDATE campaign_pages SET status="draft" WHERE id=? AND account_id=?','ii',$page_id,$account_id);
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Page reverted to draft.'];
        header('Location:'.APP_URL.'/page_builder.php?id='.$page_id); exit;
    }
    if ($act === 'delete' && $page_id) {
        $cid_back = (int)(db_fetch('SELECT campaign_id FROM campaign_pages WHERE id=?','i',$page_id)['campaign_id'] ?? 0);
        db_query('DELETE FROM campaign_pages WHERE id=? AND account_id=?','ii',$page_id,$account_id);
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Page deleted.'];
        header('Location:'.APP_URL.'/campaign_view.php?id='.$cid_back); exit;
    }
    exit;
}

$forms_list     = db_fetch_all("SELECT id, name FROM lead_forms WHERE account_id=? AND is_active=1 ORDER BY name",'i',$account_id);
$flash          = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$existing_data  = $page ? ($page['page_data'] ?? '[]') : '[]';
$page_status    = $page ? $page['status'] : 'draft';
$page_title_val = $page ? $page['title']  : '';
$page_form_id   = $page ? (int)($page['form_id'] ?? 0) : 0;
$page_slug      = $page ? $page['slug'] : '';
$page_title     = $page_id ? 'Edit: '.h($page_title_val) : 'New Landing Page';
$active_nav     = 'campaigns';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= $page_title ?> — Page Builder</title>
<?= ps_theme_css() ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
:root{
  --g50:#f8fafc;--g100:#f1f5f9;--g200:#e2e8f0;--g300:#cbd5e1;
  --g400:#94a3b8;--g500:#64748b;--g600:#475569;--g700:#334155;
  --g800:#1e293b;--g900:#0f172a;
  --br5:#2563eb;--br6:#1d4ed8;--br7:#1e3fa8;
  font-family:'Sora',sans-serif;
}
body{background:#f1f5f9;overflow:hidden;height:100vh;display:flex;flex-direction:column;}

/* TOPBAR */
.pb-top{height:52px;background:#fff;border-bottom:1.5px solid var(--g200);display:flex;align-items:center;gap:8px;padding:0 12px;flex-shrink:0;z-index:100;}
.pb-logo{font-size:.8rem;font-weight:800;color:var(--g800);}
.pb-sep{width:1px;height:22px;background:var(--g200);flex-shrink:0;}
.pb-title-input{border:none;outline:none;font-size:.86rem;font-weight:700;color:var(--g800);background:transparent;flex:1;min-width:100px;max-width:240px;}
.pb-title-input::placeholder{color:var(--g400);}
.pb-status{font-size:.68rem;font-weight:700;padding:3px 9px;border-radius:10px;flex-shrink:0;}
.pb-status.draft{background:#f1f5f9;color:#475569;}
.pb-status.published{background:#f0fdf4;color:#15803d;}
.pb-btn{height:30px;padding:0 11px;border-radius:7px;font-size:.73rem;font-weight:700;border:none;cursor:pointer;display:inline-flex;align-items:center;gap:4px;transition:.12s;white-space:nowrap;flex-shrink:0;}
.pb-btn.pri{background:var(--br6);color:#fff;} .pb-btn.pri:hover{background:var(--br7);}
.pb-btn.ghost{background:transparent;color:var(--g600);border:1.5px solid var(--g200);} .pb-btn.ghost:hover{background:var(--g50);color:var(--g800);}
.pb-btn.danger{background:#fef2f2;color:#dc2626;border:1.5px solid #fca5a5;} .pb-btn.danger:hover{background:#dc2626;color:#fff;}
.pb-btn:disabled{opacity:.4;cursor:not-allowed;}
.save-ind{display:flex;align-items:center;gap:4px;font-size:.7rem;font-weight:600;padding:4px 9px;border-radius:7px;flex-shrink:0;}
.save-ind.saved{background:#f0fdf4;color:#15803d;} .save-ind.saving{background:#fffbeb;color:#92400e;}
.undo-btn{height:26px;width:26px;border-radius:6px;border:1.5px solid var(--g200);background:#fff;color:var(--g600);cursor:pointer;font-size:.9rem;display:flex;align-items:center;justify-content:center;transition:.1s;flex-shrink:0;}
.undo-btn:hover:not(:disabled){background:var(--g50);color:var(--g900);} .undo-btn:disabled{opacity:.3;cursor:not-allowed;}

/* LAYOUT */
.pb-layout{display:flex;flex:1;overflow:hidden;}

/* LEFT SIDEBAR */
.pb-sidebar{width:220px;background:#fff;border-right:1.5px solid var(--g200);display:flex;flex-direction:column;overflow:hidden;flex-shrink:0;}
.pb-stabs{display:flex;border-bottom:1px solid var(--g200);}
.pb-stab{flex:1;padding:6px 2px;font-size:.6rem;font-weight:700;text-align:center;cursor:pointer;color:var(--g500);border-bottom:2px solid transparent;transition:.1s;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.pb-stab.active{color:var(--br5);border-bottom-color:var(--br5);}
.pb-sbody{flex:1;overflow-y:auto;padding:8px 6px;}
.wcat{font-size:.6rem;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:var(--g400);padding:8px 6px 4px;}
.wi{display:flex;align-items:center;gap:7px;padding:6px 9px;border-radius:7px;cursor:grab;margin-bottom:2px;border:1.5px solid var(--g100);background:#fff;font-size:.73rem;font-weight:600;color:var(--g700);user-select:none;transition:.1s;}
.wi:hover{background:var(--br5);color:#fff;border-color:var(--br5);}
.wi:hover .wi-ic{filter:brightness(10);}
.wi-ic{font-size:.9rem;flex-shrink:0;width:16px;text-align:center;}
.wi:active{cursor:grabbing;}

/* Settings panel */
.sp-f{margin-bottom:10px;}
.sp-l{font-size:.65rem;font-weight:700;color:var(--g500);margin-bottom:3px;display:block;text-transform:uppercase;letter-spacing:.04em;}
.sp-in{width:100%;padding:5px 9px;border:1.5px solid var(--g200);border-radius:6px;font-size:.76rem;color:var(--g800);outline:none;font-family:inherit;}
.sp-in:focus{border-color:var(--br5);}
.sp-sel{width:100%;padding:5px 9px;border:1.5px solid var(--g200);border-radius:6px;font-size:.76rem;color:var(--g800);outline:none;background:#fff;cursor:pointer;}
.sp-col{display:flex;gap:7px;align-items:center;}
.sp-col input[type=color]{width:32px;height:28px;padding:2px;border:1.5px solid var(--g200);border-radius:5px;cursor:pointer;flex-shrink:0;}
.sp-hint{font-size:.63rem;color:var(--g400);margin-top:2px;}
.sp-2{display:grid;grid-template-columns:1fr 1fr;gap:6px;}
.sp-div{border:none;border-top:1px solid var(--g100);margin:8px 0;}
.sp-sec{font-size:.63rem;font-weight:800;text-transform:uppercase;color:var(--g500);margin:8px 0 5px;letter-spacing:.05em;}

/* CANVAS */
.pb-canvas-wrap{flex:1;display:flex;flex-direction:column;overflow:hidden;}
.pb-devbar{display:flex;align-items:center;justify-content:center;gap:5px;padding:6px;background:var(--g100);border-bottom:1px solid var(--g200);}
.dev-btn{padding:4px 11px;border-radius:5px;border:1.5px solid transparent;font-size:.68rem;font-weight:700;cursor:pointer;background:transparent;color:var(--g500);display:flex;align-items:center;gap:3px;transition:.1s;}
.dev-btn.active{background:#fff;border-color:var(--g300);color:var(--g800);box-shadow:0 1px 3px rgba(0,0,0,.08);}
.pb-canvas-outer{flex:1;overflow-y:auto;padding:20px 20px 60px;display:flex;justify-content:flex-start;flex-direction:column;align-items:center;background:var(--g100);}
.pb-canvas{background:#fff;border-radius:8px;box-shadow:0 4px 24px rgba(0,0,0,.1);overflow:visible;transition:max-width .25s;min-height:200px;}
.pb-canvas.desktop{max-width:900px;width:100%;}
.pb-canvas.tablet{max-width:768px;width:100%;}
.pb-canvas.mobile{max-width:390px;width:100%;}

/* DROP ZONE */
.drop-zone{min-height:200px;border:2px dashed #cbd5e1;border-radius:6px;transition:.15s;position:relative;width:100%;}
.drop-zone.dz-over{border-color:var(--br5);background:rgba(37,99,235,.04);}
.dz-hint{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;font-size:.8rem;color:var(--g300);font-weight:600;pointer-events:none;}

/* BLOCKS */
.pb-block{position:relative;border:2px solid transparent;border-radius:4px;transition:border-color .1s;overflow:visible;}
.pb-block:hover:not(.locked){border-color:var(--br5);}
.pb-block.selected{border-color:var(--br6);box-shadow:0 0 0 3px rgba(37,99,235,.1);}
.pb-block.locked{border:2px dashed #f59e0b !important;}

/* Block toolbar */
.btbar{position:absolute;top:6px;right:6px;left:auto;z-index:100;display:none;align-items:center;gap:2px;background:#1e293b;border-radius:6px;padding:2px 4px;box-shadow:0 2px 8px rgba(0,0,0,.35);pointer-events:all;}
.pb-block:hover .btbar,.pb-block.selected .btbar{display:flex;}
.pb-block{position:relative;}
.btbtn{height:20px;padding:0 5px;border-radius:3px;border:none;background:transparent;color:#94a3b8;cursor:pointer;font-size:.68rem;display:flex;align-items:center;gap:2px;transition:.1s;white-space:nowrap;}
.btbtn:hover{background:rgba(255,255,255,.1);color:#fff;}
.btbtn.d:hover{background:#dc2626;color:#fff;}
.btbtn.lk{color:#f59e0b;}
.bt-sep{width:1px;height:12px;background:rgba(255,255,255,.1);margin:0 1px;}

/* RIGHT PANEL */
.pb-right{width:244px;background:#fff;border-left:1.5px solid var(--g200);overflow-y:auto;flex-shrink:0;}
.pb-right-sec{padding:13px 13px 0;}
.pb-right-title{font-size:.73rem;font-weight:800;color:var(--g700);margin-bottom:9px;text-transform:uppercase;letter-spacing:.04em;}

/* ── LP WIDGET STYLES ── */
.lp-section{padding:40px 32px;width:100%;}
.lp-headline{font-size:2.2rem;font-weight:800;line-height:1.2;margin:0;}
.lp-subheadline{font-size:1.3rem;font-weight:700;line-height:1.4;margin:0;}
.lp-paragraph{font-size:1rem;line-height:1.7;margin:0;}
.lp-section-title{font-size:1.1rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#2563eb;text-align:center;}
.lp-bullet-list{list-style:none;padding:0;}
.lp-bullet-list li{display:flex;align-items:flex-start;gap:10px;margin-bottom:10px;font-size:.95rem;color:#475569;line-height:1.5;}
.lp-bullet-list li::before{content:"✓";color:#16a34a;font-weight:800;flex-shrink:0;}
.lp-image-wrap{text-align:center;} .lp-image-wrap img{max-width:100%;}
.lp-video-wrap{position:relative;padding-bottom:56.25%;height:0;overflow:hidden;border-radius:8px;}
.lp-video-wrap iframe{position:absolute;inset:0;width:100%;height:100%;border:none;}
.lp-testimonial{background:#f8fafc;border-radius:12px;padding:20px;border-left:4px solid #2563eb;}
.lp-testimonial-text{font-size:.95rem;color:#334155;line-height:1.6;margin-bottom:10px;font-style:italic;}
.lp-testimonial-author{font-size:.82rem;font-weight:700;color:#0f172a;}
.lp-countdown{display:flex;gap:12px;justify-content:center;flex-wrap:wrap;}
.lp-cd-unit{text-align:center;min-width:64px;}
.lp-cd-n{font-size:2rem;font-weight:800;color:#0f172a;background:#f1f5f9;border-radius:10px;padding:8px 0;}
.lp-cd-l{font-size:.68rem;font-weight:700;color:#94a3b8;text-transform:uppercase;margin-top:4px;}
.lp-offer-banner{background:linear-gradient(135deg,#2563eb,#7c3aed);color:#fff;padding:20px 32px;border-radius:12px;text-align:center;}
.lp-offer-banner h3{font-size:1.3rem;font-weight:800;margin-bottom:6px;}
.lp-offer-banner p{font-size:.9rem;opacity:.9;}
.lp-pricing{background:#fff;border:2px solid #e2e8f0;border-radius:16px;padding:28px;text-align:center;max-width:320px;margin:0 auto;}
.lp-pricing h3{font-size:1.1rem;font-weight:700;color:#0f172a;margin-bottom:8px;}
.lp-pricing .lp-price{font-size:2.5rem;font-weight:900;color:#2563eb;}
.lp-pricing .lp-price sub{font-size:1rem;font-weight:600;}
.lp-trust-badges{display:flex;flex-wrap:wrap;gap:10px;justify-content:center;}
.lp-badge{display:inline-flex;align-items:center;gap:5px;padding:5px 13px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:99px;font-size:.76rem;font-weight:600;color:#475569;}
.lp-logo-gallery{display:flex;flex-wrap:wrap;gap:20px;justify-content:center;align-items:center;padding:20px 0;opacity:.7;}
.lp-logo-gallery span{font-size:1.4rem;font-weight:900;color:#94a3b8;letter-spacing:-.02em;}
.lp-divider{border:none;border-top:1px solid #e2e8f0;margin:8px 0;}
.lp-form-wrapper{background:#f8fafc;border-radius:14px;padding:24px;max-width:480px;margin:0 auto;}
.lp-form-title{font-size:1.2rem;font-weight:800;color:#0f172a;text-align:center;margin-bottom:16px;}
.lp-cta-btn{display:inline-block;background:#2563eb;color:#fff;padding:13px 28px;border-radius:10px;font-size:1rem;font-weight:700;border:none;cursor:pointer;text-decoration:none;transition:.15s;}
.lp-cta-btn:hover{opacity:.88;}
/* Reviews */
.lp-reviews-grid{display:flex;flex-wrap:wrap;gap:14px;justify-content:center;}
.lp-rv-card{background:#fff;border:1.5px solid #e2e8f0;border-radius:12px;padding:18px;max-width:280px;flex:1;min-width:200px;}
.lp-rv-stars{color:#f59e0b;font-size:1rem;margin-bottom:6px;}
.lp-rv-text{font-size:.85rem;color:#475569;line-height:1.6;margin-bottom:10px;font-style:italic;}
.lp-rv-author{font-size:.78rem;font-weight:700;color:#1e293b;}
/* Appointment */
.lp-appointment{text-align:center;padding:8px 0;}
.lp-apt-lbl{font-size:.82rem;color:#64748b;margin-bottom:10px;}
.lp-apt-btn{display:inline-flex;align-items:center;gap:8px;background:#0f172a;color:#fff;padding:13px 28px;border-radius:10px;font-size:.95rem;font-weight:700;border:none;cursor:pointer;text-decoration:none;transition:.15s;}
.lp-apt-btn:hover{opacity:.88;}
/* FAQ */
.lp-faq{max-width:640px;margin:0 auto;}
.lp-faq-item{border-bottom:1px solid #e2e8f0;}
.lp-faq-q{display:flex;justify-content:space-between;align-items:center;padding:14px 4px;cursor:pointer;font-size:.92rem;font-weight:600;color:#1e293b;gap:12px;user-select:none;}
.lp-faq-arrow{font-size:.78rem;color:#94a3b8;transition:transform .2s;flex-shrink:0;}
.lp-faq-item.open .lp-faq-arrow{transform:rotate(180deg);}
.lp-faq-a{font-size:.88rem;color:#475569;line-height:1.7;padding:0 4px 14px;display:none;}
.lp-faq-item.open .lp-faq-a{display:block;}
/* Inline edit */
[contenteditable="true"]{outline:2px dashed var(--br5);outline-offset:2px;border-radius:3px;cursor:text;}
[contenteditable="true"]:focus{outline-color:var(--br6);background:rgba(37,99,235,.025);}
/* ── NEW v3 WIDGET STYLES ── */
/* Hero Section */
.lp-hero{position:relative;min-height:480px;display:flex;align-items:center;background:#1e293b;overflow:hidden;}
.lp-hero-bg{position:absolute;inset:0;background-size:cover;background-position:center;background-repeat:no-repeat;}
.lp-hero-overlay{position:absolute;inset:0;}
.lp-hero-inner{position:relative;z-index:2;width:100%;padding:60px 40px;}
.lp-hero-grid{display:grid;grid-template-columns:1fr 1fr;gap:40px;align-items:center;max-width:1100px;margin:0 auto;}
.lp-hero-grid.full{grid-template-columns:1fr;text-align:center;}
.lp-hero h1{font-size:2.8rem;font-weight:900;line-height:1.1;margin:0 0 16px;color:#fff;}
.lp-hero p{font-size:1.1rem;opacity:.85;color:#fff;margin:0 0 24px;line-height:1.6;}
.lp-hero-form{background:rgba(255,255,255,.95);border-radius:16px;padding:28px;box-shadow:0 20px 60px rgba(0,0,0,.3);}
/* Two-col split */
.lp-two-col{display:grid;align-items:center;gap:48px;}
.lp-two-col.img-left{grid-template-columns:1fr 1fr;}
.lp-two-col.img-right{grid-template-columns:1fr 1fr;}
.lp-two-col .lp-tc-img img{width:100%;border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,.1);}
.lp-two-col .lp-tc-text h2{font-size:1.9rem;font-weight:800;color:#0f172a;line-height:1.2;margin:0 0 16px;}
.lp-two-col .lp-tc-text p{font-size:.95rem;color:#475569;line-height:1.7;margin:0 0 20px;}
/* Feature grid */
.lp-feature-grid{display:grid;gap:24px;}
.lp-feature-grid.cols-2{grid-template-columns:repeat(2,1fr);}
.lp-feature-grid.cols-3{grid-template-columns:repeat(3,1fr);}
.lp-feature-grid.cols-4{grid-template-columns:repeat(4,1fr);}
.lp-feat-card{padding:28px 24px;border-radius:14px;background:#fff;border:1.5px solid #e2e8f0;transition:.15s;}
.lp-feat-card:hover{box-shadow:0 8px 24px rgba(0,0,0,.08);transform:translateY(-2px);}
.lp-feat-icon{font-size:1.8rem;margin-bottom:14px;display:block;}
.lp-feat-card h3{font-size:1rem;font-weight:700;color:#0f172a;margin:0 0 8px;}
.lp-feat-card p{font-size:.85rem;color:#64748b;line-height:1.6;margin:0;}
/* Stats row */
.lp-stats{display:flex;flex-wrap:wrap;justify-content:center;gap:0;}
.lp-stat-item{flex:1;min-width:140px;text-align:center;padding:32px 20px;border-right:1px solid #e2e8f0;}
.lp-stat-item:last-child{border-right:none;}
.lp-stat-num{font-size:2.4rem;font-weight:900;color:#0f172a;line-height:1;}
.lp-stat-label{font-size:.8rem;color:#94a3b8;margin-top:6px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;}
/* Progress bars */
.lp-progress-item{margin-bottom:18px;}
.lp-progress-label{display:flex;justify-content:space-between;font-size:.85rem;font-weight:600;color:#334155;margin-bottom:6px;}
.lp-progress-track{height:8px;background:#f1f5f9;border-radius:4px;overflow:hidden;}
.lp-progress-bar{height:100%;border-radius:4px;transition:width 1s ease;}
/* Contact info */
.lp-contact-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;}
.lp-contact-item{display:flex;align-items:flex-start;gap:14px;padding:18px;background:#f8fafc;border-radius:12px;border:1px solid #e2e8f0;}
.lp-contact-icon{font-size:1.4rem;flex-shrink:0;margin-top:2px;}
.lp-contact-item strong{display:block;font-size:.82rem;font-weight:700;color:#0f172a;margin-bottom:3px;}
.lp-contact-item span{font-size:.78rem;color:#64748b;line-height:1.5;}
/* Social links */
.lp-social{display:flex;gap:10px;flex-wrap:wrap;}
.lp-social a{display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:10px;font-size:1.1rem;text-decoration:none;transition:.15s;}
.lp-social a:hover{transform:translateY(-2px);}
/* Announcement bar */
.lp-announce{padding:10px 20px;text-align:center;font-size:.82rem;font-weight:600;}
/* Nav bar */
.lp-nav{display:flex;align-items:center;justify-content:space-between;padding:16px 40px;background:#fff;border-bottom:1px solid #e2e8f0;}
.lp-nav-brand{font-size:1.1rem;font-weight:900;color:#0f172a;text-decoration:none;}
.lp-nav-links{display:flex;align-items:center;gap:24px;}
.lp-nav-links a{font-size:.85rem;color:#475569;text-decoration:none;font-weight:500;}
.lp-nav-links a:hover{color:#2563eb;}
.lp-nav-cta{padding:8px 20px;background:#2563eb;color:#fff;border-radius:8px;font-size:.82rem;font-weight:700;text-decoration:none;}
/* Footer */
.lp-footer{background:#0f172a;color:#94a3b8;padding:48px 40px 24px;}
.lp-footer-grid{display:grid;grid-template-columns:1.5fr repeat(3,1fr);gap:40px;margin-bottom:40px;}
.lp-footer-brand{font-size:1.1rem;font-weight:900;color:#fff;margin-bottom:12px;}
.lp-footer-desc{font-size:.82rem;line-height:1.7;}
.lp-footer-col h4{font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#64748b;margin-bottom:14px;}
.lp-footer-col a{display:block;font-size:.82rem;color:#94a3b8;text-decoration:none;margin-bottom:8px;}
.lp-footer-col a:hover{color:#fff;}
.lp-footer-bottom{border-top:1px solid #1e293b;padding-top:20px;font-size:.75rem;text-align:center;}
/* ── NEW WIDGET CSS v3.1 ── */
/* Image Slider */
.lp-slider{position:relative;overflow:hidden;border-radius:12px;}
.lp-slider-track{display:flex;transition:transform .4s ease;}
.lp-slider-track img{flex-shrink:0;width:100%;height:100%;object-fit:cover;}
.lp-slider-btn{position:absolute;top:50%;transform:translateY(-50%);background:rgba(0,0,0,.5);color:#fff;border:none;width:36px;height:36px;border-radius:50%;cursor:pointer;font-size:1.1rem;z-index:2;transition:.15s;}
.lp-slider-btn:hover{background:rgba(0,0,0,.75);}
.lp-slider-btn.prev{left:10px;}
.lp-slider-btn.next{right:10px;}
.lp-slider-dots{text-align:center;margin-top:10px;display:flex;gap:6px;justify-content:center;}
.lp-slider-dot{width:8px;height:8px;border-radius:50%;background:#cbd5e1;cursor:pointer;transition:.15s;border:none;}
.lp-slider-dot.active{background:#2563eb;}
/* Card Carousel */
.lp-carousel{overflow:hidden;position:relative;}
.lp-carousel-track{display:flex;gap:20px;transition:transform .35s ease;}
.lp-carousel-card{flex-shrink:0;background:#fff;border-radius:14px;border:1.5px solid #e2e8f0;padding:24px;box-shadow:0 2px 12px rgba(0,0,0,.06);}
.lp-carousel-nav{display:flex;justify-content:center;gap:10px;margin-top:16px;}
.lp-carousel-nav button{padding:8px 16px;border-radius:8px;border:1.5px solid #e2e8f0;background:#fff;cursor:pointer;font-size:.8rem;font-weight:600;}
/* Timeline */
.lp-timeline{position:relative;padding-left:28px;}
.lp-timeline::before{content:'';position:absolute;left:9px;top:0;bottom:0;width:2px;background:#e2e8f0;}
.lp-tl-item{position:relative;margin-bottom:28px;}
.lp-tl-dot{position:absolute;left:-24px;top:4px;width:12px;height:12px;border-radius:50%;background:#2563eb;border:2px solid #fff;box-shadow:0 0 0 2px #2563eb;}
.lp-tl-date{font-size:.72rem;font-weight:700;color:#94a3b8;margin-bottom:4px;text-transform:uppercase;letter-spacing:.05em;}
.lp-tl-title{font-size:.95rem;font-weight:700;color:#0f172a;margin-bottom:4px;}
.lp-tl-desc{font-size:.85rem;color:#475569;line-height:1.6;}
/* Icon widget */
.lp-icon-wrap{display:flex;align-items:center;justify-content:center;}
/* Badge widget */
.lp-badge-el{display:inline-flex;align-items:center;gap:6px;font-weight:700;border-radius:999px;}
/* Newsletter bar */
.lp-newsletter{display:flex;flex-wrap:wrap;gap:10px;align-items:center;}
.lp-newsletter input{flex:1;min-width:220px;padding:12px 16px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:.9rem;font-family:inherit;outline:none;}
.lp-newsletter input:focus{border-color:#2563eb;}
.lp-newsletter button{padding:12px 24px;border:none;border-radius:8px;font-weight:700;font-size:.88rem;cursor:pointer;white-space:nowrap;}
/* BG Video */
.lp-bgvideo{position:relative;overflow:hidden;min-height:400px;display:flex;align-items:center;}
.lp-bgvideo video{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:0;}
.lp-bgvideo-overlay{position:absolute;inset:0;z-index:1;}
.lp-bgvideo-content{position:relative;z-index:2;width:100%;padding:60px 40px;text-align:center;}
/* Scroll animations */
.lp-animate{opacity:0;transform:translateY(30px);transition:opacity .6s ease,transform .6s ease;}
.lp-animate.animated{opacity:1;transform:none;}
.lp-animate-left{opacity:0;transform:translateX(-40px);transition:opacity .6s ease,transform .6s ease;}
.lp-animate-left.animated{opacity:1;transform:none;}
.lp-animate-scale{opacity:0;transform:scale(.9);transition:opacity .5s ease,transform .5s ease;}
.lp-animate-scale.animated{opacity:1;transform:none;}
/* AI Buttons */
.ai-btn{display:inline-flex;align-items:center;gap:4px;padding:3px 9px;border-radius:6px;border:1.5px solid #a78bfa;background:#f5f3ff;color:#6d28d9;font-size:.65rem;font-weight:700;cursor:pointer;transition:.1s;white-space:nowrap;margin-top:4px;}
.ai-btn:hover{background:#ede9fe;border-color:#7c3aed;}
.ai-btn:disabled{opacity:.45;cursor:not-allowed;}
.ai-btn.loading{background:#ede9fe;color:#7c3aed;}
.ai-opts{margin-top:6px;display:flex;flex-direction:column;gap:4px;}
.ai-opt{padding:6px 9px;border-radius:6px;border:1.5px solid #e2e8f0;background:#fff;font-size:.73rem;color:#334155;cursor:pointer;text-align:left;transition:.1s;line-height:1.4;}
.ai-opt:hover{border-color:#7c3aed;background:#f5f3ff;color:#4c1d95;}
.ai-spinner{display:inline-block;width:10px;height:10px;border:2px solid #a78bfa;border-top-color:#6d28d9;border-radius:50%;animation:aispin .6s linear infinite;}
@keyframes aispin{to{transform:rotate(360deg);}}
</style>
</head>
<body>

<!-- TOPBAR -->
<div class="pb-top">
  <div class="pb-logo">⚡ LeadPro</div>
  <div class="pb-sep"></div>
  <input type="text" class="pb-title-input" id="pageTitle" placeholder="Untitled Page" value="<?= h($page_title_val) ?>">
  <div class="pb-sep"></div>
  <span class="pb-status <?= $page_status ?>" id="pageStatusBadge"><?= ucfirst($page_status) ?></span>
  <div style="flex:1;min-width:0;"></div>
  <button class="undo-btn" id="undoBtn" onclick="doUndo()" title="Undo (Ctrl+Z)" disabled>↩</button>
  <button class="undo-btn" id="redoBtn" onclick="doRedo()" title="Redo (Ctrl+Y)" disabled>↪</button>
  <div class="pb-sep"></div>
  <span class="save-ind saved" id="saveInd">
    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 6L9 17l-5-5"/></svg> Saved
  </span>
  <button class="pb-btn ghost" onclick="togglePreview()" id="previewBtn">👁 Preview</button>
  <?php if ($page_status === 'published'): ?>
    <a href="<?= APP_URL ?>/lp/<?= h($page_slug) ?>" target="_blank" class="pb-btn ghost">↗ View</a>
    <?php if (can('campaigns','edit')): ?>
    <form method="post" style="display:inline;">
      <?= csrf_field() ?><input type="hidden" name="action" value="unpublish">
      <button type="submit" class="pb-btn ghost">Unpublish</button>
    </form>
    <?php endif; ?>
  <?php else: ?>
    <?php if (can('campaigns','edit')): ?>
    <form method="post" style="display:inline;">
      <?= csrf_field() ?><input type="hidden" name="action" value="publish">
      <button type="submit" class="pb-btn pri" onclick="return confirm('Save and publish this page?')">🚀 Publish</button>
    </form>
    <?php endif; ?>
  <?php endif; ?>
  <button class="pb-btn ghost" onclick="openSaveTemplate()" title="Save page as reusable template">📐 Template</button>
  <button class="pb-btn ghost" id="saveBtn" onclick="savePage()">💾 Save</button>
  <?php if (!$page_id): ?>
    <button class="pb-btn pri" onclick="savePage(true)">Save &amp; Continue →</button>
  <?php endif; ?>
  <?php if ($page_id): ?>
  <div class="pb-sep"></div>
  <form method="post" style="display:inline;">
    <?= csrf_field() ?><input type="hidden" name="action" value="delete">
    <button type="submit" class="pb-btn danger" onclick="return confirm('Delete this page?')">🗑</button>
  </form>
  <?php endif; ?>
  <a href="<?= APP_URL ?>/campaign_view.php?id=<?= $campaign_id ?>" class="pb-btn ghost">← Campaign</a>
</div>

<?php if ($flash): ?>
<div style="background:<?= $flash['type']==='success'?'#f0fdf4':'#fef2f2' ?>;color:<?= $flash['type']==='success'?'#15803d':'#991b1b' ?>;padding:7px 20px;font-size:.76rem;font-weight:600;text-align:center;"><?= h($flash['msg']) ?></div>
<?php endif; ?>

<div class="pb-layout">

<!-- LEFT SIDEBAR -->
<div class="pb-sidebar">
  <div class="pb-stabs">
    <div class="pb-stab active" onclick="switchTab('widgets',this)">Widgets</div>
    <div class="pb-stab" onclick="switchTab('templates',this)">Templates</div>
    <div class="pb-stab" onclick="switchTab('media',this)">Media</div>
    <div class="pb-stab" onclick="switchTab('saved',this)">Saved</div>
    <div class="pb-stab" onclick="switchTab('settings',this)">Settings</div>
  </div>
  <div class="pb-sbody" id="tabWidgets">
    <div class="wcat">Layout &amp; Sections</div>
    <?php foreach ([
      ['hero_section','🦸','Hero Section'],
      ['two_col','⬛','Image + Text'],
      ['feature_grid','⊞','Feature Grid'],
      ['stats_row','📊','Stats Row'],
      ['nav_bar','☰','Navigation Bar'],
      ['footer_block','⬇','Footer'],
    ] as [$t,$ic,$lb]): ?>
    <div class="wi" draggable="true" data-widget="<?= $t ?>"><span class="wi-ic"><?= $ic ?></span><?= $lb ?></div>
    <?php endforeach; ?>
    <div class="wcat">Text</div>
    <?php foreach ([
      ['headline','📢','Headline'],['subheadline','🔤','Sub-headline'],
      ['paragraph','¶','Paragraph'],['section_title','🏷','Section Title'],
      ['bullet_list','☑','Bullet List'],['divider','─','Divider'],['spacer','↕','Spacer'],
    ] as [$t,$ic,$lb]): ?>
    <div class="wi" draggable="true" data-widget="<?= $t ?>"><span class="wi-ic"><?= $ic ?></span><?= $lb ?></div>
    <?php endforeach; ?>
    <div class="wcat">Media</div>
    <?php foreach ([['image','🖼','Image'],['video','▶','Video'],['logo_gallery','🏢','Logo Gallery']] as [$t,$ic,$lb]): ?>
    <div class="wi" draggable="true" data-widget="<?= $t ?>"><span class="wi-ic"><?= $ic ?></span><?= $lb ?></div>
    <?php endforeach; ?>
    <div class="wcat">Conversion</div>
    <?php foreach ([['lead_form','📋','Lead Form'],['cta_button','🚀','CTA Button'],['appointment','📅','Appointment CTA']] as [$t,$ic,$lb]): ?>
    <div class="wi" draggable="true" data-widget="<?= $t ?>"><span class="wi-ic"><?= $ic ?></span><?= $lb ?></div>
    <?php endforeach; ?>
    <div class="wcat">Trust &amp; Social</div>
    <?php foreach ([['testimonial','💬','Testimonial'],['reviews','⭐','Reviews'],['trust_badges','🛡','Trust Badges'],['social_links','🔗','Social Links']] as [$t,$ic,$lb]): ?>
    <div class="wi" draggable="true" data-widget="<?= $t ?>"><span class="wi-ic"><?= $ic ?></span><?= $lb ?></div>
    <?php endforeach; ?>
    <div class="wcat">Marketing</div>
    <?php foreach ([
      ['countdown','⏱','Countdown Timer'],['offer_banner','🎁','Offer Banner'],
      ['pricing','💰','Pricing Table'],['faq','❓','FAQ Accordion'],
      ['progress_bars','📶','Progress Bars'],['contact_info','📍','Contact Info'],
      ['announcement_bar','📣','Announcement Bar'],
    ] as [$t,$ic,$lb]): ?>
    <div class="wi" draggable="true" data-widget="<?= $t ?>"><span class="wi-ic"><?= $ic ?></span><?= $lb ?></div>
    <?php endforeach; ?>
    <div class="wcat">Interactive</div>
    <?php foreach ([
      ['map_embed','🗺','Map Embed'],
      ['image_gallery','🖼','Image Gallery'],
      ['image_slider','🎠','Image Slider'],
      ['tabs_widget','🗂','Tabs'],
      ['counter_widget','🔢','Animated Counter'],
      ['timeline_widget','📅','Timeline'],
      ['carousel_widget','🎡','Card Carousel'],
    ] as [$t,$ic,$lb]): ?>
    <div class="wi" draggable="true" data-widget="<?= $t ?>"><span class="wi-ic"><?= $ic ?></span><?= $lb ?></div>
    <?php endforeach; ?>
    <div class="wcat">Basic Elements</div>
    <?php foreach ([
      ['icon_widget','✨','Icon'],
      ['badge_widget','🏷','Badge'],
      ['newsletter_bar','📧','Newsletter Bar'],
      ['bg_video','🎬','Background Video'],
      ['raw_html','<>','Raw HTML'],
    ] as [$t,$ic,$lb]): ?>
    <div class="wi" draggable="true" data-widget="<?= $t ?>"><span class="wi-ic"><?= $ic ?></span><?= $lb ?></div>
    <?php endforeach; ?>
  </div>
  <!-- Templates tab (inside builder) -->
  <div class="pb-sbody" id="tabTemplates" style="display:none;">
    <div style="padding:4px 0 8px;font-size:.7rem;color:var(--g500);">Click a template to load it onto the canvas. <strong>This will replace current blocks.</strong></div>
    <div style="display:flex;gap:4px;margin-bottom:8px;flex-wrap:wrap;" id="builderTplCats">
      <button class="btn btn-secondary btn-sm" style="font-size:.65rem;padding:3px 8px;" onclick="builderFilterTpl('all',this)">All</button>
    </div>
    <div id="builderTplGrid" style="display:flex;flex-direction:column;gap:6px;"></div>
    <div id="builderTplLoading" style="text-align:center;padding:20px;font-size:.72rem;color:var(--g400);">Loading templates…</div>
  </div>

  <!-- Saved Components tab -->
  <div class="pb-sbody" id="tabSaved" style="display:none;">
    <div style="padding:4px 0 8px;font-size:.7rem;color:var(--g500);">Save any selected block as a reusable component. Click to insert.</div>
    <div id="savedComponentsList" style="display:flex;flex-direction:column;gap:6px;">
      <div style="text-align:center;padding:20px;color:var(--g400);font-size:.72rem;">
        Select a block → click 💾 Save Component in its toolbar.
      </div>
    </div>
  </div>

  <!-- Media Library tab -->
  <div class="pb-sbody" id="tabMedia" style="display:none;">
    <!-- Upload button -->
    <div style="padding:8px 2px 6px;">
      <label style="display:block;border:2px dashed var(--g200);border-radius:8px;padding:10px;text-align:center;cursor:pointer;font-size:.72rem;font-weight:700;color:var(--br5);transition:.1s;"
             onmouseover="this.style.borderColor='var(--br5)'" onmouseout="this.style.borderColor='var(--g200)'">
        ⬆ Upload Image
        <input type="file" accept="image/*" style="display:none;" onchange="uploadMediaFile(this)">
      </label>
    </div>
    <!-- Stock image search -->
    <div style="display:flex;gap:4px;padding:4px 0 8px;">
      <input type="text" id="stockSearchQ" class="sp-in" placeholder="Search stock photos…" style="flex:1;" onkeydown="if(event.key==='Enter')searchStock()">
      <button onclick="searchStock()" style="padding:5px 9px;border-radius:6px;border:1.5px solid var(--g200);background:#fff;cursor:pointer;font-size:.78rem;color:var(--br5);font-weight:700;">Go</button>
    </div>
    <!-- Image grid -->
    <div id="mediaGrid" style="display:grid;grid-template-columns:1fr 1fr;gap:5px;"></div>
    <div id="mediaLoading" style="display:none;text-align:center;padding:20px;font-size:.72rem;color:var(--g400);">Loading…</div>
    <div id="mediaHint" style="text-align:center;padding:20px;font-size:.72rem;color:var(--g400);line-height:1.6;">
      Upload images or search free stock photos.<br>Click an image to insert into selected block.
    </div>
  </div>
  <div class="pb-sbody" id="tabSettings" style="display:none;">
    <div class="sp-f"><label class="sp-l">Page Background</label>
      <div class="sp-col">
        <input type="color" id="pageBgColor" value="#ffffff" oninput="applyPageBg(this.value)">
        <input type="text" class="sp-in" id="pageBgText" value="#ffffff" style="flex:1;" oninput="document.getElementById('pageBgColor').value=this.value;applyPageBg(this.value);">
      </div>
    </div>
    <div class="sp-f"><label class="sp-l">Attached Form</label>
      <select class="sp-sel" id="pageFormId">
        <option value="0">— No form —</option>
        <?php foreach ($forms_list as $f): ?><option value="<?= $f['id'] ?>" <?= $page_form_id===$f['id']?'selected':'' ?>><?= h($f['name']) ?></option><?php endforeach; ?>
      </select>
      <div class="sp-hint">Used by Lead Form widget</div>
      <a href="<?= APP_URL ?>/form_builder.php?return_to=page_builder&campaign_id=<?= $campaign_id ?>"
         style="display:inline-flex;align-items:center;gap:4px;margin-top:6px;font-size:.68rem;font-weight:700;color:var(--br5);text-decoration:none;">
        + Create new form →
      </a>
    </div>
    <hr class="sp-div">
    <div class="sp-f"><label class="sp-l">Meta Title</label><input type="text" class="sp-in" id="metaTitle" placeholder="SEO title" value="<?= h($page ? $page['meta_title'] : '') ?>"></div>
    <div class="sp-f"><label class="sp-l">Meta Description</label><textarea class="sp-in" id="metaDesc" rows="3" style="resize:vertical;" placeholder="SEO description"><?= h($page ? $page['meta_desc'] : '') ?></textarea></div>
    <div class="sp-f"><label class="sp-l">OG Image URL</label>
      <input type="text" class="sp-in" id="ogImage" placeholder="https://… (social share image)" value="<?= h($page['og_image'] ?? '') ?>"
             oninput="updateSharePreview()">
      <div class="sp-hint">Shown when shared on Facebook, LinkedIn, etc.</div>
    </div>
    <!-- Social Share Preview -->
    <div class="sp-sec">Social Share Preview</div>
    <div id="sharePreview" style="border:1.5px solid var(--g200);border-radius:8px;overflow:hidden;font-family:Arial,sans-serif;">
      <div id="spImg" style="height:90px;background:#e2e8f0;background-size:cover;background-position:center;"></div>
      <div style="padding:8px 10px;background:#fff;">
        <div id="spTitle" style="font-size:.74rem;font-weight:700;color:#1a1a1a;margin-bottom:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= h($page ? ($page['meta_title']?:$page['title']) : 'Page Title') ?></div>
        <div id="spDesc" style="font-size:.67rem;color:#606060;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;"><?= h($page ? $page['meta_desc'] : '') ?></div>
        <div style="font-size:.62rem;color:#909090;margin-top:3px;"><?= strtolower(parse_url(APP_URL, PHP_URL_HOST) ?: APP_URL) ?></div>
      </div>
    </div>
    <?php if ($page_id && $page_slug): ?>
    <div class="sp-f"><label class="sp-l">Page Slug (URL)</label>
      <div style="display:flex;gap:5px;align-items:center;">
        <span style="font-size:.62rem;color:var(--g500);white-space:nowrap;">/lp/</span>
        <input type="text" class="sp-in" id="pageSlugEdit" value="<?= h($page_slug) ?>" style="flex:1;"
               oninput="this.value=this.value.toLowerCase().replace(/[^a-z0-9\-]/g,'-').replace(/-+/g,'-')">
      </div>
      <div class="sp-hint">Change the page URL. Must be unique.</div>
      <a href="<?= APP_URL ?>/lp/<?= h($page_slug) ?>" target="_blank" style="font-size:.66rem;color:var(--br5);text-decoration:none;">
        <?= h(APP_URL.'/lp/'.$page_slug) ?> ↗
      </a>
    </div>
    <?php endif; ?>
    <hr class="sp-div">
    <div class="sp-sec" style="font-size:.63rem;font-weight:800;text-transform:uppercase;color:var(--g500);margin:4px 0 8px;letter-spacing:.05em;">Global Styles</div>
    <div class="sp-f"><label class="sp-l">Brand Colour</label>
      <div class="sp-col">
        <input type="color" id="globalBrandColor" value="#2563eb" oninput="applyGlobalBrand(this.value)">
        <input type="text" class="sp-in" id="globalBrandColorText" value="#2563eb" style="flex:1;"
               oninput="document.getElementById('globalBrandColor').value=this.value;applyGlobalBrand(this.value);">
      </div>
      <div class="sp-hint">Applied to buttons, links, and accents across all blocks.</div>
    </div>
    <div class="sp-f"><label class="sp-l">Font Family</label>
      <select class="sp-sel" id="globalFont" onchange="applyGlobalFont(this.value)">
        <option value="Sora">Sora (default)</option>
        <option value="Inter">Inter</option>
        <option value="Poppins">Poppins</option>
        <option value="DM Sans">DM Sans</option>
        <option value="Nunito">Nunito</option>
        <option value="Raleway">Raleway</option>
        <option value="Lato">Lato</option>
        <option value="Open Sans">Open Sans</option>
        <option value="Roboto">Roboto</option>
        <option value="Montserrat">Montserrat</option>
        <option value="Georgia">Georgia (serif)</option>
        <option value="Playfair Display">Playfair Display (editorial)</option>
      </select>
      <div class="sp-hint">Changes the font across the entire page.</div>
    </div>
    <hr class="sp-div">
    <div class="sp-hint" style="line-height:1.9;"><b>Ctrl+Z</b> Undo &nbsp; <b>Ctrl+Y</b> Redo<br><b>Ctrl+S</b> Save &nbsp; <b>Ctrl+D</b> Duplicate<br><b>Ctrl+C</b> Copy &nbsp; <b>Ctrl+V</b> Paste<br><b>Del</b> Delete &nbsp; <b>Esc</b> Deselect</div>
  </div>
</div>

<!-- CANVAS -->
<div class="pb-canvas-wrap">
  <div class="pb-devbar">
    <button class="dev-btn active" onclick="setDevice('desktop',this)">🖥 Desktop</button>
    <button class="dev-btn" onclick="setDevice('tablet',this)">📱 Tablet</button>
    <button class="dev-btn" onclick="setDevice('mobile',this)">📲 Mobile</button>
  </div>
  <div class="pb-canvas-outer" id="canvasOuter">
    <div class="pb-canvas desktop" id="pbCanvas">
      <div class="drop-zone" id="rootDZ" data-zone="root">
        <div class="dz-hint" id="dzHint" style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:300px;gap:12px;color:var(--g400);font-size:.82rem;text-align:center;padding:40px;">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" opacity=".4"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M9 12h6M12 9v6"/></svg>
          <div style="font-weight:600;color:var(--g500);">Drag a widget here</div>
          <div style="font-size:.72rem;">or click a widget in the left panel</div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- RIGHT PANEL -->
<div class="pb-right" id="pbRight">
  <div class="pb-right-sec">
    <div class="pb-right-title">Block Settings</div>
    <div id="bsBody" style="color:var(--g400);font-size:.76rem;padding:6px 0;">Select a block to edit its settings.</div>
  </div>
</div>

</div><!-- /pb-layout -->
<input type="hidden" id="csrfToken" value="<?= csrf_token() ?>">
<input type="hidden" id="pageId" value="<?= $page_id ?>">
<input type="hidden" id="campaignId" value="<?= $campaign_id ?>">

<script>
/* ── State ── */
let blocks = [], selectedId = null, dragWidget = null, dragBlockId = null;
let dirty = false, saveTimer = null, currentPageId = <?= $page_id ?: 0 ?>, previewMode = false;
let undoStack = [], redoStack = [];
const MAX_UNDO = 30;

/* ── Undo / Redo ── */
function pushUndo() {
  undoStack.push(JSON.stringify(blocks));
  if (undoStack.length > MAX_UNDO) undoStack.shift();
  redoStack = [];
  updUR();
}
function doUndo() {
  if (!undoStack.length) return;
  redoStack.push(JSON.stringify(blocks));
  blocks = JSON.parse(undoStack.pop());
  selectedId = null; render(); updUR(); markDirty(false);
}
function doRedo() {
  if (!redoStack.length) return;
  undoStack.push(JSON.stringify(blocks));
  blocks = JSON.parse(redoStack.pop());
  selectedId = null; render(); updUR(); markDirty(false);
}
function updUR() {
  document.getElementById('undoBtn').disabled = !undoStack.length;
  document.getElementById('redoBtn').disabled = !redoStack.length;
}

/* ── Init ── */
(function(){
  try { blocks = JSON.parse(<?= json_encode($existing_data) ?>) || []; } catch(e) { blocks = []; }
  render();
})();

function uid() { return Date.now().toString(36)+Math.random().toString(36).slice(2,6); }

/* ── Default block data ── */
function defaultBlock(type) {
  const D = {
    headline:     {text:'Your Powerful Headline Here',align:'center',size:'2.2rem',color:'#0f172a',bold:true},
    subheadline:  {text:'Supporting headline that explains your value',align:'center',size:'1.3rem',color:'#1e293b',bold:true},
    paragraph:    {text:'Write your paragraph text here. Explain your offer clearly to visitors.',align:'left',size:'1rem',color:'#475569'},
    section_title:{text:'SECTION TITLE',align:'center',size:'1.1rem',color:'#2563eb'},
    bullet_list:  {items:['Key benefit one','Key benefit two','Key benefit three'],color:'#475569'},
    divider:      {color:'#e2e8f0'},
    spacer:       {height:'40'},
    image:        {src:'',alt:'Image',width:'100',imgRadius:'0'},
    video:        {url:'https://www.youtube.com/embed/dQw4w9WgXcQ'},
    logo_gallery: {logos:['Brand A','Brand B','Brand C','Brand D']},
    lead_form:    {title:'Get Started Today',submitText:'Submit',successMsg:"Thank you! We'll be in touch.",bg:'#f8fafc'},
    cta_button:   {text:'Get Started Now',url:'#',align:'center',bg:'#2563eb',color:'#ffffff',size:'1rem',radius:'10',fullWidth:false},
    appointment:  {label:'Ready to talk?',btnText:'📅 Book a Free Call',url:'https://calendly.com/',bg:'#0f172a',color:'#ffffff',radius:'10'},
    testimonial:  {quote:'This product completely changed how we work. Absolutely love it!',author:'Jane Smith',role:'CEO, Acme Corp',color:'#2563eb'},
    reviews:      {title:'What our customers say',items:[
      {stars:5,text:'Amazing product, saved us so much time!',name:'Sarah K.'},
      {stars:5,text:'Highly recommend to any growing business.',name:'Mark T.'},
      {stars:4,text:'Great support and excellent features.',name:'Linda R.'},
    ]},
    trust_badges: {badges:['SSL Secured','Money-back Guarantee','5-Star Rated','GDPR Compliant']},
    countdown:    {targetDate:new Date(Date.now()+7*86400000).toISOString().slice(0,10),label:'Offer ends in:'},
    offer_banner: {headline:'Limited Time Offer',text:'Get 50% off when you sign up today!',bg1:'#2563eb',bg2:'#7c3aed'},
    pricing:      {name:'Pro Plan',price:'49',period:'month',features:['Unlimited leads','Priority support','Advanced analytics'],btnText:'Get Started',btnBg:'#2563eb'},
    faq:          {title:'Frequently Asked Questions',items:[
      {q:'How does it work?',a:'Simply sign up, connect your domain, and start capturing leads immediately.'},
      {q:'Is there a free trial?',a:'Yes! 14-day free trial with full access. No credit card required.'},
      {q:'Can I cancel anytime?',a:'Absolutely. No long-term contracts. Cancel with one click.'},
    ]},
    // ── v3 NEW WIDGETS ──
    hero_section: {
      headline:'Your Powerful Headline Goes Here',
      subheadline:'A compelling subheadline that explains your value proposition in one sentence.',
      bgImage:'',bgColor:'#1e293b',overlayColor:'rgba(0,0,0,0.45)',
      layout:'split', // 'split' | 'full'
      btnText:'Get Started Free',btnUrl:'#',btnBg:'#2563eb',
      showForm:false,
    },
    two_col: {
      imgUrl:'',imgAlt:'',imgPosition:'left', // 'left' | 'right'
      headline:'Compelling Section Headline',
      body:'Write your section description here. Explain the key benefit clearly and concisely to engage your visitors.',
      btnText:'Learn More',btnUrl:'#',btnBg:'#2563eb',showBtn:true,
    },
    feature_grid: {
      headline:'Why Choose Us',
      subheadline:'Everything you need to grow your business.',
      cols:3,
      bgColor:'#ffffff',
      items:[
        {icon:'🎯',title:'Effective Targeting',desc:'Reach exactly the right audience with precision tools.'},
        {icon:'⚡',title:'Lightning Fast',desc:'Optimised for speed so your pages load instantly.'},
        {icon:'🛡',title:'Secure & Reliable',desc:'Enterprise-grade security keeping your data safe.'},
        {icon:'📊',title:'Analytics',desc:'Detailed insights to track performance and growth.'},
        {icon:'🤝',title:'Great Support',desc:'Our team is available to help you every step of the way.'},
        {icon:'♾',title:'Unlimited Scale',desc:'Grow without limits — our platform scales with you.'},
      ],
    },
    stats_row: {
      bgColor:'#ffffff',
      items:[
        {number:'10,000+',label:'Happy Customers'},
        {number:'98%',label:'Satisfaction Rate'},
        {number:'150+',label:'Countries'},
        {number:'24/7',label:'Support'},
      ],
    },
    progress_bars: {
      headline:'Our Expertise',
      items:[
        {label:'Business Consulting',value:74,color:'#2563eb'},
        {label:'Digital Marketing',value:88,color:'#8b5cf6'},
        {label:'Brand Strategy',value:65,color:'#16a34a'},
      ],
    },
    contact_info: {
      headline:'Get In Touch',
      items:[
        {icon:'📍',label:'Location',value:'123 Business Street, New York, NY 10001'},
        {icon:'📞',label:'Phone',value:'+1 (555) 123-4567'},
        {icon:'⏰',label:'Working Hours',value:'Mon–Fri: 9:00am – 6:00pm'},
        {icon:'✉️',label:'Email',value:'hello@company.com'},
      ],
    },
    social_links: {
      label:'Follow Us',
      items:[
        {icon:'f',label:'Facebook',url:'https://facebook.com/',bg:'#1877f2',color:'#fff'},
        {icon:'in',label:'LinkedIn',url:'https://linkedin.com/',bg:'#0a66c2',color:'#fff'},
        {icon:'tw',label:'Twitter',url:'https://twitter.com/',bg:'#1da1f2',color:'#fff'},
        {icon:'ig',label:'Instagram',url:'https://instagram.com/',bg:'#e1306c',color:'#fff'},
        {icon:'yt',label:'YouTube',url:'https://youtube.com/',bg:'#ff0000',color:'#fff'},
      ],
    },
    announcement_bar: {
      text:'🚀 New: We just launched our Pro plan. Get 30% off this week only!',
      bgColor:'#2563eb',textColor:'#ffffff',linkText:'Learn More',linkUrl:'#',
    },
    nav_bar: {
      brand:'YourBrand',brandUrl:'#',
      links:[
        {label:'Home',url:'#'},
        {label:'Features',url:'#'},
        {label:'Pricing',url:'#'},
        {label:'Contact',url:'#'},
      ],
      ctaText:'Get Started',ctaUrl:'#',ctaBg:'#2563eb',
      bgColor:'#ffffff',textColor:'#475569',
    },
    // ── New v3.1 widgets ──
    icon_widget:     {icon:'⭐', size:'3rem', color:'#2563eb', align:'center'},
    badge_widget:    {text:'New Feature', bg:'#eff6ff', color:'#2563eb', size:'.82rem', radius:'999px', px:'14', py:'5'},
    newsletter_bar:  {headline:'Stay in the Loop', subheadline:'Get the latest updates delivered to your inbox.',
                      placeholder:'Enter your email', btnText:'Subscribe', btnBg:'#2563eb', btnColor:'#fff', bgColor:'#f8fafc'},
    bg_video:        {videoUrl:'https://www.w3schools.com/html/mov_bbb.mp4', overlayColor:'rgba(0,0,0,0.5)',
                      headline:'Powerful Headline', subheadline:'Supporting text goes here.', btnText:'Get Started', btnUrl:'#', btnBg:'#fff', btnColor:'#0f172a', minHeight:500},
    image_slider:    {images:['https://picsum.photos/seed/s1/1200/500','https://picsum.photos/seed/s2/1200/500','https://picsum.photos/seed/s3/1200/500'], height:420, radius:12, autoplay:true},
    carousel_widget: {headline:'What Our Customers Say', cols:3, items:[
                      {icon:'💬',title:'Amazing Results','desc':'Doubled our conversion rate in the first month. Absolutely worth every penny.','name':'Sarah M.','role':'CMO, TechStart'},
                      {icon:'⭐',title:'Game Changer','desc':'The easiest tool we\'ve ever used. Our team was up and running in hours.','name':'James K.','role':'CEO, GrowthHQ'},
                      {icon:'🚀',title:'Highly Recommend','desc':'Best investment we made this year. The ROI has been phenomenal.','name':'Lisa T.','role':'Founder, ScaleUp'},
                     ]},
    timeline_widget: {headline:'Our Journey', items:[
                      {date:'2021', title:'Founded', desc:'Started with a vision to simplify lead generation for every business.'},
                      {date:'2022', title:'First 1,000 Customers', desc:'Reached our first milestone and expanded to 20+ countries.'},
                      {date:'2023', title:'Series A Funding', desc:'Raised $5M to accelerate growth and product development.'},
                      {date:'2024', title:'10,000+ Customers', desc:'Trusted by businesses in 50+ countries worldwide.'},
                     ], dotColor:'#2563eb'},
    // ── Interactive widgets ──
    map_embed:      {embedUrl:'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2483.4!2d-0.1!3d51.5!', height:400, label:'Find Us'},
    image_gallery:  {images:['https://picsum.photos/seed/1/800/600','https://picsum.photos/seed/2/800/600','https://picsum.photos/seed/3/800/600','https://picsum.photos/seed/4/800/600'], cols:2, gap:8, radius:8},
    tabs_widget:    {tabs:[{label:'Features',content:'List your key features here. Explain what makes your product or service unique and valuable.'},{label:'Benefits',content:'Describe the outcomes and benefits your customers will experience after using your product.'},{label:'How It Works',content:'Explain the simple steps to get started. Make it easy for visitors to understand the process.'}]},
    counter_widget: {items:[{number:10000,suffix:'+',label:'Happy Customers'},{number:98,suffix:'%',label:'Satisfaction'},{number:150,suffix:'',label:'Countries'},{number:24,suffix:'/7',label:'Support'}], color:'#2563eb', animateDuration:2000},
    footer_block: {
      brand:'YourBrand',
      description:'A trusted company formed to help your business grow and succeed online.',
      bgColor:'#0f172a',textColor:'#94a3b8',
      columns:[
        {title:'Solutions',links:[{label:'Features',url:'#'},{label:'Pricing',url:'#'},{label:'Templates',url:'#'}]},
        {title:'Support',links:[{label:'Help Center',url:'#'},{label:'Contact Us',url:'#'},{label:'FAQ',url:'#'}]},
        {title:'Company',links:[{label:'About Us',url:'#'},{label:'Blog',url:'#'},{label:'Careers',url:'#'}]},
      ],
      copyright:'© 2024 YourBrand. All rights reserved.',
    },
  };
  return Object.assign({id:uid(),type,padding:'20',blockBg:'',marginTop:'0',marginBottom:'0',borderWidth:'0',borderColor:'#e2e8f0',borderRadius:'0',locked:false}, D[type]||{});
}

/* ══ RENDER ══ */
function render() {
  const zone = document.getElementById('rootDZ');
  const hint = document.getElementById('dzHint');
  zone.querySelectorAll('.pb-block').forEach(e=>e.remove());
  hint.style.display = blocks.length ? 'none' : 'flex';
  blocks.forEach((b,idx)=>{
    const el = document.createElement('div');
    el.className = 'pb-block'+(selectedId===b.id?' selected':'')+(b.locked?' locked':'');
    el.dataset.id = b.id; el.dataset.idx = idx;
    applyBlockStyle(el, b);
    try {
      el.innerHTML = btbar(b.id,idx)+renderWidget(b);
    } catch(err) {
      el.innerHTML = btbar(b.id,idx)+`<div style="padding:16px;background:#fef2f2;color:#991b1b;font-size:.78rem;border:1px solid #fca5a5;border-radius:6px;margin:8px;">⚠ Render error (${b.type}): ${err.message}</div>`;
      console.error('renderWidget error for '+b.type+':', err);
    }
    el.addEventListener('click', e=>{
      if (e.target.closest('.btbar')) return;
      if (e.target.getAttribute('contenteditable')) return;
      e.stopPropagation();
      if (!b.locked) selectBlock(b.id);
    });
    zone.insertBefore(el, hint);
  });
  setupDragOnBlocks();
  initCountdowns();
  if (selectedId) renderBS(blocks.find(b=>b.id===selectedId));
}

function applyBlockStyle(el, b) {
  el.style.marginTop    = (b.marginTop||'0')+'px';
  el.style.marginBottom = (b.marginBottom||'0')+'px';
  // Gradient overrides solid bg
  if (b.gradFrom && b.gradTo) {
    el.style.background = `linear-gradient(${b.gradDir||'135deg'}, ${b.gradFrom}, ${b.gradTo})`;
  } else {
    el.style.background = b.blockBg || '';
  }
  // Border
  if (b.borderWidth && parseInt(b.borderWidth) > 0) {
    el.style.border       = `${b.borderWidth}px solid ${b.borderColor||'#e2e8f0'}`;
    el.style.borderRadius = (b.borderRadius||'0')+'px';
  } else { el.style.border = ''; el.style.borderRadius = ''; }
  // Box shadow
  const shadowMap = {'none':'none','sm':'0 1px 3px rgba(0,0,0,.1)','md':'0 4px 16px rgba(0,0,0,.12)','lg':'0 8px 32px rgba(0,0,0,.16)','xl':'0 20px 60px rgba(0,0,0,.2)'};
  el.style.boxShadow = shadowMap[b.boxShadow||'none'] || 'none';
  // Hide-on-device flags
  el.classList.toggle('pb-hide-mobile',  !!b.hideOnMobile);
  el.classList.toggle('pb-hide-tablet',  !!b.hideOnTablet);
  el.classList.toggle('pb-hide-desktop', !!b.hideOnDesktop);
}

/* ── Block toolbar ── */
function btbar(id, idx) {
  const b = blocks.find(x=>x.id===id);
  const lk = b&&b.locked;
  return `<div class="btbar">
    <span class="btbtn" style="cursor:grab;color:#475569;" title="Drag">⠿</span>
    <button class="btbtn" onclick="moveBlock('${id}',-1)" title="Up">↑</button>
    <button class="btbtn" onclick="moveBlock('${id}',1)" title="Down">↓</button>
    <span class="bt-sep"></span>
    <button class="btbtn" onclick="dupBlock('${id}')" title="Duplicate (Ctrl+D)">⧉</button>
    <button class="btbtn" onclick="saveComponent('${id}')" title="Save as Component">💾</button>
    <button class="btbtn ${lk?'lk':''}" onclick="toggleLock('${id}')" title="${lk?'Unlock':'Lock'}">🔒</button>
    <span class="bt-sep"></span>
    <button class="btbtn d" onclick="delBlock('${id}')" title="Delete block (Del)" style="color:#ef4444;" >🗑</button>
  </div>`;
}

/* ══ WIDGET RENDERERS ══ */
function rw(b) {
  const p = b.padding||'20';
  const wrap = h => `<div class="lp-section" style="padding:${p}px 32px;">${h}</div>`;
  const inline = (tag,cls,style,content,key) => {
    if (b.locked) return `<${tag} class="${cls}" style="${style}">${esc(content)}</${tag}>`;
    return `<${tag} class="${cls}" style="${style}" contenteditable="true"
      onblur="updateBlock('${b.id}','${key}',this.innerText)"
      onkeydown="if(event.key==='Enter'&&this.tagName!=='P'){event.preventDefault();this.blur();}"
      onclick="event.stopPropagation()">${esc(content)}</${tag}>`;
  };

  switch(b.type) {
    case 'headline':
      return wrap(inline('h1','lp-headline',`font-size:${b.size||'2.2rem'};color:${b.color||'#0f172a'};text-align:${b.align||'center'};font-weight:${b.bold?'800':'500'};`,b.text,'text'));
    case 'subheadline':
      return wrap(inline('h2','lp-subheadline',`font-size:${b.size||'1.3rem'};color:${b.color||'#1e293b'};text-align:${b.align||'center'};font-weight:${b.bold?'700':'500'};`,b.text,'text'));
    case 'paragraph':
      return wrap(inline('p','lp-paragraph',`font-size:${b.size||'1rem'};color:${b.color||'#475569'};text-align:${b.align||'left'};`,b.text,'text'));
    case 'section_title':
      return wrap(inline('div','lp-section-title',`color:${b.color||'#2563eb'};font-size:${b.size||'1.1rem'};text-align:${b.align||'center'};`,b.text,'text'));
    case 'bullet_list':
      return wrap(`<ul class="lp-bullet-list" style="color:${b.color||'#475569'};">${(b.items||[]).map(i=>`<li>${esc(i)}</li>`).join('')}</ul>`);
    case 'divider':
      return `<div style="padding:${p}px 32px;"><hr class="lp-divider" style="border-color:${b.color||'#e2e8f0'};"></div>`;
    case 'spacer':
      return `<div style="height:${b.height||40}px;"></div>`;
    case 'image':
      return wrap(b.src
        ? `<div class="lp-image-wrap"><img src="${esc(b.src)}" alt="${esc(b.alt)}" style="width:${b.width||100}%;border-radius:${b.imgRadius||0}px;"></div>`
        : `<div style="background:#f1f5f9;border:2px dashed #cbd5e1;border-radius:8px;padding:40px;text-align:center;color:#94a3b8;font-size:.82rem;">🖼 Enter image URL in settings</div>`);
    case 'video':
      return wrap(`<div class="lp-video-wrap"><iframe src="${esc(b.url)}" allowfullscreen></iframe></div>`);
    case 'logo_gallery':
      return wrap(`<div class="lp-logo-gallery">${(b.logos||[]).map(l=>`<span>${esc(l)}</span>`).join('')}</div>`);
    case 'lead_form':
      return wrap(`<div class="lp-form-wrapper" style="background:${b.bg||'#f8fafc'};">
        <div class="lp-form-title">${esc(b.title||'Get Started')}</div>
        <div style="text-align:center;padding:12px;background:#e0e7ff;border-radius:8px;font-size:.78rem;color:#3730a3;">📋 Form renders here when published.</div>
        <div style="text-align:center;margin-top:14px;"><button class="lp-cta-btn" style="background:#2563eb;">${esc(b.submitText||'Submit')}</button></div>
      </div>`);
    case 'cta_button':
      return wrap(`<div style="text-align:${b.align||'center'};">
        <a href="${esc(b.url||'#')}" class="lp-cta-btn"
           style="background:${b.bg||'#2563eb'};color:${b.color||'#fff'};font-size:${b.size||'1rem'};border-radius:${b.radius||10}px;${b.fullWidth?'display:block;width:100%;':''}">
          ${esc(b.text||'Get Started Now')}</a></div>`);
    case 'appointment':
      return wrap(`<div class="lp-appointment">
        ${b.label?`<div class="lp-apt-lbl">${esc(b.label)}</div>`:''}
        <a href="${esc(b.url||'#')}" class="lp-apt-btn"
           style="background:${b.bg||'#0f172a'};color:${b.color||'#fff'};border-radius:${b.radius||10}px;" target="_blank">
          ${esc(b.btnText||'📅 Book a Free Call')}</a></div>`);
    case 'testimonial':
      return wrap(`<div class="lp-testimonial" style="border-left-color:${b.color||'#2563eb'};">
        <div class="lp-testimonial-text">"${esc(b.quote)}"</div>
        <div class="lp-testimonial-author">${esc(b.author)} <span style="font-weight:400;color:#64748b;">— ${esc(b.role)}</span></div>
      </div>`);
    case 'reviews':
      const rvs = (b.items||[]).map(r=>{
        const filled = Math.min(5,Math.max(1,parseInt(r.stars)||5));
        const stars = '★'.repeat(filled)+'☆'.repeat(5-filled);
        return `<div class="lp-rv-card"><div class="lp-rv-stars">${stars}</div><div class="lp-rv-text">"${esc(r.text)}"</div><div class="lp-rv-author">— ${esc(r.name)}</div></div>`;
      }).join('');
      return wrap(`${b.title?`<div style="text-align:center;font-size:1.1rem;font-weight:800;color:#0f172a;margin-bottom:20px;">${esc(b.title)}</div>`:''}
        <div class="lp-reviews-grid">${rvs}</div>`);
    case 'trust_badges':
      return wrap(`<div class="lp-trust-badges">${(b.badges||[]).map(bg=>`<span class="lp-badge">✓ ${esc(bg)}</span>`).join('')}</div>`);
    case 'countdown':
      return wrap(`<div>
        <div style="text-align:center;font-size:.84rem;font-weight:600;color:#64748b;margin-bottom:12px;">${esc(b.label||'Offer ends in:')}</div>
        <div class="lp-countdown" id="cd_${b.id}">
          <div class="lp-cd-unit"><div class="lp-cd-n" id="cd_${b.id}_d">--</div><div class="lp-cd-l">Days</div></div>
          <div class="lp-cd-unit"><div class="lp-cd-n" id="cd_${b.id}_h">--</div><div class="lp-cd-l">Hours</div></div>
          <div class="lp-cd-unit"><div class="lp-cd-n" id="cd_${b.id}_m">--</div><div class="lp-cd-l">Mins</div></div>
          <div class="lp-cd-unit"><div class="lp-cd-n" id="cd_${b.id}_s">--</div><div class="lp-cd-l">Secs</div></div>
        </div></div>`);
    case 'offer_banner':
      return wrap(`<div class="lp-offer-banner" style="background:linear-gradient(135deg,${b.bg1||'#2563eb'},${b.bg2||'#7c3aed'});"><h3>${esc(b.headline)}</h3><p>${esc(b.text)}</p></div>`);
    case 'pricing':
      const pfeats = (b.features||[]).map(f=>`<li style="padding:6px 0;border-bottom:1px solid #f1f5f9;font-size:.84rem;color:#475569;">✓ ${esc(f)}</li>`).join('');
      return wrap(`<div class="lp-pricing"><h3>${esc(b.name)}</h3>
        <div class="lp-price">$${esc(b.price)}<sub>/${esc(b.period)}</sub></div>
        <ul style="list-style:none;text-align:left;margin:16px 0;">${pfeats}</ul>
        <button class="lp-cta-btn" style="background:${b.btnBg||'#2563eb'};width:100%;">${esc(b.btnText||'Get Started')}</button></div>`);
    case 'faq':
      const fqitems = (b.items||[]).map((item,i)=>`
        <div class="lp-faq-item" id="fq_${b.id}_${i}">
          <div class="lp-faq-q" onclick="toggleFAQ('fq_${b.id}_${i}')">
            <span>${esc(item.q)}</span><span class="lp-faq-arrow">▼</span></div>
          <div class="lp-faq-a">${esc(item.a)}</div>
        </div>`).join('');
      return wrap(`${b.title?`<div style="text-align:center;font-size:1.1rem;font-weight:800;color:#0f172a;margin-bottom:20px;">${esc(b.title)}</div>`:''}
        <div class="lp-faq">${fqitems}</div>`);
    // ── v3 NEW WIDGET RENDERERS ──
    case 'hero_section': {
      const bgStyle = b.bgImage
        ? `background-image:url('${esc(b.bgImage)}');background-size:cover;background-position:center;`
        : `background:${b.bgColor||'#1e293b'};`;
      const overlay = b.overlayColor ? `<div class="lp-hero-overlay" style="background:${b.overlayColor};"></div>` : '';
      const isFull  = b.layout === 'full';
      const content = `
        <div class="lp-hero-inner">
          <div class="lp-hero-grid ${isFull?'full':''}">
            <div>
              <h1 style="font-size:${b.headlineSize||'2.8rem'};">${esc(b.headline)}</h1>
              <p>${esc(b.subheadline)}</p>
              <a href="${esc(b.btnUrl||'#')}" class="lp-cta-btn" style="background:${b.btnBg||'#2563eb'};">${esc(b.btnText||'Get Started')}</a>
            </div>
            ${!isFull&&b.showForm?`<div class="lp-hero-form">
              <div class="lp-form-title" style="color:#0f172a;">${esc(b.formTitle||'Get Started Today')}</div>
              <div style="text-align:center;padding:10px;background:#e0e7ff;border-radius:8px;font-size:.78rem;color:#3730a3;">📋 Form renders when published.</div>
            </div>`:''}
          </div>
        </div>`;
      return `<div class="lp-hero pb-block-inner" style="${bgStyle}min-height:${b.minHeight||480}px;">${overlay}${content}</div>`;
    }

    case 'two_col': {
      const imgHtml = b.imgUrl
        ? `<img src="${esc(b.imgUrl)}" alt="${esc(b.imgAlt||'')}" style="width:100%;border-radius:${b.imgRadius||12}px;box-shadow:0 8px 32px rgba(0,0,0,.1);">`
        : `<div style="background:#f1f5f9;border:2px dashed #cbd5e1;border-radius:12px;height:280px;display:flex;align-items:center;justify-content:center;color:#94a3b8;font-size:.85rem;">🖼 Image</div>`;
      const textHtml = `
        <div>
          ${b.eyebrow?`<div style="font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:${b.eyebrowColor||'#2563eb'};margin-bottom:10px;">${esc(b.eyebrow)}</div>`:''}
          <h2 style="font-size:${b.headlineSize||'1.9rem'};font-weight:800;color:${b.headlineColor||'#0f172a'};line-height:1.2;margin:0 0 16px;">${esc(b.headline)}</h2>
          <p style="font-size:.95rem;color:${b.bodyColor||'#475569'};line-height:1.7;margin:0 0 20px;">${esc(b.body)}</p>
          ${b.bullets&&b.bullets.length?`<ul style="list-style:none;padding:0;margin:0 0 20px;">${b.bullets.map(x=>`<li style="display:flex;gap:8px;margin-bottom:8px;font-size:.88rem;color:${b.bodyColor||'#475569'};"><span style="color:#16a34a;font-weight:800;">✓</span>${esc(x)}</li>`).join('')}</ul>`:''}
          ${b.showBtn?`<a href="${esc(b.btnUrl||'#')}" class="lp-cta-btn" style="background:${b.btnBg||'#2563eb'};color:${b.btnColor||'#fff'};">${esc(b.btnText||'Learn More')}</a>`:''}
        </div>`;
      const left  = b.imgPosition==='right' ? textHtml : `<div class="lp-tc-img">${imgHtml}</div>`;
      const right = b.imgPosition==='right' ? `<div class="lp-tc-img">${imgHtml}</div>` : textHtml;
      return `<div class="lp-section" style="padding:${b.padding||60}px 40px;background:${b.blockBg||'#fff'};">
        <div class="lp-two-col" style="max-width:1100px;margin:0 auto;grid-template-columns:1fr 1fr;display:grid;align-items:center;gap:${b.gap||48}px;">
          ${left}${right}
        </div></div>`;
    }

    case 'feature_grid': {
      const cols = b.cols || 3;
      const cards = (b.items||[]).map(it=>`
        <div class="lp-feat-card" style="background:${b.cardBg||'#fff'};border-color:${b.cardBorder||'#e2e8f0'};">
          <span class="lp-feat-icon">${esc(it.icon||'⭐')}</span>
          <h3>${esc(it.title)}</h3>
          <p>${esc(it.desc)}</p>
        </div>`).join('');
      return `<div class="lp-section" style="padding:${b.padding||60}px 40px;background:${b.bgColor||'#fff'};">
        ${b.headline?`<div style="text-align:center;margin-bottom:${b.subheadline?8:36}px;"><h2 style="font-size:1.8rem;font-weight:800;color:#0f172a;">${esc(b.headline)}</h2></div>`:''}
        ${b.subheadline?`<div style="text-align:center;margin-bottom:36px;"><p style="font-size:1rem;color:#64748b;max-width:520px;margin:0 auto;">${esc(b.subheadline)}</p></div>`:''}
        <div class="lp-feature-grid cols-${cols}" style="max-width:1100px;margin:0 auto;">${cards}</div>
      </div>`;
    }

    case 'stats_row': {
      const items = (b.items||[]).map(it=>`
        <div class="lp-stat-item">
          <div class="lp-stat-num" style="color:${b.numColor||'#0f172a'};">${esc(it.number)}</div>
          <div class="lp-stat-label">${esc(it.label)}</div>
        </div>`).join('');
      return `<div style="padding:${b.padding||20}px 0;background:${b.bgColor||'#fff'};">
        <div class="lp-stats" style="max-width:1100px;margin:0 auto;">${items}</div>
      </div>`;
    }

    case 'progress_bars': {
      const bars = (b.items||[]).map(it=>`
        <div class="lp-progress-item">
          <div class="lp-progress-label"><span>${esc(it.label)}</span><span style="color:${it.color||'#2563eb'};">${it.value}%</span></div>
          <div class="lp-progress-track"><div class="lp-progress-bar" style="width:${it.value}%;background:${it.color||'#2563eb'};"></div></div>
        </div>`).join('');
      return `<div class="lp-section" style="padding:${b.padding||40}px 40px;background:${b.blockBg||'#fff'};">
        ${b.headline?`<h2 style="font-size:1.4rem;font-weight:800;color:#0f172a;margin-bottom:24px;">${esc(b.headline)}</h2>`:''}
        <div style="max-width:640px;">${bars}</div>
      </div>`;
    }

    case 'contact_info': {
      const items = (b.items||[]).map(it=>`
        <div class="lp-contact-item">
          <span class="lp-contact-icon">${esc(it.icon||'📍')}</span>
          <div><strong>${esc(it.label)}</strong><span>${esc(it.value)}</span></div>
        </div>`).join('');
      return `<div class="lp-section" style="padding:${b.padding||40}px 40px;background:${b.blockBg||'#fff'};">
        ${b.headline?`<h2 style="font-size:1.5rem;font-weight:800;color:#0f172a;margin-bottom:24px;">${esc(b.headline)}</h2>`:''}
        <div class="lp-contact-grid">${items}</div>
      </div>`;
    }

    case 'social_links': {
      const links = (b.items||[]).map(it=>`
        <a href="${esc(it.url||'#')}" target="_blank" style="background:${it.bg||'#2563eb'};color:${it.color||'#fff'};" title="${esc(it.label||'')}">
          ${esc(it.icon||'●')}
        </a>`).join('');
      return `<div class="lp-section" style="padding:${b.padding||20}px 32px;background:${b.blockBg||'#fff'};">
        ${b.label?`<div style="font-size:.8rem;font-weight:700;color:#94a3b8;margin-bottom:12px;text-transform:uppercase;letter-spacing:.05em;">${esc(b.label)}</div>`:''}
        <div class="lp-social">${links}</div>
      </div>`;
    }

    case 'announcement_bar': {
      return `<div class="lp-announce" style="background:${b.bgColor||'#2563eb'};color:${b.textColor||'#fff'};">
        ${esc(b.text||'')}
        ${b.linkText?` <a href="${esc(b.linkUrl||'#')}" style="color:${b.textColor||'#fff'};font-weight:700;text-decoration:underline;margin-left:8px;">${esc(b.linkText)}</a>`:''}
      </div>`;
    }

    case 'nav_bar': {
      const links = (b.links||[]).map(l=>`<a href="${esc(l.url||'#')}" style="color:${b.textColor||'#475569'};">${esc(l.label)}</a>`).join('');
      return `<div class="lp-nav" style="background:${b.bgColor||'#fff'};border-bottom-color:${b.borderColor||'#e2e8f0'};">
        <a href="${esc(b.brandUrl||'#')}" class="lp-nav-brand" style="color:${b.brandColor||'#0f172a'};">${esc(b.brand||'YourBrand')}</a>
        <div class="lp-nav-links">${links}
          ${b.ctaText?`<a href="${esc(b.ctaUrl||'#')}" class="lp-nav-cta" style="background:${b.ctaBg||'#2563eb'};">${esc(b.ctaText)}</a>`:''}
        </div>
      </div>`;
    }

    case 'footer_block': {
      const cols = (b.columns||[]).map(col=>`
        <div>
          <h4>${esc(col.title||'')}</h4>
          ${(col.links||[]).map(l=>`<a href="${esc(l.url||'#')}">${esc(l.label)}</a>`).join('')}
        </div>`).join('');
      return `<div class="lp-footer" style="background:${b.bgColor||'#0f172a'};color:${b.textColor||'#94a3b8'};">
        <div class="lp-footer-grid">
          <div>
            <div class="lp-footer-brand" style="color:${b.brandColor||'#fff'};">${esc(b.brand||'YourBrand')}</div>
            <div class="lp-footer-desc">${esc(b.description||'')}</div>
          </div>
          <div style="display:contents;" class="lp-footer-col">${cols}</div>
        </div>
        <div class="lp-footer-bottom">${esc(b.copyright||'')}</div>
      </div>`;
    }

    // ── v3.1 NEW WIDGET RENDERERS ──
    case 'raw_html':
      return `<div class="pb-block-inner" style="padding:${b.padding||0}px;background:${b.blockBg||'transparent'};">
        <div style="border:2px dashed #e2e8f0;border-radius:8px;padding:16px;background:#f8fafc;">
          <div style="font-size:.7rem;font-weight:700;color:#94a3b8;margin-bottom:8px;text-transform:uppercase;">RAW HTML BLOCK</div>
          <pre style="font-size:.68rem;color:#475569;overflow:auto;max-height:120px;white-space:pre-wrap;">${esc((b.html||'').slice(0,200))}${(b.html||'').length>200?'…':''}</pre>
        </div>
      </div>`;

    case 'icon_widget':
      return `<div class="lp-icon-wrap pb-block-inner" style="justify-content:${b.align||'center'};padding:${b.padding||20}px;background:${b.blockBg||'transparent'};">
        <span style="font-size:${b.size||'3rem'};color:${b.color||'#2563eb'};">${esc(b.icon||'⭐')}</span>
      </div>`;

    case 'badge_widget':
      return `<div style="text-align:${b.align||'left'};padding:${b.padding||10}px;background:${b.blockBg||'transparent'};">
        <span class="lp-badge-el" style="background:${b.bg||'#eff6ff'};color:${b.color||'#2563eb'};font-size:${b.size||'.82rem'};padding:${b.py||5}px ${b.px||14}px;border-radius:${b.radius||'999px'};">${esc(b.text||'Badge')}</span>
      </div>`;

    case 'newsletter_bar':
      return `<div style="padding:${b.padding||40}px 40px;background:${b.bgColor||'#f8fafc'};">
        ${b.headline?`<div style="font-size:1.3rem;font-weight:800;color:#0f172a;text-align:center;margin-bottom:8px;">${esc(b.headline)}</div>`:''}
        ${b.subheadline?`<div style="font-size:.9rem;color:#64748b;text-align:center;margin-bottom:20px;">${esc(b.subheadline)}</div>`:''}
        <div class="lp-newsletter" style="max-width:560px;margin:0 auto;">
          <input type="email" placeholder="${esc(b.placeholder||'Enter your email')}" style="flex:1;min-width:220px;">
          <button style="background:${b.btnBg||'#2563eb'};color:${b.btnColor||'#fff'};">${esc(b.btnText||'Subscribe')}</button>
        </div>
      </div>`;

    case 'bg_video':
      return `<div class="lp-bgvideo" style="min-height:${b.minHeight||400}px;">
        <video autoplay muted loop playsinline style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:0;">
          <source src="${esc(b.videoUrl||'')}" type="video/mp4">
        </video>
        <div class="lp-bgvideo-overlay" style="background:${b.overlayColor||'rgba(0,0,0,0.5)'}"></div>
        <div class="lp-bgvideo-content">
          ${b.headline?`<h2 style="font-size:2.5rem;font-weight:900;color:#fff;margin:0 0 14px;">${esc(b.headline)}</h2>`:''}
          ${b.subheadline?`<p style="font-size:1.1rem;color:rgba(255,255,255,.85);margin:0 0 24px;">${esc(b.subheadline)}</p>`:''}
          ${b.btnText?`<a href="${esc(b.btnUrl||'#')}" class="lp-cta-btn" style="background:${b.btnBg||'#fff'};color:${b.btnColor||'#0f172a'};">${esc(b.btnText)}</a>`:''}
        </div>
      </div>`;

    case 'image_slider': {
      const sid = b.id;
      const imgs = (b.images||[]).map((u,i)=>`<img src="${esc(u)}" style="flex-shrink:0;width:100%;height:${b.height||420}px;object-fit:cover;" loading="lazy">`).join('');
      const dots = (b.images||[]).map((_,i)=>`<button class="lp-slider-dot ${i===0?'active':''}" onclick="lpSlide('${sid}',${i})"></button>`).join('');
      return `<div style="padding:${b.padding||0}px;background:${b.blockBg||'transparent'};">
        <div class="lp-slider" style="height:${b.height||420}px;border-radius:${b.radius||12}px;" id="lps_${sid}">
          <div class="lp-slider-track" id="lpst_${sid}" style="height:100%;">${imgs}</div>
          <button class="lp-slider-btn prev" onclick="lpSlideStep('${sid}',-1)">‹</button>
          <button class="lp-slider-btn next" onclick="lpSlideStep('${sid}',1)">›</button>
        </div>
        <div class="lp-slider-dots" id="lpsd_${sid}">${dots}</div>
      </div>`;
    }

    case 'carousel_widget': {
      const cid = b.id;
      const cols = b.cols || 3;
      const colW = Math.round(100/cols);
      const cards = (b.items||[]).map(it=>`
        <div class="lp-carousel-card" style="flex-shrink:0;width:calc(${100/cols}% - ${Math.round(20*(cols-1)/cols)}px);">
          <div style="font-size:1.6rem;margin-bottom:12px;">${esc(it.icon||'⭐')}</div>
          <div style="font-size:.95rem;font-weight:700;color:#0f172a;margin-bottom:8px;">${esc(it.title||'')}</div>
          <div style="font-size:.82rem;color:#64748b;line-height:1.6;margin-bottom:14px;">${esc(it.desc||'')}</div>
          ${it.name?`<div style="font-size:.78rem;font-weight:700;color:#0f172a;">${esc(it.name)}</div>`:''}
          ${it.role?`<div style="font-size:.72rem;color:#94a3b8;">${esc(it.role)}</div>`:''}
        </div>`).join('');
      return `<div style="padding:${b.padding||40}px;background:${b.blockBg||'#fff'};">
        ${b.headline?`<h2 style="font-size:1.6rem;font-weight:800;color:#0f172a;text-align:center;margin-bottom:28px;">${esc(b.headline)}</h2>`:''}
        <div class="lp-carousel" id="lpc_${cid}">
          <div class="lp-carousel-track" id="lpct_${cid}">${cards}</div>
        </div>
        <div class="lp-carousel-nav">
          <button onclick="lpCarouselStep('${cid}',-1)">‹ Prev</button>
          <button onclick="lpCarouselStep('${cid}',1)">Next ›</button>
        </div>
      </div>`;
    }

    case 'timeline_widget': {
      const items = (b.items||[]).map(it=>`
        <div class="lp-tl-item">
          <div class="lp-tl-dot" style="background:${b.dotColor||'#2563eb'};box-shadow:0 0 0 2px ${b.dotColor||'#2563eb'};"></div>
          ${it.date?`<div class="lp-tl-date">${esc(it.date)}</div>`:''}
          <div class="lp-tl-title">${esc(it.title||'')}</div>
          <div class="lp-tl-desc">${esc(it.desc||'')}</div>
        </div>`).join('');
      return `<div style="padding:${b.padding||40}px;background:${b.blockBg||'#fff'};">
        ${b.headline?`<h2 style="font-size:1.6rem;font-weight:800;color:#0f172a;margin-bottom:28px;">${esc(b.headline)}</h2>`:''}
        <div class="lp-timeline" style="max-width:640px;">${items}</div>
      </div>`;
    }

    // ── Interactive widget renderers ──
    // ── v3.1 SETTINGS PANEL ──
    case 'raw_html':
      html += `<div class="sp-sec">Raw HTML</div>`;
      html += `<textarea class="sp-in" rows="10" style="resize:vertical;font-family:monospace;font-size:.68rem;" oninput="ub('${b.id}','html',this.value)">${esc(b.html||'')}</textarea>`;
      html += `<div class="sp-hint">⚠ Raw HTML is rendered as-is on the published page. Use for custom embeds, iframes, or imported HTML templates.</div>`; break;
    
    case 'icon_widget':
      html += f('Icon (emoji or symbol)',ti('icon',b.icon,'⭐'));
      html += r2(f('Size',ti('size',b.size,'3rem')),f('Color',ci('color',b.color||'#2563eb')));
      html += f('Alignment',si('align',b.align||'center',[['left','Left'],['center','Center'],['right','Right']])); break;

    case 'badge_widget':
      html += f('Badge Text',ti('text',b.text,''));
      html += r2(f('Background',ci('bg',b.bg||'#eff6ff')),f('Text Color',ci('color',b.color||'#2563eb')));
      html += r2(f('Font Size',ti('size',b.size,'.82rem')),f('Border Radius',ti('radius',b.radius,'999px')));
      html += r2(f('H Padding (px)',ni('px',b.px,'0','60')),f('V Padding (px)',ni('py',b.py,'0','40')));
      html += f('Alignment',si('align',b.align||'left',[['left','Left'],['center','Center'],['right','Right']])); break;

    case 'newsletter_bar':
      html += f('Headline',ti('headline',b.headline,''));
      html += aiBtn('text','✨ Write headline');
      html += f('Sub-headline',ti('subheadline',b.subheadline,''));
      html += f('Placeholder',ti('placeholder',b.placeholder,'Enter your email'));
      html += r2(f('Button Text',ti('btnText',b.btnText,'Subscribe')),f('Button Color',ci('btnBg',b.btnBg||'#2563eb')));
      html += f('Background',ci('bgColor',b.bgColor||'#f8fafc')); break;

    case 'bg_video':
      html += f('Video URL (.mp4)',ti('videoUrl',b.videoUrl,''));
      html += f('Overlay Color',ti('overlayColor',b.overlayColor,'rgba(0,0,0,0.5)'));
      html += f('Min Height (px)',ni('minHeight',b.minHeight,'200','900'));
      html += f('Headline',ti('headline',b.headline,''));
      html += f('Sub-headline',ti('subheadline',b.subheadline,''));
      html += r2(f('Button Text',ti('btnText',b.btnText,'')),f('Button URL',ti('btnUrl',b.btnUrl,'#')));
      html += r2(f('Button Bg',ci('btnBg',b.btnBg||'#fff')),f('Button Color',ci('btnColor',b.btnColor||'#0f172a'))); break;

    case 'image_slider':
      html += `<div class="sp-sec">Image URLs (one per line)</div>`;
      html += `<textarea class="sp-in" rows="5" style="resize:vertical;" oninput="ub('${b.id}','images',this.value.split('\n').filter(s=>s.trim()))">${(b.images||[]).join('\n')}</textarea>`;
      html += r2(f('Height (px)',ni('height',b.height,'100','800')),f('Radius (px)',ni('radius',b.radius,'0','30')));
      html += f('Autoplay',si('autoplay',b.autoplay?'true':'false',[['true','Yes'],['false','No']])); break;

    case 'carousel_widget':
      html += f('Headline',ti('headline',b.headline,''));
      html += f('Columns (visible)',si('cols',String(b.cols||3),[['1','1'],['2','2'],['3','3']]));
      html += `<div class="sp-sec">Cards JSON [{icon,title,desc,name,role}]</div>`;
      html += `<textarea class="sp-in" rows="12" style="resize:vertical;font-family:monospace;font-size:.68rem;" oninput="try{ub('${b.id}','items',JSON.parse(this.value))}catch(e){}">${JSON.stringify(b.items||[],null,2)}</textarea>`; break;

    case 'timeline_widget':
      html += f('Headline',ti('headline',b.headline,''));
      html += f('Dot Color',ci('dotColor',b.dotColor||'#2563eb'));
      html += `<div class="sp-sec">Items JSON [{date,title,desc}]</div>`;
      html += `<textarea class="sp-in" rows="12" style="resize:vertical;font-family:monospace;font-size:.68rem;" oninput="try{ub('${b.id}','items',JSON.parse(this.value))}catch(e){}">${JSON.stringify(b.items||[],null,2)}</textarea>`; break;

    case 'map_embed':
      return `<div style="padding:${b.padding||20}px 0;background:${b.blockBg||'#fff'};">
        ${b.label?`<div style="font-size:.78rem;font-weight:700;color:#64748b;margin-bottom:8px;text-transform:uppercase;letter-spacing:.04em;">${esc(b.label)}</div>`:''}
        <iframe src="${esc(b.src)}" width="100%" height="${b.height||400}" style="border:0;border-radius:${b.radius||8}px;" allowfullscreen loading="lazy"></iframe>
      </div>`;

    case 'image_gallery': {
      const cols = b.cols || 2;
      const imgs = (b.images||[]).map(u=>`<img src="${esc(u)}" loading="lazy" style="width:100%;height:${b.thumbHeight||220}px;object-fit:cover;border-radius:${b.radius||8}px;cursor:zoom-in;" onclick="window.open('${esc(u)}','_blank')">`).join('');
      return `<div style="padding:${b.padding||20}px 0;background:${b.blockBg||'#fff'};">
        <div style="display:grid;grid-template-columns:repeat(${cols},1fr);gap:${b.gap||8}px;">${imgs}</div>
      </div>`;
    }

    case 'tabs_widget': {
      const tid = b.id;
      const tabBtns = (b.tabs||[]).map((t,i)=>`<button onclick="lpTab('${tid}',${i},this)" id="tbb_${tid}_${i}" style="padding:9px 18px;border:none;border-bottom:2px solid ${i===0?'#2563eb':'transparent'};background:transparent;font-size:.85rem;font-weight:${i===0?'700':'500'};color:${i===0?'#2563eb':'#64748b'};cursor:pointer;transition:.15s;white-space:nowrap;">${esc(t.label)}</button>`).join('');
      const tabPanes = (b.tabs||[]).map((t,i)=>`<div id="tbp_${tid}_${i}" style="${i===0?'':'display:none;'}padding:20px 0;font-size:.9rem;color:#475569;line-height:1.7;">${esc(t.content)}</div>`).join('');
      return `<div style="padding:${b.padding||20}px 0;background:${b.blockBg||'#fff'};">
        <div style="display:flex;border-bottom:1px solid #e2e8f0;overflow-x:auto;">${tabBtns}</div>
        ${tabPanes}
      </div>`;
    }

    case 'counter_widget': {
      const items = (b.items||[]).map((it,i)=>`
        <div style="text-align:center;padding:24px 16px;">
          <div style="font-size:2.4rem;font-weight:900;color:${b.color||'#2563eb'};line-height:1;" id="cnt_${b.id}_${i}" data-target="${it.number}" data-suffix="${esc(it.suffix||'')}">0${esc(it.suffix||'')}</div>
          <div style="font-size:.8rem;color:#94a3b8;margin-top:6px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;">${esc(it.label)}</div>
        </div>`).join('');
      return `<div style="padding:${b.padding||20}px 0;background:${b.blockBg||'#fff'};">
        <div style="display:flex;flex-wrap:wrap;justify-content:center;max-width:900px;margin:0 auto;">${items}</div>
      </div>`;
    }

    default:
      return `<div style="padding:20px;background:#fef3c7;border-radius:8px;font-size:.78rem;color:#92400e;">Unknown: ${esc(b.type)}</div>`;
  }
}
function renderWidget(b) { return rw(b); }

function esc(s) {
  if (s===null||s===undefined) return '';
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function toggleFAQ(id) {
  const el = document.getElementById(id);
  if (el) el.classList.toggle('open');
}

/* ── Select block ── */
function selectBlock(id) {
  selectedId = id;
  document.querySelectorAll('.pb-block').forEach(el=>el.classList.toggle('selected',el.dataset.id===id));
  const b = blocks.find(b=>b.id===id);
  if (b) renderBS(b);
}

document.getElementById('pbCanvas').addEventListener('click', function(e) {
  if (e.target===this||e.target.id==='rootDZ'||e.target.id==='dzHint'||e.target.closest('.dz-hint')) {
    selectedId=null;
    document.querySelectorAll('.pb-block').forEach(el=>el.classList.remove('selected'));
    document.getElementById('bsBody').innerHTML='<div style="color:var(--g400);font-size:.76rem;padding:6px 0;">Select a block to edit its settings.</div>';
  }
});

/* ══ SETTINGS PANEL ══ */
function renderBS(b) {
  if (!b) return;
  const body = document.getElementById('bsBody');

  const f  = (lbl,inp,hint='') => `<div class="sp-f"><label class="sp-l">${lbl}</label>${inp}${hint?`<div class="sp-hint">${hint}</div>`:''}</div>`;
  const ti = (key,val,ph='') => `<input class="sp-in" placeholder="${ph}" value="${esc(val)}" oninput="ub('${b.id}','${key}',this.value)">`;
  const ta = (key,val,rows=3) => `<textarea class="sp-in" rows="${rows}" style="resize:vertical;" oninput="ub('${b.id}','${key}',this.value)">${esc(val)}</textarea>`;
  const ci = (key,val) => `<div class="sp-col"><input type="color" value="${val||'#000000'}" oninput="ub('${b.id}','${key}',this.value);document.getElementById('ci_${b.id}_${key}').value=this.value;"><input id="ci_${b.id}_${key}" type="text" class="sp-in" value="${esc(val)}" style="flex:1;" oninput="ub('${b.id}','${key}',this.value)"></div>`;
  const si = (key,val,opts) => `<select class="sp-sel" onchange="ub('${b.id}','${key}',this.value)">${opts.map(([v,l])=>`<option value="${v}" ${String(val)===String(v)?'selected':''}>${l}</option>`).join('')}</select>`;
  const ni = (key,val,mn='0',mx='200') => `<input type="number" class="sp-in" min="${mn}" max="${mx}" value="${val||0}" oninput="ub('${b.id}','${key}',this.value)">`;
  const r2 = (a,b2) => `<div class="sp-2">${a}${b2}</div>`;
  // AI generate button — only shown if AI is enabled
  const aiEnabled = <?= json_encode(ai_enabled()) ?>;
  const aiBtn = (field, label='✨ Generate') => !aiEnabled ? '' :
    `<button class="ai-btn" id="aibtn_${b.id}_${field}"
       onclick="aiGenField('${b.id}','${b.type}','${field}')">${label}</button>
     <div class="ai-opts" id="aiopts_${b.id}_${field}" style="display:none;"></div>`;

  let html = `<div style="font-size:.63rem;font-weight:800;text-transform:uppercase;color:var(--g400);margin-bottom:8px;letter-spacing:.06em;">
    ${b.type.replace(/_/g,' ')}${b.locked?' <span style="color:#f59e0b">🔒 Locked</span>':''}
  </div>`;

  if (b.locked) { html+=`<div class="sp-hint">Unlock via toolbar 🔒 button.</div>`; body.innerHTML=html; return; }

  switch(b.type) {
    case 'headline': case 'subheadline': case 'paragraph': case 'section_title':
      html += f('Text',ta('text',b.text,4));
      html += aiBtn('text', b.type==='paragraph' ? '✨ Write copy' : b.type==='section_title' ? '✨ Suggest labels' : '✨ Write headline');
      html += r2(f('Size',ti('size',b.size,'2rem')),f('Color',ci('color',b.color)));
      html += f('Alignment',si('align',b.align,[['left','Left'],['center','Center'],['right','Right']]));
      if (b.type!=='paragraph') html += f('Bold',si('bold',b.bold?'true':'false',[['true','Yes'],['false','No']]));
      break;
    case 'bullet_list':
      html += f('Items (one per line)',`<textarea class="sp-in" rows="5" style="resize:vertical;" oninput="ub('${b.id}','items',this.value.split('\\n').filter(s=>s.trim()))">${(b.items||[]).join('\n')}</textarea>`);
      html += aiBtn('items', '✨ Generate benefits');
      html += f('Text Color',ci('color',b.color)); break;
    case 'divider': html += f('Color',ci('color',b.color)); break;
    case 'spacer':  html += f('Height (px)',ni('height',b.height,'10','400')); break;
    case 'image':
      html += f('Image URL',ti('src',b.src,'https://…'));
      html += f('Alt Text',ti('alt',b.alt,''));
      html += r2(f('Width %',ni('width',b.width,'10','100')),f('Radius (px)',ni('imgRadius',b.imgRadius,'0','50'))); break;
    case 'video': html += f('Embed URL',ti('url',b.url,'https://www.youtube.com/embed/…')); break;
    case 'logo_gallery':
      html += f('Brands (one per line)',`<textarea class="sp-in" rows="4" style="resize:vertical;" oninput="ub('${b.id}','logos',this.value.split('\\n').filter(s=>s.trim()))">${(b.logos||[]).join('\n')}</textarea>`); break;
    case 'lead_form':
      html += f('Form Title',ti('title',b.title,''));
      html += aiBtn('title', '✨ Suggest form headline');
      html += f('Submit Text',ti('submitText',b.submitText,'Submit'));
      html += f('Success Message',ti('successMsg',b.successMsg,''));
      html += f('Background',ci('bg',b.bg));
      html += `<div class="sp-hint">Attach form: Page Settings → Attached Form</div>`; break;
    case 'cta_button':
      html += f('Button Text',ti('text',b.text,''));
      html += aiBtn('text', '✨ Suggest CTA text');
      html += f('Link URL',ti('url',b.url,'https://…'));
      html += f('Alignment',si('align',b.align,[['left','Left'],['center','Center'],['right','Right']]));
      html += r2(f('Background',ci('bg',b.bg)),f('Text Color',ci('color',b.color)));
      html += r2(f('Font Size',ti('size',b.size,'1rem')),f('Radius (px)',ni('radius',b.radius,'0','50')));
      html += f('Full Width',si('fullWidth',b.fullWidth?'true':'false',[['false','No'],['true','Yes']])); break;
    case 'appointment':
      html += f('Label',ti('label',b.label,''));
      html += f('Button Text',ti('btnText',b.btnText,'📅 Book a Free Call'));
      html += f('Booking URL',ti('url',b.url,'https://calendly.com/…'));
      html += r2(f('Background',ci('bg',b.bg)),f('Text Color',ci('color',b.color)));
      html += f('Radius (px)',ni('radius',b.radius,'0','50')); break;
    case 'testimonial':
      html += f('Quote',ta('quote',b.quote));
      html += aiBtn('quote', '✨ Generate testimonial');
      html += r2(f('Author',ti('author',b.author,'')),f('Role',ti('role',b.role,'')));
      html += f('Accent Color',ci('color',b.color)); break;
    case 'reviews':
      html += f('Title',ti('title',b.title,''));
      html += `<div class="sp-sec">Reviews JSON</div>`;
      html += `<textarea class="sp-in" rows="8" style="resize:vertical;font-family:monospace;font-size:.68rem;"
        oninput="try{ub('${b.id}','items',JSON.parse(this.value))}catch(e){}">${JSON.stringify(b.items||[],null,2)}</textarea>`;
      html += aiBtn('items', '✨ Generate reviews'); break;
    case 'trust_badges':
      html += f('Badges (one per line)',`<textarea class="sp-in" rows="4" style="resize:vertical;" oninput="ub('${b.id}','badges',this.value.split('\\n').filter(s=>s.trim()))">${(b.badges||[]).join('\n')}</textarea>`); break;
    case 'countdown':
      html += f('Target Date',`<input type="date" class="sp-in" value="${b.targetDate||''}" onchange="ub('${b.id}','targetDate',this.value)">`);
      html += f('Label',ti('label',b.label,'Offer ends in:')); break;
    case 'offer_banner':
      html += f('Headline',ti('headline',b.headline,''));
      html += aiBtn('headline', '✨ Write banner headline');
      html += f('Body Text',ti('text',b.text,''));
      html += aiBtn('text', '✨ Write body text');
      html += r2(f('From',ci('bg1',b.bg1)),f('To',ci('bg2',b.bg2))); break;
    case 'pricing':
      html += r2(f('Plan Name',ti('name',b.name,'')),f('Price',ti('price',b.price,'')));
      html += f('Period',ti('period',b.period,'month'));
      html += f('Features (one per line)',`<textarea class="sp-in" rows="4" style="resize:vertical;" oninput="ub('${b.id}','features',this.value.split('\\n').filter(s=>s.trim()))">${(b.features||[]).join('\n')}</textarea>`);
      html += aiBtn('features', '✨ Generate features');
      html += r2(f('Button Text',ti('btnText',b.btnText,'')),f('Button Color',ci('btnBg',b.btnBg))); break;
    case 'faq':
      html += f('Title',ti('title',b.title,''));
      html += `<div class="sp-sec">FAQ Items JSON</div>`;
      html += `<textarea class="sp-in" rows="10" style="resize:vertical;font-family:monospace;font-size:.68rem;"
        oninput="try{ub('${b.id}','items',JSON.parse(this.value))}catch(e){}">${JSON.stringify(b.items||[],null,2)}</textarea>`;
      html += aiBtn('items', '✨ Generate FAQ'); break;

    // ── v3 NEW WIDGET SETTINGS ──
    case 'hero_section':
      html += f('Headline',ti('headline',b.headline,''));
      html += aiBtn('text','✨ Write headline');
      html += f('Sub-headline',ta('subheadline',b.subheadline,2));
      html += f('Button Text',ti('btnText',b.btnText,'Get Started'));
      html += f('Button URL',ti('btnUrl',b.btnUrl,'#'));
      html += f('Button Color',ci('btnBg',b.btnBg));
      html += `<hr class="sp-div"><div class="sp-sec">Background</div>`;
      html += f('Background Image URL',ti('bgImage',b.bgImage,'https://…'));
      html += f('Background Color',ci('bgColor',b.bgColor||'#1e293b'));
      html += f('Overlay Color',ti('overlayColor',b.overlayColor,'rgba(0,0,0,0.45)'));
      html += f('Layout',si('layout',b.layout,[['split','Split (text + form)'],['full','Full width centered']]));
      html += f('Min Height (px)',ni('minHeight',b.minHeight,'200','900'));
      html += f('Show Form',si('showForm',b.showForm?'true':'false',[['false','No'],['true','Yes']]));
      break;

    case 'two_col':
      html += f('Eyebrow Label',ti('eyebrow',b.eyebrow,'e.g. OUR SERVICES'));
      html += f('Headline',ti('headline',b.headline,''));
      html += aiBtn('text','✨ Write headline');
      html += f('Body Text',ta('body',b.body,4));
      html += f('Bullet Points (one per line)',`<textarea class="sp-in" rows="3" style="resize:vertical;" oninput="ub('${b.id}','bullets',this.value.split('\\n').filter(s=>s.trim()))">${(b.bullets||[]).join('\n')}</textarea>`);
      html += f('Image URL',ti('imgUrl',b.imgUrl,'https://…'));
      html += r2(f('Image Position',si('imgPosition',b.imgPosition,[['left','Image Left'],['right','Image Right']])),f('Image Radius',ni('imgRadius',b.imgRadius,'0','50')));
      html += f('Show Button',si('showBtn',b.showBtn?'true':'false',[['true','Yes'],['false','No']]));
      html += r2(f('Button Text',ti('btnText',b.btnText,'')),f('Button URL',ti('btnUrl',b.btnUrl,'#')));
      html += f('Button Color',ci('btnBg',b.btnBg));
      break;

    case 'feature_grid':
      html += f('Section Headline',ti('headline',b.headline,''));
      html += f('Sub-headline',ti('subheadline',b.subheadline,''));
      html += f('Columns',si('cols',String(b.cols||3),[['2','2 Columns'],['3','3 Columns'],['4','4 Columns']]));
      html += f('Background',ci('bgColor',b.bgColor||'#ffffff'));
      html += `<div class="sp-sec">Feature Cards JSON</div>`;
      html += `<textarea class="sp-in" rows="12" style="resize:vertical;font-family:monospace;font-size:.68rem;"
        oninput="try{ub('${b.id}','items',JSON.parse(this.value))}catch(e){}">${JSON.stringify(b.items||[],null,2)}</textarea>`;
      break;

    case 'stats_row':
      html += f('Background',ci('bgColor',b.bgColor||'#ffffff'));
      html += f('Number Color',ci('numColor',b.numColor||'#0f172a'));
      html += `<div class="sp-sec">Stats JSON</div>`;
      html += `<textarea class="sp-in" rows="8" style="resize:vertical;font-family:monospace;font-size:.68rem;"
        oninput="try{ub('${b.id}','items',JSON.parse(this.value))}catch(e){}">${JSON.stringify(b.items||[],null,2)}</textarea>`;
      break;

    case 'progress_bars':
      html += f('Headline',ti('headline',b.headline,''));
      html += `<div class="sp-sec">Progress Items JSON [{label, value, color}]</div>`;
      html += `<textarea class="sp-in" rows="8" style="resize:vertical;font-family:monospace;font-size:.68rem;"
        oninput="try{ub('${b.id}','items',JSON.parse(this.value))}catch(e){}">${JSON.stringify(b.items||[],null,2)}</textarea>`;
      break;

    case 'contact_info':
      html += f('Headline',ti('headline',b.headline,''));
      html += `<div class="sp-sec">Contact Items JSON [{icon, label, value}]</div>`;
      html += `<textarea class="sp-in" rows="10" style="resize:vertical;font-family:monospace;font-size:.68rem;"
        oninput="try{ub('${b.id}','items',JSON.parse(this.value))}catch(e){}">${JSON.stringify(b.items||[],null,2)}</textarea>`;
      break;

    case 'social_links':
      html += f('Label',ti('label',b.label,'Follow Us'));
      html += `<div class="sp-sec">Links JSON [{icon, label, url, bg, color}]</div>`;
      html += `<textarea class="sp-in" rows="10" style="resize:vertical;font-family:monospace;font-size:.68rem;"
        oninput="try{ub('${b.id}','items',JSON.parse(this.value))}catch(e){}">${JSON.stringify(b.items||[],null,2)}</textarea>`;
      break;

    case 'announcement_bar':
      html += f('Text',ti('text',b.text,''));
      html += r2(f('Background',ci('bgColor',b.bgColor)),f('Text Color',ci('textColor',b.textColor)));
      html += r2(f('Link Text',ti('linkText',b.linkText,'')),f('Link URL',ti('linkUrl',b.linkUrl,'#')));
      break;

    case 'nav_bar':
      html += f('Brand Name',ti('brand',b.brand,'YourBrand'));
      html += f('Brand URL',ti('brandUrl',b.brandUrl,'#'));
      html += r2(f('Background',ci('bgColor',b.bgColor||'#ffffff')),f('Text Color',ci('textColor',b.textColor||'#475569')));
      html += f('CTA Text',ti('ctaText',b.ctaText,'Get Started'));
      html += r2(f('CTA URL',ti('ctaUrl',b.ctaUrl,'#')),f('CTA Color',ci('ctaBg',b.ctaBg||'#2563eb')));
      html += `<div class="sp-sec">Nav Links JSON [{label, url}]</div>`;
      html += `<textarea class="sp-in" rows="6" style="resize:vertical;font-family:monospace;font-size:.68rem;"
        oninput="try{ub('${b.id}','links',JSON.parse(this.value))}catch(e){}">${JSON.stringify(b.links||[],null,2)}</textarea>`;
      break;

    case 'footer_block':
      html += f('Brand Name',ti('brand',b.brand,'YourBrand'));
      html += f('Description',ta('description',b.description,2));
      html += r2(f('Background',ci('bgColor',b.bgColor||'#0f172a')),f('Text Color',ci('textColor',b.textColor||'#94a3b8')));
      html += f('Copyright Text',ti('copyright',b.copyright,''));
      html += `<div class="sp-sec">Columns JSON [{title, links:[{label,url}]}]</div>`;
      html += `<textarea class="sp-in" rows="12" style="resize:vertical;font-family:monospace;font-size:.68rem;"
        oninput="try{ub('${b.id}','columns',JSON.parse(this.value))}catch(e){}">${JSON.stringify(b.columns||[],null,2)}</textarea>`;
      break;

    case 'map_embed':
      html += f('Map Embed URL',ti('embedUrl',b.embedUrl,'https://www.google.com/maps/embed?pb=…'));
      html += `<div class="sp-hint">Copy the embed URL from Google Maps → Share → Embed a map → Copy HTML, then paste just the src= value.</div>`;
      html += f('Height (px)',ni('height',b.height,'100','800'));
      html += f('Label',ti('label',b.label,''));
      html += f('Border Radius',ni('radius',b.radius,'0','20')); break;

    case 'image_gallery':
      html += `<div class="sp-sec">Image URLs (one per line)</div>`;
      html += `<textarea class="sp-in" rows="6" style="resize:vertical;" oninput="ub('${b.id}','images',this.value.split('\n').filter(s=>s.trim()))">${(b.images||[]).join('\n')}</textarea>`;
      html += r2(f('Columns',si('cols',String(b.cols||2),[['1','1'],['2','2'],['3','3'],['4','4']])),f('Gap (px)',ni('gap',b.gap,'0','40')));
      html += r2(f('Thumb Height',ni('thumbHeight',b.thumbHeight,'80','600')),f('Radius',ni('radius',b.radius,'0','20'))); break;

    case 'tabs_widget':
      html += `<div class="sp-sec">Tabs JSON [{label, content}]</div>`;
      html += `<textarea class="sp-in" rows="10" style="resize:vertical;font-family:monospace;font-size:.68rem;"
        oninput="try{ub('${b.id}','tabs',JSON.parse(this.value))}catch(e){}">${JSON.stringify(b.tabs||[],null,2)}</textarea>`; break;

    case 'counter_widget':
      html += f('Accent Color',ci('color',b.color||'#2563eb'));
      html += `<div class="sp-sec">Counter Items JSON [{number, suffix, label}]</div>`;
      html += `<textarea class="sp-in" rows="8" style="resize:vertical;font-family:monospace;font-size:.68rem;"
        oninput="try{ub('${b.id}','items',JSON.parse(this.value))}catch(e){}">${JSON.stringify(b.items||[],null,2)}</textarea>`; break;

    default: break;
  } // end switch(b.type)

  // ── Common block styling (applied to ALL widget types) ──
  html += `<hr class="sp-div"><div class="sp-sec">Block Styling</div>`;
  html += f('Padding (px)',ni('padding',b.padding,'0','120'));
  html += r2(f('Margin Top',ni('marginTop',b.marginTop,'0','120')),f('Margin Bottom',ni('marginBottom',b.marginBottom,'0','120')));
  html += f('Background Color',ci('blockBg',b.blockBg||'#ffffff'));
  html += `<div class="sp-sec">Gradient Background</div>`;
  html += f('Gradient From',ci('gradFrom',b.gradFrom||''));
  html += f('Gradient To',ci('gradTo',b.gradTo||''));
  html += f('Gradient Direction',si('gradDir',b.gradDir||'135deg',[['to right','→ Horizontal'],['to bottom','↓ Vertical'],['135deg','↘ Diagonal'],['to top right','↗ Diagonal Up']]));
  html += `<div class="sp-hint">Set both From and To colors to enable gradient (overrides bg color).</div>`;
  html += `<div class="sp-sec">Shadow</div>`;
  html += f('Box Shadow',si('boxShadow',b.boxShadow||'none',[['none','None'],['sm','Small'],['md','Medium'],['lg','Large'],['xl','Extra Large']]));
  html += `<div class="sp-sec">Border</div>`;
  html += r2(f('Width (px)',ni('borderWidth',b.borderWidth,'0','8')),f('Radius (px)',ni('borderRadius',b.borderRadius,'0','40')));
  html += f('Color',ci('borderColor',b.borderColor||'#e2e8f0'));
  html += `<div class="sp-sec">Scroll Animation</div>`;
  html += f('Animation',si('animation',b.animation||'none',[['none','None'],['fade-up','Fade Up'],['fade-left','Fade from Left'],['scale','Scale In']]));
  html += `<div class="sp-sec">Visibility</div>`;
  html += `<div style="display:flex;gap:12px;flex-wrap:wrap;">
    <label style="display:flex;align-items:center;gap:5px;font-size:.72rem;cursor:pointer;">
      <input type="checkbox" ${b.hideOnMobile?'checked':''} onchange="ub('${b.id}','hideOnMobile',this.checked)"> Hide on Mobile
    </label>
    <label style="display:flex;align-items:center;gap:5px;font-size:.72rem;cursor:pointer;">
      <input type="checkbox" ${b.hideOnTablet?'checked':''} onchange="ub('${b.id}','hideOnTablet',this.checked)"> Hide on Tablet
    </label>
    <label style="display:flex;align-items:center;gap:5px;font-size:.72rem;cursor:pointer;">
      <input type="checkbox" ${b.hideOnDesktop?'checked':''} onchange="ub('${b.id}','hideOnDesktop',this.checked)"> Hide on Desktop
    </label>
  </div>`;

  body.innerHTML = html;
  initCountdowns();
}

/* ── Update block ── */
function ub(id, key, value) {
  const b = blocks.find(b=>b.id===id);
  if (!b) return;
  if (key==='bold'||key==='fullWidth') value=(value==='true'||value===true);
  b[key] = value;
  const el = document.querySelector(`.pb-block[data-id="${id}"]`);
  if (el) {
    el.innerHTML = btbar(id,blocks.indexOf(b))+renderWidget(b);
    applyBlockStyle(el,b);
    initCountdowns();
  }
  markDirty();
}
function updateBlock(id,key,value) { ub(id,key,value); }

/* ── Block ops ── */
function moveBlock(id, dir) {
  pushUndo();
  const idx = blocks.findIndex(b=>b.id===id);
  if (idx<0) return;
  const ni2 = idx+dir;
  if (ni2<0||ni2>=blocks.length) return;
  [blocks[idx],blocks[ni2]]=[blocks[ni2],blocks[idx]];
  render(); markDirty();
}
function dupBlock(id) {
  pushUndo();
  const b = blocks.find(b=>b.id===id);
  if (!b) return;
  const copy = JSON.parse(JSON.stringify(b)); copy.id=uid();
  blocks.splice(blocks.findIndex(x=>x.id===id)+1,0,copy);
  render(); selectBlock(copy.id); markDirty();
}
function delBlock(id) {
  const b = blocks.find(x=>x.id===id);
  const label = b ? b.type.replace(/_/g,' ') : 'block';
  if (!confirm(`Delete this ${label}? This can be undone with Ctrl+Z.`)) return;
  pushUndo();
  blocks = blocks.filter(b=>b.id!==id);
  if (selectedId===id) { selectedId=null; document.getElementById('bsBody').innerHTML='<div style="color:var(--g400);font-size:.76rem;padding:6px 0;">Select a block to edit.</div>'; }
  render(); markDirty();
}
function toggleLock(id) {
  const b = blocks.find(b=>b.id===id);
  if (!b) return;
  b.locked=!b.locked;
  render(); if(!b.locked) selectBlock(id); markDirty();
}

/* ── Drag & Drop ── */
document.querySelectorAll('.wi').forEach(item=>{
  item.setAttribute('title', 'Click to add · Drag to position');
  item.addEventListener('dragstart',e=>{ dragWidget=item.dataset.widget; dragBlockId=null; e.dataTransfer.effectAllowed='copy'; });
  item.addEventListener('dragend',()=>{ dragWidget=null; });
  item.addEventListener('click', ()=>{
    try {
      pushUndo();
      const nb = defaultBlock(item.dataset.widget);
      // Insert after selected block or at end
      const selIdx = selectedId ? blocks.findIndex(b=>b.id===selectedId) : -1;
      if (selIdx >= 0) blocks.splice(selIdx+1, 0, nb);
      else blocks.push(nb);
      render();
      selectBlock(nb.id);
      markDirty();
      // Scroll new block into view
      setTimeout(()=>{
        const el = document.querySelector('.pb-block[data-id="'+nb.id+'"]');
        if (el) el.scrollIntoView({behavior:'smooth', block:'center'});
      }, 100);
    } catch(err) {
      console.error('Add widget error:', err);
      alert('Error adding widget: ' + err.message);
    }
  });
});

function setupDragOnBlocks() {
  const rootDZ = document.getElementById('rootDZ');

  document.querySelectorAll('.pb-block').forEach(el=>{
    el.setAttribute('draggable','true');
    el.addEventListener('dragstart', e=>{
      if (e.target.closest('.btbar')||e.target.tagName==='INPUT'||e.target.tagName==='TEXTAREA'||e.target.getAttribute('contenteditable')) return;
      dragBlockId=el.dataset.id; dragWidget=null; e.dataTransfer.effectAllowed='move';
    });
    el.addEventListener('dragover', e=>{
      e.preventDefault(); rootDZ.classList.add('dz-over');
      const mid = el.getBoundingClientRect().top + el.getBoundingClientRect().height/2;
      el.style.borderTop    = e.clientY<mid ? '3px solid var(--br5)' : '';
      el.style.borderBottom = e.clientY>=mid ? '3px solid var(--br5)' : '';
    });
    el.addEventListener('dragleave', ()=>{ el.style.borderTop=''; el.style.borderBottom=''; });
    el.addEventListener('drop', e=>{
      e.preventDefault(); e.stopPropagation();
      el.style.borderTop=''; el.style.borderBottom='';
      rootDZ.classList.remove('dz-over');
      const toIdx = parseInt(el.dataset.idx);
      const mid   = el.getBoundingClientRect().top + el.getBoundingClientRect().height/2;
      const insertAt = e.clientY<mid ? toIdx : toIdx+1;
      if (dragWidget) {
        try {
          pushUndo();
          const nb = defaultBlock(dragWidget); dragWidget=null;
          blocks.splice(insertAt,0,nb);
          render(); selectBlock(nb.id); markDirty();
        } catch(err) { console.error('Drop widget error:', dragWidget, err); dragWidget=null; }
        return;
      }
      if (!dragBlockId||dragBlockId===el.dataset.id) return;
      pushUndo();
      const fromIdx = blocks.findIndex(b=>b.id===dragBlockId);
      const [moved] = blocks.splice(fromIdx,1);
      const adj = fromIdx<insertAt ? insertAt-1 : insertAt;
      blocks.splice(adj,0,moved);
      dragBlockId=null; render(); markDirty();
    });
  });

  rootDZ.addEventListener('dragover', e=>{ e.preventDefault(); rootDZ.classList.add('dz-over'); });
  rootDZ.addEventListener('dragleave', e=>{ if (!rootDZ.contains(e.relatedTarget)) rootDZ.classList.remove('dz-over'); });
  rootDZ.addEventListener('drop', e=>{
    e.preventDefault(); rootDZ.classList.remove('dz-over');
    if (!dragWidget) return;
    try {
      pushUndo();
      const nb = defaultBlock(dragWidget); dragWidget=null;
      blocks.push(nb); render(); selectBlock(nb.id); markDirty();
    } catch(err) { console.error('Root drop error:', dragWidget, err); dragWidget=null; }
  });
}

/* ── Keyboard shortcuts ── */
document.addEventListener('keydown', e=>{
  const tag = document.activeElement.tagName;
  const isEdit = tag==='INPUT'||tag==='TEXTAREA'||document.activeElement.getAttribute('contenteditable')==='true';
  if ((e.ctrlKey||e.metaKey)&&e.key==='z'&&!e.shiftKey) { e.preventDefault(); doUndo(); return; }
  if ((e.ctrlKey||e.metaKey)&&(e.key==='y'||(e.key==='z'&&e.shiftKey))) { e.preventDefault(); doRedo(); return; }
  if ((e.ctrlKey||e.metaKey)&&e.key==='s') { e.preventDefault(); savePage(); return; }
  if (isEdit) return;
  if ((e.ctrlKey||e.metaKey)&&e.key==='d') { e.preventDefault(); if(selectedId) dupBlock(selectedId); return; }
  if (e.key==='Delete'||e.key==='Backspace') { if(selectedId){ delBlock(selectedId); } return; }
  if (e.key==='Escape') {
    selectedId=null;
    document.querySelectorAll('.pb-block').forEach(el=>el.classList.remove('selected'));
    document.getElementById('bsBody').innerHTML='<div style="color:var(--g400);font-size:.76rem;padding:6px 0;">Select a block to edit.</div>';
  }
});

/* ── Save ── */
function markDirty(push=true) {
  dirty=true;
  const ind=document.getElementById('saveInd');
  if(ind){ind.className='save-ind saving';ind.innerHTML='<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg> Unsaved';}
  clearTimeout(saveTimer); saveTimer=setTimeout(savePage,3000);
}
function markSaved() {
  dirty=false;
  const ind=document.getElementById('saveInd');
  if(ind){ind.className='save-ind saved';ind.innerHTML='<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 6L9 17l-5-5"/></svg> Saved';}
}
async function savePage(redirect) {
  const title = document.getElementById('pageTitle').value.trim();
  if (!title) { alert('Enter a page title first.'); document.getElementById('pageTitle').focus(); return; }
  const btn=document.getElementById('saveBtn');
  if(btn){btn.disabled=true;btn.textContent='⏳ Saving…';}
  const fd=new FormData();
  fd.append('action','save'); fd.append('_csrf',document.getElementById('csrfToken').value);
  fd.append('title',title); fd.append('page_data',JSON.stringify(blocks));
  fd.append('meta_title',document.getElementById('metaTitle')?.value||'');
  fd.append('meta_desc', document.getElementById('metaDesc')?.value||'');
  fd.append('og_image',  document.getElementById('ogImage')?.value||'');
  fd.append('form_id',   document.getElementById('pageFormId')?.value||'0');
  fd.append('page_bg',   document.getElementById('pageBgText')?.value||'#ffffff');
  // Slug edit (only for existing pages)
  const slugEl = document.getElementById('pageSlugEdit');
  if (slugEl) fd.append('page_slug', slugEl.value.trim());
  try {
    const url = window.location.href.split('?')[0]+'?id='+currentPageId+'&campaign_id=<?= $campaign_id ?>';
    const res = await fetch(url,{method:'POST',body:fd});
    // Check for non-JSON response (PHP error / redirect)
    const ct = res.headers.get('content-type')||'';
    if (!ct.includes('json')) {
      const txt = await res.text();
      const ind=document.getElementById('saveInd');
      if(ind){ind.style.color='#ef4444';ind.innerHTML='⚠ Save error (HTTP '+res.status+')';}
      console.error('Save response not JSON:', txt.slice(0,200));
      if(btn){btn.disabled=false;btn.textContent='💾 Save';} return;
    }
    const data = await res.json();
    if (data.ok) {
      if (!currentPageId&&data.id) { currentPageId=data.id; history.replaceState(null,'','?id='+data.id+'&campaign_id=<?= $campaign_id ?>'); }
      // Update slug display if slug was changed
      if (data.slug) {
        const slugEl2 = document.getElementById('pageSlugEdit');
        if (slugEl2) slugEl2.value = data.slug;
        const slugLink = document.querySelector('a[href*="/lp/"]');
        if (slugLink) { slugLink.href = '<?= APP_URL ?>/lp/'+data.slug; slugLink.textContent = '<?= APP_URL ?>/lp/'+data.slug+' ↗'; }
      }
      markSaved();
      if (redirect) window.location.href='<?= APP_URL ?>/campaign_view.php?id=<?= $campaign_id ?>';
    } else {
      const ind=document.getElementById('saveInd');
      if(ind){ind.style.color='#ef4444';ind.innerHTML='⚠ Save failed';}
      console.error('Save returned error:', data);
    }
  } catch(e) {
    const ind=document.getElementById('saveInd');
    if(ind){ind.style.color='#ef4444';ind.innerHTML='⚠ Network error';}
    console.error('Save failed',e);
  }
  if(btn){btn.disabled=false;btn.textContent='💾 Save';}
}

/* ── UI helpers ── */
function setDevice(name,btn) {
  document.querySelectorAll('.dev-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('pbCanvas').className='pb-canvas '+name;
}
function togglePreview() {
  previewMode=!previewMode;
  document.getElementById('previewBtn').textContent=previewMode?'✏ Edit':'👁 Preview';
  ['pb-sidebar','pbRight'].forEach(id=>document.getElementById(id).style.display=previewMode?'none':'');
  document.querySelector('.pb-devbar').style.display=previewMode?'none':'';
  if (previewMode) {
    selectedId=null;
    document.querySelectorAll('.pb-block').forEach(el=>{el.classList.remove('selected');el.style.pointerEvents='none';el.style.border='none';});
  } else { render(); }
}
function switchTab(tab,el) {
  document.querySelectorAll('.pb-stab').forEach(t=>t.classList.remove('active')); el.classList.add('active');
  ['Widgets','Templates','Media','Saved','Settings'].forEach(n => {
    const el2 = document.getElementById('tab'+n);
    if (el2) el2.style.display = tab===n.toLowerCase() ? '' : 'none';
  });
  if (tab==='media'     && !mediaLoaded)    loadMediaLibrary();
  if (tab==='templates' && !tplTabLoaded)   loadBuilderTemplates();
  if (tab==='saved')                        renderSavedComponents();
}
function applyPageBg(val) {
  document.getElementById('pbCanvas').style.background=val;
  document.getElementById('pageBgText').value=val;
  markDirty();
}

function updateSharePreview() {
  const title = document.getElementById('metaTitle')?.value || document.getElementById('pageTitle')?.value || '';
  const desc  = document.getElementById('metaDesc')?.value  || '';
  const img   = document.getElementById('ogImage')?.value   || '';
  const spT   = document.getElementById('spTitle');
  const spD   = document.getElementById('spDesc');
  const spI   = document.getElementById('spImg');
  if (spT) spT.textContent = title || 'Page Title';
  if (spD) spD.textContent = desc;
  if (spI) spI.style.backgroundImage = img ? `url('${img}')` : '';
}
// Keep preview live
['metaTitle','metaDesc','ogImage','pageTitle'].forEach(id => {
  const el = document.getElementById(id);
  if (el) el.addEventListener('input', updateSharePreview);
});

function applyGlobalBrand(val) {
  document.getElementById('globalBrandColorText').value = val;
  // Apply CSS variable across canvas
  document.getElementById('pbCanvas').style.setProperty('--lp-brand', val);
  markDirty();
}

function applyGlobalFont(val) {
  // Dynamically load Google Font if needed
  const safeSystemFonts = ['Georgia'];
  if (!safeSystemFonts.includes(val)) {
    const id = 'gf_' + val.replace(/\s/g,'_');
    if (!document.getElementById(id)) {
      const link = document.createElement('link');
      link.id = id; link.rel = 'stylesheet';
      link.href = `https://fonts.googleapis.com/css2?family=${encodeURIComponent(val)}:wght@400;500;600;700;800;900&display=swap`;
      document.head.appendChild(link);
    }
  }
  document.getElementById('pbCanvas').style.fontFamily = `'${val}', sans-serif`;
  markDirty();
}
function initCountdowns() {
  blocks.filter(b=>b.type==='countdown').forEach(b=>{
    const target = b.targetDate ? new Date(b.targetDate+'T23:59:59') : null;
    if (!target) return;
    clearInterval(window['cd_'+b.id]);
    function tick() {
      const diff=target-new Date(); if(diff<=0) return;
      const set=(id,v)=>{const el=document.getElementById(id);if(el)el.textContent=String(v).padStart(2,'0');};
      set('cd_'+b.id+'_d',Math.floor(diff/86400000));
      set('cd_'+b.id+'_h',Math.floor((diff%86400000)/3600000));
      set('cd_'+b.id+'_m',Math.floor((diff%3600000)/60000));
      set('cd_'+b.id+'_s',Math.floor((diff%60000)/1000));
    }
    tick(); window['cd_'+b.id]=setInterval(tick,1000);
  });
}
window.addEventListener('beforeunload',e=>{ if(dirty){e.preventDefault();e.returnValue='';} });

/* ═══════════════════════════════════════════════════════════════
   v3.1: Slider, Carousel, Scroll Animations
═══════════════════════════════════════════════════════════════ */

// ── Image Slider ─────────────────────────────────────────────
const lpSliderState = {};
function lpSlide(id, idx) {
  const track = document.getElementById('lpst_'+id);
  const dots  = document.querySelectorAll(`#lpsd_${id} .lp-slider-dot`);
  if (!track) return;
  const imgs = track.querySelectorAll('img');
  const n    = imgs.length;
  const i    = ((idx % n) + n) % n;
  lpSliderState[id] = i;
  track.style.transform = `translateX(-${i * 100}%)`;
  dots.forEach((d,j) => d.classList.toggle('active', j===i));
}
function lpSlideStep(id, dir) {
  lpSlide(id, (lpSliderState[id]||0) + dir);
}
// Auto-play handled on publish side

// ── Card Carousel ─────────────────────────────────────────────
const lpCarouselState = {};
function lpCarouselStep(id, dir) {
  const track = document.getElementById('lpct_'+id);
  if (!track) return;
  const cards  = track.querySelectorAll('.lp-carousel-card');
  const cols   = parseInt(track.closest('.lp-carousel')?.dataset?.cols||3);
  const max    = Math.max(0, cards.length - cols);
  const cur    = lpCarouselState[id] || 0;
  const next   = Math.max(0, Math.min(max, cur + dir));
  lpCarouselState[id] = next;
  const cardW  = cards[0]?.offsetWidth + 20 || 300;
  track.style.transform = `translateX(-${next * cardW}px)`;
}

// ── Templates Tab (inside builder) ──────────────────────────
let tplTabLoaded = false;
let builderTemplates = [];
let builderTplCatFilter = 'all';

async function loadBuilderTemplates() {
  tplTabLoaded = true;
  const grid    = document.getElementById('builderTplGrid');
  const loading = document.getElementById('builderTplLoading');
  const catBar  = document.getElementById('builderTplCats');
  if (!grid) return;
  try {
    const res  = await fetch('<?= APP_URL ?>/templates.php?action=list');
    const data = await res.json();
    loading.style.display = 'none';
    builderTemplates = data.templates || [];
    // Build cat buttons
    const cats = [...new Set(builderTemplates.map(t=>t.category))];
    cats.forEach(c => {
      const btn = document.createElement('button');
      btn.className = 'btn btn-secondary btn-sm';
      btn.style.cssText = 'font-size:.65rem;padding:3px 8px;';
      btn.textContent = c.replace('_',' ');
      btn.onclick = () => builderFilterTpl(c, btn);
      catBar.appendChild(btn);
    });
    renderBuilderTplGrid(builderTemplates);
  } catch(e) {
    loading.textContent = 'Failed to load templates.';
  }
}

function builderFilterTpl(cat, btn) {
  builderTplCatFilter = cat;
  document.querySelectorAll('#builderTplCats button').forEach(b => b.style.fontWeight='400');
  if (btn) btn.style.fontWeight = '700';
  const filtered = cat === 'all' ? builderTemplates : builderTemplates.filter(t=>t.category===cat);
  renderBuilderTplGrid(filtered);
}

function renderBuilderTplGrid(list) {
  const grid = document.getElementById('builderTplGrid');
  if (!grid) return;
  grid.innerHTML = list.map(t => `
    <div style="display:flex;align-items:center;gap:8px;padding:8px;border-radius:8px;border:1.5px solid var(--g100);background:#fff;cursor:pointer;transition:.1s;"
         onmouseover="this.style.borderColor='var(--br5)'" onmouseout="this.style.borderColor='var(--g100)'"
         onclick="loadBuilderTemplate(${t.id})">
      <div style="width:32px;height:32px;border-radius:6px;background:${t.thumbnail_color||'#2563eb'}22;display:flex;align-items:center;justify-content:center;font-size:1rem;flex-shrink:0;">${t.thumbnail_emoji||'📄'}</div>
      <div style="min-width:0;">
        <div style="font-size:.75rem;font-weight:700;color:var(--g800);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escAI(t.name)}</div>
        <div style="font-size:.65rem;color:var(--g400);">${escAI(t.category||'')}</div>
      </div>
    </div>`).join('');
}

async function loadBuilderTemplate(id) {
  if (!confirm('Load this template? Current blocks will be replaced.')) return;
  try {
    const res  = await fetch(`<?= APP_URL ?>/templates.php?action=get&id=${id}`);
    const data = await res.json();
    if (data.ok && data.page_data) {
      pushUndo();
      try {
        const tplBlocks = JSON.parse(data.page_data) || [];
        // Assign fresh IDs
        blocks = tplBlocks.map(b => ({ ...b, id: uid() }));
        render();
        markDirty();
        const ind = document.getElementById('saveInd');
        if (ind) { const old=ind.innerHTML; ind.style.color='#16a34a'; ind.innerHTML='✓ Template loaded'; setTimeout(()=>{ind.innerHTML=old;ind.style.color='';},2000); }
      } catch(err) {
        console.error('Template load error:', err);
        alert('Failed to load template: ' + err.message);
      }
      // Switch back to widgets tab
      document.querySelector('.pb-stab').click();
    }
  } catch(e) { alert('Failed to load template.'); }
}

// ── Saved Components ─────────────────────────────────────────
let savedComponents = JSON.parse(localStorage.getItem('lp_saved_components_<?= $account_id ?>') || '[]');

function saveComponent(id) {
  const b = blocks.find(x=>x.id===id);
  if (!b) return;
  const name = prompt('Name this component:', b.type.replace(/_/g,' '));
  if (!name) return;
  const comp = { ...JSON.parse(JSON.stringify(b)), _savedName: name, _savedAt: Date.now() };
  savedComponents.unshift(comp);
  localStorage.setItem('lp_saved_components_<?= $account_id ?>', JSON.stringify(savedComponents.slice(0,50)));
  const ind = document.getElementById('saveInd');
  if (ind) { const old=ind.innerHTML; ind.innerHTML='💾 Component saved'; setTimeout(()=>{ind.innerHTML=old;},1400); }
}

function renderSavedComponents() {
  const list = document.getElementById('savedComponentsList');
  if (!list) return;
  if (!savedComponents.length) {
    list.innerHTML = '<div style="text-align:center;padding:20px;color:var(--g400);font-size:.72rem;">No saved components yet.<br>Select a block → click 💾 in its toolbar.</div>';
    return;
  }
  list.innerHTML = savedComponents.map((c,i) => `
    <div style="display:flex;align-items:center;gap:8px;padding:8px;border-radius:8px;border:1.5px solid var(--g100);background:#fff;">
      <div style="flex:1;min-width:0;">
        <div style="font-size:.75rem;font-weight:700;color:var(--g800);">${escAI(c._savedName||c.type)}</div>
        <div style="font-size:.65rem;color:var(--g400);">${c.type}</div>
      </div>
      <button onclick="insertSavedComponent(${i})" style="padding:4px 8px;border-radius:6px;border:1.5px solid var(--br5);background:#eff6ff;color:var(--br6);font-size:.65rem;font-weight:700;cursor:pointer;">Insert</button>
      <button onclick="deleteSavedComponent(${i})" style="padding:4px 6px;border-radius:6px;border:1.5px solid #fca5a5;background:#fef2f2;color:#dc2626;font-size:.65rem;cursor:pointer;">✕</button>
    </div>`).join('');
}

function insertSavedComponent(idx) {
  const c = savedComponents[idx];
  if (!c) return;
  pushUndo();
  const newB = { ...JSON.parse(JSON.stringify(c)), id: uid() };
  delete newB._savedName; delete newB._savedAt;
  const insertIdx = selectedId ? blocks.findIndex(b=>b.id===selectedId)+1 : blocks.length;
  blocks.splice(insertIdx, 0, newB);
  render(); selectBlock(newB.id); markDirty();
}

function deleteSavedComponent(idx) {
  savedComponents.splice(idx, 1);
  localStorage.setItem('lp_saved_components_<?= $account_id ?>', JSON.stringify(savedComponents));
  renderSavedComponents();
}

// ── Scroll Animations ─────────────────────────────────────────────
(function() {
  if (!('IntersectionObserver' in window)) return;
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('animated'); obs.unobserve(e.target); }
    });
  }, { threshold: 0.15 });
  function observeAnimated() {
    document.querySelectorAll('.lp-animate:not(.animated),.lp-animate-left:not(.animated),.lp-animate-scale:not(.animated)').forEach(el => obs.observe(el));
  }
  observeAnimated();
  // Re-observe after renders
  const origRender = window.render;
  if (origRender) { window.render = function(){ origRender(); setTimeout(observeAnimated, 100); }; }
})();

/* ═══════════════════════════════════════════════════════════════
   v3: Media Library + Stock Images + Copy/Paste
═══════════════════════════════════════════════════════════════ */
let mediaLoaded = false;
let clipboard   = null;

const UPLOAD_URL = '<?= APP_URL ?>/upload.php';
const UPLOAD_CSRF = '<?= csrf_token() ?>';

// ── Media Library ─────────────────────────────────────────────
async function loadMediaLibrary() {
  const grid = document.getElementById('mediaGrid');
  const hint = document.getElementById('mediaHint');
  const load = document.getElementById('mediaLoading');
  if (!grid) return;
  mediaLoaded = true;
  hint.style.display = 'none';
  load.style.display = '';
  try {
    const res  = await fetch(`${UPLOAD_URL}?action=list`);
    const data = await res.json();
    load.style.display = 'none';
    if (data.ok && data.assets && data.assets.length) {
      renderMediaGrid(data.assets.map(a => ({ thumb:a.url, url:a.url, desc:a.filename })));
    } else {
      hint.style.display = '';
      hint.textContent = 'No uploads yet. Upload an image or search stock photos.';
    }
  } catch(e) {
    load.style.display = 'none';
    hint.style.display = '';
  }
}

async function searchStock() {
  const q = document.getElementById('stockSearchQ')?.value.trim();
  if (!q) return;
  const grid = document.getElementById('mediaGrid');
  const load = document.getElementById('mediaLoading');
  const hint = document.getElementById('mediaHint');
  grid.innerHTML = '';
  hint.style.display = 'none';
  load.style.display = '';
  try {
    const res  = await fetch(`${UPLOAD_URL}?action=unsplash&q=${encodeURIComponent(q)}`);
    const data = await res.json();
    load.style.display = 'none';
    if (data.ok && data.photos.length) {
      renderMediaGrid(data.photos.map(p => ({ thumb:p.thumb, url:p.url, desc:p.desc })));
    } else {
      hint.style.display = '';
      hint.textContent = 'No results found.';
    }
  } catch(e) {
    load.style.display = 'none';
  }
}

function renderMediaGrid(photos) {
  const grid = document.getElementById('mediaGrid');
  grid.innerHTML = photos.map((p,i) =>
    `<div onclick="insertMediaImage('${escAttrAI(p.url)}')"
       style="aspect-ratio:4/3;border-radius:6px;overflow:hidden;cursor:pointer;border:2px solid transparent;transition:.1s;"
       onmouseover="this.style.borderColor='var(--br5)'" onmouseout="this.style.borderColor='transparent'">
       <img src="${escAttrAI(p.thumb)}" alt="${escAttrAI(p.desc||'')}" loading="lazy"
            style="width:100%;height:100%;object-fit:cover;">
    </div>`
  ).join('');
}

function insertMediaImage(url) {
  // If a block is selected and supports image, set its src
  if (selectedId) {
    const b = blocks.find(x=>x.id===selectedId);
    if (b) {
      if (b.type === 'image') { ub(selectedId,'src',url); return; }
      if (b.type === 'two_col') { ub(selectedId,'imgUrl',url); return; }
      if (b.type === 'hero_section') { ub(selectedId,'bgImage',url); return; }
    }
  }
  // Otherwise insert a new image block
  pushUndo();
  const nb = defaultBlock('image');
  nb.src = url;
  blocks.push(nb);
  render();
  selectBlock(nb.id);
  markDirty();
}

async function uploadMediaFile(input) {
  const file = input.files[0];
  if (!file) return;
  const grid = document.getElementById('mediaGrid');
  const load = document.getElementById('mediaLoading');
  const hint = document.getElementById('mediaHint');
  load.style.display = '';
  const fd = new FormData();
  fd.append('action','image');
  fd.append('_csrf',UPLOAD_CSRF);
  fd.append('file',file);
  try {
    const res  = await fetch(UPLOAD_URL, {method:'POST',body:fd});
    const data = await res.json();
    load.style.display = 'none';
    if (data.ok) {
      // Prepend to grid
      const div = document.createElement('div');
      div.innerHTML = `<div onclick="insertMediaImage('${escAttrAI(data.url)}')"
         style="aspect-ratio:4/3;border-radius:6px;overflow:hidden;cursor:pointer;border:2px solid var(--br5);">
         <img src="${escAttrAI(data.url)}" style="width:100%;height:100%;object-fit:cover;">
      </div>`;
      grid.prepend(div.firstChild);
      hint.style.display = 'none';
    } else {
      alert('Upload failed: '+(data.error||'Unknown error'));
    }
  } catch(e) {
    load.style.display = 'none';
    alert('Upload failed. Please try again.');
  }
  input.value = '';
}

// ── Copy / Paste ──────────────────────────────────────────────
document.addEventListener('keydown', e => {
  const tag  = document.activeElement.tagName;
  const edit = tag==='INPUT'||tag==='TEXTAREA'||document.activeElement.getAttribute('contenteditable')==='true';
  if (edit) return;

  if ((e.ctrlKey||e.metaKey) && e.key==='c') {
    if (selectedId) {
      clipboard = JSON.parse(JSON.stringify(blocks.find(b=>b.id===selectedId)));
      // Brief visual feedback
      const ind = document.getElementById('saveInd');
      if (ind) { const old=ind.innerHTML; ind.innerHTML='📋 Block copied'; setTimeout(()=>{ind.innerHTML=old;},1200); }
    }
  }
  if ((e.ctrlKey||e.metaKey) && e.key==='v') {
    if (clipboard) {
      pushUndo();
      const copy = JSON.parse(JSON.stringify(clipboard));
      copy.id = uid();
      const idx = selectedId ? blocks.findIndex(b=>b.id===selectedId)+1 : blocks.length;
      blocks.splice(idx,0,copy);
      render();
      selectBlock(copy.id);
      markDirty();
    }
  }
});

</script>
<!-- Save as Template modal -->
<div id="saveTplModal" style="display:none;position:fixed;inset:0;z-index:2000;background:rgba(15,23,42,.6);display:none;align-items:center;justify-content:center;">
  <div style="background:#fff;border-radius:14px;padding:24px;width:100%;max-width:400px;box-shadow:0 20px 60px rgba(0,0,0,.25);">
    <div style="font-size:.95rem;font-weight:800;color:#0f172a;margin-bottom:16px;">Save as Template</div>
    <div style="margin-bottom:12px;">
      <label style="font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;display:block;margin-bottom:4px;">Template Name *</label>
      <input type="text" id="stplName" class="sp-in" placeholder="e.g. My Lead Gen Page" style="width:100%;padding:8px 10px;">
    </div>
    <div style="margin-bottom:12px;">
      <label style="font-size:.68rem;font-weight:700;color:#64748b;text-transform:uppercase;display:block;margin-bottom:4px;">Category</label>
      <select id="stplCat" class="sp-sel" style="width:100%;">
        <option value="general">General</option>
        <option value="lead_gen">Lead Generation</option>
        <option value="webinar">Webinar</option>
        <option value="product_launch">Product Launch</option>
        <option value="booking">Booking</option>
        <option value="promotion">Promotion</option>
        <option value="saas">SaaS</option>
        <option value="app">App</option>
        <option value="event">Event</option>
      </select>
    </div>
    <div style="display:flex;gap:8px;margin-top:18px;">
      <button onclick="closeSaveTemplate()" style="flex:1;padding:9px;border-radius:8px;border:1.5px solid #e2e8f0;background:#fff;font-size:.78rem;font-weight:700;cursor:pointer;color:#475569;">Cancel</button>
      <button onclick="doSaveTemplate()" style="flex:1;padding:9px;border-radius:8px;border:none;background:#2563eb;color:#fff;font-size:.78rem;font-weight:700;cursor:pointer;" id="stplSaveBtn">Save Template</button>
    </div>
  </div>
</div>

<script>
function openSaveTemplate() {
  const modal = document.getElementById('saveTplModal');
  modal.style.display = 'flex';
  // Pre-fill name from page title
  const title = document.getElementById('pageTitle')?.value || '';
  document.getElementById('stplName').value = title;
  document.getElementById('stplName').focus();
}
function closeSaveTemplate() {
  document.getElementById('saveTplModal').style.display = 'none';
}
async function doSaveTemplate() {
  const name = document.getElementById('stplName').value.trim();
  const cat  = document.getElementById('stplCat').value;
  if (!name) { document.getElementById('stplName').focus(); return; }

  const btn = document.getElementById('stplSaveBtn');
  btn.disabled = true; btn.textContent = '⏳ Saving…';

  const fd = new FormData();
  fd.append('action',    'save');
  fd.append('_csrf',     document.getElementById('csrfToken').value);
  fd.append('name',      name);
  fd.append('category',  cat);
  fd.append('page_data', JSON.stringify(blocks));
  fd.append('emoji',     '📄');
  fd.append('color',     '#2563eb');

  try {
    const res  = await fetch('<?= APP_URL ?>/templates.php', { method:'POST', body:fd });
    const data = await res.json();
    if (data.ok) {
      closeSaveTemplate();
      // Brief success flash
      const ind = document.getElementById('saveInd');
      if (ind) { const old = ind.innerHTML; ind.innerHTML = '✅ Template saved!'; setTimeout(()=>{ ind.innerHTML=old; }, 2500); }
    } else {
      alert('Failed to save template: ' + (data.error || 'Unknown error'));
    }
  } catch(e) {
    alert('Save failed. Please try again.');
  }
  btn.disabled = false; btn.textContent = 'Save Template';
}
document.getElementById('saveTplModal').addEventListener('click', function(e) {
  if (e.target === this) closeSaveTemplate();
});
</script>

<?php if (ai_enabled()): ?>
<script>
// ═══════════════════════════════════════════════════════════════
//  LeadPro Page Builder — AI Content Generator (Phase 9)
// ═══════════════════════════════════════════════════════════════

const AI_CONTENT_URL  = '<?= APP_URL ?>/ai_content.php';
const AI_CONTENT_CSRF = '<?= csrf_token() ?>';
const AI_CAMPAIGN_NAME = <?= json_encode($page ? ($page['campaign_name'] ?? '') : ($campaign['name'] ?? '')) ?>;

// ── Build a compact context summary of current page blocks ────
function buildPageContext() {
  const icons = {headline:'H1',subheadline:'H2',paragraph:'P',bullet_list:'LIST',
    cta_button:'CTA',lead_form:'FORM',testimonial:'QUOTE',offer_banner:'BANNER',
    trust_badges:'BADGES',pricing:'PRICE',faq:'FAQ',reviews:'REVIEWS',appointment:'BOOK'};
  return blocks.slice(0,8).map(b => {
    const type = b.type;
    let preview = b.text || b.title || b.headline || b.quote || '';
    if (!preview && b.items && b.items.length) preview = b.items[0];
    if (!preview && b.badges && b.badges.length) preview = b.badges[0];
    return { type, preview: String(preview).slice(0,60) };
  }).filter(x => x.preview);
}

// ── Main entry: called by ✨ button onclick ───────────────────
async function aiGenField(blockId, widgetType, field) {
  const btnEl  = document.getElementById(`aibtn_${blockId}_${field}`);
  const optsEl = document.getElementById(`aiopts_${blockId}_${field}`);
  if (!btnEl || !optsEl) return;

  // Show spinner
  btnEl.disabled = true;
  btnEl.innerHTML = `<span class="ai-spinner"></span> Generating…`;
  optsEl.style.display = 'none';
  optsEl.innerHTML = '';

  // Get current value from the block
  const b = blocks.find(x => x.id === blockId);
  const currentValue = b ? (b[field] || '') : '';

  // Collect context
  const pageTitle   = document.getElementById('pageTitle')?.value || '';
  const pageContext = JSON.stringify(buildPageContext());
  const blockIndex  = blocks.findIndex(x => x.id === blockId);

  const fd = new FormData();
  fd.append('action',        'generate');
  fd.append('_csrf',         AI_CONTENT_CSRF);
  fd.append('widget_type',   widgetType);
  fd.append('field',         field);
  fd.append('current_value', String(currentValue).slice(0, 200));
  fd.append('campaign_name', AI_CAMPAIGN_NAME);
  fd.append('page_title',    pageTitle);
  fd.append('block_index',   blockIndex);
  fd.append('page_context',  pageContext);

  try {
    const res  = await fetch(AI_CONTENT_URL, { method:'POST', body:fd });
    const data = await res.json();

    if (!data.ok) {
      btnEl.innerHTML = '✨ Generate';
      btnEl.disabled  = false;
      // Show error inline
      optsEl.innerHTML = `<div style="font-size:.68rem;color:#dc2626;padding:4px 0;">${escAI(data.error || 'Generation failed.')}</div>`;
      optsEl.style.display = '';
      return;
    }

    renderAIOptions(blockId, widgetType, field, data.data, b);

  } catch(e) {
    btnEl.innerHTML = '✨ Generate';
    btnEl.disabled  = false;
    optsEl.innerHTML = `<div style="font-size:.68rem;color:#dc2626;padding:4px 0;">Network error. Please try again.</div>`;
    optsEl.style.display = '';
  }

  btnEl.innerHTML = '✨ Regenerate';
  btnEl.disabled  = false;
}

// ── Render AI options as clickable suggestion pills ───────────
function renderAIOptions(blockId, widgetType, field, data, block) {
  const optsEl = document.getElementById(`aiopts_${blockId}_${field}`);
  if (!optsEl) return;

  let html = '';

  // ── Multi-option responses (options array) ──
  if (data.options && Array.isArray(data.options)) {
    data.options.forEach((opt, i) => {
      html += `<button class="ai-opt" onclick="applyAIOption('${escAttrAI(blockId)}','${escAttrAI(field)}',${i},${escAttrAI(JSON.stringify(opt))},'single')">${escAI(opt)}</button>`;
    });
  }

  // ── Single text response ──
  else if (data.text) {
    html += `<button class="ai-opt" onclick="applyAIOption('${escAttrAI(blockId)}','${escAttrAI(field)}',0,${escAttrAI(JSON.stringify(data.text))},'single')">${escAI(data.text)}</button>`;
  }

  // ── Array items (bullet list, pricing features) ──
  else if (data.items && Array.isArray(data.items)) {
    // items could be strings OR objects (faq, reviews)
    const isObjects = data.items.length > 0 && typeof data.items[0] === 'object';
    if (isObjects) {
      // FAQ or Reviews — show a summary + apply-all button
      const preview = data.items.slice(0,2).map(item => {
        if (item.q) return escAI(item.q.slice(0,50));
        if (item.text) return `★${item.stars} — ${escAI(item.text.slice(0,40))}`;
        return '';
      }).join('<br>');
      html += `<div style="font-size:.7rem;color:#64748b;padding:4px 0;line-height:1.5;">${preview}${data.items.length > 2 ? '<br>…' : ''}</div>`;
      html += `<button class="ai-opt" style="background:#f5f3ff;border-color:#a78bfa;" onclick="applyAIOption('${escAttrAI(blockId)}','${escAttrAI(field)}',0,${escAttrAI(JSON.stringify(data.items))},'array_obj')">Apply all ${data.items.length} items →</button>`;
    } else {
      // String items (bullet list, pricing features) — show all + apply-all
      const preview = data.items.slice(0,3).map(i => `• ${escAI(String(i).slice(0,50))}`).join('<br>');
      html += `<div style="font-size:.7rem;color:#64748b;padding:4px 0;line-height:1.6;">${preview}${data.items.length > 3 ? '<br>…' : ''}</div>`;
      html += `<button class="ai-opt" style="background:#f0fdf4;border-color:#86efac;" onclick="applyAIOption('${escAttrAI(blockId)}','${escAttrAI(field)}',0,${escAttrAI(JSON.stringify(data.items))},'array_str')">Apply all ${data.items.length} items →</button>`;
    }
  }

  // ── Testimonial (quote + suggested author/role) ──
  else if (data.quote) {
    html += `<button class="ai-opt" onclick="applyAIOption('${escAttrAI(blockId)}','${escAttrAI(field)}',0,${escAttrAI(JSON.stringify(data.quote))},'testimonial_full',${escAttrAI(JSON.stringify(data))})">"${escAI(data.quote.slice(0,100))}…"<br><span style="font-size:.66rem;color:#7c3aed;">— ${escAI(data.suggested_author||'')} · Apply quote + name + role</span></button>`;
  }

  if (!html) {
    html = `<div style="font-size:.68rem;color:#94a3b8;padding:4px 0;">No suggestions generated. Try again.</div>`;
  }

  optsEl.innerHTML = html;
  optsEl.style.display = '';
}

// ── Apply a selected AI suggestion to the block ───────────────
function applyAIOption(blockId, field, idx, valueJson, mode, extraJson) {
  const b = blocks.find(x => x.id === blockId);
  if (!b) return;

  let value;
  try { value = JSON.parse(valueJson); } catch(e) { value = valueJson; }

  if (mode === 'single') {
    ub(blockId, field, value);
    // Also update textarea/input in settings panel so it reflects the value
    syncSettingField(blockId, field, value);

  } else if (mode === 'array_str') {
    // String array (bullet list items, pricing features)
    ub(blockId, field, value);
    syncSettingField(blockId, field, value.join('\n'));

  } else if (mode === 'array_obj') {
    // Object array (faq items, review items)
    ub(blockId, field, value);
    // Sync the JSON textarea
    const ta = document.querySelector(`#aiopts_${blockId}_${field}`);
    // Re-render settings to refresh textarea
    renderBS(b);

  } else if (mode === 'testimonial_full') {
    // Apply quote + suggested author + role
    ub(blockId, 'quote', value);
    syncSettingField(blockId, 'quote', value);
    if (extraJson) {
      let extra;
      try { extra = JSON.parse(extraJson); } catch(e) { extra = null; }
      if (extra) {
        if (extra.suggested_author) { ub(blockId, 'author', extra.suggested_author); }
        if (extra.suggested_role)   { ub(blockId, 'role',   extra.suggested_role); }
      }
    }
    renderBS(b);
  }

  // Flash the block on canvas
  const blockEl = document.querySelector(`.pb-block[data-id="${blockId}"]`);
  if (blockEl) {
    blockEl.style.outline = '2px solid #7c3aed';
    setTimeout(() => { blockEl.style.outline = ''; }, 800);
  }

  // Hide options after applying
  const optsEl = document.getElementById(`aiopts_${blockId}_${field}`);
  if (optsEl) {
    setTimeout(() => {
      optsEl.style.display = 'none';
      optsEl.innerHTML = '';
    }, 400);
  }

  markDirty();
}

// ── Sync the visible input/textarea in the settings panel ─────
function syncSettingField(blockId, field, value) {
  // Find input/textarea inside bsBody that updates this field
  // They use oninput="ub('blockId','field',this.value)"
  const body = document.getElementById('bsBody');
  if (!body) return;
  const inputs = body.querySelectorAll('input, textarea');
  inputs.forEach(el => {
    const handler = el.getAttribute('oninput') || el.getAttribute('onchange') || '';
    if (handler.includes(`'${field}'`)) {
      el.value = Array.isArray(value) ? value.join('\n') : value;
    }
  });
}

// Tab switcher for tabs widget (builder canvas)
function lpTab(tid, idx, btn) {
  // Update buttons
  document.querySelectorAll(`[id^="tbb_${tid}_"]`).forEach((b,i) => {
    b.style.borderBottomColor = i===idx ? '#2563eb' : 'transparent';
    b.style.fontWeight        = i===idx ? '700' : '500';
    b.style.color             = i===idx ? '#2563eb' : '#64748b';
  });
  // Update panes
  document.querySelectorAll(`[id^="tbp_${tid}_"]`).forEach((p,i) => {
    p.style.display = i===idx ? '' : 'none';
  });
}

function escAI(s) {
  return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function escAttrAI(s) {
  return String(s||'').replace(/\\/g,'\\\\').replace(/'/g,"\\'").replace(/"/g,'&quot;');
}
</script>
<?php endif; ?>
</body>
</html>
