<?php
/**
 * LeadPro — SEO & AI Auditor
 * Account-owner level tool
 */
require_once __DIR__ . '/config/auth.php';
$user = require_permission('auditor', 'run');

// Account owner restriction — not for regular team members
if (!is_super_admin() && ($user['role_id'] ?? 0) > 2) {
    $_SESSION['flash'] = ['type'=>'error','msg'=>'SEO Auditor is available to account owners only.'];
    header('Location: ' . APP_URL . '/index.php'); exit;
}

$account_id = (int)($user['account_id'] ?? 0);
$page_title = 'SEO Auditor';
$active_nav = 'seo_auditor';

$api_key_set = (bool)ps('ai_api_key', '');
$ai_model    = ps('ai_model', 'meta-llama/llama-3.3-70b-instruct:free');

// Recent audits
$recent_audits = [];
$db_sa = db();
if ($db_sa->query("SHOW TABLES LIKE 'seo_audits'")->num_rows > 0) {
    $recent_audits = db_fetch_all(
        'SELECT id, url, score_overall, created_at FROM seo_audits
         WHERE account_id = ? ORDER BY id DESC LIMIT 8',
        'i', $account_id
    );
}

include __DIR__ . '/layouts/header.php';
?>
<!-- CSRF + app URL meta tags — read by app.js -->
<meta name="csrf-token" content="<?= csrf_token() ?>">
<meta name="app-url" content="<?= APP_URL ?>">

<style>
  /* Scope auditor styles inside .auditor-wrap to avoid LMS conflicts */
  .auditor-wrap .page-shell { background:transparent; padding:0; }
  .auditor-wrap .hero { background:transparent; padding:0; margin-bottom:24px; display:block; }
  .auditor-wrap .hero-panel { background:var(--bg-card,#fff); border:1.5px solid var(--border,#e2e8f0); border-radius:14px; padding:24px; }
  .auditor-wrap .hero-copy { display:none; }
  .auditor-wrap .hero-badges { display:none; }
  .auditor-wrap .hero-stat-grid { margin-top:16px; }
  .auditor-wrap .report-shell { background:transparent; padding:0; }
  .auditor-wrap .status-card { border-radius:12px; margin-bottom:20px; }
  .auditor-wrap .is-hidden { display:none !important; }
  @keyframes spin { to { transform:rotate(360deg); } }
</style>

<div class="page-header" style="margin-bottom:20px;">
    <div>
        <div class="page-title"><i class="hgi hgi-stroke hgi-search-visual"></i> SEO & AI Auditor</div>
        <div class="page-subtitle">Technical SEO · Analytics · Competitor benchmarking · Content lab</div>
    </div>
    <?php if ($recent_audits): ?>
    <a href="<?= APP_URL ?>/seo_audits.php" class="btn btn-outline btn-sm">
        <i class="hgi hgi-stroke hgi-clock-01"></i> Audit History
    </a>
    <?php endif; ?>
</div>

<?php if (!$api_key_set): ?>
<div class="alert alert-warning" style="margin-bottom:20px;">
    <i class="hgi hgi-stroke hgi-alert-02"></i>
    OpenRouter API key not configured — AI analysis will be skipped.
    <?php if (is_super_admin()): ?>
    <a href="<?= APP_URL ?>/settings.php?tab=ai" style="font-weight:600;margin-left:8px;">Configure →</a>
    <?php endif; ?>
</div>
<?php endif; ?>

<div style="display:grid;grid-template-columns:1fr 280px;gap:20px;align-items:start;">

  <!-- Auditor tool (original app.js DOM) -->
  <div class="auditor-wrap">
    <div class="page-shell">
      <header class="hero">
        <div class="hero-panel">
          <!-- form id="audit-form" is what app.js binds to -->
          <form id="audit-form"
                class="audit-form"
                data-endpoint="<?= APP_URL ?>/auditor/run.php"
                novalidate>

            <div class="stack-field">
              <label for="url" class="input-label">Website or page URL</label>
              <div class="input-row">
                <input id="url" name="url" type="url"
                  placeholder="https://example.com"
                  autocomplete="url" required>
                <button type="submit" <?= !$api_key_set ? 'disabled title="Configure API key first"' : '' ?>>
                  Run audit
                </button>
              </div>
            </div>

            <div class="stack-field">
              <label for="competitor_urls" class="input-label">
                Competitor URLs <span class="field-note">Optional</span>
              </label>
              <textarea id="competitor_urls" name="competitor_urls" rows="3"
                placeholder="https://competitor-one.com&#10;https://competitor-two.com&#10;https://competitor-three.com"></textarea>
              <p class="helper-text">Up to 3 competitor pages for keyword and depth benchmarking.</p>
            </div>

            <div class="stack-field inline-fields">
              <div>
                <label for="crawl_scope" class="input-label">Audit scope</label>
                <select id="crawl_scope" name="crawl_scope">
                  <option value="page" selected>Single page</option>
                  <option value="site">Whole site crawl</option>
                </select>
              </div>
              <div>
                <label for="crawl_limit" class="input-label">Page limit</label>
                <input id="crawl_limit" name="crawl_limit" type="number" min="5" max="25" value="12">
              </div>
            </div>

            <p id="form-feedback" class="form-feedback">
              Model: <?= h($ai_model) ?>
            </p>
          </form>

          <div class="hero-stat-grid">
            <?php foreach ([
              ['Technical SEO',          'Titles, meta, H1, canonicals, robots, speed signals'],
              ['Analytics Integrity',    'GA4, GTM, Meta Pixel, events, conversion gaps'],
              ['Competitor Benchmark',   'Keyword gaps, content depth, authority proxies'],
              ['Ecommerce & CX',         'Product, checkout, pricing, friction points'],
              ['Chatbot & Lead Capture', 'Chat, forms, booking, follow-up readiness'],
              ['Content Lab',            'Keywords, page priorities, draft copy prompts'],
            ] as [$t,$d]): ?>
            <article class="hero-stat">
              <strong><?= $t ?></strong>
              <span><?= $d ?></span>
            </article>
            <?php endforeach; ?>
          </div>
        </div>
      </header>

      <!-- Loading card — app.js shows/hides these -->
      <section id="loading-card" class="status-card is-hidden" aria-live="polite">
        <div class="loading-pulse"></div>
        <div>
          <p class="status-label">Audit in progress</p>
          <h2 id="loading-message">Fetching the target URL and inspecting the page source.</h2>
          <p class="status-copy">Competitor and funnel checks add extra requests — deeper audits take longer.</p>
        </div>
      </section>

      <!-- Save Report bar — shown after audit completes, hidden until then -->
      <div id="save-report-bar" style="display:none;align-items:center;gap:12px;background:#fff;border:1.5px solid #e2e8f0;border-radius:12px;padding:14px 18px;margin-bottom:16px;flex-wrap:wrap;">
        <div style="flex:1;min-width:0;">
          <div style="font-size:.8rem;font-weight:700;color:#0f172a;margin-bottom:2px;">&#128197; Audit complete — save to keep this report</div>
          <div style="font-size:.74rem;color:#64748b;">Saving generates a shareable public link you can send to clients.</div>
        </div>
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
          <span id="save-report-status" style="font-size:.8rem;"></span>
          <button id="save-report-btn" class="btn btn-primary btn-sm" style="white-space:nowrap;">
            &#128190; Save Report
          </button>
        </div>
      </div>

      <!-- Report shell — app.js populates these divs -->
      <section id="report-shell" class="report-shell is-hidden">
        <div id="report-summary"></div>
        <div id="report-ai"></div>
        <div id="report-content-lab"></div>
        <div id="report-modules"></div>
        <div id="report-metrics"></div>
        <div id="report-issues"></div>
      </section>
    </div>
  </div>

  <!-- Sidebar -->
  <div>
    <?php if ($recent_audits): ?>
    <div class="card" style="margin-bottom:16px;">
      <div class="card-header">
        <div class="card-title">Recent Audits</div>
        <a href="<?= APP_URL ?>/seo_audits.php" style="font-size:.72rem;color:var(--brand-500);">View all →</a>
      </div>
      <div style="padding:0;">
        <?php foreach ($recent_audits as $ra):
          $s  = (int)$ra['score_overall'];
          $sc = $s >= 70 ? 'badge-success' : ($s >= 40 ? 'badge-warning' : 'badge-danger');
          $host = parse_url($ra['url'], PHP_URL_HOST);
          $path = parse_url($ra['url'], PHP_URL_PATH) ?: '/';
        ?>
        <a href="<?= APP_URL ?>/seo_audits.php?id=<?= (int)$ra['id'] ?>"
           style="display:flex;align-items:center;gap:8px;padding:8px 14px;border-bottom:1px solid var(--gray-100);text-decoration:none;color:inherit;">
          <span class="badge <?= $sc ?> badge-sm" style="flex-shrink:0;"><?= $s ?></span>
          <div style="flex:1;min-width:0;">
            <div style="font-size:.74rem;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= h($host) ?></div>
            <div style="font-size:.67rem;color:var(--gray-400);"><?= format_dt($ra['created_at'],'d M H:i') ?></div>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

    <div class="card">
      <div class="card-header"><div class="card-title">About the Auditor</div></div>
      <div class="card-body" style="font-size:.78rem;line-height:1.7;color:var(--gray-500);">
        <p>Runs deterministic SEO checks combined with AI strategy from OpenRouter.</p>
        <p style="margin-top:8px;">Uses your configured AI model: <strong style="color:var(--gray-700);"><?= h($ai_model) ?></strong></p>
        <p style="margin-top:8px;">Click <strong>Save Report</strong> after the audit completes to store results and get a shareable client link.</p>
      </div>
    </div>
  </div>

</div>

<script src="<?= APP_URL ?>/assets/auditor/app.js" defer></script>
<?php include __DIR__ . '/layouts/footer.php'; ?>