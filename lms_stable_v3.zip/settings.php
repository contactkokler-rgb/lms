<?php
require_once __DIR__ . '/config/auth.php';
$user = require_permission('settings', 'view');
$account_id = (int)($user['account_id'] ?? 0);
$is_super   = is_super_admin();

$page_title = 'Settings';
$active_nav = 'settings';

$account = $account_id ? db_fetch('SELECT * FROM accounts WHERE id = ?', 'i', $account_id) : null;

// Load platform settings for super admin
$platform_settings = [];
if ($is_super) {
    require_once __DIR__ . '/config/ai.php';
    $rows = db_fetch_all('SELECT `key`, `value` FROM platform_settings');
    foreach ($rows as $r) $platform_settings[$r['key']] = $r['value'];
}

// Helper: get a platform setting value (from loaded array, not DB)
function pss(array &$ps, string $key, string $default = ''): string {
    return isset($ps[$key]) && $ps[$key] !== '' ? $ps[$key] : $default;
}

// Full grouped timezone list
$timezones_grouped = [
    'UTC' => ['UTC'],
    'Americas' => [
        'America/New_York','America/Chicago','America/Denver','America/Phoenix',
        'America/Los_Angeles','America/Anchorage','America/Adak',
        'America/Toronto','America/Vancouver','America/Winnipeg','America/Halifax',
        'America/St_Johns','America/Sao_Paulo','America/Argentina/Buenos_Aires',
        'America/Bogota','America/Lima','America/Santiago','America/Caracas',
        'America/Mexico_City','America/Monterrey',
    ],
    'Europe' => [
        'Europe/London','Europe/Dublin','Europe/Lisbon',
        'Europe/Paris','Europe/Berlin','Europe/Amsterdam','Europe/Brussels',
        'Europe/Madrid','Europe/Rome','Europe/Zurich','Europe/Vienna',
        'Europe/Warsaw','Europe/Prague','Europe/Budapest','Europe/Stockholm',
        'Europe/Copenhagen','Europe/Oslo','Europe/Helsinki','Europe/Athens',
        'Europe/Bucharest','Europe/Sofia','Europe/Kiev','Europe/Moscow',
        'Europe/Istanbul',
    ],
    'Asia' => [
        'Asia/Dubai','Asia/Karachi','Asia/Kolkata','Asia/Colombo',
        'Asia/Dhaka','Asia/Kathmandu','Asia/Yangon',
        'Asia/Bangkok','Asia/Jakarta','Asia/Ho_Chi_Minh',
        'Asia/Singapore','Asia/Kuala_Lumpur','Asia/Manila',
        'Asia/Shanghai','Asia/Hong_Kong','Asia/Taipei',
        'Asia/Seoul','Asia/Tokyo',
        'Asia/Riyadh','Asia/Tehran','Asia/Kabul','Asia/Tashkent',
        'Asia/Almaty','Asia/Colombo',
    ],
    'Africa' => [
        'Africa/Casablanca','Africa/Abidjan','Africa/Lagos',
        'Africa/Cairo','Africa/Johannesburg','Africa/Nairobi',
        'Africa/Addis_Ababa','Africa/Khartoum',
    ],
    'Pacific / Oceania' => [
        'Australia/Perth','Australia/Darwin','Australia/Adelaide',
        'Australia/Brisbane','Australia/Sydney','Australia/Melbourne',
        'Pacific/Auckland','Pacific/Fiji','Pacific/Honolulu','Pacific/Guam',
    ],
];
// Flat list for validation
$timezones = ['UTC'];
foreach ($timezones_grouped as $group => $tzs) {
    if ($group !== 'UTC') foreach ($tzs as $tz) $timezones[] = $tz;
}
$timezones = array_unique($timezones);

// ── Actions ──────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { http_response_code(403); die('CSRF'); }
    $act = $_POST['action'] ?? '';

    // ── Profile update (any user) ────────────────────────────
    if ($act === 'update_profile') {
        $first = trim($_POST['first_name'] ?? '');
        $last  = trim($_POST['last_name']  ?? '');
        $phone = trim($_POST['phone']      ?? '');
        $desig = trim($_POST['designation']?? '');

        if (!$first || !$last) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'First and last name are required.'];
        } else {
            db_query(
                'UPDATE users SET first_name=?, last_name=?, phone=?, designation=?, updated_at=NOW() WHERE id=?',
                'ssssi', $first, $last, $phone, $desig, $user['id']
            );
            audit('user.profile_updated', "user:{$user['id']}");
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Profile updated.'];
        }
    }

    // ── Password change (any user) ───────────────────────────
    elseif ($act === 'change_password') {
        $current  = $_POST['current_password'] ?? '';
        $new_pass = $_POST['new_password']      ?? '';
        $confirm  = $_POST['confirm_password']  ?? '';

        $fresh = db_fetch('SELECT password_hash FROM users WHERE id = ?', 'i', $user['id']);
        if (!password_verify($current, $fresh['password_hash'])) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Current password is incorrect.'];
        } elseif (strlen($new_pass) < 8) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'New password must be at least 8 characters.'];
        } elseif ($new_pass !== $confirm) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'New passwords do not match.'];
        } else {
            $hash = password_hash($new_pass, PASSWORD_BCRYPT, ['cost' => 10]);
            db_query('UPDATE users SET password_hash=?, updated_at=NOW() WHERE id=?', 'si', $hash, $user['id']);
            audit('user.password_changed', "user:{$user['id']}");
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Password changed successfully.'];
        }
    }

    // ── Reminder settings ─────────────────────────────────────
    elseif ($act === 'save_reminder_settings' && $account_id && can('settings', 'edit')) {
        require_once __DIR__ . '/config/reminders.php';
        $cfg = [
            'enabled'        => isset($_POST['reminders_enabled']) ? 1 : 0,
            'no_contact_hrs' => max(1, min(168, (int)($_POST['no_contact_hrs'] ?? 24))),
            'overdue_hrs'    => max(1, min(336, (int)($_POST['overdue_hrs'] ?? 48))),
            'inactive_days'  => max(1, min(90,  (int)($_POST['inactive_days'] ?? 7))),
        ];
        reminder_save_settings($account_id, $cfg);
        audit('account.reminder_settings_updated', "account:{$account_id}");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Reminder settings saved.'];
        header('Location: ' . APP_URL . '/settings.php?tab=reminders'); exit;
    }

    // ── Account settings (account_owner only) ────────────────
    elseif ($act === 'update_account' && $account_id && can('settings', 'edit')) {
        $name     = trim($_POST['account_name'] ?? '');
        $email    = trim($_POST['account_email'] ?? '');
        $phone    = trim($_POST['account_phone'] ?? '');
        $website  = trim($_POST['account_website'] ?? '');
        $tz       = in_array($_POST['timezone'] ?? '', $timezones) ? $_POST['timezone'] : 'UTC';

        if (!$name || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Name and a valid email are required.'];
        } else {
            db_query(
                'UPDATE accounts SET name=?, email=?, phone=?, website=?, timezone=?, updated_at=NOW() WHERE id=?',
                'sssssi', $name, $email, $phone, $website, $tz, $account_id
            );
            audit('account.updated', "account:{$account_id}");
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Account settings saved.'];
            $account = db_fetch('SELECT * FROM accounts WHERE id = ?', 'i', $account_id); // refresh
        }
    }

    // ── AI / Platform settings (super admin only) ────────────
    // ── SMTP Test (AJAX) ─────────────────────────────────────
    if ($act === 'smtp_test' && $is_super) {
        header('Content-Type: application/json');
        require_once __DIR__ . '/config/mailer.php';
        $test_to = trim($_POST['test_email'] ?? '');
        if (!filter_var($test_to, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(['ok'=>false,'error'=>'Invalid email address']); exit;
        }
        $app_name = ps('app_name','LeadPro');
        $body     = email_wrap_html(
            "This is a test email from {$app_name}.\n\nIf you received this, your SMTP settings are working correctly.",
            "SMTP Test — {$app_name}"
        );
        $result = send_email($test_to, $test_to, "SMTP Test — {$app_name}", $body);
        echo json_encode($result); exit;
    }

    elseif ($act === 'save_ai_settings' && $is_super) {
        require_once __DIR__ . '/config/ai.php';
        $map = [
            'ai_enabled'          => (isset($_POST['ai_enabled'])          ? '1' : '0'),
            // Groq
            'groq_api_key'        => substr(trim($_POST['groq_api_key']    ?? ''), 0, 200),
            'groq_model'          => substr(trim($_POST['groq_model']      ?? 'llama-3.3-70b-versatile'), 0, 150),
            // Gemini
            'gemini_api_key'      => substr(trim($_POST['gemini_api_key']  ?? ''), 0, 200),
            'gemini_model'        => substr(trim($_POST['gemini_model']    ?? 'gemini-2.0-flash-lite'), 0, 150),
            // OpenRouter (fallback)
            'ai_api_key'          => substr(trim($_POST['ai_api_key']      ?? ''), 0, 200),
            'ai_model'            => substr(trim($_POST['ai_model']        ?? 'meta-llama/llama-3.3-70b-instruct:free'), 0, 150),
            // Feature flags
            'ai_scoring_enabled'  => (isset($_POST['ai_scoring_enabled'])  ? '1' : '0'),
            'ai_qualify_enabled'  => (isset($_POST['ai_qualify_enabled'])  ? '1' : '0'),
            'ai_email_enabled'    => (isset($_POST['ai_email_enabled'])    ? '1' : '0'),
            'ai_summary_enabled'  => (isset($_POST['ai_summary_enabled'])  ? '1' : '0'),
            'ai_enrich_enabled'   => (isset($_POST['ai_enrich_enabled'])   ? '1' : '0'),
            'ai_followup_enabled'    => (isset($_POST['ai_followup_enabled'])    ? '1' : '0'),
            'ai_smart_reply_enabled' => (isset($_POST['ai_smart_reply_enabled']) ? '1' : '0'),
            'ai_auto_analyze'        => (isset($_POST['ai_auto_analyze'])        ? '1' : '0'),
            'ai_smart_reply_enabled' => (isset($_POST['ai_smart_reply_enabled']) ? '1' : '0'),
            'ai_auto_analyze'        => (isset($_POST['ai_auto_analyze'])        ? '1' : '0'),
            // Step 1: Auto-analyze + Business Context
            'ai_auto_analyze'     => (isset($_POST['ai_auto_analyze'])     ? '1' : '0'),
            'ai_business_name'    => substr(trim($_POST['ai_business_name']    ?? ''), 0, 200),
            'ai_business_type'    => substr(trim($_POST['ai_business_type']    ?? ''), 0, 100),
            'ai_business_location'=> substr(trim($_POST['ai_business_location']?? ''), 0, 200),
            'ai_services_offered' => substr(trim($_POST['ai_services_offered'] ?? ''), 0, 500),
            'ai_pricing_info'     => substr(trim($_POST['ai_pricing_info']     ?? ''), 0, 500),
            'ai_business_context' => substr(trim($_POST['ai_business_context'] ?? ''), 0, 1000),
        ];
        foreach ($map as $k => $v) ai_save_setting($k, $v);
        audit('platform.ai_updated', 'user:' . $user['id']);
        $_SESSION['flash'] = ['type'=>'success','msg'=>'AI settings saved.'];

    } elseif ($act === 'test_ai' && $is_super) {
        require_once __DIR__ . '/config/ai.php';
        $result = ai_call([
            ['role' => 'system', 'content' => 'You are a helpful assistant. Respond with JSON only.'],
            ['role' => 'user',   'content' => 'Reply with exactly this JSON and nothing else: {"status":"ok","ping":"pong"}'],
        ], 40);
        if ($result['ok']) {
            $used = isset($result['model']) ? $result['model'] : 'unknown';
            $_SESSION['flash'] = ['type'=>'success','msg'=>'✓ Connection successful — model: ' . $used . ' · ' . ($result['tokens'] ?? 0) . ' tokens'];
        } else {
            $_SESSION['flash'] = ['type'=>'error','msg'=>$result['error']];
        }

    // ── Platform / White-label (super admin only) ────────────
    } elseif ($act === 'save_platform' && $is_super) {
        $str_fields = [
            'app_name','app_tagline','app_logo_url','app_favicon_url',
            'app_badge_text','app_support_url','app_docs_url','app_status_url',
            'brand_color_500','brand_color_600','brand_color_50','brand_color_100','brand_color_700',
            'sidebar_bg','sidebar_text','sidebar_active_bg',
            'font_body','font_mono',
            'footer_copyright','footer_credits_text','footer_credits_url',
            'login_headline','login_subtext',
            'login_hero_color_from','login_hero_color_to',
            'meta_description','meta_og_image',
            'maintenance_message',
            'smtp_host','smtp_port','smtp_user','smtp_pass',
            'smtp_from_name','smtp_from_email','smtp_encryption',
        ];
        // Textarea fields (allow longer content)
        $text_fields = ['custom_css', 'footer_links'];
        // Checkbox fields
        $bool_fields = [
            'footer_show_credits',
            'feature_kanban','feature_reports','feature_spam',
            'feature_scoring','feature_domains','feature_api',
            'maintenance_mode','registration_open',
        ];

        foreach ($str_fields as $k) {
            $v = substr(trim($_POST[$k] ?? ''), 0, 500);
            ps_save($k, $v);
        }
        foreach ($text_fields as $k) {
            $v = trim($_POST[$k] ?? '');
            // Validate footer_links as JSON if non-empty
            if ($k === 'footer_links' && $v !== '') {
                $test = json_decode($v, true);
                if (!is_array($test)) $v = ''; // reset bad JSON
            }
            ps_save($k, substr($v, 0, 8000));
        }
        foreach ($bool_fields as $k) {
            ps_save($k, isset($_POST[$k]) ? '1' : '0');
        }

        audit('platform.settings_updated', 'user:' . $user['id']);
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Platform settings saved successfully.'];
        header('Location: ' . APP_URL . '/settings.php?tab=platform'); exit;
    }

    $tab_redirect = isset($_POST['_tab']) ? '?tab=' . urlencode($_POST['_tab']) : '';
    header('Location: ' . APP_URL . '/settings.php' . $tab_redirect); exit;
}

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);

// Reload fresh user data
$user = auth_user();

include __DIR__ . '/layouts/header.php';
?>

<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type'] ?> mb-4" data-auto-dismiss><?= $flash['msg'] ?></div>
<?php endif; ?>

<div class="page-header">
    <div>
        <h1 class="page-title">Settings</h1>
        <p class="page-subtitle">Manage your profile and account preferences</p>
    </div>
</div>

<div>
    
    <div class="tabs mb-6">
        <?php
          $tab = $_GET['tab'] ?? 'profile';
          $tabs_nav = [
            ['profile',  'Profile',         'user-circle-02'],
            ['password', 'Password',        'lock-password'],
          ];
          if ($account && can('settings', 'edit')) {
            $tabs_nav[] = ['account',   'Account',   'account-setting-03'];
            $tabs_nav[] = ['reminders', 'Reminders', 'notification-01'];
          }
          if ($is_super) {
            $tabs_nav[] = ['ai',       'AI & API',  'ai-chip'];
            $tabs_nav[] = ['platform', 'Platform',  'three-d-view'];
          }
          foreach ($tabs_nav as [$tid, $tlabel, $icon]):
            $active = $tab === $tid;
        ?>

        
        <a href="?tab=<?= $tid ?>" class="tab <?= $active ? 'active' : '' ?>">
            <i class="hgi hgi-stroke hgi-<?= $icon ?>"></i>
            <?= $tlabel ?>
        </a>
        <?php endforeach; ?>
    </div>
    
    <?php if ($tab === 'profile'): ?>
    <form method="POST" class="card">
        <div class="card-header">
            <div class="card-title">Your Profile</div>
            <div class="card-subtitle">How you appear to teammates</div>
        </div>
        <div class="card-body">                        

            <?= csrf_field() ?>
            <input type="hidden" name="action" value="update_profile">
            <div class="grid grid-cols-2 gap-x-4">
                <div class="form-group">
                    <label class="form-label form-label-required">First Name</label>
                    <input name="first_name" type="text" class="form-control" value="<?= h($user['first_name']) ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label form-label-required">Last Name</label>
                    <input name="last_name" type="text" class="form-control" value="<?= h($user['last_name']) ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control" value="<?= h($user['email']) ?>" disabled>
                    <div class="form-help">Contact a Super Admin to change your email.</div>
                </div>
                <div class="form-group">
                    <label class="form-label">Phone</label>
                    <input name="phone" type="tel" class="form-control" value="<?= h($user['phone'] ?? '') ?>" placeholder="+1 234 567 8900">
                </div>
                <div class="form-group" style="grid-column:1/-1;">
                    <label class="form-label">Job Title / Designation</label>
                    <input name="designation" type="text" class="form-control" value="<?= h($user['designation'] ?? '') ?>" placeholder="e.g. Sales Manager">
                </div>
            </div>
            
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-primary"><i class="hgi hgi-stroke hgi-tick-02"></i>Save Profile</button>
        </div>
    </form>
    
    <div class="card">
        <div class="card-header">
            <div class="card-title">Session Info</div>
        </div>
        <div class="card-body">
            <div class="card-row">
                <div>Last Login</div>
                <div><?= $user['last_login_at'] ? format_dt($user['last_login_at']) : 'Never' ?></div>
            </div>
            <div class="card-row">
                <div>Last IP</div>
                <div><?= h($user['last_login_ip'] ?? '—') ?></div>
            </div>
            <div class="card-row">
                <div>Member Since</div>
                <div><?= format_dt($user['created_at'], 'd M Y') ?></div>
            </div>
        </div>
    </div>
    
    <?php elseif ($tab === 'password'): ?>
    <form method="POST" class="card">
        <div class="card-header">
            <div class="card-title">Change Password</div>
            <div class="card-subtitle">Use a strong password you don't use elsewhere</div>
        </div>
        <div class="card-body">
        
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="change_password">
            <div class="form-group">
                <label class="form-label form-label-required">Current Password</label>
                <input name="current_password" type="password" class="form-control" required autocomplete="current-password">
            </div>
            <div class="form-group">
                <label class="form-label form-label-required">New Password</label>
                <input name="new_password" id="new_password" type="password" class="form-control" minlength="8" required autocomplete="new-password">
                <div class="form-help">Minimum 8 characters.</div>
            </div>
            <div class="form-group">
                <label class="form-label form-label-required">Confirm New Password</label>
                <input name="confirm_password" id="confirm_password" type="password" class="form-control" required autocomplete="new-password">
            </div>

            <!-- Password strength meter -->
            <div>
                <div class="progress mb-1">
                    <div class="progressbar" id="strengthBar" style="height:100%;width:0;transition:width .25s,background .25s;"></div>
                </div>
                <div id="strengthLabel"></div>
            </div>

        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-primary"><i class="hgi hgi-stroke hgi-tick-02"></i>Change Password</button>
        </div>
    </form>

    <script>
        document.getElementById('new_password').addEventListener('input', function() {
            const v = this.value;
            let score = 0;
            if (v.length >= 8) score++;
            if (v.length >= 12) score++;
            if (/[A-Z]/.test(v)) score++;
            if (/[0-9]/.test(v)) score++;
            if (/[^A-Za-z0-9]/.test(v)) score++;
            const colors = ['#ef4444', '#f97316', '#eab308', '#22c55e', '#16a34a'];
            const labels = ['Very weak', 'Weak', 'Fair', 'Strong', 'Very strong'];
            const bar = document.getElementById('strengthBar');
            const label = document.getElementById('strengthLabel');
            bar.style.width = ((score / 5) * 100) + '%';
            bar.style.background = colors[score - 1] || '#e2e8f0';
            label.textContent = score > 0 ? labels[score - 1] : '';
        });
    </script>
    
    
    <?php elseif ($tab === 'account' && $account): ?>
    <form method="POST" class="card">
        <div class="card-header">
            <div class="card-title">Account Settings</div>
            <div class="card-subtitle">
                <?= h($account['name']) ?> &nbsp;&bull;&nbsp; <span class="badge"><?= ucfirst($account['plan']) ?></span>
                &nbsp;&bull;&nbsp; <span class="badge" title="Current timezone"><i class="hgi hgi-stroke hgi-clock-01"></i><?= h($account['timezone'] ?? 'UTC') ?></span>
            </div>
        </div>
        <div class="card-body">
            
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="update_account">
            <div class="grid grid-cols-2 gap-x-4">
                <div class="form-group">
                    <label class="form-label">Account Name <span style="color:#ef4444">*</span></label>
                    <input name="account_name" type="text" class="form-control" value="<?= h($account['name']) ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Billing Email <span style="color:#ef4444">*</span></label>
                    <input name="account_email" type="email" class="form-control" value="<?= h($account['email']) ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Phone</label>
                    <input name="account_phone" type="tel" class="form-control" value="<?= h($account['phone'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Website</label>
                    <input name="account_website" type="url" class="form-control" value="<?= h($account['website'] ?? '') ?>">
                </div>
                <div class="form-group" style="grid-column:1/-1;">
                    <label class="form-label">Timezone</label>
                    <select name="timezone" class="form-control">
                        <?php
                        $current_tz = $account['timezone'] ?? 'UTC';
                        foreach ($timezones_grouped as $group => $tzs):
                          if ($group === 'UTC'):
                        ?>
                        <option value="UTC" <?= $current_tz === 'UTC' ? 'selected' : '' ?>>UTC — Coordinated Universal Time</option>
                        <?php else: ?>
                        <optgroup label="── <?= $group ?>">
                            <?php foreach ($tzs as $tz):
                                try {
                                  $dt = new DateTime('now', new DateTimeZone($tz));
                                  $offset = $dt->format('P');
                                  $label  = 'UTC' . $offset . ' — ' . str_replace(['_','/'], [' ','  /  '], $tz);
                                } catch (Exception $e) { continue; }
                            ?>
                            <option value="<?= $tz ?>" <?= $current_tz === $tz ? 'selected' : '' ?>><?= $label ?></option>
                            <?php endforeach; ?>
                        </optgroup>
                        <?php endif; endforeach; ?>
                    </select>
                    <div class="form-help">All timestamps across your account will display in this timezone.</div>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-primary"><i class="hgi hgi-stroke hgi-tick-02"></i>Save Account Settings</button>
        </div>
    </form>

    <!-- Account info panel -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">Plan & Status</div>
        </div>
        <div class="card-body">
            <div class="card-row">
                <div>Current Plan</div>
                <div class="badge badge-purple"><?= ucfirst($account['plan']) ?></div>
            </div>
            <div class="card-row">
                <div>Status</div>
                <div class="badge badge-green"><span class="badge-dot"></span><?= ucfirst($account['status']) ?></div>
            </div>
            <div class="card-row">
                <div>Account Since</div>
                <div><?= format_dt($account['created_at'], 'd M Y') ?></div>
            </div>
            <?php if ($account['plan_expires_at']): ?>
            <div class="card-row">
                <?= strtotime($account['plan_expires_at']) < time() ? '<i class="hgi hgi-stroke hgi-calendar-03"></i>Plan expired on ' : '<i class="hgi hgi-stroke hgi-calendar-03"></i>Plan expires on ' ?>
                <div><?= format_dt($account['plan_expires_at'], 'd M Y') ?></div>
            </div>
            <?php endif; ?>
            <div class="card-row">
                <div><?= strtotime($account['plan_expires_at']) < time() ? 'Plan expired on ' : 'Plan expires on ' ?></div>
                <div><i class="hgi hgi-stroke hgi-calendar-03"></i><?= format_dt($account['plan_expires_at'], 'd M Y') ?></div>
            </div>
        </div>
    </div>
    
    
    <?php elseif ($tab === 'ai' && $is_super): ?>
    
    <!-- Header banner -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">
                <i class="hgi hgi-stroke hgi-ai-chip"></i>
                AI Intelligence Engine
            </div>
            <div class="card-subtitle">Multi-Provider · Auto-Failover</div>
        </div>
        <div class="card-body">
            <div>
                Add one or more free AI providers. LeadPro tries them in priority order — if one hits its rate limit it automatically falls over to the next. <strong>All three together give ~15,600 free requests/day.</strong>
            </div>
            <div>
                <?php foreach ([
                    ['bg-b2','Groq',        '#10b981', '14,400/day',   '1st'],
                    ['bg-b3','Gemini',      '#60a5fa', '1,000/day',    '2nd'],
                    ['bg-b4','OpenRouter',  '#a78bfa', '200/day',      '3rd'],
                  ] as [$ic,$nm,$clr,$lim,$ord]):
                ?>
                <div class="card-row">
                    <i class="hgi hgi-stroke hgi-ai-chip card-icon <?= $ic ?>"></i>
                    <div class="flex-1"><?= $ic ?> <?= $nm ?><div class="text-muted"><?= $ord ?> priority</div></div>                    
                    <div><?= $lim ?> free</div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <form method="POST" class="card">
        <div class="card-header">
            <div class="card-title">Provider Configuration</div>
            <div class="card-subtitle">Add API keys below — all free, no credit card required</div>
        </div>
        <div class="card-body">
            
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save_ai_settings">
            <input type="hidden" name="_tab" value="ai">

            <!-- Master toggle -->
            <div class="flex items-center justify-between gap-3 mb-4">
                <div>
                    <div class="text-md font-semibold">Enable AI Features</div>
                    <div class="text-muted text-sm">Master switch — applies platform-wide to all accounts</div>
                </div>
                <label class="toggle toggle-sm">
                    <input type="checkbox" name="ai_enabled" id="aiToggle" <?= ($platform_settings['ai_enabled'] ?? '0') === '1' ? 'checked' : '' ?>>
                    <div class="toggle-track">
                        <div class="toggle-thumb"></div>
                    </div>
                </label>
            </div>
            <style>
                #aiToggle:checked+span {
                    background: var(--brand-500) !important
                }

                #aiToggle:checked+span+span {
                    transform: translateX(20px)
                }
            </style>

            <!-- ── GROQ ── -->
            <div class="bg-b2-10 p-4 rounded mb-4">
                <div class="flex justify-between">
                    <div>
                        <div class="text-md font-semibold mb-1">Groq</div>
                        <div>1st priority · 14,400 req/day · No credit card</div>
                    </div>
                    <a href="https://console.groq.com/keys" target="_blank" class="btn btn-white btn-sm">Get free key<i class="hgi hgi-stroke hgi-arrow-right-02"></i></a>
                </div>
                <div class="flex gap-3 mt-3">
                    <div class="form-group flex-1">
                        <label class="form-label">API Key</label>
                        <div class="input-wrapper has-icon-right">
                            <input type="password" name="groq_api_key" id="groqKey" class="form-control" value="<?= h($platform_settings['groq_api_key'] ?? '') ?>" placeholder="gsk_...">
                            <div class="input-icon-right text-xs" type="button" onclick="toggleKey('groqKey',this)">Show</div>
                        </div>
                    </div>
                    <div class="form-group ">
                        <label class="form-label">Model</label>
                        <select name="groq_model" class="form-control">
                            <?php foreach ([
                                'llama-3.3-70b-versatile' => 'Llama 3.3 70B (best)',
                                'llama-3.1-8b-instant'    => 'Llama 3.1 8B (fastest)',
                                'gemma2-9b-it'            => 'Gemma 2 9B',
                                'mixtral-8x7b-32768'      => 'Mixtral 8x7B',
                              ] as $gm => $gl):
                            ?>
                            <option value="<?= $gm ?>" <?= ($platform_settings['groq_model'] ?? 'llama-3.3-70b-versatile') === $gm ? 'selected' : '' ?>><?= $gl ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>

            <!-- ── GEMINI ── -->
            <div class="bg-b3-10 p-4 rounded mb-4">
                <div class="flex justify-between">
                    <div>                        
                        <div class="text-md font-semibold mb-1">Google Gemini</div>
                        <div>2nd priority · 1,000 req/day · No credit card</div>
                    </div>
                    <a href="https://aistudio.google.com/app/apikey" target="_blank" class="btn btn-white btn-sm">Get free key<i class="hgi hgi-stroke hgi-arrow-right-02"></i></a>
                </div>
                <div class="flex gap-3 mt-3">
                    <div class="form-group flex-1">
                        <label class="form-label">API Key</label>
                        <div class="input-wrapper has-icon-right">
                            <input type="password" name="gemini_api_key" id="geminiKey" class="form-control" value="<?= h($platform_settings['gemini_api_key'] ?? '') ?>" placeholder="AIza...">
                            <div class="input-icon-right text-xs" type="button" onclick="toggleKey('geminiKey',this)">Show</div>
                        </div>
                    </div>
                    <div class="form-group ">
                        <label class="form-label">Model</label>
                        <select name="gemini_model" class="form-control">
                            <?php foreach ([
                                'gemini-2.0-flash-lite' => 'Flash Lite · 1,000/day',
                                'gemini-2.0-flash'      => 'Flash 2.0 · 500/day',
                                'gemini-1.5-flash'      => 'Flash 1.5 · 1,500/day',
                              ] as $gm => $gl):
                            ?>
                            <option value="<?= $gm ?>" <?= ($platform_settings['gemini_model'] ?? 'gemini-2.0-flash-lite') === $gm ? 'selected' : '' ?>><?= $gl ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>

            <!-- ── OPENROUTER ── -->
            <div class="bg-b4-10 p-4 rounded mb-4">
                <div class="flex justify-between">
                    <div>
                        <div class="text-md font-semibold mb-1">OpenRouter</div>
                        <div>3rd priority · 200 req/day · 50+ free models</div>
                    </div>
                    <a href="https://openrouter.ai/keys" target="_blank" class="btn btn-white btn-sm">Get free key<i class="hgi hgi-stroke hgi-arrow-right-02"></i></a>
                </div>
                <div class="alert alert-warning mt-3 mb-4">
                    <span><i class="hgi hgi-stroke hgi-alert-02"></i>After getting your key, go to <a href="https://openrouter.ai/settings/privacy" target="_blank">openrouter.ai/settings/privacy</a> and enable <strong>"Allow free model endpoints"</strong> — otherwise free models are blocked.</span>
                </div>
                <div class="flex gap-3 mt-3">
                    <div class="form-group flex-1">
                        <label class="form-label">API Key</label>
                        <div style="position:relative;">
                            <input type="password" name="ai_api_key" id="orKey" class="form-control" value="<?= h($platform_settings['ai_api_key'] ?? '') ?>" placeholder="sk-or-v1-...">
                            <div class="input-icon-right text-xs" type="button" onclick="toggleKey('orKey',this)">Show</div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Model <a href="https://openrouter.ai/models?q=free" target="_blank" class="ml-2">Browse<i class="hgi hgi-stroke hgi-arrow-right-02"></i></a></label>
                        <input type="text" name="ai_model" class="form-control" value="<?= h($platform_settings['ai_model'] ?? 'meta-llama/llama-3.3-70b-instruct:free') ?>" placeholder="meta-llama/llama-3.3-70b-instruct:free">
                    </div>
                </div>
            </div>

            <!-- Feature toggles -->
            <hr>
            <div class="text-md font-semibold mb-3">AI Feature Toggles</div>
            <div class="grid grid-cols-4 gap-3">
                <?php foreach ([
                      ['ai_scoring_enabled',  'Lead Scoring',         '0–100 score · Cold/Warm/Hot'],
                      ['ai_qualify_enabled',  'Lead Qualification',   'Pipeline stage prediction'],
                      ['ai_email_enabled',    'Email Generation',     'Draft follow-up emails'],
                      ['ai_summary_enabled',  'Conversation Summary', 'Summarize comments & activity'],
                      ['ai_enrich_enabled',   'Data Enrichment',      'Clean & infer missing data'],
                      ['ai_followup_enabled',    'Follow-up Reminders',  'AI next-action suggestions'],
                      ['ai_smart_reply_enabled', 'Smart Reply System',   'Generate email replies from KB + send instantly'],
                      ['ai_auto_analyze',        'Auto-Analyze on Submit','Run AI analysis on every new lead automatically'],
                      ['ai_smart_reply_enabled', 'Smart Reply System',   'AI generates reply suggestions per lead'],
                      ['ai_auto_analyze',        'Auto-Analyze on Submit','Run AI on every new lead automatically'],
                      ['ai_auto_analyze',     'Auto-Analyze on Submit','Run AI on every new lead automatically'],
                    ] as [$key, $label, $desc]):
                ?>
                <label class="p-4 border-1 rounded border-grey-30 flex gap-3 toggle toggle-sm">
                    <input type="checkbox" name="<?= $key ?>" <?= ($platform_settings[$key] ?? '1') === '1' ? 'checked' : '' ?>>
                    <div class="toggle-track">
                        <div class="toggle-thumb"></div>
                    </div>
                    <div>
                        <div class="text-base font-semibold"><?= $label ?></div>
                        <div class="text-sm text-muted"><?= $desc ?></div>
                    </div>
                </label>
                <?php endforeach; ?>
            </div>

            <!-- Step 12: Business Context for AI -->
            <hr>
            
            <div class="text-md font-semibold">Business Context</div>
            <div class="text-muted text-sm mb-3">
                Help the AI understand your business so it generates accurate, relevant responses and analyses.
            </div>
            <div class="grid grid-cols-2 gap-x-4">
                <div class="form-group">
                    <label class="form-label">Business Name</label>
                    <input type="text" name="ai_business_name" class="input" value="<?= h($platform_settings['ai_business_name'] ?? '') ?>" placeholder="e.g. Smith Dental Clinic">
                </div>
                <div class="form-group">
                    <label class="form-label">Business Type</label>
                    <input type="text" name="ai_business_type" class="input" value="<?= h($platform_settings['ai_business_type'] ?? '') ?>" placeholder="e.g. Dental Clinic, Real Estate Agency, SaaS">
                </div>
                <div class="form-group">
                    <label class="form-label">Location</label>
                    <input type="text" name="ai_business_location" class="input" value="<?= h($platform_settings['ai_business_location'] ?? '') ?>" placeholder="e.g. London, UK">
                </div>
                <div class="form-group">
                    <label class="form-label">Services Offered</label>
                    <input type="text" name="ai_services_offered" class="input" value="<?= h($platform_settings['ai_services_offered'] ?? '') ?>" placeholder="e.g. Teeth whitening, Implants, Invisalign">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Pricing Information <span class="text-muted">(optional)</span></label>
                <input type="text" name="ai_pricing_info" class="input" value="<?= h($platform_settings['ai_pricing_info'] ?? '') ?>" placeholder="e.g. Consultations from £50, Whitening from £200">
            </div>
            <div class="form-group">
                <label class="form-label">Additional Context <span class="text-muted">(optional)</span></label>
                <textarea name="ai_business_context" class="textarea" rows="3" placeholder="Any other context the AI should know — opening hours, unique selling points, target audience, etc."><?= h($platform_settings['ai_business_context'] ?? '') ?></textarea>
            </div>

                
          
        </div>
        
        <div class="card-footer">
            <button type="submit" class="btn btn-primary"><i class="hgi hgi-stroke hgi-tick-02"></i>Save Settings</button>
            <button type="button" onclick="testAI()" class="btn btn-secondary" id="testAiBtn"><i class="hgi hgi-stroke hgi-play"></i>Test Connection</button>
        </div>
    </form>

    <!-- Hidden test form -->
    <form method="POST" id="testAiForm" style="display:none;">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="test_ai">
        <input type="hidden" name="_tab" value="ai">
    </form>

    <script>
        function toggleKey(id, btn) {
            var i = document.getElementById(id);
            i.type = i.type === 'password' ? 'text' : 'password';
            btn.textContent = i.type === 'password' ? 'Show' : 'Hide';
        }

        function testAI() {
            var btn = document.getElementById('testAiBtn');
            btn.textContent = 'Testing…';
            btn.disabled = true;
            document.getElementById('testAiForm').submit();
        }
    </script>
    
    <?php elseif ($tab === 'platform' && $is_super): ?>
    <form method="POST" id="platformForm">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save_platform">

        <!-- ── 1. Branding ── -->
        <div class="card">
            <div class="card-header justify-start">
                <div class="card-header-icon bg-b2-5">
                    <i class="hgi hgi-stroke hgi-stack-star"></i>
                </div>
                <div>
                    <div class="card-title">Branding & Identity</div>
                    <div class="card-subtitle">App name, logo, and display text</div>
                </div>
            </div>
            
            <div class="card-body">
                <div class="grid grid-cols-3 gap-x-3">
                    <div class="form-group">
                        <label class="form-label">App Name <span style="color:#ef4444">*</span></label>
                        <input name="app_name" type="text" class="form-control" maxlength="60" value="<?= h(pss($platform_settings,'app_name','LeadPro')) ?>" placeholder="LeadPro" required>
                        <div class="form-help">Shown in the browser tab, sidebar, emails, and login page.</div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Tagline</label>
                        <input name="app_tagline" type="text" class="form-control" maxlength="120" value="<?= h(pss($platform_settings,'app_tagline','Turn leads into customers')) ?>" placeholder="Turn leads into customers">
                        <div class="form-help">Short description shown on marketing/auth pages.</div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Logo URL</label>
                        <input name="app_logo_url" type="url" class="form-control" value="<?= h(pss($platform_settings,'app_logo_url','')) ?>" placeholder="https://cdn.example.com/logo.svg">
                        <div class="form-help">Leave blank to use the default icon + text. SVG or PNG, max 200×40px.</div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Favicon URL</label>
                        <input name="app_favicon_url" type="url" class="form-control" value="<?= h(pss($platform_settings,'app_favicon_url','')) ?>" placeholder="https://cdn.example.com/favicon.ico">
                        <div class="form-help">.ico or 32×32 PNG. Shown in browser tabs.</div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Sidebar Badge Text</label>
                        <input name="app_badge_text" type="text" class="form-control" maxlength="20" value="<?= h(pss($platform_settings,'app_badge_text','Beta')) ?>" placeholder="Beta">
                        <div class="form-help">Small pill next to logo. Leave blank to hide.</div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">SEO Meta Description</label>
                        <input name="meta_description" type="text" class="form-control" maxlength="200" value="<?= h(pss($platform_settings,'meta_description','')) ?>" placeholder="Smart lead management CRM">
                    </div>
                </div>
            </div>
        </div>

        <!-- ── 2. Colours & Theme ── -->
        <div class="card">
            <div class="card-header justify-start">
                <div class="card-header-icon bg-b2-5">
                    <i class="hgi hgi-stroke hgi-paint-board"></i>
                </div>
                <div>
                    <div class="card-title">Colours & Theme</div>
                    <div class="card-subtitle">Brand palette, sidebar, and custom CSS</div>
                </div>
            </div>
            
            <div class="card-body">

                <div class="grid grid-cols-3 gap-x-3">
                    <?php
                    $color_fields = [
                      ['brand_color_500',   'Brand Color',      '#00a5cf', 'Buttons, active nav, links'],
                      ['brand_color_600',   'Brand Color 2',    '#004e64', 'Button hover state'],
                      ['brand_color_50',    'Brand Color 3',    '#25a18e', 'Badge backgrounds, highlights'],
                      ['brand_color_100',   'Brand Color 4',    '#7ae582', 'Hover backgrounds'],
                      ['brand_color_700',   'Brand Color 5',    '#9fffcb', 'Active press state'],
                    ];
                    foreach ($color_fields as [$cfk, $cfl, $cfd, $cfs]):
                      $cfv = pss($platform_settings, $cfk, $cfd);
                    ?>
                    <div class="form-group">
                        <label class="form-label"><?= $cfl ?></label>
                        <div class="flex gap-2">
                            <label class="color-swatch" style="background:<?= h($cfv) ?>;" id="swatch_<?= $cfk ?>">
                                <input type="color" name="<?= $cfk ?>" value="<?= h($cfv) ?>" oninput="updateSwatch('<?= $cfk ?>',this.value)" onchange="updateSwatch('<?= $cfk ?>',this.value)">
                            </label>
                            <input type="text" class="form-control color-text" style="font-family:var(--font-mono);font-size:.75rem;" value="<?= h($cfv) ?>" maxlength="30" oninput="syncColor('<?= $cfk ?>',this.value)" id="txt_<?= $cfk ?>">
                        </div>
                        <div><?= $cfs ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <hr>
                <div class="grid grid-cols-3 gap-x-3">
                    <div class="form-group">
                        <label class="form-label">Sidebar Bg</label>
                        <div class="flex gap-2">
                            <label class="color-swatch" style="background:<?= h(pss($platform_settings,'sidebar_bg','#1e3a8a')) ?>;" id="swatch_sidebar_bg">
                                <input type="color" name="sidebar_bg" value="<?= h(pss($platform_settings,'sidebar_bg','#1e3a8a')) ?>" oninput="updateSwatch('sidebar_bg',this.value)" onchange="updateSwatch('sidebar_bg',this.value)">
                            </label>
                            <input type="text" class="form-control color-text" style="font-family:var(--font-mono);font-size:.75rem;" value="<?= h(pss($platform_settings,'sidebar_bg','#1e3a8a')) ?>" maxlength="30" oninput="syncColor('sidebar_bg',this.value)" id="txt_sidebar_bg">
                        </div>
                        <div>Sidebar Background</div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Sidebar Links</label>
                        <div class="flex gap-2">
                            <label class="color-swatch" style="background:<?= h(pss($platform_settings,'sidebar_text','#1e3a8a')) ?>;" id="swatch_sidebar_text">
                                <input type="color" name="sidebar_text" value="<?= h(pss($platform_settings,'sidebar_text','#1e3a8a')) ?>" oninput="updateSwatch('sidebar_text',this.value)" onchange="updateSwatch('sidebar_text',this.value)">
                            </label>
                            <input type="text" class="form-control color-text" style="font-family:var(--font-mono);font-size:.75rem;" value="<?= h(pss($platform_settings,'sidebar_text','#1e3a8a')) ?>" maxlength="30" oninput="syncColor('sidebar_text',this.value)" id="txt_sidebar_text">
                        </div>
                        <div>Sidebar Text</div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Sidebar Active Background</label>
                        <div class="flex gap-2">
                            <label class="color-swatch" style="background:<?= h(pss($platform_settings,'sidebar_active_bg','#1e3a8a')) ?>;" id="swatch_sidebar_active_bg">
                                <input type="color" name="sidebar_active_bg" value="<?= h(pss($platform_settings,'sidebar_active_bg','#1e3a8a')) ?>" oninput="updateSwatch('sidebar_active_bg',this.value)" onchange="updateSwatch('sidebar_active_bg',this.value)">
                            </label>
                            <input type="text" class="form-control color-text" style="font-family:var(--font-mono);font-size:.75rem;" value="<?= h(pss($platform_settings,'sidebar_active_bg','#1e3a8a')) ?>" maxlength="30" oninput="syncColor('sidebar_active_bg',this.value)" id="txt_sidebar_active_bg">
                        </div>
                        <div>Sidebar Active Background</div>
                    </div>

                </div>

                <hr>
                <div class="grid grid-cols-3 gap-x-3">
                    <div class="form-group">
                        <label class="form-label">Login Hero Gradient — From</label>
                        <div class="flex gap-2">
                            <label class="color-swatch" style="background:<?= h(pss($platform_settings,'login_hero_color_from','#1e3a8a')) ?>;" id="swatch_login_hero_color_from">
                                <input type="color" name="login_hero_color_from" value="<?= h(pss($platform_settings,'login_hero_color_from','#1e3a8a')) ?>" oninput="updateSwatch('login_hero_color_from',this.value)" onchange="updateSwatch('login_hero_color_from',this.value)">
                            </label>
                            <input type="text" class="form-control color-text" style="font-family:var(--font-mono);font-size:.75rem;" value="<?= h(pss($platform_settings,'login_hero_color_from','#1e3a8a')) ?>" maxlength="30" oninput="syncColor('login_hero_color_from',this.value)" id="txt_login_hero_color_from">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Login Hero Gradient — To</label>
                        <div class="flex gap-2">
                            <label class="color-swatch" style="background:<?= h(pss($platform_settings,'login_hero_color_to','#7c3aed')) ?>;" id="swatch_login_hero_color_to">
                                <input type="color" name="login_hero_color_to" value="<?= h(pss($platform_settings,'login_hero_color_to','#7c3aed')) ?>" oninput="updateSwatch('login_hero_color_to',this.value)" onchange="updateSwatch('login_hero_color_to',this.value)">
                            </label>
                            <input type="text" class="form-control color-text" style="font-family:var(--font-mono);font-size:.75rem;" value="<?= h(pss($platform_settings,'login_hero_color_to','#7c3aed')) ?>" maxlength="30" oninput="syncColor('login_hero_color_to',this.value)" id="txt_login_hero_color_to">
                        </div>
                    </div>
                </div>

                <!-- Typography -->
                <hr>
                <div class="grid grid-cols-2 gap-x-3">
                    <div class="form-group">
                        <label class="form-label">Body Font (Google Fonts)</label>
                        <input name="font_body" type="text" class="form-control" maxlength="80" value="<?= h(pss($platform_settings,'font_body','Sora')) ?>" placeholder="Sora">
                        <div class="form-help">Must be available on <a href="https://fonts.google.com" target="_blank">fonts.google.com</a>. E.g. Inter, DM Sans, Manrope</div>
                    </div>
                    <div class="form-group" >
                        <label class="form-label">Monospace Font (Google Fonts)</label>
                        <input name="font_mono" type="text" class="form-control" maxlength="80" value="<?= h(pss($platform_settings,'font_mono','JetBrains Mono')) ?>" placeholder="JetBrains Mono">
                        <div class="form-help">Used for code, IPs, reference numbers. E.g. Fira Code, Source Code Pro</div>
                    </div>
                </div>

                <!-- Custom CSS -->
                <div class="form-group">
                    <label class="form-label">Custom CSS</label>
                    <textarea name="custom_css" rows="6" class="form-control" style="font-family:var(--font-mono);font-size:.78rem;resize:vertical;"><?= h(pss($platform_settings,'custom_css','')) ?></textarea>
                    <div class="form-help">Injected into <code>&lt;head&gt;</code> on every page. Use with caution — can break layout.</div>
                </div>
            </div>
        </div>

        <!-- ── 3. Login Page ── -->
        <div class="card">
            <div class="card-header justify-start">
                <div class="card-header-icon bg-b2-5">
                    <i class="hgi hgi-stroke hgi-login-circle-01"></i>
                </div>
                <div>
                    <div class="card-title">Login Page</div>
                    <div class="card-subtitle">Hero copy and background</div>
                </div>
            </div>
                        
            <div class="card-body">
                <div class="grid grid-cols-2 gap-x-3">
                    <div class="form-group">
                        <label class="form-label">Hero Headline</label>
                        <textarea name="login_headline" rows="3" class="form-control" placeholder="Close more deals,&#10;faster."><?= h(pss($platform_settings,'login_headline',"Close more deals,\nfaster.")) ?></textarea>
                        <div class="form-help">Use line breaks for multi-line headlines. Shown on the left side of the login screen.</div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Hero Sub-text</label>
                        <textarea name="login_subtext" rows="3" class="form-control" placeholder="The all-in-one CRM for modern sales teams."><?= h(pss($platform_settings,'login_subtext','The all-in-one CRM for modern sales teams.')) ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <!-- ── 4. Footer & Copyright ── -->
        <div class="card">
            <div class="card-header justify-start">
                <div class="card-header-icon bg-b2-5">
                    <i class="hgi hgi-stroke hgi-information-square"></i>
                </div>
                <div>
                    <div class="card-title">Footer & Copyright</div>
                    <div class="card-subtitle">Branding credits and legal links</div>
                </div>
            </div>
                    
            <div class="card-body">
                <div class="grid grid-cols-2 gap-x-3">
                    <div class="form-group">
                        <label class="form-label">Copyright Text</label>
                        <input name="footer_copyright" type="text" class="form-control" maxlength="200" value="<?= h(pss($platform_settings,'footer_copyright','© {year} LeadPro. All rights reserved.')) ?>" placeholder="© {year} YourCompany. All rights reserved.">
                        <div class="form-help">Use <code>{year}</code> for the current year — it updates automatically.</div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Credits Text</label>
                        <input name="footer_credits_text" type="text" class="form-control" maxlength="100" value="<?= h(pss($platform_settings,'footer_credits_text','Powered by LeadPro')) ?>" placeholder="Powered by LeadPro">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Credits Link URL</label>
                        <input name="footer_credits_url" type="url" class="form-control" value="<?= h(pss($platform_settings,'footer_credits_url','')) ?>" placeholder="https://leadpro.app">
                        <div class="form-help">Clicking the credits text links here. Leave blank for no link.</div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Support URL</label>
                        <input name="app_support_url" type="url" class="form-control" value="<?= h(pss($platform_settings,'app_support_url','')) ?>" placeholder="https://support.yourdomain.com">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Documentation URL</label>
                        <input name="app_docs_url" type="url" class="form-control" value="<?= h(pss($platform_settings,'app_docs_url','')) ?>" placeholder="https://docs.yourdomain.com">
                    </div>
                </div>

                <!-- Show credits toggle -->
                <label class="flex gap-3 toggle toggle-sm my-3 w-full justify-between">
                    <div>
                        <div class="text-base font-semibold">Show "Powered by" credit</div>
                        <div class="text-sm text-muted">Display the credits text in the footer of every page.</div>
                    </div>
                    <div>
                        <input type="checkbox" name="footer_show_credits" <?= pss($platform_settings,'footer_show_credits','1') === '1' ? 'checked' : '' ?>>
                        <div class="toggle-track">
                            <div class="toggle-thumb"></div>
                        </div>
                    </div>
                </label>

                <!-- Footer links JSON -->
                <div class="form-group">
                    <label class="form-label">Extra Footer Links <span style="font-weight:400;color:var(--gray-400);">(JSON)</span></label>
                    <textarea name="footer_links" rows="4" class="form-control" style="font-family:var(--font-mono);font-size:.76rem;resize:vertical;" placeholder='[{"label":"Privacy","url":"https://..."},{"label":"Terms","url":"https://..."}]'><?= h(pss($platform_settings,'footer_links','')) ?></textarea>
                    <div class="form-help">
                        JSON array of <code>{"label": "...", "url": "..."}</code> objects.
                        These appear in the footer alongside the copyright text.
                    </div>
                </div>
            </div>
        </div>

        <!-- ── 5. Feature Flags ── -->
        <div class="card">
            <div class="card-header justify-start">
                <div class="card-header-icon bg-b2-5">
                    <i class="hgi hgi-stroke hgi-flag-03"></i>
                </div>
                <div>
                    <div class="card-title">Feature Flags</div>
                    <div class="card-subtitle">Enable or disable platform features for all accounts</div>
                </div>
            </div>
            <div class="card-body">
                <?php
                  $feature_flags = [
                    ['feature_kanban',   'Kanban Board',       'Visual pipeline board for all users'],
                    ['feature_reports',  'Reports & Analytics','Charts, funnels, attribution dashboards'],
                    ['feature_spam',     'Spam Protection',    'IP blocklist, honeypot, keyword filters'],
                    ['feature_scoring',  'Lead Scoring',       'Rule-based and AI lead scoring engine'],
                    ['feature_domains',  'Domain Management',  'Multi-domain form hosting & DNS verify'],
                    ['feature_api',      'API Access',         'Developer API and embed code'],
                  ];
                ?>
                <div class="grid grid-cols-4 gap-3">
                    <?php foreach ($feature_flags as [$fk,$fl,$fs]): ?>
                    <label class="p-4 border-1 rounded border-grey-30 flex gap-3 toggle toggle-sm">
                        <input type="checkbox" name="<?= $fk ?>" <?= pss($platform_settings,$fk,'1') === '1' ? 'checked' : '' ?>>
                        <div class="toggle-track">
                            <div class="toggle-thumb"></div>
                        </div>
                        <div>
                            <div class="text-base font-semibold"><?= $fl ?></div>
                            <div class="text-sm text-muted"><?= $fs ?></div>
                        </div>
                    </label>
                    <?php endforeach; ?>
                </div>
                
            </div>
        </div>
        
        <div class="alert alert-danger my-6">
            <div class="w-full">
                <div class="alert-header">
                    <i class="hgi hgi-stroke hgi-alert-02"></i>
                    <div class="alert-title flex-1">
                        <div class="alert-title">
                            <div>Maintenance Mode</div>
                            <div class="alert-subtitle">When enabled, all non-super-admin users see a maintenance message instead of the app.</div>
                        </div>
                    </div>
                    <label class="toggle toggle-sm">
                        <input type="checkbox" name="maintenance_mode" <?= pss($platform_settings,'maintenance_mode','0') === '1' ? 'checked' : '' ?>>
                        <div class="toggle-track">
                            <div class="toggle-thumb"></div>
                        </div>
                        <span class="ts"></span><span class="th"></span>
                    </label>
                </div>
                                
                <div class="form-group">
                    <label class="form-label">Maintenance Message</label>
                    <input name="maintenance_message" type="text" class="form-control" value="<?= h(pss($platform_settings,'maintenance_message','We are performing scheduled maintenance. We will be back shortly.')) ?>" placeholder="We are performing scheduled maintenance…">
                </div>
            </div>
        </div>

        <!-- ── 6. Email / SMTP ── -->
        <div class="card">
            <div class="card-header justify-start">
                <div class="card-header-icon bg-b2-5">
                    <i class="hgi hgi-stroke hgi-mail-01"></i>
                </div>
                <div>
                    <div class="card-title">Email / SMTP</div>
                    <div class="card-subtitle">Outbound mail for invitations and notifications</div>
                </div>
            </div>
            <div class="card-body">
                <div class="grid grid-cols-2 gap-x-4">
                    <div class="form-group">
                        <label class="form-label">SMTP Host</label>
                        <input name="smtp_host" type="text" class="form-control" value="<?= h(pss($platform_settings,'smtp_host','')) ?>" placeholder="smtp.mailgun.org">
                    </div>
                    <div class="form-group">
                        <label class="form-label">SMTP Port</label>
                        <input name="smtp_port" type="text" class="form-control" value="<?= h(pss($platform_settings,'smtp_port','587')) ?>" placeholder="587">
                    </div>
                    <div class="form-group">
                        <label class="form-label">SMTP Username</label>
                        <input name="smtp_user" type="text" class="form-control" autocomplete="off" value="<?= h(pss($platform_settings,'smtp_user','')) ?>" placeholder="apikey or username">
                    </div>
                    <div class="form-group">
                        <label class="form-label">SMTP Password</label>
                        <div class="input-wrapper has-icon-right">
                            <input name="smtp_pass" type="password" class="form-control" autocomplete="new-password" id="smtpPass" value="<?= h(pss($platform_settings,'smtp_pass','')) ?>" style="padding-right:52px;">
                            <div type="button" onclick="toggleKey('smtpPass',this)" class="input-icon-right text-xs text-muted font-normal">Show</div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">From Name</label>
                        <input name="smtp_from_name" type="text" class="form-control" maxlength="80" value="<?= h(pss($platform_settings,'smtp_from_name','LeadPro')) ?>" placeholder="LeadPro">
                    </div>
                    <div class="form-group">
                        <label class="form-label">From Email</label>
                        <input name="smtp_from_email" type="email" class="form-control" value="<?= h(pss($platform_settings,'smtp_from_email','')) ?>" placeholder="noreply@yourdomain.com">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Encryption</label>
                        <select name="smtp_encryption" class="form-control">
                            <?php foreach (['tls'=>'TLS (port 587, recommended)','ssl'=>'SSL (port 465)','none'=>'None (port 25, insecure)'] as $ev=>$el): ?>
                            <option value="<?= $ev ?>" <?= pss($platform_settings,'smtp_encryption','tls') === $ev ? 'selected' : '' ?>><?= $el ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <!-- SMTP Test -->
                    <div class="form-group">
                        <label class="form-label">Test SMTP Connection</label>
                        <div class="flex gap-2">
                            <input type="email" id="smtpTestEmail" class="form-control flex-1" placeholder="Send test email to…">
                            <button type="button" class="btn btn-secondary" onclick="smtpTest()">
                                <i class="hgi hgi-stroke hgi-play"></i>Send Test
                            </button>
                        </div>
                        <div id="smtpTestResult" class="text-sm text-muted"></div>
                    </div>
                </div>
            </div>
        </div>
    

        <!-- Save bar -->
        <div class="flex justify-between items-center rounded px-5 py-3" style="position: fixed;bottom: 0;width: -webkit-fill-available;background: #fff;">
            <div>
                Changes affect all accounts and users immediately after save.
            </div>
            <div>                
                <button type="submit" class="btn btn-primary"><i class="hgi hgi-stroke hgi-tick-02"></i>Save Settings</button>
            </div>
        </div>
    </form>
    
    <?php endif; ?>

    
    <script>
        // ── SMTP Test ────────────────────────────────────────────
        function smtpTest() {
            var email = document.getElementById('smtpTestEmail').value.trim();
            var result = document.getElementById('smtpTestResult');
            if (!email) {
                alert('Enter a test email address');
                return;
            }
            result.style.display = 'block';
            result.style.color = '#64748b';
            result.textContent = 'Sending test email…';
            var fd = new FormData();
            fd.append('action', 'smtp_test');
            fd.append('_csrf', '<?= csrf_token() ?>');
            fd.append('test_email', email);
            fetch(window.location.href, {
                    method: 'POST',
                    body: fd,
                    credentials: 'same-origin'
                })
                .then(function(r) {
                    return r.json();
                })
                .then(function(d) {
                    result.style.color = d.ok ? '#16a34a' : '#ef4444';
                    result.textContent = d.ok ? '✓ Test email sent to ' + email : '✗ Failed: ' + (d.error || 'Unknown error');
                })
                .catch(function(e) {
                    result.style.color = '#ef4444';
                    result.textContent = '✗ Request error: ' + e.message;
                });
        }

        // ── Color picker ↔ text input sync ──────────────────────
        function updateSwatch(key, val) {
            const sw = document.getElementById('swatch_' + key);
            const tx = document.getElementById('txt_' + key);
            if (sw) sw.style.background = val;
            if (tx && tx.value !== val) tx.value = val;
            updatePreview();
        }

        function syncColor(key, val) {
            const sw = document.getElementById('swatch_' + key);
            const cp = sw && sw.querySelector('input[type=color]');
            if (sw) sw.style.background = val;
            if (cp) {
                try {
                    cp.value = val;
                } catch (e) {}
            }
            updatePreview();
        }

        // ── Live preview bar ──────────────────────────────────────
        function updatePreview() {
            const c500 = document.getElementById('txt_brand_color_500');
            const c50 = document.getElementById('txt_brand_color_50');
            const sbg = document.getElementById('txt_sidebar_bg');
            const btn = document.getElementById('prevBtn');
            const lnk = document.getElementById('prevLink');
            const bdg = document.getElementById('prevBadge');
            const sb = document.getElementById('prevSidebar');
            const v500 = c500 ? c500.value : '#2563eb';
            const v50 = c50 ? c50.value : '#eef5ff';
            const vsbg = sbg ? sbg.value : '#0f172a';
            if (btn) {
                btn.style.background = v500;
                btn.style.borderColor = v500;
            }
            if (lnk) {
                lnk.style.color = v500;
            }
            if (bdg) {
                bdg.style.background = v50;
                bdg.style.color = v500;
            }
            if (sb) {
                sb.style.background = vsbg;
            }
        }
        updatePreview();

        // Sync on load — color inputs initialize from saved values
        document.querySelectorAll('input[type=color]').forEach(function(cp) {
            var name = cp.closest('[id]');
            var lbl = cp.closest('label');
            if (lbl) lbl.querySelector && lbl.setAttribute('style', 'background:' + cp.value + ';width:32px;height:32px;border-radius:7px;border:2px solid var(--gray-200);cursor:pointer;overflow:hidden;flex-shrink:0;');
        });
    </script>

    

    <!-- ── Reminders tab ── -->
    <?php if ($tab === 'reminders' && $account && can('settings','edit')):
        require_once __DIR__ . '/config/reminders.php';
        $rem_cfg = reminder_get_settings($account_id);
    ?>
    <form method="POST" class="card">
        <div class="card-header">
            <div>
                <div class="card-title">Smart Reminder Settings</div>
                <div class="card-subtitle">Configure automatic follow-up reminders for your leads</div>
            </div>
        </div>
        <div class="card-body">
            
            <div class="alert alert-info">
                <div><strong>How it works:</strong> Reminders are checked automatically when agents browse the app. Assigned agents receive the reminder directly; if a lead is unassigned, managers are notified. Reminders can be snoozed or marked done from the dashboard or the lead detail page.</div>
            </div>

            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save_reminder_settings">

            <!-- Master toggle -->
            <div class="flex gap-3 my-3 justify-between">                
                <div class="my-4">
                    <div class="text-md font-semibold">Enable Automatic Reminders</div>
                    <div class="text-sm text-muted">Automatically flag leads that need attention based on inactivity thresholds</div>
                </div>
                <label class="toggle toggle-sm">
                    <input type="checkbox" name="reminders_enabled" value="1" <?= $rem_cfg['enabled'] ? 'checked' : '' ?> id="remToggle" onchange="toggleRemSettings(this)">
                    <div class="toggle-track">
                        <div class="toggle-thumb"></div>
                    </div>
                    
                </label>
            </div>

            <div id="remSettings" style="<?= $rem_cfg['enabled'] ? '' : 'opacity:.45;pointer-events:none;' ?>">
                <!-- Threshold cards -->
                <div class="grid grid-cols-3 gap-3 mb-3">

                    <div class="alert alert-warning">
                        <div>
                            <div class="alert-header">
                                <i class="hgi hgi-stroke hgi-clock-01"></i>
                                <div class="alert-title">
                                    <div class="alert-title">
                                        <div>No Contact</div>
                                        <div class="alert-subtitle">Remind when a <em>new</em> lead has not been contacted within:</div>
                                    </div>
                                </div>
                            </div>
                            <div class="flex gap-2 items-center">
                                <input type="number" name="no_contact_hrs" value="<?= (int)$rem_cfg['no_contact_hrs'] ?>" min="1" max="168" class="form-control" style="width:70px;">
                                <span>hours</span>
                            </div>
                            <div class="mt-2">1–168 hours (max 7 days)</div>
                        </div>
                    </div>

                    <div class="alert alert-danger">
                        <div>
                            <div class="alert-header">
                                <i class="hgi hgi-stroke hgi-notification-off-01"></i>
                                <div class="alert-title">
                                    <div>Follow-up Overdue</div>
                                    <div class="alert-subtitle">Remind when a <em>contacted</em> lead has no activity for:</div>
                                </div>
                            </div>

                            <div class="flex gap-2 items-center">
                                <input type="number" name="overdue_hrs" value="<?= (int)$rem_cfg['overdue_hrs'] ?>" min="1" max="336" class="form-control" style="width:70px;">
                                <span>hours</span>
                            </div>
                            <div class="mt-2">1–336 hours (max 14 days)</div>
                        </div>
                    </div>

                    <div class="alert alert-info">
                        <div>
                            <div class="alert-header">
                                <i class="hgi hgi-stroke hgi-notification-snooze-02"></i>
                                <div class="alert-title">
                                    <div>Inactive Lead</div>
                                    <div class="alert-subtitle">Remind when any active lead has no activity for:</div>
                                </div>                                    
                            </div>                                
                            <div class="flex gap-2 items-center">
                                <input type="number" name="inactive_days" value="<?= (int)$rem_cfg['inactive_days'] ?>" min="1" max="90" class="form-control" style="width:70px;">
                                <span>days</span>
                            </div>
                            <div class="mt-2">1–90 days</div>
                        </div>
                    </div>

                </div>

            </div>

        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-primary"><i class="hgi hgi-stroke hgi-tick-02"></i>Save Settings</button>
        </div>
    </form>

    <script>
        function toggleRemSettings(cb) {
            var track = document.getElementById('remToggleTrack');
            var settings = document.getElementById('remSettings');
            var thumb = track.querySelector('span');
            if (cb.checked) {
                track.style.background = 'var(--brand-500)';
                thumb.style.transform = 'translateX(20px)';
                settings.style.opacity = '1';
                settings.style.pointerEvents = 'auto';
            } else {
                track.style.background = 'var(--gray-300)';
                thumb.style.transform = '';
                settings.style.opacity = '.45';
                settings.style.pointerEvents = 'none';
            }
        }
    </script>

    <?php endif; ?>


</div><!-- /grid -->

<?php include __DIR__ . '/layouts/footer.php'; ?>