<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/config/auth.php';
$user = require_permission('campaigns', 'view');
if (!is_super_admin()) {
    $_SESSION['flash'] = ['type'=>'error','msg'=>'Super admin access required.'];
    header('Location: ' . APP_URL . '/campaigns.php'); exit;
}

$page_title = 'Template Manager';
$active_nav = 'template_manager';
$flash      = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { http_response_code(403); die('CSRF'); }
    $act = $_POST['action'] ?? '';

    if ($act === 'create' || $act === 'edit') {
        $name        = trim($_POST['name'] ?? '');
        $category    = trim($_POST['category'] ?? 'general');
        $description = trim($_POST['description'] ?? '');
        $emoji       = trim($_POST['thumbnail_emoji'] ?? '🚀');
        $color       = preg_match('/^#[0-9a-fA-F]{6}$/', $_POST['thumbnail_color'] ?? '') ? $_POST['thumbnail_color'] : '#2563eb';
        $sort_order  = max(0, (int)($_POST['sort_order'] ?? 0));
        $is_featured = isset($_POST['is_featured']) ? 1 : 0;
        $is_active   = isset($_POST['is_active'])   ? 1 : 0;
        $page_data   = $_POST['page_data'] ?? '[]';
        json_decode($page_data);
        if (json_last_error() !== JSON_ERROR_NONE) $page_data = '[]';
        if (!$name) { $_SESSION['flash'] = ['type'=>'error','msg'=>'Name required.']; header('Location: template_manager.php'); exit; }

        if ($act === 'create') {
            db_insert(
                'INSERT INTO campaign_templates (account_id,name,category,description,thumbnail_emoji,thumbnail_color,page_data,is_system,sort_order,is_featured,is_active,created_by) VALUES (NULL,?,?,?,?,?,?,1,?,?,?,?)',
                'ssssssiiii',
                $name, $category, $description, $emoji, $color, $page_data, $sort_order, $is_featured, $is_active, (int)$user['id']
            );
            $_SESSION['flash'] = ['type'=>'success','msg'=>"Template created."];
        } else {
            $tid = (int)($_POST['id'] ?? 0);
            db_query(
                'UPDATE campaign_templates SET name=?,category=?,description=?,thumbnail_emoji=?,thumbnail_color=?,page_data=?,sort_order=?,is_featured=?,is_active=? WHERE id=? AND is_system=1',
                'ssssssiiii',
                $name, $category, $description, $emoji, $color, $page_data, $sort_order, $is_featured, $is_active, $tid
            );
            $_SESSION['flash'] = ['type'=>'success','msg'=>"Template updated."];
        }
        header('Location: template_manager.php'); exit;
    }

    if ($act === 'delete') {
        $tid = (int)($_POST['id'] ?? 0);
        db_query('DELETE FROM campaign_templates WHERE id=? AND is_system=1', 'i', $tid);
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Template deleted.'];
        header('Location: template_manager.php'); exit;
    }

    if ($act === 'toggle') {
        $tid   = (int)($_POST['id'] ?? 0);
        $field = in_array($_POST['field'] ?? '', ['is_active','is_featured']) ? $_POST['field'] : 'is_active';
        db_query("UPDATE campaign_templates SET {$field} = 1 - {$field} WHERE id=? AND is_system=1", 'i', $tid);
        header('Location: template_manager.php'); exit;
    }
}

// Load templates
$templates = db_fetch_all(
    'SELECT t.*, CONCAT(u.first_name," ",u.last_name) AS creator_name
     FROM campaign_templates t LEFT JOIN users u ON u.id=t.created_by
     WHERE t.is_system=1 ORDER BY t.sort_order ASC, t.name ASC'
);

$categories = array_unique(array_column($templates, 'category'));
sort($categories);

include __DIR__ . '/layouts/header.php';
?>
<div class="page-header">
    <div>
        <div class="page-title">Template Manager</div>
        <div class="page-subtitle">Manage system landing page templates</div>
    </div>
    <button class="btn btn-primary" onclick="openModal('createModal')"><i class="hgi hgi-stroke hgi-plus-sign"></i>New Template</button>
</div>

<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type']==='success'?'success':'danger' ?> mb-3"><?= h($flash['msg']) ?></div>
<?php endif; ?>


<!-- Category filter -->
<?php if ($categories): ?>
<div class="tabs-pill">
    <button class="tab-pill on" onclick="filterCat('all',this)">All <span class="badge badge-light badge-sm"><?= count($templates) ?></span></button>
    <?php foreach ($categories as $cat):
    $cnt = count(array_filter($templates, function($t) use ($cat){ return $t['category']===$cat; })); ?>
    <button class="tab-pill" onclick="filterCat('<?= h($cat) ?>',this)"><?= h(ucfirst(str_replace('_',' ',$cat))) ?><span class="badge badge-light badge-sm"><?= $cnt ?></span></button>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Template grid -->
<?php if ($templates): ?>
<div class="grid grid-cols-3 gap-x-6 my-6" id="tplGrid">
    <?php foreach ($templates as $t): ?>
    <div class="card border-0 border-l4 border-l-warning" style="border-left-color:<?= h($t['thumbnail_color'] ?? 'var(--b1)') ?>;<?= empty($t['is_active'])?'opacity:.55;':'' ?>" data-cat="<?= h($t['category']) ?>">        
        <div class="card-header justify-start">
            <div class="card-header-icon bg-b2-5" style="background:<?= h($t['thumbnail_color']??'bg-b1-5') ?>22;"><i class="hgi hgi-stroke hgi-<?= h($t['thumbnail_emoji']??'artboard-tool') ?>"></i></div>
            <div class="flex-1">
                <div class="card-title"><?= h($t['name']) ?></div>
                <div class="card-subtitle"><?= h($t['category']) ?></div>
            </div>
            <div class="flex justify-end items-center gap-1">                
                <?= !empty($t['is_active'])?'<span class="badge badge-dot badge-success badge-sm">Active</span>':'<span class="badge badge-dot badge-dark badge-sm">Inactive</span>' ?>
            </div>
        </div>
        
        <div class="card-body">            
            <?php if (!empty($t['description'])): ?>
            <div class="text-base mt-2 mb-4"><?= h(mb_substr($t['description'],0,80)) ?><?= mb_strlen($t['description']??'')>80?'…':'' ?></div>
            <?php endif; ?>
            <div class="flex justify-between">
                <div class="badge">Sort (<?= (int)$t['sort_order'] ?>)</div>
                <span class="badge"><?php $pd=json_decode($t['page_data']??'[]',true); echo count((array)$pd); ?> blocks</span>
                <?php if (!empty($t['is_featured'])): ?><span class="badge badge-sm badge-outline-warning"><i class="hgi hgi-stroke hgi-star"></i>Featured</span><?php endif; ?>
            </div>            
        </div>
        <div class="card-footer">
            <button class="btn btn-outline btn-sm" onclick="openEdit(<?= (int)$t['id'] ?>)"><i class="hgi hgi-stroke hgi-edit-02"></i>Edit</button>
            <form method="POST" style="display:inline;"><?= csrf_field() ?>
                <input type="hidden" name="action" value="toggle">
                <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
                <input type="hidden" name="field" value="is_active">
                <button type="submit" class="btn btn-outline btn-sm"><?= !empty($t['is_active'])?'<i class="hgi hgi-stroke hgi-unavailable"></i>Deactivate':'<i class="hgi hgi-stroke hgi-checkmark-circle-02"></i>Activate' ?></button>
            </form>
            <form method="POST" style="display:inline;"><?= csrf_field() ?>
                <input type="hidden" name="action" value="toggle">
                <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
                <input type="hidden" name="field" value="is_featured">
                <button type="submit" class="btn btn-outline btn-sm"><?= !empty($t['is_featured'])?'<i class="hgi hgi-stroke hgi-star"></i>Unfeature':'<i class="hgi hgi-stroke hgi-star"></i>Feature' ?></button>
            </form>
            <form method="POST" style="display:inline;" onsubmit="return confirm('Delete?')"><?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
                <button type="submit" class="btn btn-danger btn-sm btn-icon"><i class="hgi hgi-stroke hgi-delete-02"></i></button>
            </form>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php else: ?>
<div class="empty-state">
    <div class="empty-state-icon">
        <i class="hgi hgi-stroke hgi-artboard-tool"></i>
    </div>
    <div class="empty-state-title">No templates yet</div>
    <div class="empty-state-desc">Run install_templates.sql to seed system templates, or create one manually.</div>
    <button class="btn btn-primary" onclick="openModal('createModal')"><i class="hgi hgi-stroke hgi-plus-sign"></i>Create first template</button>
</div>
<?php endif; ?>

<!-- CREATE/EDIT MODAL -->
<div id="createModal" class="modal-overlay">
        
    <form method="POST" id="tplForm" class="modal">
        <div class="modal-header">
            <h2 class="modal-title" id="modalTitle">New Template</h2>
        </div>
        <div class="modal-body">
            <?= csrf_field() ?>
            <input type="hidden" name="action" id="formAction" value="create">
            <input type="hidden" name="id" id="formId" value="">
            <div class="grid grid-cols-2 gap-x-3">
                <div class="form-group">
                    <label class="form-label">Template Name *</label>
                    <input type="text" name="name" id="fName" class="form-control" required placeholder="e.g. SaaS Lead Generation">
                </div>
                <div class="form-group">
                    <label class="form-label">Category</label>
                    <input type="text" name="category" id="fCat" class="form-control" placeholder="lead_gen, webinar, saas…">
                </div>
                <div class="form-group">
                    <label class="form-label">Sort Order</label>
                    <input type="number" name="sort_order" id="fSort" class="form-control" value="0" min="0">
                </div>
                <div class="form-group">
                    <label class="form-label">Emoji</label>
                    <input type="text" name="thumbnail_emoji" id="fEmoji" class="form-control" value="blockchain-01" maxlength="30">
                </div>
                <div class="form-group">
                    <label class="form-label">Accent Colour</label>
                    <div class="flex gap-2">
                        <label class="color-swatch" style="background:#2563eb;" id="swatch_thumbnail_color">
                            <input type="color" name="thumbnail_color" value="#2563eb" oninput="updateSwatch('thumbnail_color',this.value)" onchange="updateSwatch('thumbnail_color',this.value)">
                        </label>
                        <input type="text" class="form-control color-text" style="font-family:var(--font-mono);font-size:.75rem;" value="#2563eb" maxlength="30" oninput="syncColor('thumbnail_color',this.value)" id="txt_thumbnail_color">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Description</label>
                <textarea name="description" id="fDesc" class="form-control" rows="2"></textarea>
            </div>
            <div class="grid grid-cols-2 gap-x-3">
                <label class="toggle toggle-sm">
                    <input type="checkbox" name="is_active" id="fActive" checked> Active
                    <div class="toggle-track">
                        <div class="toggle-thumb"></div>
                    </div>
                </label>
                <label class="toggle toggle-sm">
                    <input type="checkbox" name="is_featured" id="fFeatured"> Featured
                    <div class="toggle-track">
                        <div class="toggle-thumb"></div>
                    </div>
                </label>
            </div>
            <div class="form-group mt-4">
                <label class="form-label">Page Data (JSON)</label>
                <textarea name="page_data" id="fPageData" class="form-control" rows="5" style="font-family:monospace;font-size:.72rem;resize:vertical;" placeholder="[]"></textarea>
            </div>
            
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-outline" onclick="closeModal('createModal')">Cancel</button>
            <button type="submit" class="btn btn-primary" id="fSubmitBtn"><i class="hgi hgi-stroke hgi-tick-02"></i>Create Template</button>
        </div>
    </form>
</div>

<script>
    
    function updateSwatch(key, val) {
        const sw = document.getElementById('swatch_' + key);
        const tx = document.getElementById('txt_' + key);
        if (sw) sw.style.background = val;
        if (tx && tx.value !== val) tx.value = val;
        updatePreview();
    }

    function syncColor(key, val) {
        const sw = document.getElementById('swatch_' + key);
        const cp = sw && sw.querySelector('input[type=color]');
        if (sw) sw.style.background = val;
        if (cp) {
            try {
                cp.value = val;
            } catch (e) {}
        }
        updatePreview();
    }

    const TEMPLATES = <?= json_encode(array_column($templates, null, 'id'), JSON_HEX_TAG | JSON_HEX_APOS) ?>;

    function openModal(id) {
        // Reset to "create" state when opening fresh
        document.getElementById('modalTitle').textContent = 'New Template';
        document.getElementById('formAction').value = 'create';
        document.getElementById('formId').value = '';
        document.getElementById('fSubmitBtn').innerHTML = '<i class="hgi hgi-stroke hgi-tick-02"></i> Create Template';
        document.getElementById('tplForm').reset();
        document.getElementById('fActive').checked = true;
        document.getElementById('txt_thumbnail_color').value = '#2563eb';
        document.getElementById('fEmoji').value = 'blockchain-01';
        document.getElementById(id).style.display = 'flex';
    }

    function openEdit(id) {
        const t = TEMPLATES[id];
        if (!t) return;
        document.getElementById('modalTitle').textContent = 'Edit Template';
        document.getElementById('formAction').value = 'edit';
        document.getElementById('formId').value = id;
        document.getElementById('fSubmitBtn').innerHTML = '<i class="hgi hgi-stroke hgi-tick-02"></i> Save Changes';
        document.getElementById('fName').value = t.name || '';
        document.getElementById('fCat').value = t.category || '';
        document.getElementById('fEmoji').value = t.thumbnail_emoji || 'artboard-tool';
        document.getElementById('txt_thumbnail_color').value = t.thumbnail_color || '#2563eb';
        document.getElementById('swatch_thumbnail_color').style.backgroundColor = t.thumbnail_color;
        document.getElementById('fSort').value = t.sort_order || 0;
        document.getElementById('fDesc').value = t.description || '';
        document.getElementById('fPageData').value = t.page_data || '[]';
        document.getElementById('fActive').checked = !!t.is_active;
        document.getElementById('fFeatured').checked = !!t.is_featured;
        document.getElementById('createModal').classList.add('open');
    }

    function closeModal(id) {
        var el = document.getElementById(id || 'createModal');
        if (el) el.style.display = 'none';
    }

    document.getElementById('createModal').addEventListener('click', function(e) {
        if (e.target === this) closeModal('createModal');
    });

    function filterCat(cat, btn) {
        document.querySelectorAll('[onclick^="filterCat"]').forEach(b => b.classList.remove('on'));
        btn.classList.add('on');
        document.querySelectorAll('#tplGrid>div').forEach(card => {
            card.style.display = (cat === 'all' || card.dataset.cat === cat) ? '' : 'none';
        });
    }
</script>

<?php include __DIR__ . '/layouts/footer.php'; ?>