<?php
/**
 * LeadPro — Campaign Workspace  v2.0
 * campaign_view.php — Full analytics dashboard (Phase 6 complete)
 */
require_once __DIR__ . '/config/auth.php';
$user       = require_permission('campaigns', 'view');
$account_id = (int)($user['account_id'] ?? 0);
$is_super   = is_super_admin();
$uid        = (int)$user['id'];

$cid = (int)($_GET['id'] ?? 0);
$campaign = db_fetch(
    'SELECT c.*, CONCAT(u.first_name," ",u.last_name) AS owner_name
     FROM campaigns c LEFT JOIN users u ON u.id=c.owner_id
     WHERE c.id=? AND c.account_id=?',
    'ii', $cid, $account_id
);
if (!$campaign) {
    $_SESSION['flash'] = ['type'=>'error','msg'=>'Campaign not found.'];
    header('Location: ' . APP_URL . '/campaigns.php'); exit;
}

$page_title = h($campaign['name']);
$active_nav = 'campaigns';
$flash      = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);

// ── Column safety checks (self-healing) ──────────────────────
$_cv_db      = db();
$_has_og     = $_cv_db->query("SHOW COLUMNS FROM `campaign_pages` LIKE 'og_image'")->num_rows > 0;
$_has_is_act = $_cv_db->query("SHOW COLUMNS FROM `campaign_templates` LIKE 'is_active'")->num_rows > 0;

// ── Date range filter (Phase 6) ─────────────────────────────
$range      = $_GET['range'] ?? '30';
$range_map  = ['7'=>7,'30'=>30,'90'=>90,'all'=>0];
$range_days = $range_map[$range] ?? 30;
$date_from  = $range_days > 0 ? date('Y-m-d', strtotime("-{$range_days} days")) : null;
$date_sql   = $date_from ? "AND DATE(l.submitted_at) >= '{$date_from}'" : '';
$date_sql_p = $date_from ? "AND DATE(submitted_at) >= '{$date_from}'"   : '';

// ── Landing pages ────────────────────────────────────────────
$pages = db_fetch_all(
    'SELECT cp.*, f.name AS form_name,
        (SELECT COUNT(*) FROM leads l WHERE l.campaign_page_id=cp.id) AS lead_count_all,
        (SELECT COUNT(*) FROM leads l WHERE l.campaign_page_id=cp.id ' . $date_sql . ') AS lead_count
     FROM campaign_pages cp
     LEFT JOIN lead_forms f ON f.id=cp.form_id
     WHERE cp.campaign_id=? AND cp.account_id=?
     ORDER BY cp.created_at DESC',
    'ii', $cid, $account_id
);

// ── Recent leads ─────────────────────────────────────────────
$recent_leads = db_fetch_all(
    "SELECT l.id, l.reference_no, l.status, l.submitted_at,
            cp.title AS page_title,
            CONCAT(ua.first_name,' ',ua.last_name) AS assigned_name
     FROM leads l
     LEFT JOIN campaign_pages cp ON cp.id=l.campaign_page_id
     LEFT JOIN users ua ON ua.id=l.assigned_to
     WHERE l.campaign_id=? AND l.account_id=? {$date_sql}
     ORDER BY l.submitted_at DESC LIMIT 10",
    'ii', $cid, $account_id
);

// ── KPI stats ────────────────────────────────────────────────
$stats = db_fetch(
    "SELECT COUNT(*) AS total_leads,
            SUM(status='converted') AS converted,
            SUM(status='qualified') AS qualified,
            SUM(status='new')       AS new_l
     FROM leads WHERE campaign_id=? AND account_id=? {$date_sql_p}",
    'ii', $cid, $account_id
) ?? [];

$total_views = db_fetch(
    'SELECT COALESCE(SUM(views),0) AS v FROM campaign_pages WHERE campaign_id=?', 'i', $cid
)['v'] ?? 0;
$total_leads = (int)($stats['total_leads'] ?? 0);
$conv_rate   = $total_views > 0 ? round($total_leads / $total_views * 100, 1) : 0;

// ── Leads per day (last N days or 30 if all) ─────────────────
$chart_days = $range_days > 0 ? $range_days : 30;
$leads_by_day = db_fetch_all(
    "SELECT DATE(submitted_at) AS day, COUNT(*) AS n
     FROM leads WHERE campaign_id=? AND account_id=?
       AND submitted_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
     GROUP BY DATE(submitted_at) ORDER BY day ASC",
    'iii', $cid, $account_id, $chart_days
);
// Fill in zero days
$day_map = [];
foreach ($leads_by_day as $r) $day_map[$r['day']] = (int)$r['n'];
$chart_labels = [];
$chart_values = [];
for ($i = $chart_days - 1; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-{$i} days"));
    $chart_labels[] = date('d M', strtotime($d));
    $chart_values[] = $day_map[$d] ?? 0;
}

// ── UTM source breakdown ─────────────────────────────────────
$utm_breakdown = db_fetch_all(
    "SELECT COALESCE(NULLIF(utm_source,''),'(direct)') AS src, COUNT(*) AS n
     FROM leads WHERE campaign_id=? AND account_id=? {$date_sql_p}
     GROUP BY src ORDER BY n DESC LIMIT 8",
    'ii', $cid, $account_id
);

// ── Device split ─────────────────────────────────────────────
$device_split = db_fetch_all(
    "SELECT COALESCE(NULLIF(device_type,''),'unknown') AS dev, COUNT(*) AS n
     FROM leads WHERE campaign_id=? AND account_id=? {$date_sql_p}
     GROUP BY dev ORDER BY n DESC",
    'ii', $cid, $account_id
);

// ── Per-page performance ──────────────────────────────────────
// Already in $pages above with lead_count (date-filtered)

$status_cfg = [
    'draft'    => ['bg'=>'var(--color-info-bg)',    'text'=>'var(--color-info-text)',       'label'=>'Draft'],
    'active'   => ['bg'=>'var(--color-success-bg)', 'text'=>'var(--color-success-text)',    'label'=>'Active'],
    'paused'   => ['bg'=>'var(--color-warning-bg)', 'text'=>'var(--color-warning-text)',    'label'=>'Paused'],
    'archived' => ['bg'=>'var(--color-danger-bg)',  'text'=>'var(--color-danger-text)',     'label'=>'Archived'],
];
$sc = $status_cfg[$campaign['status']] ?? $status_cfg['draft'];

$page_status_cfg = [
    'draft'     => ['bg'=>'var(--color-info-bg)',       'text'=>'var(--color-info-text)',       'dot'=>'var(--color-info-text)'],
    'published' => ['bg'=>'var(--color-success-bg)',    'text'=>'var(--color-success-text)',    'dot'=>'var(--color-success-text)'],
];
$lead_status_colors = [
    'new'       => 'info',        'contacted' => 'info',
    'qualified' => 'info',        'converted' => 'success',
    'lost'      => 'danger',      'spam'      => 'danger',
];

include __DIR__ . '/layouts/header.php';
?>

<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type']==='success'?'success':'danger' ?> mb-5"><?= h($flash['msg']) ?></div>
<?php endif; ?>

<!-- Top bar -->

<div class="page-header">
    <div>
        <h1 class="page-title">
            <span class="dot dot-sm mr-2" style="background:<?= h($campaign['color']) ?>;"></span>
            <?= h($campaign['name']) ?>
            <span class="badge ml-2" style="background:<?= $sc['bg'] ?>;color:<?= $sc['text'] ?>;"><?= $sc['label'] ?></span>
        </h1>
        <?php if ($campaign['objective']): ?>
        <p class="page-subtitle"><?= h($campaign['objective']) ?></p>
        <?php endif; ?>
    </div>
    <div class="nav-pills">
        <?php foreach(['7'=>'7d','30'=>'30d','90'=>'90d','all'=>'All'] as $val=>$lbl): ?>
        <a href="?id=<?= $cid ?>&range=<?= $val ?>" class="nav-pill<?= $range==$val ? ' active' : '' ?>">
            <?= $lbl ?>
        </a>
        <?php endforeach; ?>
        <?php if (can('campaigns','edit')): ?>
        <a href="<?= APP_URL ?>/campaigns.php" class="btn btn-secondary btn-sm"><i class="hgi hgi-stroke hgi-megaphone-02"></i>All Campaigns</a>
        <?php endif; ?>
        <a href="<?= APP_URL ?>/leads.php?campaign_id=<?= $cid ?>" class="btn btn-secondary btn-sm"><i class="hgi hgi-stroke hgi-user-warning-02"></i>View Leads</a>
        <a href="<?= APP_URL ?>/reports.php?tab=source_roi" class="btn btn-secondary btn-sm"><i class="hgi hgi-stroke hgi-chart-line-data-01"></i>Analytics</a>
        <a href="<?= APP_URL ?>/campaign_knowledge.php?id=<?= $cid ?>" class="btn btn-secondary btn-sm"><i class="hgi hgi-stroke hgi-ai-brain-05"></i>AI Knowledge</a>
        <a href="#" class="btn btn-primary btn-sm" onclick="openTemplatePicker();return false;"><i class="hgi hgi-stroke hgi-plus-sign"></i> New Page</a>
    </div>
</div>

<!-- KPIs -->
<div class="flex items-center gap-4">
    <?php
  $kpis = [
    [(int)$total_views,   'Page Views',     'var(--color-success-bg)',  'var(--color-success-text)',    'hgi-view'],
    [$total_leads,        'Leads',          'var(--color-info-bg)',     'var(--color-info-text)',       'hgi-user-account'],
    [$conv_rate . '%',    'Conv. Rate',     'var(--color-warning-bg)',  'var(--color-warning-text)',    'hgi-chart-02'],
    [count($pages),       'Landing Pages',  'var(--color-danger-bg)',   'var(--color-danger-text)',     'hgi-file-01'],
  ];
  foreach ($kpis as [$v,$l,$bg,$c,$i]): ?>

    <div class="card stat-card" style="border-top: 3px solid <?= $c ?>;">
        <div class="flex items-center justify-between gap-5">
            <div>
                <div class="stat-card-label"><?= $l ?></div>
                <div class="stat-card-value mt-1"><?= $v ?></div>
            </div>
            <div class="stat-card-icon bg-brand-100 color-brand-600" style="background: <?= $bg ?>; color: <?= $c ?>;">
                <i class="hgi hgi-stroke <?= $i ?>"></i>
            </div>
        </div>

    </div>
    <?php endforeach; ?>
</div>


<div class="page-cols mt-6">
    <div>
        <div class="card">
            <div class="card-header">
                <div class="card-title">Campaign Details</div>
            </div>
            <div class="card-body">
                <div class="info-row">
                    <span class="info-lbl">Status</span>
                    <span class="info-val"><span style="background:<?= $sc['bg'] ?>;color:<?= $sc['text'] ?>;padding:2px 8px;border-radius:6px;font-size:.72rem;font-weight:700;"><?= $sc['label'] ?></span></span>
                </div>
                <?php if ($campaign['owner_name'] && trim($campaign['owner_name'])): ?>
                <div class="info-row"><span class="info-lbl">Owner</span><span class="info-val"><?= h(trim($campaign['owner_name'])) ?></span></div>
                <?php endif; ?>
                <?php if ($campaign['start_date']): ?>
                <div class="info-row"><span class="info-lbl">Start</span><span class="info-val"><?= date('d M Y', strtotime($campaign['start_date'])) ?></span></div>
                <?php endif; ?>
                <?php if ($campaign['end_date']): ?>
                <div class="info-row"><span class="info-lbl">End</span><span class="info-val"><?= date('d M Y', strtotime($campaign['end_date'])) ?></span></div>
                <?php endif; ?>
                <div class="info-row"><span class="info-lbl">Created</span><span class="info-val"><?= format_dt($campaign['created_at'],'d M Y') ?></span></div>
                <?php if ($campaign['description']): ?>
                <div class="detail-row">
                    <div class="detail-lbl">DESCRIPTION</div>
                    <div class="detail-val"><?= h($campaign['description']) ?></div>
                </div>
                <?php endif; ?>

                <?php if ($campaign['objective']): ?>
                <div class="detail-row">
                    <div class="detail-lbl">OBJECTIVE</div>
                    <div class="detail-val"><?= h($campaign['objective']) ?></div>
                </div>
                <?php endif; ?>

            </div>
        </div>

        <!-- Lead Funnel -->
        <div class="card mt-4">
            <div class="card-header">
                <div class="card-title">Lead Funnel</div>
            </div>
            <div class="card-body">
                <?php
                $funnel = [
                  ['New',       (int)($stats['new_l']    ?? 0),     'var(--color-warning-text)'],
                  ['Qualified', (int)($stats['qualified'] ?? 0),    'var(--color-info-text)'],
                  ['Converted', (int)($stats['converted'] ?? 0),    'var(--color-success-text)'],
                ];
                $max_f = max(array_column($funnel,'1') ?: [1]);
                foreach ($funnel as [$fl,$fv,$fc]):
                  $fw = $max_f > 0 ? round($fv/$max_f*100) : 0;
                ?>
                <div class="mb-5">
                    <div class="flex justify-between text-xs">
                        <span><?= $fl ?></span>
                        <span class="font-bold" style="color:<?= $fc ?>;"><?= $fv ?></span>
                    </div>
                    <div class="progress mt-2">
                        <div class="progress-bar" style="width:<?= $fw ?>%;background:<?= $fc ?>;transition:width .5s;"></div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php if ($total_leads === 0): ?>
                <div class="text-2xs text-muted">No leads yet</div>
                <?php endif; ?>
            </div>
        </div>
        
        
        <?php if ($utm_breakdown || $device_split): ?>
        
        <!-- UTM Source Breakdown -->
        <?php if ($utm_breakdown): ?>
        <div class="card mt-4">
            <div class="card-header">
                <div class="card-title">Traffic Sources</div>
                <a href="<?= APP_URL ?>/leads.php?campaign_id=<?= $cid ?>" class="btn btn-xs btn-white">Filter leads</a>
            </div>
            <div class="card-body">
                <?php
                  $utm_max    = max(array_column($utm_breakdown, 'n') ?: [1]);
                  $utm_colors = ['var(--color-info-text)','var(--color-branding-text)','var(--color-success-text)','var(--color-warning-text)','var(--color-danger-text)','#06b6d4','#ec4899','#84cc16'];
                  foreach ($utm_breakdown as $i => $row):
                    $uw = $utm_max > 0 ? round($row['n'] / $utm_max * 100) : 0;
                    $uc = $utm_colors[$i % count($utm_colors)];
                    $src_param = $row['src'] === '(direct)' ? '' : urlencode($row['src']);
                ?>
                <div>
                    <div class="info-row">
                        <a class="info-lbl" href="<?= APP_URL ?>/leads.php?campaign_id=<?= $cid ?>&utm_source=<?= $src_param ?>"><?= h($row['src']) ?></a>
                        <span class="info-val" style="color:<?= $uc ?>;"><?= $row['n'] ?></span>
                    </div>
                    <div class="progress">
                        <div class="progress-bar" style="width:<?= $uw ?>%;background:<?= $uc ?>;"></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php else: ?><div></div><?php endif; ?>
        
        <!-- Device Split -->
        <?php if ($device_split && $total_leads > 0): ?>
        <div class="card mt-4">
            <div class="card-header">
                <div class="card-title">Device Breakdown</div>
            </div>
            <div class="card-body">
                <?php
                  $dev_icons  = ['desktop'=>'<i class="hgi hgi-stroke hgi-monitor-stop"></i>','mobile'=>'<i class="hgi hgi-stroke hgi-smart-phone-02"></i>','tablet'=>'<i class="hgi hgi-stroke hgi-tablet-01"></i>','unknown'=>'<i class="hgi hgi-stroke hgi-help-circle"></i>'];
                  $dev_colors = ['desktop'=>'var(--color-info-text)','mobile'=>'var(--color-success-text)','tablet'=>'var(--color-brand-text)','unknown'=>'var(--color-warning-text)'];
                  foreach ($device_split as $row):
                    $dw = $total_leads > 0 ? round($row['n'] / $total_leads * 100) : 0;
                    $dc = $dev_colors[$row['dev']] ?? 'var(--color-warning-text)';
                    $di = $dev_icons[$row['dev']] ?? '<i class="hgi hgi-stroke hgi-help-circle"></i>';
                ?>
                <div>
                    <span><?= $di ?></span>
                    <div class="flex-1">
                        <div class="info-row">
                            <span class="info-lbl"><?= h($row['dev']) ?></span>
                            <span class="info-val" style="color:<?= $dc ?>;"><?= $dw ?>% <span>(<?= $row['n'] ?>)</span></span>
                        </div>
                        <div class="progress">
                            <div class="progress-bar" style="width:<?= $dw ?>%;background:<?= $dc ?>;"></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php else: ?><div></div><?php endif; ?>
        
        <?php endif; ?>
    </div>
    
    <div>
        <!-- Landing Pages -->
        <div class="card">
            <div class="card-header">
                <div class="card-title">Landing Pages</div>
                <a href="#" class="btn btn-primary btn-sm" onclick="openTemplatePicker();return false;"><i class="hgi hgi-stroke hgi-plus-sign"></i>Add Page</a>
            </div>
            <div class="card-body">
                <?php if ($pages): ?>
                <?php foreach ($pages as $pg):
                  $psc = $page_status_cfg[$pg['status']] ?? $page_status_cfg['draft'];
                ?>
                <div class="page-row">
                    <div class="page-thumb" style="background:<?= h($campaign['color']) ?>;"><i class="hgi hgi-stroke hgi-file-01"></i></div>
                    <div class="flex-1">
                        <div class="page-name"><?= h($pg['title']) ?></div>
                        <div class="page-meta">
                            <span class="badge badge-sm" style="background:<?= $psc['bg'] ?>; color:<?= $psc['text'] ?>;">
                                <span class="dot dot-xs" style="background:<?= $psc['dot'] ?>;"></span>
                                <span><?= ucfirst($pg['status']) ?></span>
                            </span>
                            <?= $pg['form_name'] ? '<span class="badge badge-warning ml-4"><i class="hgi hgi-stroke hgi-database-01"></i> '.h($pg['form_name']).'</span>' : '' ?>
                            <span class="badge badge-success ml-4"><?= $pg['views'] ?></span> <span class="text-xs">Views</span>
                            <span class="badge badge-info ml-4"><?= $pg['lead_count'] ?></span> <span class="text-xs">Leads</span>                            
                        </div>
                    </div>
                    <div style="display:flex;gap:5px;flex-shrink:0;">
                        <a href="<?= APP_URL ?>/page_builder.php?id=<?= $pg['id'] ?>" target="_blank" rel="noopener" class="btn btn-info btn-icon btn-xs" title="Edit in Builder"><i class="hgi hgi-stroke hgi-edit-02"></i></a>
                        <?php if ($pg['status']==='published'): ?>
                        <a href="<?= APP_URL ?>/lp/<?= h($pg['slug']) ?>" target="_blank" class="btn btn-secondary btn-icon btn-xs" title="Preview"><i class="hgi hgi-stroke hgi-link-circle"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php else: ?>
                <div class="empty-state">
                    <div class="empty-state-icon">
                        <i class="hgi hgi-stroke hgi-file-01"></i>
                    </div>
                    <div class="empty-state-title">No landing pages yet.</div>
                    <a href="#" class="btn btn-primary btn-sm" style="margin-top:12px;" onclick="openTemplatePicker();return false;"><i class="hgi hgi-stroke hgi-plus-sign"></i>Create First Page</a>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Recent Leads -->
        <div class="card mt-4">
            <div class="card-header">
                <div class="card-title">Recent Leads</div>
                <a href="<?= APP_URL ?>/leads.php?campaign_id=<?= $cid ?>" class="btn btn-secondary btn-sm"><i class="hgi hgi-stroke hgi-user-account"></i>View All</a>
            </div>
            <div class="card-body">
                <?php if ($recent_leads): ?>
                <?php foreach ($recent_leads as $l): ?>
                <div class="lead-row">
                    <span class="dot dot-xs" style="background:<?= $lead_status_colors[$l['status']] ?? 'var(--neutral-200)' ?>;"></span>
                    <div class="flex-1">
                        <a href="<?= APP_URL ?>/lead_view.php?id=<?= $l['id'] ?>" class="uppercase font-bold text-sm tracking-wider text-primary"><?= h($l['reference_no']) ?></a>
                        <?php if ($l['page_title']): ?><span class="badge badge-dark capitalise badge-xs ml-4"><?= h($l['page_title']) ?></span><?php endif; ?>
                    </div>
                    <span class="flex gap-1 items-center ml-4 text-xs"><i class="hgi hgi-stroke hgi-calendar-03"></i><?= format_dt($l['submitted_at'],'d M') ?></span>
                    <span class="badge badge-<?= $lead_status_colors[$l['status']] ?? 'dark' ?>"><?= ucfirst($l['status']) ?></span>
                </div>
                <?php endforeach; ?>
                <?php else: ?>
                <div class="text-xs text-danger text-center my-8">No leads captured yet. Publish a landing page to start collecting leads.</div>
                <?php endif; ?>
            </div>
        </div>
        
        
        <!-- Leads Over Time Chart -->
        <div class="card mt-4">
            <div class="card-header">
                <div class="card-title">Leads Over Time</div>
                <span class="text-xs text-muted">Last <?= $range_days > 0 ? $range_days . ' days' : '30 days' ?></span>
            </div>
            <div class="card-body">
                <?php if (array_sum($chart_values) > 0): ?>
                <canvas id="leadsChart" height="120"></canvas>
                <?php else: ?>
                <div class="text-center text-danger text-xs">No lead data in this period.</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Per-Page Performance -->
        <div class="card mt-4">
            <div class="card-header">
                <div class="card-title">Page Performance</div>
            </div>
            <?php if ($pages): ?>
            <table class="table table-stripped table-hover table-sm">
                <thead>
                    <tr>
                        <th>Page</th>
                        <th class="text-right">Views</th>
                        <th class="text-right">Leads</th>
                        <th class="text-right">Conv%</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pages as $pg):
                        $psc2    = $page_status_cfg[$pg['status']] ?? $page_status_cfg['draft'];
                        $pg_conv = $pg['views'] > 0 ? round($pg['lead_count'] / $pg['views'] * 100, 1) : 0;
                    ?>
                    <tr>
                        <td>
                            <div class="flex gap-2 items-center">
                                <span class="dot dot-xs" style="background:<?= $psc2['dot'] ?>;"></span>
                                <a href="<?= APP_URL ?>/page_builder.php?id=<?= $pg['id'] ?>" target="_blank" rel="noopener" class="text-primary"><?= h(mb_substr($pg['title'],0,28)) ?><?= mb_strlen($pg['title'])>28?'…':'' ?></a>
                            </div>
                        </td>
                        <td class="font-bold text-right"><?= number_format($pg['views']) ?></td>
                        <td class="font-bold text-right"><?= $pg['lead_count'] ?></td>
                        <td class="font-bold text-success text-right"><?= $pg_conv ?>%</td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div class="card-body my-4 text-center text-xs text-danger">No pages yet.</div>
            <?php endif; ?>
        </div>
        
    </div>
    
</div>


<!-- Chart.js -->
<?php if (array_sum($chart_values) > 0): ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
    (function() {
        const ctx = document.getElementById('leadsChart');
        if (!ctx) return;
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?= json_encode($chart_labels) ?>,
                datasets: [{
                    label: 'Leads',
                    data: <?= json_encode($chart_values) ?>,
                    borderColor: '#2563eb',
                    backgroundColor: 'rgba(37,99,235,.08)',
                    borderWidth: 2,
                    pointRadius: 3,
                    pointHoverRadius: 5,
                    pointBackgroundColor: '#2563eb',
                    fill: true,
                    tension: 0.4,
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            title: items => items[0].label,
                            label: item => ' ' + item.raw + ' lead' + (item.raw !== 1 ? 's' : ''),
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            font: {
                                size: 10
                            },
                            maxTicksLimit: 10,
                            color: '#94a3b8'
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0,0,0,.04)'
                        },
                        ticks: {
                            font: {
                                size: 10
                            },
                            stepSize: 1,
                            color: '#94a3b8',
                            precision: 0
                        }
                    }
                }
            }
        });
    })();
</script>
<?php endif; ?>



<div id="tplModal" style="display:none;">
    <div class="tplModal_container modal">

        <!-- Modal header -->
        <div class="modal-header">
            <div>
                <div class="modal-title">Choose a Template</div>
                <div class="text-xs text-muted">Start from a pre-built layout or begin with a blank canvas</div>
            </div>
            <button onclick="closeTemplatePicker()" title="Close" class="modal-close"><i class="hgi hgi-stroke hgi-cancel-01"></i></button>
        </div>

        <!-- Category filter tabs -->
        <div id="tplCatTabs">
            <button class="tpl-cat-btn active" data-cat="all" onclick="filterTemplates('all',this)">All</button>
            <button class="tpl-cat-btn" data-cat="lead_gen" onclick="filterTemplates('lead_gen',this)">Lead Gen</button>
            <button class="tpl-cat-btn" data-cat="webinar" onclick="filterTemplates('webinar',this)">Webinar</button>
            <button class="tpl-cat-btn" data-cat="product_launch" onclick="filterTemplates('product_launch',this)">Product Launch</button>
            <button class="tpl-cat-btn" data-cat="booking" onclick="filterTemplates('booking',this)">Booking</button>
            <button class="tpl-cat-btn" data-cat="promotion" onclick="filterTemplates('promotion',this)">Promotion</button>
            <button class="tpl-cat-btn" data-cat="saas" onclick="filterTemplates('saas',this)">SaaS</button>
            <button class="tpl-cat-btn" data-cat="app" onclick="filterTemplates('app',this)">App</button>
            <button class="tpl-cat-btn" data-cat="event" onclick="filterTemplates('event',this)">Event</button>
            <button class="tpl-cat-btn" data-cat="saved" onclick="filterTemplates('saved',this)" id="savedTab" style="display:none;">My Templates</button>
        </div>

        <!-- Template grid -->
        <div class="modal-body">

            <!-- Blank option — always first -->
            <div class="grid grid-cols-5 gap-3" id="tplGrid">

                <div class="tpl-card tpl-card-blank" onclick="useBlankTemplate()">
                    <i class="hgi hgi-stroke hgi-plus-sign"></i>
                    <div class="tpl-title">Blank Page</div>
                    <div class="tpl-info">Start from scratch</div>
                </div>

                <!-- Templates injected here by JS -->
                <div id="tplLoading" style="grid-column:1/-1;text-align:center;padding:40px;color:#94a3b8;font-size:.85rem;">
                    Loading templates…
                </div>

            </div>
        </div>

    </div>
</div>

<script>
    const CAMPAIGN_ID = <?= (int)$cid ?>;
    const TEMPLATES_URL = '<?= APP_URL ?>/templates.php';
    const BUILDER_URL = '<?= APP_URL ?>/page_builder.php';

    let allTemplates = [];
    let activeCat = 'all';

    function openTemplatePicker() {
        document.getElementById('tplModal').style.display = 'block';
        document.body.style.overflow = 'hidden';
        if (!allTemplates.length) loadTemplates();
    }

    function closeTemplatePicker() {
        document.getElementById('tplModal').style.display = 'none';
        document.body.style.overflow = '';
    }
    document.getElementById('tplModal').addEventListener('click', function(e) {
        if (e.target === this) closeTemplatePicker();
    });
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') closeTemplatePicker();
    });

    async function loadTemplates() {
        try {
            const res = await fetch(TEMPLATES_URL + '?action=list');
            const data = await res.json();
            if (data.ok) {
                allTemplates = data.templates;
                const hasSaved = allTemplates.some(t => t.source === 'saved');
                if (hasSaved) document.getElementById('savedTab').style.display = '';
                renderTemplates(allTemplates);
            }
        } catch (e) {
            document.getElementById('tplLoading').textContent = 'Failed to load templates.';
        }
    }

    function renderTemplates(list) {
        const grid = document.getElementById('tplGrid');
        // Remove old template cards (keep blank card + loading div)
        grid.querySelectorAll('.tpl-dyn').forEach(el => el.remove());
        document.getElementById('tplLoading').style.display = 'none';

        if (!list.length) {
            grid.insertAdjacentHTML('beforeend', '<div class="tpl-dyn" style="grid-column:1/-1;text-align:center;padding:40px;color:#94a3b8;font-size:.85rem;">No templates in this category.</div>');
            return;
        }

        list.forEach(t => {
            const isSaved = t.source === 'saved';
            const isFeatured = t.is_featured && !isSaved;
            const blockCount = (() => {
                try {
                    return JSON.parse(t.page_data || '[]').length;
                } catch (e) {
                    return 0;
                }
            })();
            const card = document.createElement('div');
            card.className = 'tpl-card';
            card.setAttribute('data-cat', t.category);
            card.innerHTML = `
      ${isSaved    ? '<span class="badge badge-sm badge-success">Saved</span>' : ''}
      ${isFeatured ? '<span class="tpl-featured badge badge-brand my-2">Featured</span>' : ''}
      ${isSaved ? `<button class="btn btn-xs btn-danger" onclick="deleteTemplate(${t.id},event)" title="Delete"><i class="hgi hgi-stroke hgi-delete-02"></i>Delete</button>` : ''}
      <div class="tpl-icon"><i class="hgi hgi-stroke hgi-${t.thumbnail_emoji || 'blockchain-05'}"></i></div>
      <div>
        <div class="tpl-title">${escHtml(t.name)}</div>
        <div class="tpl-info">${escHtml(t.description || '')}</div>
        ${blockCount ? `<div class="badge badge-sm badge-warning my-2">${blockCount} blocks</div>` : ''}
      </div>      
      <button onclick="useTemplate(${t.id},event)" class="btn btn-xs w-full">Use This</button>`;
            grid.appendChild(card);
        });
    }

    function filterTemplates(cat, btn) {
        activeCat = cat;
        document.querySelectorAll('.tpl-cat-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const filtered = cat === 'all' ? allTemplates :
            cat === 'saved' ? allTemplates.filter(t => t.source === 'saved') :
            allTemplates.filter(t => t.category === cat);
        renderTemplates(filtered);
    }

    function useBlankTemplate() {
        closeTemplatePicker();
        // Open page builder in new tab - campaign_view stays open
        window.open(`${BUILDER_URL}?campaign_id=${CAMPAIGN_ID}&new=1`, '_blank');
        // Reload this page after 2s to show the new page in list
        setTimeout(() => window.location.reload(), 2500);
    }

    async function useTemplate(id, e) {
        e.stopPropagation();
        try {
            const res = await fetch(`${TEMPLATES_URL}?action=get&id=${id}`);
            const data = await res.json();
            if (!data.ok) {
                alert('Could not load template.');
                return;
            }
            // Pass page_data as encoded param to page_builder
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = `${BUILDER_URL}?campaign_id=${CAMPAIGN_ID}&new=1&from_template=1`;
            form.target = '_blank'; // Open in new tab
            form.style.display = 'none';
            form.innerHTML = `<input type="hidden" name="_csrf" value="<?= csrf_token() ?>">
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="title" value="${escHtml(data.name)}">
      <input type="hidden" name="page_data" value="${escAttr(data.page_data)}">
      <input type="hidden" name="meta_title" value="">
      <input type="hidden" name="meta_desc"  value="">
      <input type="hidden" name="form_id"    value="0">
      <input type="hidden" name="page_bg"    value="#ffffff">`;
            document.body.appendChild(form);
            closeTemplatePicker();
            form.submit();
            // Reload this page after 2s so new page appears in list
            setTimeout(() => window.location.reload(), 2500);
        } catch (err) {
            alert('Failed to load template. Please try again.');
        }
    }

    async function deleteTemplate(id, e) {
        e.stopPropagation();
        if (!confirm('Delete this saved template?')) return;
        const fd = new FormData();
        fd.append('action', 'delete');
        fd.append('id', id);
        fd.append('_csrf', '<?= csrf_token() ?>');
        const res = await fetch(TEMPLATES_URL, {
            method: 'POST',
            body: fd
        });
        const data = await res.json();
        if (data.ok) {
            allTemplates = allTemplates.filter(t => t.id !== id);
            const filtered = activeCat === 'all' ? allTemplates :
                activeCat === 'saved' ? allTemplates.filter(t => t.source === 'saved') :
                allTemplates.filter(t => t.category === activeCat);
            renderTemplates(filtered);
        }
    }

    function escHtml(s) {
        return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function escAttr(s) {
        return String(s || '').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }
</script>

<?php include __DIR__ . '/layouts/footer.php'; ?>