<?php
require_once __DIR__ . '/config/auth.php';

$user = require_permission('platform', 'manage_accounts');
// Only super admin can access this page
if (!is_super_admin()) {
    http_response_code(403); include __DIR__ . '/layouts/403.php'; exit;
}

$page_title = 'Accounts';
$active_nav = 'accounts';

$plans  = ['free', 'starter', 'pro', 'enterprise'];
$statuses = ['active', 'suspended', 'cancelled'];

// Fetch dynamic pricing plans from DB for plan assignment
$pricing_plans = db_fetch_all('SELECT id, name, slug, price_monthly, trial_days FROM pricing_plans WHERE is_active = 1 ORDER BY price_monthly ASC');

// ── Helpers ──────────────────────────────────────────────────
function account_slug(string $name): string {
    $base = strtolower(trim(preg_replace('/[^a-zA-Z0-9]+/', '-', $name), '-'));
    $slug = $base; $i = 1;
    while (db_fetch('SELECT id FROM accounts WHERE slug = ?', 's', $slug)) {
        $slug = $base . '-' . ($i++);
    }
    return $slug;
}

// ── Actions ──────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { http_response_code(403); die('CSRF'); }
    $act = $_POST['action'] ?? '';

    if ($act === 'create') {
        $name      = trim($_POST['name'] ?? '');
        $email     = trim($_POST['email'] ?? '');
        $phone     = trim($_POST['phone'] ?? '');
        $website   = trim($_POST['website'] ?? '');
        $plan_slug = trim($_POST['plan'] ?? 'free');
        $expires   = trim($_POST['plan_expires_at'] ?? '');

        // Owner user fields
        $first   = trim($_POST['owner_first'] ?? '');
        $last    = trim($_POST['owner_last'] ?? '');
        $oemail  = trim($_POST['owner_email'] ?? '');
        $opass   = trim($_POST['owner_password'] ?? '');

        // Validate plan slug against DB (or allow 'free')
        $chosen_plan = null;
        if ($plan_slug !== 'free') {
            $chosen_plan = db_fetch('SELECT * FROM pricing_plans WHERE slug = ? AND is_active = 1', 's', $plan_slug);
            if (!$chosen_plan) $plan_slug = 'free';
        }

        if (!$name || !$email || !$first || !$last || !$oemail || !$opass) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'All required fields must be filled.'];
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || !filter_var($oemail, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Please enter valid email addresses.'];
        } elseif (db_fetch('SELECT id FROM users WHERE email = ?', 's', $oemail)) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'A user with that email already exists.'];
        } else {
            $slug = account_slug($name);

            // Calculate expiry if a plan was chosen
            $plan_expires = null;
            if ($chosen_plan) {
                if ($expires) {
                    $plan_expires = $expires . ' 23:59:59';
                } else {
                    $trial_days = (int)($chosen_plan['trial_days'] ?? 14);
                    $plan_expires = date('Y-m-d H:i:s', strtotime("+{$trial_days} days"));
                }
            } elseif ($expires) {
                $plan_expires = $expires . ' 23:59:59';
            }

            // accounts.plan is a legacy ENUM('free','starter','pro','enterprise').
            // Custom plan slugs will break it — always write 'free' here.
            // The real plan assignment lives in account_plans.
            $legacy_plan = in_array($plan_slug, ['free','starter','pro','enterprise']) ? $plan_slug : 'free';
            $aid = db_insert(
                'INSERT INTO accounts (name, slug, email, phone, website, plan, plan_expires_at, status) VALUES (?,?,?,?,?,?,?,?)',
                'ssssssss',
                $name, $slug, $email, $phone, $website, $legacy_plan, $plan_expires, 'active'
            );
            if ($aid) {
                // Also create account_plans row if a real plan was selected
                if ($chosen_plan) {
                    $now    = date('Y-m-d H:i:s');
                    $status = 'trial';
                    $stmt = db()->prepare(
                        'INSERT INTO account_plans (account_id, plan_id, status, plan_starts_at, plan_expires_at)
                         VALUES (?, ?, ?, ?, ?)
                         ON DUPLICATE KEY UPDATE plan_id=VALUES(plan_id), status=VALUES(status),
                           plan_starts_at=VALUES(plan_starts_at), plan_expires_at=VALUES(plan_expires_at), updated_at=NOW()'
                    );
                    $stmt->bind_param('iisss', $aid, $chosen_plan['id'], $status, $now, $plan_expires);
                    $stmt->execute();
                }

                // Get account_owner role id
                $owner_role = db_fetch("SELECT id FROM roles WHERE name = 'account_owner'");
                $hash = password_hash($opass, PASSWORD_BCRYPT, ['cost' => 10]);
                db_insert(
                    'INSERT INTO users (account_id, role_id, first_name, last_name, email, password_hash, status, email_verified) VALUES (?,?,?,?,?,?,?,?)',
                    'iisssssi', $aid, $owner_role['id'], $first, $last, $oemail, $hash, 'active', 1
                );
                audit('account.created', "account:{$aid}", ['name' => $name]);
                $_SESSION['flash'] = ['type'=>'success','msg'=>'Account <strong>' . h($name) . '</strong> created with owner <strong>' . h($oemail) . '</strong>.'];
            } else {
                $_SESSION['flash'] = ['type'=>'error','msg'=>'Failed to create account. Check for duplicate slug/email.'];
            }
        }
    } elseif ($act === 'update_status') {
        $aid    = (int)($_POST['account_id'] ?? 0);
        $status = in_array($_POST['status'] ?? '', $statuses) ? $_POST['status'] : 'active';

        db_query('UPDATE accounts SET status = ? WHERE id = ?', 'si', $status, $aid);
        audit('account.status_changed', "account:{$aid}", ['status' => $status]);

        $_SESSION['flash'] = ['type'=>'success','msg'=>'Account status updated.'];
    } elseif ($act === 'update_plan') {
        $aid       = (int)($_POST['account_id'] ?? 0);
        $plan_id   = (int)($_POST['plan_id'] ?? 0);
        $sub_type  = $_POST['sub_type'] ?? 'trial'; // trial | active
        $custom_exp = trim($_POST['plan_expires_at'] ?? '') ?: null;

        if ($aid && $plan_id) {
            $pricing_plan = db_fetch('SELECT * FROM pricing_plans WHERE id = ? AND is_active = 1', 'i', $plan_id);
            if ($pricing_plan) {
                // Calculate expiry
                if ($custom_exp) {
                    $expires = $custom_exp . ' 23:59:59';
                } elseif ($sub_type === 'trial') {
                    $trial_days = (int)($pricing_plan['trial_days'] ?? 14);
                    $expires = date('Y-m-d H:i:s', strtotime("+{$trial_days} days"));
                } else {
                    $expires = date('Y-m-d H:i:s', strtotime('+1 month'));
                }

                $now    = date('Y-m-d H:i:s');
                $status = $sub_type === 'trial' ? 'trial' : 'active';

                // Upsert into account_plans
                $stmt = db()->prepare(
                    'INSERT INTO account_plans (account_id, plan_id, status, plan_starts_at, plan_expires_at)
                     VALUES (?, ?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE
                       plan_id = VALUES(plan_id),
                       status = VALUES(status),
                       plan_starts_at = VALUES(plan_starts_at),
                       plan_expires_at = VALUES(plan_expires_at),
                       updated_at = NOW()'
                );
                $stmt->bind_param('iisss', $aid, $plan_id, $status, $now, $expires);
                $stmt->execute();
                if ($stmt->error) {
                    $_SESSION['flash'] = ['type'=>'error','msg'=>'DB error (account_plans): ' . $stmt->error];
                    header('Location: ' . APP_URL . '/accounts.php'); exit;
                }

                // Keep legacy accounts.plan ENUM in sync — only map known enum values, else 'free'
                $legacy_slug = in_array($pricing_plan['slug'], ['free','starter','pro','enterprise']) ? $pricing_plan['slug'] : 'free';
                db_query('UPDATE accounts SET plan = ?, plan_expires_at = ? WHERE id = ?', 'ssi', $legacy_slug, $expires, $aid);

                audit('account.plan_assigned', "account:{$aid}", [
                    'plan' => $pricing_plan['name'],
                    'type' => $sub_type,
                    'expires' => $expires
                ]);
                $_SESSION['flash'] = ['type'=>'success','msg'=>'Plan <strong>' . h($pricing_plan['name']) . '</strong> assigned (' . $sub_type . ', expires ' . date('M d, Y', strtotime($expires)) . ').'];
            } else {
                $_SESSION['flash'] = ['type'=>'error','msg'=>'Invalid plan selected.'];
            }
        } else {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Missing account or plan.'];
        }
    } elseif ($act === 'delete') {
        $aid = (int)($_POST['account_id'] ?? 0);
        $acc = db_fetch('SELECT name FROM accounts WHERE id = ?', 'i', $aid);
        if ($acc) {
            db_query('DELETE FROM accounts WHERE id = ?', 'i', $aid);
            audit('account.deleted', "account:{$aid}", ['name' => $acc['name']]);
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Account deleted.'];
        }
    }

    header('Location: ' . APP_URL . '/accounts.php'); exit;
}

$flash  = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$search = trim($_GET['q'] ?? '');
$status_filter = $_GET['status'] ?? '';

$sql    = "SELECT a.*,
           COUNT(DISTINCT u.id)  AS user_count,
           COUNT(DISTINCT d.id)  AS domain_count,
           COUNT(DISTINCT f.id)  AS form_count,
           COUNT(DISTINCT l.id)  AS lead_count
           FROM accounts a
           LEFT JOIN users u      ON u.account_id = a.id
           LEFT JOIN domains d    ON d.account_id = a.id
           LEFT JOIN lead_forms f ON f.account_id = a.id
           LEFT JOIN leads l      ON l.account_id = a.id";
$types  = '';
$params = [];
$where  = [];

if ($search)        { $where[] = '(a.name LIKE ? OR a.email LIKE ?)'; $types .= 'ss'; $params[] = "%$search%"; $params[] = "%$search%"; }
if ($status_filter) { $where[] = 'a.status = ?'; $types .= 's'; $params[] = $status_filter; }

if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
$sql .= ' GROUP BY a.id ORDER BY a.created_at DESC';

$accounts = db_fetch_all($sql, $types, ...$params);

// Platform stats
$stats = [
    'accounts' => db_fetch('SELECT COUNT(*) AS n FROM accounts WHERE status = "active"')['n'] ?? 0,
    'users'    => db_fetch('SELECT COUNT(*) AS n FROM users WHERE status = "active"')['n'] ?? 0,
    'leads'    => db_fetch('SELECT COUNT(*) AS n FROM leads')['n'] ?? 0,
    'domains'  => db_fetch('SELECT COUNT(*) AS n FROM domains')['n'] ?? 0,
];

$plan_colors = ['free'=>'badge-gray','starter'=>'badge-blue','pro'=>'badge-purple','enterprise'=>'badge-yellow'];
$status_colors = ['active'=>'badge-green','suspended'=>'badge-yellow','cancelled'=>'badge-red'];

include __DIR__ . '/layouts/header.php';
?>

<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type'] ?> mb-5" data-auto-dismiss><?= $flash['msg'] ?></div>
<?php endif; ?>

<div class="page-header">
    <div>
        <h1 class="page-title"><i class="hgi hgi-stroke hgi-briefcase-06 mr-2"></i>Accounts</h1>
        <p class="page-subtitle">Manage all client accounts on the platform</p>
    </div>
    <button class="btn btn-primary btn-sm" onclick="openModal('createAccountModal')">
        <i class="hgi hgi-stroke hgi-plus-sign"></i>
        New Account
    </button>
</div>

<!-- Platform stats -->
<div class="grid grid-cols-4 gap-4 mb-6">
    <?php foreach ([
    ['Active Accounts', $stats['accounts'], 'var(--color-success-bg)',  'var(--color-success-text)',    'hgi-briefcase-06'],
    ['Active Users',    $stats['users'],    'var(--color-info-bg)',     'var(--color-info-text)',       'hgi-user-multiple-02'],
    ['Domains',         $stats['domains'],  'var(--color-warning-bg)',  'var(--color-warning-text)',    'hgi-globe-02'],
    ['Total Leads',     $stats['leads'],    'var(--color-danger-bg)',   'var(--color-danger-text)',     'hgi-user-account'],
  ] as [$label, $val, $bg, $color, $path]): ?>
    
    
    <div class="card stat-card">
        <div class="flex items-center justify-between">
            <div>
                <div class="stat-card-label"><?= $label ?></div>
                <div class="stat-card-value mt-1"><?= $val ?></div>
            </div>
            <div class="stat-card-icon bg-brand-100 color-brand-600" style="background: <?= $bg ?>; color: <?= $color ?>;">
                <i class="hgi hgi-stroke <?= $path ?>"></i>
            </div>
        </div>

    </div>
    <?php endforeach; ?>
</div>

<!-- Filters -->
<div class="mb-5">
    
    <form method="GET" class="flex flex-auto gap-2 items-center">

        <div class="input-wrapper has-icon-left flex-1">
            <span class="input-icon-left"><i class="hgi hgi-stroke hgi-search-01"></i></span>
            <input name="q" type="search" placeholder="Search accounts…" value="<?= h($search) ?>" class="input input-sm">
        </div>

        <select name="status" class="select select-sm" style="width: 200px;" onchange="this.form.submit()">
            <option value="">All statuses</option>
            <?php foreach ($statuses as $s): ?>
            <option value="<?= $s ?>" <?= $status_filter === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
            <?php endforeach; ?>
        </select>
        <?php if ($search || $status_filter): ?>
        <a href="accounts.php" class="btn btn-ghost btn-sm">Clear</a>
        <?php endif; ?>
        <span class="text-xs text-muted text-right"><?= count($accounts) ?> account<?= count($accounts) !== 1 ? 's' : '' ?></span>
    </form>
    
</div>

<!-- Accounts table -->
<div class="card">
    <?php if ($accounts): ?>
    <div style="overflow-x:auto;">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Account</th>
                    <th>Plan</th>
                    <th>Users</th>
                    <th>Domains</th>
                    <th>Leads</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th class="text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($accounts as $a): ?>
                <tr>
                    <td>
                        <div><?= h($a['name']) ?></div>
                        <div class="text-muted text-2xs"><?= h($a['email']) ?></div>
                    </td>
                    <td>
                        <span class="badge badge-sm <?= $plan_colors[$a['plan']] ?? 'badge-gray' ?>">
                            <?= ucfirst($a['plan']) ?>
                        </span>
                    </td>
                    <td class="font-bold"><?= (int)$a['user_count'] ?></td>
                    <td class="font-bold"><?= (int)$a['domain_count'] ?></td>
                    <td class="font-bold"><?= (int)$a['lead_count'] ?></td>
                    <td>
                        <span class="badge badge-sm <?= $status_colors[$a['status']] ?? 'badge-gray' ?>">
                            <span class="badge-dot"></span><?= ucfirst($a['status']) ?>
                        </span>
                    </td>
                    <td class="text-xs text-muted"><?= format_dt($a['created_at'], 'd M Y') ?></td>
                    <td>
                        <div class="flex justify-end gap-1">
                            <button class="btn btn-secondary btn-icon btn-xs" onclick="openModal('editModal<?= $a['id'] ?>')"><i class="hgi hgi-stroke hgi-edit-02"></i></button>
                            <a href="<?= APP_URL ?>/team.php?account_id=<?= $a['id'] ?>" class="btn btn-secondary btn-icon btn-xs"><i class="hgi hgi-stroke hgi-user-multiple"></i></a>
                            <a href="<?= APP_URL ?>/domains.php?account_id=<?= $a['id'] ?>" class="btn btn-secondary btn-icon btn-xs"><i class="hgi hgi-stroke hgi-globe-02"></i></a>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Delete account <?= h(addslashes($a['name'])) ?>? This permanently deletes ALL users, domains, forms and leads.')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="account_id" value="<?= $a['id'] ?>">
                                <button class="btn btn-danger btn-icon btn-xs"><i class="hgi hgi-stroke hgi-delete-01"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    
    <?php else: ?>
    
    <div class="empty-state">
        <div class="empty-state-icon">
            <i class="hgi hgi-stroke hgi-briefcase-06"></i>
        </div>
        <div class="empty-state-title"><?= $search ? 'No accounts match your search' : 'No accounts yet' ?></div>
        <div class="empty-state-desc">Create an account to get started. Each account gets its own users, domains and forms.</div>
        <?php if (!$search): ?>
        <button class="btn btn-primary" onclick="openModal('createAccountModal')"><i class="hgi hgi-stroke hgi-plus-sign"></i>Create first account</button>
        <?php endif; ?>
    </div>
    
    <?php endif; ?>
</div>

<!-- ── Create Account Modal ── -->

<div class="modal-overlay" id="modalDefault">
    <div class="modal">
        <div class="modal-header">
            <div>
                <h2 class="modal-title">Create New Project</h2>
                <p class="text-sm text-muted mt-1">Fill in the details to start your new fragrance formulation.</p>
            </div>
            <button class="modal-close" onclick="toggleModal('modalDefault')">
                <i class="hi hi-x-mark"></i>
            </button>
        </div>
        <div class="modal-body">
            <div class="">
                <div class="form-group">
                    <label class="label-text mb-2 block">Project Name</label>
                    <input type="text" class="input border-neutral-200 w-full" placeholder="e.g., Midnight Bloom Attar">
                </div>
                <div class="form-group">
                    <label class="label-text mb-2 block">Base Concentration</label>
                    <div class="tabs-pill">
                        <button class="tab-pill active">25% (Extrait)</button>
                        <button class="tab-pill">50% (Concentrate)</button>
                        <button class="tab-pill">100% (Pure Oil)</button>
                    </div>
                </div>
                <div class="alert alert-info">
                    <div class="alert-icon"><i class="hi hi-information-circle"></i></div>
                    <div class="alert-content">You can add raw materials and adjust ratios in the next step.</div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-sm btn-ghost" onclick="toggleModal('modalDefault')">Cancel</button>
            <button class="btn btn-sm btn-primary"><i class="hgi hgi-stroke hgi-tick-02"></i>Create Project</button>
        </div>
    </div>
</div>


<div class="modal-overlay" id="createAccountModal">
    <form class="modal" method="POST">
        <div class="modal-header">
            <div class="modal-title">Create Account</div>
            <button class="modal-close" onclick="closeModal('createAccountModal')">
                <i class="hgi hgi-stroke hgi-cancel-01"></i>
            </button>
        </div>
        <div class="modal-body">
          
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create">

            <div class="fieldset">Account Details</div>
            <div class="grid grid-cols-2 gap-3">
                <div class="form-group">
                    <label class="form-label">Account Name <span style="color:#ef4444">*</span></label>
                    <input name="name" type="text" class="input input-sm" placeholder="e.g. Acme Marketing" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Billing Email <span style="color:#ef4444">*</span></label>
                    <input name="email" type="email" class="input input-sm" placeholder="billing@company.com" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Phone</label>
                    <input name="phone" type="tel" class="input input-sm" placeholder="+1 234 567 8900">
                </div>
                <div class="form-group">
                    <label class="form-label">Website</label>
                    <input name="website" type="url" class="input input-sm" placeholder="https://company.com">
                </div>
                <div class="form-group">
                    <label class="form-label">Plan</label>
                    <select name="plan" class="select select-sm">
                        <option value="free">Free (No plan)</option>
                        <?php foreach ($pricing_plans as $pp): ?>
                        <option value="<?= h($pp['slug']) ?>" <?= $pp['slug'] === 'starter' ? 'selected' : '' ?>><?= h($pp['name']) ?> — $<?= number_format($pp['price_monthly'], 2) ?>/mo</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Plan Expires</label>
                    <input name="plan_expires_at" type="date" class="input input-sm">
                </div>
            </div>

            
            <div class="fieldset">Account Owner</div>
            <div class="grid grid-cols-2 gap-3">
                <div class="form-group">
                    <label class="form-label">First Name <span style="color:#ef4444">*</span></label>
                    <input name="owner_first" type="text" class="input input-sm" placeholder="Jane" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Last Name <span style="color:#ef4444">*</span></label>
                    <input name="owner_last" type="text" class="input input-sm" placeholder="Smith" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Email <span style="color:#ef4444">*</span></label>
                    <input name="owner_email" type="email" class="input input-sm" placeholder="jane@company.com" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Password <span style="color:#ef4444">*</span></label>
                    <input name="owner_password" type="password" class="input input-sm" placeholder="Min 8 characters" minlength="8" required>
                </div>
            </div>
          
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-sm btn-secondary" onclick="closeModal('createAccountModal')">Cancel</button>
            <button type="submit" class="btn btn-sm btn-primary"><i class="hgi hgi-stroke hgi-tick-02"></i>Create Account & Owner</button>
        </div>
    </form>
</div>

<!-- ── Edit Account Modals ── -->
<?php foreach ($accounts as $a):
    $a_active_plan = db_fetch(
        'SELECT ap.*, p.name AS plan_name, p.price_monthly FROM account_plans ap
         JOIN pricing_plans p ON p.id = ap.plan_id
         WHERE ap.account_id = ? ORDER BY ap.id DESC LIMIT 1',
        'i', $a['id']
    );
?>
<div class="modal-overlay" id="editModal<?= $a['id'] ?>">
    <div class="modal">
        <div class="modal-header">
            <div class="modal-title">Edit: <?= h($a['name']) ?></div>
            <button class="modal-close" onclick="closeModal('editModal<?= $a['id'] ?>')">
                <i class="hgi hgi-stroke hgi-cancel-01"></i>
            </button>
        </div>
        <div class="modal-body">

            <!-- Current Plan Info -->
            <div class="fieldset">Current Plan</div>
            <?php if ($a_active_plan): ?>
            <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:6px;padding:10px 12px;font-size:.85rem;margin-bottom:12px;">
                <strong><?= h($a_active_plan['plan_name']) ?></strong>
                <span style="color:#6b7280;"> — $<?= number_format($a_active_plan['price_monthly'],2) ?>/mo</span>
                <span style="margin-left:8px;background:<?= $a_active_plan['status']==='active'?'#dcfce7':'#fef3c7' ?>;color:<?= $a_active_plan['status']==='active'?'#166534':'#92400e' ?>;padding:2px 6px;border-radius:3px;font-size:.75rem;"><?= ucfirst($a_active_plan['status']) ?></span>
                <div style="color:#6b7280;font-size:.78rem;margin-top:3px;">Expires: <?= $a_active_plan['plan_expires_at'] ? date('M d, Y', strtotime($a_active_plan['plan_expires_at'])) : 'N/A' ?></div>
            </div>
            <?php else: ?>
            <p style="font-size:.85rem;color:#6b7280;margin-bottom:12px;">No plan assigned yet.</p>
            <?php endif; ?>

            <!-- ── FORM 1: Assign Plan ── -->
            <div class="fieldset">Assign / Change Plan</div>
            <form method="POST" id="planForm<?= $a['id'] ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="update_plan">
                <input type="hidden" name="account_id" value="<?= $a['id'] ?>">
                <div class="grid grid-cols-2 gap-3">
                    <div class="form-group" style="grid-column:1/-1;">
                        <label class="form-label">Plan</label>
                        <select name="plan_id" class="select select-sm" required>
                            <option value="">— Select plan —</option>
                            <?php foreach ($pricing_plans as $pp): ?>
                            <option value="<?= $pp['id'] ?>" <?= ($a_active_plan && (int)$a_active_plan['plan_id'] === (int)$pp['id']) ? 'selected' : '' ?>>
                                <?= h($pp['name']) ?> — $<?= number_format($pp['price_monthly'],2) ?>/mo (<?= $pp['trial_days'] ?>-day trial)
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Type</label>
                        <select name="sub_type" class="select select-sm">
                            <option value="trial">Trial (<?= $pricing_plans[0]['trial_days'] ?? 14 ?> days)</option>
                            <option value="active">Active (1 month)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Custom Expiry <span style="color:#9ca3af;font-weight:400;">(optional)</span></label>
                        <input name="plan_expires_at" type="date" class="input input-sm">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-sm mt-3"><i class="hgi hgi-stroke hgi-tick-02"></i> Assign Plan</button>
            </form>

            <!-- ── FORM 2: Update Status ── -->
            <div class="fieldset" style="margin-top:16px;">Account Status</div>
            <form method="POST" id="statusForm<?= $a['id'] ?>" style="display:flex;gap:8px;align-items:center;">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="update_status">
                <input type="hidden" name="account_id" value="<?= $a['id'] ?>">
                <select name="status" class="select select-sm" style="flex:1;">
                    <?php foreach ($statuses as $s): ?>
                    <option value="<?= $s ?>" <?= $a['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-secondary btn-sm">Update Status</button>
            </form>

        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-ghost btn-sm" onclick="closeModal('editModal<?= $a['id'] ?>')">Close</button>
        </div>
    </div>
</div>
<?php endforeach; ?>

<?php include __DIR__ . '/layouts/footer.php'; ?>