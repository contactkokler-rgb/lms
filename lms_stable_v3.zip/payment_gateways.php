<?php
/**
 * LeadPro — Payment Gateway Configuration (Super Admin)
 * Configure Stripe and PhonePe for payment processing
 */
require_once __DIR__ . '/config/auth.php';
$user = require_permission('platform', 'manage_payments');
if (!is_super_admin()) {
    $_SESSION['flash'] = ['type'=>'error','msg'=>'Access denied'];
    header('Location: ' . APP_URL . '/index.php'); exit;
}

$page_title = 'Payment Gateways';
$active_nav = 'payment_gateways';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        http_response_code(403); die('CSRF');
    }

    $gateway = trim($_POST['gateway'] ?? '');
    $enabled = (int)($_POST['enabled'] ?? 0);
    $mode = in_array($_POST['mode'] ?? 'test', ['test', 'live']) ? $_POST['mode'] : 'test';
    $key = trim($_POST['key'] ?? '');
    $secret = trim($_POST['secret'] ?? '');
    $webhook = trim($_POST['webhook'] ?? '');

    if ($gateway === 'Stripe' || $gateway === 'PhonePe') {
        $stmt = db()->prepare(
            'UPDATE payment_gateways 
             SET is_enabled = ?, config_mode = ?, config_key = ?, config_secret = ?, config_webhook = ?, updated_at = NOW()
             WHERE gateway_name = ?'
        );
        $stmt->bind_param('isssss', $enabled, $mode, $key, $secret, $webhook, $gateway);
        if ($stmt->execute()) {
            $_SESSION['flash'] = ['type' => 'success', 'msg' => $gateway . ' settings updated'];
        } else {
            $_SESSION['flash'] = ['type' => 'error', 'msg' => 'Update failed: ' . $stmt->error];
        }
        header('Location: ' . APP_URL . '/payment_gateways.php'); exit;
    }
}

$gateways = db_fetch_all('SELECT * FROM payment_gateways ORDER BY gateway_name');

include __DIR__ . '/layouts/header.php';
?>

<div class="page-header">
    <div>
        <div class="page-title"><i class="hgi hgi-stroke hgi-credit-card-02"></i> Payment Gateways</div>
        <div class="page-subtitle">Configure Stripe and PhonePe payment processing</div>
    </div>
</div>

<?php if (isset($_SESSION['flash'])): ?>
<div class="alert alert-<?= $_SESSION['flash']['type'] ?>">
    <?= $_SESSION['flash']['msg'] ?>
</div>
<?php unset($_SESSION['flash']); endif; ?>

<div style="display:grid;gap:20px;">
    <?php foreach ($gateways as $gw): ?>
    <div class="card">
        <div class="card-header">
            <div>
                <div class="card-title"><?= h($gw['gateway_name']) ?></div>
                <div style="font-size:.8rem;color:var(--gray-500);">
                    <?= $gw['is_enabled'] ? '✓ Enabled' : '○ Disabled' ?> — 
                    <?= ucfirst($gw['config_mode']) ?> Mode
                </div>
            </div>
            <span class="badge <?= $gw['is_enabled'] ? 'badge-success' : 'badge-secondary' ?>">
                <?= $gw['is_enabled'] ? 'ACTIVE' : 'INACTIVE' ?>
            </span>
        </div>
        <div class="card-body">
            <form method="POST">
                <input type="hidden" name="_csrf" value="<?= csrf_token() ?>">
                <input type="hidden" name="gateway" value="<?= h($gw['gateway_name']) ?>">

                <div style="display:flex;gap:16px;margin-bottom:16px;align-items:center;">
                    <label style="display:flex;align-items:center;gap:8px;margin:0;">
                        <input type="checkbox" name="enabled" value="1" <?= $gw['is_enabled'] ? 'checked' : '' ?>>
                        <span style="font-weight:600;">Enable <?= h($gw['gateway_name']) ?></span>
                    </label>
                    <select name="mode" style="padding:8px 12px;border:1px solid var(--border);border-radius:6px;">
                        <option value="test" <?= $gw['config_mode'] === 'test' ? 'selected' : '' ?>>Test Mode</option>
                        <option value="live" <?= $gw['config_mode'] === 'live' ? 'selected' : '' ?>>Live Mode</option>
                    </select>
                </div>

                <div class="stack">
                    <label>API Key / Public Key</label>
                    <input type="password" name="key" value="<?= h($gw['config_key'] ?? '') ?>" placeholder="Enter API key">
                    <small style="color:var(--gray-500);">For Stripe: Publishable Key | For PhonePe: Merchant ID</small>
                </div>

                <div class="stack">
                    <label>Secret Key / Password</label>
                    <input type="password" name="secret" value="<?= h($gw['config_secret'] ?? '') ?>" placeholder="Enter secret key">
                    <small style="color:var(--gray-500);">For Stripe: Secret Key | For PhonePe: API Password</small>
                </div>

                <div class="stack">
                    <label>Webhook URL / Callback URL</label>
                    <input type="text" name="webhook" value="<?= h($gw['config_webhook'] ?? '') ?>" placeholder="https://yourdomain.com/webhooks/...">
                    <small style="color:var(--gray-500);">URL for payment notifications</small>
                </div>

                <button type="submit" class="btn btn-primary" style="margin-top:16px;">Save Settings</button>
            </form>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php include __DIR__ . '/layouts/footer.php'; ?>

<style>
.alert {
    padding:12px 14px;
    border-radius:8px;
    margin-bottom:16px;
    font-size:.9rem;
}
.alert-success {
    background:#dcfce7;
    color:#166534;
    border:1px solid #bbf7d0;
}
.alert-error {
    background:#fee2e2;
    color:#991b1b;
    border:1px solid #fecaca;
}
.stack {
    display:flex;
    flex-direction:column;
    gap:6px;
    margin-bottom:12px;
}
.stack label {
    font-weight:600;
    font-size:.9rem;
}
.stack input {
    padding:8px 12px;
    border:1px solid var(--border);
    border-radius:6px;
}
.stack small {
    display:block;
    font-size:.75rem;
}
</style>
