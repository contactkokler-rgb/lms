<?php
declare(strict_types=1);

final class OpenRouterClient
{
    public function __construct(private readonly HttpClient $httpClient)
    {
    }

    public function analyze(array $auditSummary): array
    {
        $response = $this->requestJson(
            'You are a senior technical SEO, analytics, CRO, and customer experience consultant. Return only valid JSON and do not wrap it in markdown.',
            $this->buildAnalyzePrompt($auditSummary),
            0.3,
            2200,
            35
        );

        if (!$response['success']) {
            return [
                'available' => false,
                'source' => 'local-fallback',
                'error' => $response['error'],
            ];
        }

        $parsed = $response['parsed'];

        return [
            'available' => true,
            'source' => 'OpenRouter',
            'model' => (string) app_config('openrouter.model', 'openai/gpt-4o-mini'),
            'executive_summary' => trim((string) ($parsed['executive_summary'] ?? '')),
            'top_priorities' => $this->normalizePriorities($parsed['top_priorities'] ?? []),
            'quick_wins' => $this->normalizeStringList($parsed['quick_wins'] ?? []),
            'content_strategy' => $this->normalizeStringList($parsed['content_strategy'] ?? []),
            'analytics_strategy' => $this->normalizeStringList($parsed['analytics_strategy'] ?? []),
            'competitor_outrank_reasons' => $this->normalizeStringList($parsed['competitor_outrank_reasons'] ?? []),
            'competitor_strategy' => $this->normalizeStringList($parsed['competitor_strategy'] ?? []),
            'ecommerce_strategy' => $this->normalizeStringList($parsed['ecommerce_strategy'] ?? []),
            'chatbot_strategy' => $this->normalizeStringList($parsed['chatbot_strategy'] ?? []),
            'keyword_opportunities' => $this->normalizeStringList($parsed['keyword_opportunities'] ?? [], 6),
            'content_suggestions' => $this->normalizeStringList($parsed['content_suggestions'] ?? [], 6),
            'important_suggestions' => $this->normalizeStringList($parsed['important_suggestions'] ?? [], 6),
            'growth_plan' => $this->normalizeGrowthPlan($parsed['growth_plan'] ?? []),
            'stakeholder_note' => trim((string) ($parsed['stakeholder_note'] ?? '')),
            'error' => null,
        ];
    }

    public function generateContent(array $context): array
    {
        $response = $this->requestJson(
            'You are an editorial strategist and conversion-focused SEO writer. Return only valid JSON. Use a natural, specific, human-sounding voice. Avoid generic AI phrasing, filler, and repetitive sentence patterns.',
            $this->buildContentPrompt($context),
            0.7,
            2400,
            45
        );

        if (!$response['success']) {
            return $this->buildContentFallback($context, $response['error']);
        }

        $parsed = $response['parsed'];
        $primaryKeyword = trim((string) ($context['primary_keyword'] ?? ''));

        return [
            'available' => true,
            'source' => 'OpenRouter',
            'model' => (string) app_config('openrouter.model', 'openai/gpt-4o-mini'),
            'title_options' => $this->normalizeStringList($parsed['title_options'] ?? [], 4),
            'meta_description' => $this->normalizeMetaDescription((string) ($parsed['meta_description'] ?? '')),
            'slug' => $this->normalizeSlug((string) ($parsed['slug'] ?? ''), $primaryKeyword),
            'outline' => $this->normalizeStringList($parsed['outline'] ?? [], 12),
            'keyword_usage_notes' => $this->normalizeStringList($parsed['keyword_usage_notes'] ?? [], 6),
            'faq_questions' => $this->normalizeStringList($parsed['faq_questions'] ?? [], 6),
            'content' => $this->normalizeGeneratedContent((string) ($parsed['content'] ?? '')),
            'editor_notes' => $this->normalizeStringList($parsed['editor_notes'] ?? [], 6),
            'error' => null,
        ];
    }

    private function requestJson(string $systemPrompt, string $userPrompt, float $temperature, int $maxTokens, int $timeout): array
    {
        $apiKey = trim(function_exists('ps') ? ps('ai_api_key','') : (string) app_config('openrouter.api_key', ''));
        if ($apiKey === '') {
            return [
                'success' => false,
                'parsed' => null,
                'error' => 'OpenRouter API key not configured. Set it in Platform Settings → AI & API.',
            ];
        }
        
        /*
        $apiKey = trim((string) app_config('openrouter.api_key', ''));
        if ($apiKey === '') {
            return [
                'success' => false,
                'parsed' => null,
                'error' => 'OpenRouter API key is not configured.',
            ];
        }
        */  

        $payload = [
            'model' => function_exists('ps') ? ps('ai_model','meta-llama/llama-3.3-70b-instruct:free') : (string) app_config('openrouter.model', 'openai/gpt-4o-mini'),
            'temperature' => $temperature,
            'max_tokens' => $maxTokens,
            'messages' => [
                [
                    'role' => 'system',
                    'content' => $systemPrompt,
                ],
                [
                    'role' => 'user',
                    'content' => $userPrompt,
                ],
            ],
        ];

        $response = $this->httpClient->post('https://openrouter.ai/api/v1/chat/completions', [
            'timeout' => $timeout,
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $apiKey,
                'HTTP-Referer' => $this->resolveSiteUrl(),
                'X-Title' => (string) app_config('openrouter.site_name', app_config('app.name', 'SEO Audit Tool')),
            ],
            'body' => json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE),
        ]);

        if (!$response['success']) {
            return [
                'success' => false,
                'parsed' => null,
                'error' => (string) ($response['error'] ?? 'OpenRouter request failed.'),
            ];
        }

        $status = (int) ($response['status'] ?? 0);
        $decoded = json_decode((string) ($response['body'] ?? ''), true);

        if ($status >= 400) {
            $errorMessage = $decoded['error']['message'] ?? ('OpenRouter responded with HTTP ' . $status . '.');
            return [
                'success' => false,
                'parsed' => null,
                'error' => (string) $errorMessage,
            ];
        }

        $content = $this->extractMessageContent($decoded['choices'][0]['message']['content'] ?? '');
        if ($content === '') {
            return [
                'success' => false,
                'parsed' => null,
                'error' => 'OpenRouter returned an empty response.',
            ];
        }

        $parsed = json_decode($this->extractJsonPayload($content), true);
        if (!is_array($parsed)) {
            return [
                'success' => false,
                'parsed' => null,
                'error' => 'OpenRouter response could not be parsed as JSON.',
            ];
        }

        return [
            'success' => true,
            'parsed' => $parsed,
            'error' => null,
        ];
    }

    private function buildAnalyzePrompt(array $auditSummary): string
    {
        $encodedSummary = json_encode($auditSummary, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);

        return <<<PROMPT
Turn the following website audit into a concise operating brief.

Rules:
- Use only the supplied data. Do not invent rankings, backlink counts, traffic, or competitor metrics.
- If competitor data is missing or limited, say so indirectly in the strategy rather than inventing details.
- Treat backlink comparison as heuristic if the payload says it is proxy-based.
- Keep the executive summary under 120 words.
- Return exactly this JSON object shape:
{
  "executive_summary": "string",
  "top_priorities": [
    {
      "title": "string",
      "why_it_matters": "string",
      "action": "string"
    }
  ],
  "quick_wins": ["string"],
  "content_strategy": ["string"],
  "analytics_strategy": ["string"],
  "competitor_outrank_reasons": ["string"],
  "competitor_strategy": ["string"],
  "ecommerce_strategy": ["string"],
  "chatbot_strategy": ["string"],
  "keyword_opportunities": ["string"],
  "content_suggestions": ["string"],
  "important_suggestions": ["string"],
  "growth_plan": [
    {
      "week": "Week 1",
      "focus": "string",
      "tasks": ["string"],
      "goal": "string"
    }
  ],
  "stakeholder_note": "string"
}
- `top_priorities` must contain exactly 3 items.
- Every strategy array must contain 2 to 4 items.
- `keyword_opportunities`, `content_suggestions`, and `important_suggestions` must each contain 3 to 5 items.
- `growth_plan` must contain exactly 4 items, one for each week of a 30-day plan.
- Each growth-plan week must include 2 to 4 concrete tasks.
- Keyword opportunities must stay grounded in the supplied keyword and crawl data. Do not make up search volume or difficulty.

Audit payload:
{$encodedSummary}
PROMPT;
    }

    private function buildContentPrompt(array $context): string
    {
        $encodedContext = json_encode($context, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);

        return <<<PROMPT
Create SEO-friendly, answer-engine-friendly website copy from this brief.

Rules:
- Use only the supplied context and notes. Do not invent company history, statistics, testimonials, or product facts.
- Write with a natural, grounded, human voice. Vary sentence length. Avoid cliches, generic filler, and robotic transitions.
- Do not mention AI, SEO optimization, or keyword stuffing.
- Use the primary keyword naturally and sparingly. Blend secondary keywords only where they fit the intent.
- Make the copy useful, specific, readable, and conversion-aware.
- Return exactly this JSON object shape:
{
  "title_options": ["string"],
  "meta_description": "string",
  "slug": "string",
  "outline": ["string"],
  "keyword_usage_notes": ["string"],
  "faq_questions": ["string"],
  "content": "string",
  "editor_notes": ["string"]
}
- `title_options` must contain 3 to 4 options.
- `meta_description` should be 140 to 160 characters.
- `outline` must contain 5 to 10 items.
- `keyword_usage_notes`, `faq_questions`, and `editor_notes` must each contain 3 to 5 items.
- `content` must be plain text only, not HTML or markdown, with clear section headings separated by blank lines.

Content brief:
{$encodedContext}
PROMPT;
    }

    private function buildContentFallback(array $context, string $error): array
    {
        $primaryKeyword = trim((string) ($context['primary_keyword'] ?? ''));
        $secondaryKeywords = $this->normalizeStringList($context['secondary_keywords'] ?? [], 5);
        $pageType = trim((string) ($context['page_type'] ?? 'landing page'));
        $audience = trim((string) ($context['audience'] ?? 'prospective customers'));
        $wordTarget = max(300, min(2400, (int) ($context['target_word_count'] ?? 900)));
        $titleBase = $primaryKeyword !== '' ? $this->titleizePhrase($primaryKeyword) : 'SEO Content Draft';
        $metaDescription = $primaryKeyword !== ''
            ? sprintf('Explore %s with clear, useful guidance tailored for %s. Built to answer key questions and move readers toward action.', strtolower($primaryKeyword), strtolower($audience))
            : 'Clear, useful website copy drafted from the available audit inputs.';

        $outline = [
            'Opening section: frame the problem and the practical outcome',
            'Why this matters: explain the stakes in plain language',
            'Core benefits or differentiators',
            'How the offer or process works',
            'Objections, trust signals, or proof points',
            'Next step or call to action',
        ];

        $content = implode("\n\n", [
            $titleBase,
            'Introduction',
            sprintf(
                'If you are evaluating %s, start with clarity. The page should explain what the offer is, who it is for, and why it is worth attention without leaning on vague claims. This draft gives you a practical baseline that can be refined with brand details, proof, and first-hand examples.',
                $primaryKeyword !== '' ? strtolower($primaryKeyword) : 'this topic'
            ),
            'Why It Matters',
            sprintf(
                'Readers comparing options move quickly. Strong %s copy reduces friction by answering the obvious questions early, showing relevance for %s, and making the next action feel straightforward.',
                $pageType,
                strtolower($audience)
            ),
            'What To Cover',
            $secondaryKeywords !== []
                ? 'Build the main body around the primary topic, then support it with related angles such as ' . implode(', ', $secondaryKeywords) . '. Keep each section concrete and avoid repeating the same phrasing.'
                : 'Build the main body around one clear topic, then support it with related questions, objections, and practical examples that help a reader make a decision.',
            'Suggested Closing',
            'End with a direct invitation to take the next step. Keep the call to action simple, specific, and aligned with the intent of the page.',
        ]);

        return [
            'available' => false,
            'source' => 'local-fallback',
            'model' => null,
            'title_options' => array_values(array_unique([
                $titleBase,
                $primaryKeyword !== '' ? $titleBase . ' Guide' : 'Clear Content Outline',
                $primaryKeyword !== '' ? $titleBase . ' for Better Conversion' : 'High-Intent Content Draft',
            ])),
            'meta_description' => $metaDescription,
            'slug' => $this->normalizeSlug('', $primaryKeyword !== '' ? $primaryKeyword : $titleBase),
            'outline' => $outline,
            'keyword_usage_notes' => [
                'Use the primary keyword in the title, opening paragraph, one subheading, and the close only where it reads naturally.',
                'Support the main phrase with adjacent terms instead of repeating the same wording every paragraph.',
                'Prioritize specificity, examples, and clear explanation over keyword density.',
            ],
            'faq_questions' => [
                'What problem does this page solve for the reader?',
                'How is this option different from the common alternatives?',
                'What should a visitor do next if the offer looks relevant?',
            ],
            'content' => $content,
            'editor_notes' => [
                'Replace generic placeholders with product, service, or brand specifics before publishing.',
                'Add proof points, examples, or customer objections that reflect real-world sales conversations.',
                'Aim for roughly ' . $wordTarget . ' words once the draft is expanded with real details.',
            ],
            'error' => $error,
        ];
    }

    private function resolveSiteUrl(): string
    {
        $configured = trim((string) app_config('openrouter.site_url', ''));
        if ($configured !== '') {
            return $configured;
        }

        $isHttps = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';

        return ($isHttps ? 'https://' : 'http://') . $host;
    }

    private function extractMessageContent(mixed $content): string
    {
        if (is_string($content)) {
            return trim($content);
        }

        if (!is_array($content)) {
            return '';
        }

        $parts = [];
        foreach ($content as $part) {
            if (is_array($part) && isset($part['text']) && is_string($part['text'])) {
                $parts[] = $part['text'];
            }
        }

        return trim(implode("\n", $parts));
    }

    private function extractJsonPayload(string $response): string
    {
        $start = strpos($response, '{');
        $end = strrpos($response, '}');

        if ($start === false || $end === false || $end <= $start) {
            return $response;
        }

        return substr($response, $start, ($end - $start) + 1);
    }

    private function normalizePriorities(array $items): array
    {
        $priorities = [];
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $title = trim((string) ($item['title'] ?? ''));
            $why = trim((string) ($item['why_it_matters'] ?? ''));
            $action = trim((string) ($item['action'] ?? ''));

            if ($title === '' || $action === '') {
                continue;
            }

            $priorities[] = [
                'title' => $title,
                'why_it_matters' => $why,
                'action' => $action,
            ];
        }

        return array_slice($priorities, 0, 3);
    }

    private function normalizeGrowthPlan(array $items): array
    {
        $weeks = [];
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $week = trim((string) ($item['week'] ?? ''));
            $focus = trim((string) ($item['focus'] ?? ''));
            $goal = trim((string) ($item['goal'] ?? ''));
            $tasks = $this->normalizeStringList($item['tasks'] ?? [], 4);

            if ($week === '' || $focus === '' || $tasks === []) {
                continue;
            }

            $weeks[] = [
                'week' => $week,
                'focus' => $focus,
                'tasks' => $tasks,
                'goal' => $goal,
            ];
        }

        return array_slice($weeks, 0, 4);
    }

    private function normalizeStringList(array $items, int $limit = 5): array
    {
        $normalized = [];
        foreach ($items as $item) {
            $value = trim((string) $item);
            if ($value !== '') {
                $normalized[] = $value;
            }
        }

        return array_values(array_slice(array_unique($normalized), 0, $limit));
    }

    private function normalizeSlug(string $candidate, string $fallback): string
    {
        $source = trim($candidate) !== '' ? $candidate : $fallback;
        $slug = strtolower($source);
        $slug = preg_replace('/[^a-z0-9]+/', '-', $slug);
        $slug = trim((string) $slug, '-');

        return $slug !== '' ? $slug : 'seo-content-draft';
    }

    private function normalizeGeneratedContent(string $content): string
    {
        $normalized = str_replace(["\r\n", "\r"], "\n", trim($content));
        $normalized = preg_replace("/\n{3,}/", "\n\n", $normalized);

        return trim((string) $normalized);
    }

    private function normalizeMetaDescription(string $value): string
    {
        $normalized = trim($value);
        if ($normalized === '') {
            return '';
        }

        if ($this->textLength($normalized) <= 160) {
            return $normalized;
        }

        $trimmed = function_exists('mb_substr') ? mb_substr($normalized, 0, 157) : substr($normalized, 0, 157);
        $trimmed = preg_replace('/\s+\S*$/u', '', (string) $trimmed);

        return rtrim((string) $trimmed, " ,;:-") . '...';
    }

    private function titleizePhrase(string $value): string
    {
        $words = preg_split('/\s+/', trim($value)) ?: [];
        $words = array_map(static fn(string $word): string => ucfirst(strtolower($word)), $words);

        return trim(implode(' ', $words));
    }

    private function textLength(string $text): int
    {
        return function_exists('mb_strlen') ? mb_strlen($text) : strlen($text);
    }
}
