<?php
/**
 * LeadPro — SEO Audit Save Endpoint
 */
$_RAW_INPUT = file_get_contents('php://input');

require_once __DIR__ . '/../config/auth.php';
$user = require_permission('auditor', 'run');

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'POST only']); exit;
}

if (!csrf_verify()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Invalid CSRF token']); exit;
}

if (!$_RAW_INPUT) {
    http_response_code(422);
    echo json_encode(['success' => false, 'error' => 'Empty request body']); exit;
}

$body = json_decode($_RAW_INPUT, true);
if (!is_array($body)) {
    http_response_code(422);
    echo json_encode(['success' => false, 'error' => 'Invalid JSON: ' . json_last_error_msg()]); exit;
}

$url         = trim((string)($body['url']   ?? ''));
$score       = (int)($body['score']         ?? 0);
$result_data = $body['result_json']         ?? null;

if ($url === '') {
    http_response_code(422);
    echo json_encode(['success' => false, 'error' => 'Missing url']); exit;
}
if (!is_array($result_data) || empty($result_data)) {
    http_response_code(422);
    echo json_encode(['success' => false, 'error' => 'Missing result_json. Keys: ' . implode(',', array_keys($body))]); exit;
}

$result_json_str = json_encode(
    $result_data,
    JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
);
if ($result_json_str === false) {
    http_response_code(422);
    echo json_encode(['success' => false, 'error' => 'json_encode failed: ' . json_last_error_msg()]); exit;
}

try {
    $db = db();

    if ($db->query("SHOW TABLES LIKE 'seo_audits'")->num_rows === 0) {
        http_response_code(503);
        echo json_encode(['success' => false, 'error' => 'Run install_auditor.sql first']); exit;
    }

    // Ensure columns exist
    $col_res   = $db->query("SHOW COLUMNS FROM seo_audits");
    $col_names = [];
    while ($c = $col_res->fetch_assoc()) { $col_names[] = $c['Field']; }
    if (!in_array('public_token', $col_names, true)) {
        $db->query("ALTER TABLE seo_audits ADD COLUMN public_token char(48) DEFAULT NULL AFTER result_json, ADD UNIQUE KEY idx_sa_token (public_token)");
    }
    if (!in_array('emailed_at', $col_names, true)) {
        $db->query("ALTER TABLE seo_audits ADD COLUMN emailed_at datetime DEFAULT NULL AFTER public_token");
    }

    // Account
    $account_id = (int)($user['account_id'] ?? $_SESSION['account_id'] ?? 0);
    if ($account_id === 0) {
        $acc = db_fetch('SELECT id FROM accounts ORDER BY id ASC LIMIT 1');
        $account_id = (int)($acc['id'] ?? 1);
    }

    // Timezone-aware timestamp
    $tz_row = db_fetch('SELECT timezone FROM accounts WHERE id = ?', 'i', $account_id);
    $tz_str = (!empty($tz_row['timezone'])) ? $tz_row['timezone'] : 'UTC';
    try { $tz = new DateTimeZone($tz_str); } catch (Exception $e) { $tz = new DateTimeZone('UTC'); }
    $now_local = (new DateTime('now', $tz))->format('Y-m-d H:i:s');

    $public_token = bin2hex(random_bytes(24));

    // ── Direct mysqli insert — bypass db_insert() which uses variadic bind_param
    // spread and cannot pass large strings by reference correctly ──────────────
    $stmt = $db->prepare(
        'INSERT INTO seo_audits
            (account_id, user_id, url, score_overall, result_json, public_token, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)'
    );

    if (!$stmt) {
        error_log('[SEO Auditor] prepare failed: ' . $db->error);
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'DB prepare failed: ' . $db->error]); exit;
    }

    // Bind each variable individually by reference — this is the correct way
    // to handle large strings with mysqli bind_param
    $v_account_id   = $account_id;
    $v_user_id      = (int)$user['id'];
    $v_url          = mb_substr($url, 0, 500);
    $v_score        = $score;
    $v_result_json  = $result_json_str;
    $v_token        = $public_token;
    $v_created_at   = $now_local;

    $stmt->bind_param(
        'iisisss',
        $v_account_id,
        $v_user_id,
        $v_url,
        $v_score,
        $v_result_json,
        $v_token,
        $v_created_at
    );

    if (!$stmt->execute()) {
        error_log('[SEO Auditor] execute failed: ' . $stmt->error);
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'DB execute failed: ' . $stmt->error]); exit;
    }

    $audit_id = (int)$db->insert_id;
    $stmt->close();

    if (!$audit_id) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Insert returned no ID']); exit;
    }

    // Confirm saved length
    $saved     = db_fetch('SELECT LENGTH(result_json) AS rjlen FROM seo_audits WHERE id = ?', 'i', $audit_id);
    $saved_len = (int)($saved['rjlen'] ?? 0);
    error_log('[SEO Auditor] saved #' . $audit_id . ' result_json=' . $saved_len . 'B url=' . $url);

    echo json_encode([
        'success'      => true,
        'audit_id'     => $audit_id,
        'public_token' => $public_token,
    ]);

} catch (Throwable $e) {
    error_log('[SEO Auditor] save.php exception: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}