<?php
// TEMPORARY DIAGNOSTIC — delete after testing
$raw = file_get_contents('php://input');
header('Content-Type: application/json');
echo json_encode([
    'raw_length'      => strlen($raw),
    'raw_first_50'    => substr($raw, 0, 50),
    'content_type'    => $_SERVER['CONTENT_TYPE'] ?? 'not set',
    'content_length'  => $_SERVER['CONTENT_LENGTH'] ?? 'not set',
    'method'          => $_SERVER['REQUEST_METHOD'],
    'post_keys'       => array_keys($_POST),
    'parsed_ok'       => is_array(json_decode($raw, true)),
]);