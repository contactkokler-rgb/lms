<?php
declare(strict_types=1);
/**
 * LeadPro — SEO Auditor: Email Report
 * POST /auditor/email_report.php
 *
 * Sends a branded HTML email to a client with a "View Report" button
 * that links to the public report URL.
 */
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/mailer.php';

$user = require_permission('auditor', 'run');

// Account-owner restriction
if (!is_super_admin() && ($user['role_id'] ?? 0) > 2) {
    http_response_code(403);
    echo json_encode(['success'=>false,'error'=>'Permission denied']); exit;
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success'=>false,'error'=>'POST only']); exit;
}

if (!csrf_verify()) {
    http_response_code(403);
    echo json_encode(['success'=>false,'error'=>'Invalid CSRF token']); exit;
}

$audit_id    = (int)($_POST['audit_id']    ?? 0);
$to_email    = trim((string)($_POST['to_email']    ?? ''));
$to_name     = trim((string)($_POST['to_name']     ?? ''));
$note        = trim((string)($_POST['note']        ?? ''));
$account_id  = (int)($user['account_id'] ?? 0);

// Validate
if (!$audit_id)                                         { http_response_code(422); echo json_encode(['success'=>false,'error'=>'Missing audit ID']); exit; }
if (!filter_var($to_email, FILTER_VALIDATE_EMAIL))      { http_response_code(422); echo json_encode(['success'=>false,'error'=>'Invalid email address']); exit; }

// Fetch audit (scoped to account)
$db = db();
if ($db->query("SHOW TABLES LIKE 'seo_audits'")->num_rows === 0) {
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>'seo_audits table missing — run migrate_auditor_v2.sql']); exit;
}

$audit = db_fetch(
    'SELECT id, url, score_overall, public_token, created_at FROM seo_audits
     WHERE id = ? AND account_id = ?',
    'ii', $audit_id, $account_id
);

if (!$audit) {
    http_response_code(404);
    echo json_encode(['success'=>false,'error'=>'Audit not found']); exit;
}

// Ensure public token exists (generate if somehow missing)
if (empty($audit['public_token'])) {
    $token = bin2hex(random_bytes(24));
    db_query('UPDATE seo_audits SET public_token = ? WHERE id = ?', 'si', $token, $audit_id);
    $audit['public_token'] = $token;
}

$public_url  = APP_URL . '/seo_report.php?token=' . urlencode($audit['public_token']);
$score       = (int)$audit['score_overall'];
$score_color = $score >= 70 ? '#16a34a' : ($score >= 40 ? '#f59e0b' : '#ef4444');
$score_label = $score >= 70 ? 'Good' : ($score >= 40 ? 'Needs Improvement' : 'Poor');
$audit_url   = htmlspecialchars($audit['url'], ENT_QUOTES);
$audit_date  = date('d M Y', strtotime($audit['created_at']));
$app_name    = ps('app_name', 'LeadPro');
$sender_name = trim(($user['name'] ?? $user['email'] ?? 'The Team'));
$recipient   = $to_name ?: 'there';

// Build branded HTML email
$html = <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Your SEO Audit Report</title>
<style>
  body { margin:0; padding:0; background:#f1f5f9; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif; }
  .wrap { max-width:600px; margin:32px auto; }
  .card { background:#ffffff; border-radius:12px; overflow:hidden; box-shadow:0 1px 4px rgba(0,0,0,.08); }
  .header { background:#0f172a; padding:28px 32px; }
  .header h1 { margin:0; color:#fff; font-size:20px; font-weight:700; letter-spacing:-.3px; }
  .header p  { margin:4px 0 0; color:#94a3b8; font-size:13px; }
  .body   { padding:32px; }
  .greeting { font-size:16px; color:#1e293b; margin:0 0 16px; font-weight:500; }
  .intro    { font-size:14px; color:#475569; line-height:1.7; margin:0 0 24px; }
  .score-box { background:#f8fafc; border:1.5px solid #e2e8f0; border-radius:10px; padding:20px 24px; display:flex; align-items:center; gap:20px; margin-bottom:24px; }
  .score-num { font-size:52px; font-weight:900; line-height:1; color:{$score_color}; }
  .score-meta h3 { margin:0 0 4px; font-size:14px; font-weight:700; color:#1e293b; }
  .score-meta p  { margin:0 0 4px; font-size:13px; color:#64748b; word-break:break-all; }
  .score-meta .label { display:inline-block; padding:2px 10px; border-radius:20px; font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.04em; background:{$score_color}22; color:{$score_color}; }
  .btn-wrap { text-align:center; margin:8px 0 28px; }
  .btn { display:inline-block; background:#6366f1; color:#fff !important; text-decoration:none; padding:14px 36px; border-radius:8px; font-size:15px; font-weight:700; letter-spacing:-.1px; }
  .note-box { background:#fafafa; border-left:3px solid #6366f1; padding:12px 16px; border-radius:0 6px 6px 0; font-size:13px; color:#475569; line-height:1.6; margin-bottom:24px; }
  .divider { border:none; border-top:1px solid #e2e8f0; margin:24px 0; }
  .footer { font-size:12px; color:#94a3b8; text-align:center; padding:16px 32px 24px; line-height:1.6; }
  .footer a { color:#94a3b8; text-decoration:underline; }
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="header">
      <h1>{$app_name} — SEO Audit Report</h1>
      <p>Audited on {$audit_date}</p>
    </div>
    <div class="body">
      <p class="greeting">Hi {$recipient},</p>
      <p class="intro">
        Your SEO audit is ready. Here's a summary of the findings for
        <strong>{$audit_url}</strong>.
        Click the button below to view the full interactive report.
      </p>

      <div class="score-box">
        <div class="score-num">{$score}</div>
        <div class="score-meta">
          <h3>Overall SEO Score</h3>
          <p>{$audit_url}</p>
          <span class="label">{$score_label}</span>
        </div>
      </div>

HTML;

if ($note !== '') {
    $safe_note = nl2br(htmlspecialchars($note, ENT_QUOTES));
    $html .= <<<HTML
      <div class="note-box">
        <strong>Note from {$sender_name}:</strong><br>
        {$safe_note}
      </div>
HTML;
}

$html .= <<<HTML
      <div class="btn-wrap">
        <a href="{$public_url}" class="btn">View Full Report →</a>
      </div>

      <hr class="divider">
      <p style="font-size:13px;color:#64748b;text-align:center;margin:0;">
        This report was prepared by <strong>{$sender_name}</strong> using {$app_name}.<br>
        The report link is publicly accessible — no login required.
      </p>
    </div>
    <div class="footer">
      If you have questions, reply to this email.<br>
      <a href="{$public_url}">{$public_url}</a>
    </div>
  </div>
</div>
</body>
</html>
HTML;

// Send email
$subject = "Your SEO Audit Report — " . parse_url($audit['url'], PHP_URL_HOST);
$result  = send_email($to_email, $to_name ?: $to_email, $subject, $html, ['is_html' => true]);

if ($result['ok'] ?? false) {
    // Record sent timestamp
    db_query('UPDATE seo_audits SET emailed_at = NOW() WHERE id = ?', 'i', $audit_id);

    echo json_encode([
        'success'    => true,
        'message'    => 'Report sent to ' . $to_email,
        'public_url' => $public_url,
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error'   => 'Email failed: ' . ($result['error'] ?? 'unknown error'),
    ]);
}
