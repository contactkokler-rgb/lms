<?php
/**
 * Subscription Restrictions & Access Control Middleware
 */

require_once __DIR__ . '/PricingService.php';

/**
 * Check if action is allowed for account based on subscription status
 */
function checkSubscriptionRestrictions($account_id, $action) {
    $is_expired = PricingService::isSubscriptionExpired($account_id);
    
    if (!$is_expired) return true;

    // Define restricted actions when subscription expires
    $restricted_actions = [
        'edit_content',
        'create_campaign',
        'add_domain',
        'add_landing_page',
        'create_form',
        'add_team_member',
        'use_tools'
    ];

    return !in_array($action, $restricted_actions);
}

/**
 * Block action if subscription expired
 */
function requireActiveSubscription($action = 'general') {
    if (!isset($_SESSION['account_id'])) {
        http_response_code(401);
        die(json_encode(['success' => false, 'error' => 'Not authenticated']));
    }

    $account_id = (int)$_SESSION['account_id'];
    
    if (!checkSubscriptionRestrictions($account_id, $action)) {
        http_response_code(403);
        die(json_encode([
            'success' => false,
            'error' => 'This action requires an active subscription. Please renew your plan.',
            'action_blocked' => true
        ]));
    }
}

/**
 * Check usage limits before allowing action
 */
function checkUsageLimit($account_id, $type) {
    if (!PricingService::checkUsageLimit($account_id, $type)) {
        return [
            'allowed' => false,
            'message' => "You've reached the {$type} limit for this billing cycle.",
            'upgrade_required' => true
        ];
    }

    return ['allowed' => true];
}

/**
 * Track usage after action is completed
 */
function trackUsage($account_id, $type, $quantity = 1) {
    return PricingService::trackUsage($account_id, $type, $quantity);
}

/**
 * Get subscription-aware limits for account
 */
function getAccountLimits($account_id) {
    $sub = PricingService::getAccountSubscription($account_id);
    
    if (!$sub || !PricingService::isSubscriptionActive($account_id)) {
        return [
            'domains' => 0,
            'forms' => 0,
            'leads_per_month' => 0,
            'team_members' => 0,
            'tools_enabled' => false
        ];
    }

    return [
        'domains' => (int)$sub['domains_limit'],
        'forms' => (int)$sub['forms_limit'],
        'leads_per_month' => (int)$sub['leads_per_month'],
        'team_members' => (int)$sub['team_members_limit'],
        'tools_enabled' => true
    ];
}

/**
 * Get subscription status with readable format
 */
function getSubscriptionStatus($account_id) {
    $sub = PricingService::getAccountSubscription($account_id);
    
    if (!$sub) {
        return [
            'active' => false,
            'plan_name' => 'None',
            'status' => 'no_subscription',
            'message' => 'No active subscription'
        ];
    }

    $is_trial = $sub['status'] === 'trial';
    $is_active = PricingService::isSubscriptionActive($account_id);

    if ($is_trial && $is_active) {
        $days_left = ceil((strtotime($sub['trial_ends_at']) - time()) / 86400);
        return [
            'active' => true,
            'plan_name' => $sub['name'],
            'status' => 'trial',
            'days_remaining' => $days_left,
            'message' => "Trial active - $days_left days remaining"
        ];
    }

    if ($is_active && $sub['status'] === 'active') {
        return [
            'active' => true,
            'plan_name' => $sub['name'],
            'status' => 'active',
            'renewal_date' => $sub['next_billing_date'],
            'message' => "Active subscription renewing on " . date('M d, Y', strtotime($sub['next_billing_date']))
        ];
    }

    return [
        'active' => false,
        'plan_name' => $sub['name'],
        'status' => 'expired',
        'expired_at' => $sub['subscription_ends_at'],
        'message' => "Subscription expired on " . date('M d, Y', strtotime($sub['subscription_ends_at']))
    ];
}

/**
 * Render subscription banner for UI
 */
function renderSubscriptionBanner($account_id) {
    $status = getSubscriptionStatus($account_id);

    if ($status['active']) return '';

    $css = $status['status'] === 'expired' 
        ? 'background:#fee2e2;border-color:#fecaca;color:#991b1b;'
        : 'background:#fef3c7;border-color:#fde68a;color:#92400e;';

    $html = "<div style='$css border:1px solid;border-radius:8px;padding:12px;margin-bottom:16px;'>";
    $html .= "<strong>" . ucfirst($status['status']) . ":</strong> " . $status['message'];

    if ($status['status'] !== 'no_subscription') {
        $html .= " <a href='" . APP_URL . "/billing.php' style='font-weight:600;margin-left:8px;'>Manage Subscription →</a>";
    } else {
        $html .= " <a href='" . APP_URL . "/billing.php' style='font-weight:600;margin-left:8px;'>Browse Plans →</a>";
    }

    $html .= "</div>";

    return $html;
}

/**
 * Cron job: Check and email reminders for expiring trials
 */
function cronCheckTrialReminders() {
    $trials_ending_soon = db_fetch_all(
        "SELECT s.*, a.owner_email, p.name as plan_name
         FROM account_subscriptions s
         JOIN accounts a ON s.account_id = a.id
         JOIN pricing_plans p ON s.plan_id = p.id
         WHERE s.status = 'trial'
         AND DATE(s.trial_ends_at) = DATE_ADD(CURDATE(), INTERVAL 7 DAY)
         AND NOT EXISTS (
            SELECT 1 FROM billing_emails 
            WHERE account_id = s.account_id 
            AND email_type = 'trial_ending'
            AND DATE(sent_at) = CURDATE()
         )"
    );

    require_once __DIR__ . '/../config/mailer.php';
    require_once __DIR__ . '/BillingEmails.php';

    foreach ($trials_ending_soon as $trial) {
        $days_left = ceil((strtotime($trial['trial_ends_at']) - time()) / 86400);
        
        BillingEmails::sendBillingEmail(
            $trial['account_id'],
            'trial_ending',
            $trial['owner_email'],
            [
                'account' => ['owner_name' => $trial['owner_name'] ?? 'User'],
                'subscription' => $trial,
                'plan' => ['name' => $trial['plan_name']],
                'days_left' => $days_left
            ]
        );
    }
}

/**
 * Cron job: Mark expired subscriptions
 */
function cronMarkExpiredSubscriptions() {
    db()->query(
        "UPDATE account_subscriptions 
         SET status = 'expired'
         WHERE status = 'active'
         AND subscription_ends_at < NOW()"
    );

    // Email expiration notice to account owners
    $expired = db_fetch_all(
        "SELECT s.*, a.owner_email, p.name as plan_name
         FROM account_subscriptions s
         JOIN accounts a ON s.account_id = a.id
         JOIN pricing_plans p ON s.plan_id = p.id
         WHERE s.status = 'expired'
         AND DATE(s.subscription_ends_at) = CURDATE()
         AND NOT EXISTS (
            SELECT 1 FROM billing_emails 
            WHERE account_id = s.account_id 
            AND email_type = 'subscription_expired'
            AND DATE(sent_at) = CURDATE()
         )"
    );

    require_once __DIR__ . '/BillingEmails.php';

    foreach ($expired as $sub) {
        BillingEmails::sendBillingEmail(
            $sub['account_id'],
            'subscription_expired',
            $sub['owner_email'],
            [
                'account' => ['owner_name' => $sub['owner_name'] ?? 'User'],
                'subscription' => $sub,
                'plan' => ['name' => $sub['plan_name']]
            ]
        );
    }
}
