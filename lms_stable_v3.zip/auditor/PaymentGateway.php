<?php
/**
 * Payment Gateway Integration
 * Supports: Stripe, PayPal
 */

class PaymentGateway {

    /**
     * Initialize Stripe
     */
    public static function initStripe() {
        $stripe_key = ps('stripe_secret_key', '');
        if (!$stripe_key) return false;

        require 'vendor/autoload.php';
        \Stripe\Stripe::setApiKey($stripe_key);
        return true;
    }

    /**
     * Create Stripe customer
     */
    public static function createStripeCustomer($account) {
        if (!self::initStripe()) return false;

        try {
            $customer = \Stripe\Customer::create([
                'email' => $account['owner_email'],
                'name' => $account['owner_name'],
                'metadata' => ['account_id' => $account['id']]
            ]);

            return [
                'provider' => 'stripe',
                'customer_id' => $customer->id
            ];
        } catch (\Stripe\Exception\ApiErrorException $e) {
            error_log('[Stripe] Create customer failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Create Stripe payment intent
     */
    public static function createPaymentIntent($amount, $customer_id, $metadata = []) {
        if (!self::initStripe()) return false;

        try {
            $intent = \Stripe\PaymentIntent::create([
                'amount' => $amount * 100, // Convert to cents
                'currency' => 'usd',
                'customer' => $customer_id,
                'metadata' => $metadata
            ]);

            return [
                'client_secret' => $intent->client_secret,
                'intent_id' => $intent->id
            ];
        } catch (\Stripe\Exception\ApiErrorException $e) {
            error_log('[Stripe] Create intent failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Confirm payment and retrieve status
     */
    public static function confirmPayment($payment_intent_id) {
        if (!self::initStripe()) return false;

        try {
            $intent = \Stripe\PaymentIntent::retrieve($payment_intent_id);

            return [
                'status' => $intent->status, // succeeded, processing, requires_action
                'amount' => $intent->amount / 100,
                'charge_id' => $intent->charges->data[0]->id ?? null
            ];
        } catch (\Stripe\Exception\ApiErrorException $e) {
            error_log('[Stripe] Confirm payment failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Save payment method
     */
    public static function savePaymentMethod($account_id, $payment_method_id) {
        if (!self::initStripe()) return false;

        try {
            $payment_method = \Stripe\PaymentMethod::retrieve($payment_method_id);
            $card = $payment_method->card;

            $stmt = db()->prepare(
                'INSERT INTO payment_methods
                 (account_id, provider, provider_customer_id, provider_payment_method_id, card_last_four, card_brand, card_exp_month, card_exp_year)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
            );

            $account = db_fetch('SELECT * FROM accounts WHERE id = ?', 'i', $account_id);
            $stripe_customer = self::createStripeCustomer($account);

            $stmt->bind_param(
                'isssssii',
                $account_id,
                $provider = 'stripe',
                $stripe_customer['customer_id'],
                $payment_method_id,
                $card->last4,
                $card->brand,
                $card->exp_month,
                $card->exp_year
            );

            return $stmt->execute();
        } catch (\Stripe\Exception\ApiErrorException $e) {
            error_log('[Stripe] Save payment method failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Create recurring subscription with Stripe
     */
    public static function createStripeSubscription($account_id, $plan_id, $payment_method_id = null) {
        if (!self::initStripe()) return false;

        try {
            $account = db_fetch('SELECT * FROM accounts WHERE id = ?', 'i', $account_id);
            $plan = db_fetch('SELECT * FROM pricing_plans WHERE id = ?', 'i', $plan_id);

            // Get or create Stripe customer
            $pm = db_fetch(
                'SELECT provider_customer_id FROM payment_methods WHERE account_id = ? AND provider = ? LIMIT 1',
                'is', $account_id, 'stripe'
            );

            $customer_id = $pm['provider_customer_id'] ?? null;

            if (!$customer_id) {
                $stripe_customer = self::createStripeCustomer($account);
                $customer_id = $stripe_customer['customer_id'];
            }

            // Create price if not exists
            $price = \Stripe\Price::create([
                'unit_amount' => (int)($plan['price_monthly'] * 100),
                'currency' => 'usd',
                'recurring' => ['interval' => 'month'],
                'product_data' => [
                    'name' => $plan['name'] . ' Plan',
                    'metadata' => ['plan_id' => $plan_id]
                ]
            ]);

            // Create subscription
            $subscription = \Stripe\Subscription::create([
                'customer' => $customer_id,
                'items' => [['price' => $price->id]],
                'payment_settings' => [
                    'payment_method_types' => ['card'],
                    'save_default_payment_method' => 'on_subscription'
                ],
                'metadata' => ['account_id' => $account_id, 'plan_id' => $plan_id]
            ]);

            // Update account subscription
            $next_billing = date('Y-m-d H:i:s', $subscription->current_period_end);
            
            db()->query(
                "UPDATE account_subscriptions 
                 SET status = 'active', 
                     subscription_started_at = NOW(),
                     next_billing_date = '$next_billing'
                 WHERE account_id = $account_id"
            );

            return [
                'success' => true,
                'subscription_id' => $subscription->id
            ];
        } catch (\Stripe\Exception\ApiErrorException $e) {
            error_log('[Stripe] Create subscription failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Webhook handler for Stripe events
     */
    public static function handleStripeWebhook() {
        $stripe_key = ps('stripe_webhook_secret', '');
        if (!$stripe_key) return false;

        $payload = file_get_contents('php://input');
        $sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';

        try {
            $event = \Stripe\Webhook::constructEvent($payload, $sig_header, $stripe_key);

            switch ($event->type) {
                case 'charge.succeeded':
                    self::handleChargeSucceeded($event->data->object);
                    break;

                case 'charge.failed':
                    self::handleChargeFailed($event->data->object);
                    break;

                case 'customer.subscription.deleted':
                    self::handleSubscriptionCancelled($event->data->object);
                    break;

                case 'invoice.payment_succeeded':
                    self::handleInvoiceSucceeded($event->data->object);
                    break;

                case 'invoice.payment_failed':
                    self::handleInvoiceFailed($event->data->object);
                    break;
            }

            http_response_code(200);
            echo json_encode(['success' => true]);
        } catch (\UnexpectedValueException $e) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid webhook signature']);
        } catch (\Stripe\Exception\ApiErrorException $e) {
            http_response_code(400);
            echo json_encode(['error' => 'Webhook processing failed']);
        }
    }

    /**
     * Handle successful charge
     */
    private static function handleChargeSucceeded($charge) {
        $account_id = $charge->metadata->account_id ?? null;
        if (!$account_id) return;

        $invoice_number = $charge->invoice;
        
        require_once __DIR__ . '/BillingEmails.php';

        // Find and update invoice
        $invoice = db_fetch(
            'SELECT * FROM invoices WHERE account_id = ? ORDER BY created_at DESC LIMIT 1',
            'i', $account_id
        );

        if ($invoice) {
            db()->query("UPDATE invoices SET status = 'paid', paid_at = NOW() WHERE id = {$invoice['id']}");

            $account = db_fetch('SELECT * FROM accounts WHERE id = ?', 'i', $account_id);
            BillingEmails::sendBillingEmail(
                $account_id,
                'payment_confirmation',
                $account['owner_email'],
                [
                    'account' => $account,
                    'invoice' => $invoice,
                    'plan' => db_fetch('SELECT * FROM pricing_plans WHERE id = ?', 'i', $invoice['plan_id'])
                ]
            );
        }
    }

    /**
     * Handle failed charge
     */
    private static function handleChargeFailed($charge) {
        $account_id = $charge->metadata->account_id ?? null;
        if (!$account_id) return;

        require_once __DIR__ . '/BillingEmails.php';

        $invoice = db_fetch(
            'SELECT * FROM invoices WHERE account_id = ? ORDER BY created_at DESC LIMIT 1',
            'i', $account_id
        );

        if ($invoice) {
            db()->query("UPDATE invoices SET status = 'failed' WHERE id = {$invoice['id']}");

            $account = db_fetch('SELECT * FROM accounts WHERE id = ?', 'i', $account_id);
            BillingEmails::sendBillingEmail(
                $account_id,
                'payment_failed',
                $account['owner_email'],
                [
                    'account' => $account,
                    'invoice' => $invoice,
                    'plan' => db_fetch('SELECT * FROM pricing_plans WHERE id = ?', 'i', $invoice['plan_id'])
                ]
            );
        }
    }

    /**
     * Handle subscription cancellation
     */
    private static function handleSubscriptionCancelled($subscription) {
        $account_id = $subscription->metadata->account_id ?? null;
        if (!$account_id) return;

        db()->query(
            "UPDATE account_subscriptions SET status = 'cancelled' WHERE account_id = $account_id"
        );
    }

    /**
     * Handle invoice succeeded
     */
    private static function handleInvoiceSucceeded($invoice) {
        $account_id = $invoice->metadata->account_id ?? null;
        if (!$account_id) return;

        self::handleChargeSucceeded($invoice);
    }

    /**
     * Handle invoice failed
     */
    private static function handleInvoiceFailed($invoice) {
        $account_id = $invoice->metadata->account_id ?? null;
        if (!$account_id) return;

        self::handleChargeFailed($invoice);
    }
}
