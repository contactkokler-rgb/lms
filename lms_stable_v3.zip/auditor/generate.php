<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/auth.php';
$user = require_permission('auditor', 'run');

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success'=>false,'error'=>'POST only']); exit;
}

if (!csrf_verify()) {
    http_response_code(403);
    echo json_encode(['success'=>false,'error'=>'Invalid CSRF token']); exit;
}

set_time_limit(120);

spl_autoload_register(static function (string $class): void {
    $path = __DIR__ . '/' . $class . '.php';
    if (is_file($path)) require $path;
});

if (!function_exists('app_config')) {
    function app_config(?string $key = null, mixed $default = null): mixed { return $default; }
}

function parse_content_list(string $input): array {
    $items = preg_split('/[\r\n,|]+/', $input) ?: [];
    $items = array_map('trim', $items);
    $items = array_filter($items, static fn(string $item): bool => $item !== '');
    return array_values(array_slice(array_unique($items), 0, 12));
}

try {
    $primaryKeyword = trim((string)($_POST['primary_keyword'] ?? ''));
    if ($primaryKeyword === '') throw new InvalidArgumentException('Primary keyword is required.');

    $targetWordCount = max(300, min(3000, (int)($_POST['target_word_count'] ?? 900)));

    $context = [
        'url'                   => trim((string)($_POST['url']                   ?? '')),
        'primary_keyword'       => $primaryKeyword,
        'secondary_keywords'    => parse_content_list((string)($_POST['secondary_keywords']   ?? '')),
        'page_type'             => trim((string)($_POST['page_type']             ?? 'landing page')),
        'tone'                  => trim((string)($_POST['tone']                  ?? 'clear, expert, human')),
        'target_word_count'     => $targetWordCount,
        'audience'              => trim((string)($_POST['audience']              ?? '')),
        'brief'                 => trim((string)($_POST['brief']                 ?? '')),
        'current_title'         => trim((string)($_POST['current_title']         ?? '')),
        'current_h1'            => trim((string)($_POST['current_h1']            ?? '')),
        'page_keywords'         => parse_content_list((string)($_POST['page_keywords']        ?? '')),
        'page_excerpt'          => trim((string)($_POST['page_excerpt']          ?? '')),
        'crawl_keywords'        => parse_content_list((string)($_POST['crawl_keywords']       ?? '')),
        'competitor_notes'      => parse_content_list((string)($_POST['competitor_notes']     ?? '')),
        'important_suggestions' => parse_content_list((string)($_POST['important_suggestions']?? '')),
    ];

    $httpClient       = new HttpClient();
    $openRouterClient = new OpenRouterClient($httpClient);
    $data             = $openRouterClient->generateContent($context);

    echo json_encode(['success'=>true,'data'=>$data],
        JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);

} catch (InvalidArgumentException $e) {
    http_response_code(422);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}