<?php
declare(strict_types=1);

final class HttpClient
{
    public function get(string $url, array $options = []): array
    {
        return $this->request('GET', $url, $options);
    }

    public function post(string $url, array $options = []): array
    {
        return $this->request('POST', $url, $options);
    }

    public function request(string $method, string $url, array $options = []): array
    {
        if (function_exists('curl_init')) {
            return $this->requestWithCurl($method, $url, $options);
        }

        return $this->requestWithStreams($method, $url, $options);
    }

    private function requestWithCurl(string $method, string $url, array $options): array
    {
        $timeout = (int) ($options['timeout'] ?? app_config('http.timeout', 20));
        $headers = [];
        $currentHeaderBlock = [];
        $body = $options['body'] ?? null;
        $requestHeaders = $options['headers'] ?? [];

        $handle = curl_init($url);
        if ($handle === false) {
            return $this->errorResponse($url, 'Could not initialize cURL.');
        }

        curl_setopt_array($handle, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_ENCODING => '',
            CURLOPT_USERAGENT => (string) app_config('http.user_agent', 'Searchlight SEO Auditor/1.0'),
            CURLOPT_HTTPHEADER => $this->formatHeaders($requestHeaders),
            CURLOPT_HEADERFUNCTION => static function ($curl, string $headerLine) use (&$headers, &$currentHeaderBlock): int {
                $trimmed = trim($headerLine);

                if ($trimmed === '') {
                    if ($currentHeaderBlock !== []) {
                        $headers = $currentHeaderBlock;
                    }
                    return strlen($headerLine);
                }

                if (str_starts_with($trimmed, 'HTTP/')) {
                    $currentHeaderBlock = [];
                    return strlen($headerLine);
                }

                $parts = explode(':', $trimmed, 2);
                if (count($parts) === 2) {
                    $name = strtolower(trim($parts[0]));
                    $value = trim($parts[1]);

                    if (array_key_exists($name, $currentHeaderBlock)) {
                        $existing = $currentHeaderBlock[$name];
                        $currentHeaderBlock[$name] = is_array($existing)
                            ? [...$existing, $value]
                            : [$existing, $value];
                    } else {
                        $currentHeaderBlock[$name] = $value;
                    }
                }

                return strlen($headerLine);
            },
        ]);

        if ($body !== null && strtoupper($method) !== 'GET') {
            curl_setopt($handle, CURLOPT_POSTFIELDS, $body);
        }

        $rawBody = curl_exec($handle);
        $error = curl_error($handle);
        $info = curl_getinfo($handle);
        curl_close($handle);

        if ($rawBody === false) {
            return $this->errorResponse($url, $error ?: 'HTTP request failed.');
        }

        return [
            'success' => true,
            'status' => (int) ($info['http_code'] ?? 0),
            'headers' => $headers,
            'body' => (string) $rawBody,
            'final_url' => (string) ($info['url'] ?? $url),
            'duration_ms' => (int) round(((float) ($info['total_time'] ?? 0)) * 1000),
            'content_type' => (string) ($info['content_type'] ?? ''),
            'redirect_count' => (int) ($info['redirect_count'] ?? 0),
            'error' => null,
        ];
    }

    private function requestWithStreams(string $method, string $url, array $options): array
    {
        $timeout = (int) ($options['timeout'] ?? app_config('http.timeout', 20));
        $body = $options['body'] ?? null;
        $headerLines = [
            'User-Agent: ' . (string) app_config('http.user_agent', 'Searchlight SEO Auditor/1.0'),
        ];

        foreach (($options['headers'] ?? []) as $name => $value) {
            $headerLines[] = $name . ': ' . $value;
        }

        $context = stream_context_create([
            'http' => [
                'method' => strtoupper($method),
                'timeout' => $timeout,
                'ignore_errors' => true,
                'follow_location' => 1,
                'max_redirects' => 5,
                'header' => implode("\r\n", $headerLines),
                'content' => $body,
            ],
        ]);

        $startedAt = microtime(true);
        $rawBody = @file_get_contents($url, false, $context);
        $durationMs = (int) round((microtime(true) - $startedAt) * 1000);
        $responseHeaders = $http_response_header ?? [];

        if ($rawBody === false && $responseHeaders === []) {
            return $this->errorResponse($url, 'HTTP request failed.');
        }

        $status = 0;
        $headers = [];
        foreach ($responseHeaders as $line) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $line, $matches)) {
                $status = (int) $matches[1];
                $headers = [];
                continue;
            }

            $parts = explode(':', $line, 2);
            if (count($parts) === 2) {
                $headers[strtolower(trim($parts[0]))] = trim($parts[1]);
            }
        }

        return [
            'success' => true,
            'status' => $status,
            'headers' => $headers,
            'body' => (string) ($rawBody ?: ''),
            'final_url' => $url,
            'duration_ms' => $durationMs,
            'content_type' => (string) ($headers['content-type'] ?? ''),
            'redirect_count' => 0,
            'error' => null,
        ];
    }

    private function formatHeaders(array $headers): array
    {
        $formatted = [];
        foreach ($headers as $name => $value) {
            $formatted[] = $name . ': ' . $value;
        }

        return $formatted;
    }

    private function errorResponse(string $url, string $message): array
    {
        return [
            'success' => false,
            'status' => 0,
            'headers' => [],
            'body' => '',
            'final_url' => $url,
            'duration_ms' => 0,
            'content_type' => '',
            'redirect_count' => 0,
            'error' => $message,
        ];
    }
}
