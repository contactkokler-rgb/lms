<?php
declare(strict_types=1);

final class SeoAuditService
{
    private array $categoryDefaults = [
        'crawlability' => 100,
        'metadata' => 100,
        'content' => 100,
        'media' => 100,
        'enhancements' => 100,
        'analytics' => 100,
        'competition' => 100,
        'ecommerce' => 100,
        'chatbot' => 100,
    ];

    private array $severityWeights = [
        'critical' => 4,
        'high' => 3,
        'medium' => 2,
        'low' => 1,
    ];

    public function __construct(
        private readonly HttpClient $httpClient,
        private readonly OpenRouterClient $openRouterClient
    ) {
    }

    public function run(string $inputUrl, array $options = []): array
    {
        $targetUrl = $this->normalizeUrl($inputUrl);
        $competitorUrls = $this->normalizeCompetitorUrls($options['competitor_urls'] ?? '', $targetUrl);
        $crawlOptions = $this->normalizeCrawlOptions($options);

        $mainResponse = $this->httpClient->get($targetUrl, [
            'headers' => [
                'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            ],
        ]);

        if (!$mainResponse['success']) {
            throw new RuntimeException((string) ($mainResponse['error'] ?? 'Could not fetch the target URL.'));
        }

        $finalUrl = (string) ($mainResponse['final_url'] ?: $targetUrl);
        $document = $this->analyzeDocument((string) ($mainResponse['body'] ?? ''), $finalUrl);
        $siteChecks = $this->runSiteChecks($finalUrl);
        $document['page']['x_robots_tag'] = $this->headerValue($mainResponse['headers'] ?? [], 'x-robots-tag');

        $supportingPages = $this->collectSupportingPages($finalUrl, $document);
        $crawl = $this->runSiteCrawl($finalUrl, $document, $mainResponse, $crawlOptions);

        $modules = [];
        $modules['analytics'] = $this->buildAnalyticsModule($document, $supportingPages);
        $modules['ecommerce'] = $this->buildEcommerceModule($document, $supportingPages);
        $modules['chatbot'] = $this->buildChatbotModule($document, $supportingPages, $modules['ecommerce']);
        $modules['competitor'] = $this->buildCompetitorModule($document, $competitorUrls);

        $audit = [
            'target' => [
                'requested_url' => $targetUrl,
                'final_url' => $finalUrl,
                'host' => (string) (parse_url($finalUrl, PHP_URL_HOST) ?: ''),
                'audited_at' => date(DATE_ATOM),
                'competitor_urls' => $competitorUrls,
            ],
            'response' => [
                'status_code' => (int) ($mainResponse['status'] ?? 0),
                'content_type' => (string) ($mainResponse['content_type'] ?? ''),
                'response_time_ms' => (int) ($mainResponse['duration_ms'] ?? 0),
                'redirect_count' => (int) ($mainResponse['redirect_count'] ?? 0),
                'html_size_kb' => round(strlen((string) ($mainResponse['body'] ?? '')) / 1024, 1),
                'headers' => $mainResponse['headers'] ?? [],
            ],
            'metrics' => $document,
            'checks' => $siteChecks,
            'crawl' => $crawl,
            'modules' => $modules,
        ];

        $audit['issues'] = $this->buildIssues($audit);
        $audit['scores'] = $this->calculateScores($audit['issues'], $modules);
        $audit['highlights'] = $this->buildHighlights($audit);

        $aiInsights = $this->openRouterClient->analyze($this->buildAiSummaryPayload($audit));
        if (!$aiInsights['available']) {
            $aiInsights = array_merge(
                $this->buildFallbackInsights($audit),
                [
                    'available' => false,
                    'source' => 'local-fallback',
                    'error' => $aiInsights['error'] ?? 'AI insights unavailable.',
                ]
            );
        }
        if (count($aiInsights['growth_plan'] ?? []) < 4) {
            $aiInsights['growth_plan'] = $this->buildLocalGrowthPlan($audit);
        }

        $audit['ai'] = $aiInsights;
        $audit['modules'] = $this->mergeAiModuleStrategies($audit['modules'], $aiInsights);
        $audit['content_lab'] = $this->buildContentLab($audit);

        return $audit;
    }

    private function analyzeDocument(string $html, string $baseUrl): array
    {
        $title = '';
        $description = '';
        $canonical = '';
        $metaRobots = '';
        $viewport = '';
        $lang = '';
        $charset = '';
        $h1 = [];
        $h2 = [];
        $headingCounts = [
            'h1' => 0,
            'h2' => 0,
            'h3' => 0,
            'h4' => 0,
            'h5' => 0,
            'h6' => 0,
        ];
        $images = [
            'total' => 0,
            'missing_alt' => 0,
            'missing_alt_samples' => [],
            'lazy_loaded' => 0,
        ];
        $links = [
            'total' => 0,
            'internal' => 0,
            'external' => 0,
            'nofollow' => 0,
            'empty_anchor_text' => 0,
            'internal_details' => [],
            'external_domains' => [],
        ];
        $assets = [
            'script_files' => 0,
            'inline_scripts' => 0,
            'stylesheets' => 0,
            'style_blocks' => 0,
            'script_sources' => [],
        ];
        $enhancements = [
            'structured_data_count' => 0,
            'structured_data_types' => [],
            'open_graph' => [
                'present' => false,
                'coverage' => [],
            ],
            'twitter_cards' => [
                'present' => false,
                'coverage' => [],
            ],
            'favicon' => false,
        ];
        $content = [
            'word_count' => 0,
            'paragraph_count' => 0,
            'heading_counts' => $headingCounts,
            'text_excerpt' => '',
            'keywords' => [],
        ];
        $forms = [
            'total' => 0,
            'lead_forms' => 0,
            'search_forms' => 0,
            'email_fields' => 0,
            'phone_fields' => 0,
            'password_fields' => 0,
            'field_count' => 0,
            'sample_actions' => [],
            'submit_texts' => [],
        ];
        $buttons = [];
        $contact = [
            'emails' => [],
            'phones' => [],
            'whatsapp' => false,
        ];

        if (trim($html) === '') {
            return [
                'page' => [
                    'title' => ['text' => '', 'length' => 0],
                    'description' => ['text' => '', 'length' => 0],
                    'canonical' => '',
                    'lang' => '',
                    'viewport' => '',
                    'meta_robots' => '',
                    'x_robots_tag' => '',
                    'charset' => '',
                    'h1' => [],
                    'h2' => [],
                    'url' => $baseUrl,
                ],
                'content' => $content,
                'media' => $images,
                'links' => $links,
                'assets' => $assets,
                'enhancements' => $enhancements,
                'forms' => $forms,
                'tracking' => [
                    'tools' => [],
                    'events' => [],
                    'conversion_events' => [],
                    'data_layer_present' => false,
                ],
                'commerce' => [
                    'is_product_like' => false,
                    'product_schema' => false,
                    'has_add_to_cart' => false,
                    'price_samples' => [],
                    'price_count' => 0,
                    'cart_links' => 0,
                    'checkout_links' => 0,
                    'review_mentions' => false,
                    'trust_mentions' => false,
                    'shipping_mentions' => false,
                    'return_mentions' => false,
                    'guest_checkout_mentions' => false,
                    'coupon_mentions' => false,
                    'compare_at_price' => false,
                    'discount_mentions' => false,
                    'bundle_mentions' => false,
                ],
                'chatbot' => [
                    'detected' => false,
                    'vendors' => [],
                    'lead_capture_ctas' => [],
                    'detected_intents' => [],
                    'knowledge_base_signals' => false,
                    'human_handoff' => false,
                ],
                'buttons' => [],
                'contact' => $contact,
            ];
        }

        libxml_use_internal_errors(true);
        $dom = new DOMDocument();
        @$dom->loadHTML('<?xml encoding="utf-8" ?>' . $html, LIBXML_NOERROR | LIBXML_NOWARNING);
        libxml_clear_errors();

        $xpath = new DOMXPath($dom);
        $host = (string) (parse_url($baseUrl, PHP_URL_HOST) ?: '');

        $title = $this->normalizeWhitespace((string) $xpath->evaluate('string(//title)'));
        $description = $this->metaContent($xpath, 'description');
        $canonical = $this->linkHref($xpath, 'canonical');
        $canonical = $canonical !== '' ? ($this->resolveUrl($canonical, $baseUrl) ?? $canonical) : '';
        $metaRobots = $this->metaContent($xpath, 'robots');
        $viewport = $this->metaContent($xpath, 'viewport');
        $lang = trim((string) $xpath->evaluate('string(/html/@lang)'));
        $charset = trim((string) $xpath->evaluate('string(//meta[@charset][1]/@charset)'));
        $h1 = $this->nodeTexts($xpath->query('//h1'));
        $h2 = $this->nodeTexts($xpath->query('//h2'));

        foreach (array_keys($headingCounts) as $headingTag) {
            $headingCounts[$headingTag] = (int) $xpath->evaluate('count(//' . $headingTag . ')');
        }

        foreach ($xpath->query('//img') as $image) {
            if (!$image instanceof DOMElement) {
                continue;
            }

            $images['total']++;
            $alt = trim($image->getAttribute('alt'));
            if ($alt === '') {
                $images['missing_alt']++;
                if (count($images['missing_alt_samples']) < 5) {
                    $images['missing_alt_samples'][] = $image->getAttribute('src') ?: '[inline image]';
                }
            }

            if ($image->hasAttribute('loading') && strtolower($image->getAttribute('loading')) === 'lazy') {
                $images['lazy_loaded']++;
            }
        }

        foreach ($xpath->query('//script[@src]') as $script) {
            if (!$script instanceof DOMElement) {
                continue;
            }
            $src = trim($script->getAttribute('src'));
            if ($src !== '') {
                $resolved = $this->resolveUrl($src, $baseUrl) ?? $src;
                $assets['script_sources'][] = $resolved;
            }
        }
        $assets['script_sources'] = array_values(array_slice(array_unique($assets['script_sources']), 0, 20));

        $buttonNodes = $xpath->query('//button|//input[@type="submit" or @type="button"]|//a[contains(@class, "button") or contains(@role, "button")]');
        foreach ($buttonNodes as $buttonNode) {
            if (!$buttonNode instanceof DOMElement) {
                continue;
            }

            $label = $buttonNode->tagName === 'input'
                ? $buttonNode->getAttribute('value')
                : $buttonNode->textContent;
            $label = $this->normalizeWhitespace($label);
            if ($label !== '') {
                $buttons[] = $label;
            }
        }
        $buttons = array_values(array_slice(array_unique($buttons), 0, 25));

        foreach ($xpath->query('//form') as $formNode) {
            if (!$formNode instanceof DOMElement) {
                continue;
            }

            $forms['total']++;
            $action = trim($formNode->getAttribute('action'));
            if ($action !== '' && count($forms['sample_actions']) < 5) {
                $forms['sample_actions'][] = $this->resolveUrl($action, $baseUrl) ?? $action;
            }

            $emailFields = (int) $xpath->evaluate('count(.//input[@type="email"])', $formNode);
            $phoneFields = (int) $xpath->evaluate('count(.//input[@type="tel"])', $formNode);
            $passwordFields = (int) $xpath->evaluate('count(.//input[@type="password"])', $formNode);
            $searchFields = (int) $xpath->evaluate('count(.//input[@type="search"])', $formNode);
            $fieldCount = (int) $xpath->evaluate('count(.//input|.//select|.//textarea)', $formNode);

            $forms['email_fields'] += $emailFields;
            $forms['phone_fields'] += $phoneFields;
            $forms['password_fields'] += $passwordFields;
            $forms['search_forms'] += $searchFields > 0 ? 1 : 0;
            $forms['field_count'] += $fieldCount;

            if (($emailFields > 0 || $phoneFields > 0) && $passwordFields === 0 && $searchFields === 0) {
                $forms['lead_forms']++;
            }

            $submitLabels = $this->nodeTexts($xpath->query('.//button|.//input[@type="submit"]', $formNode));
            foreach ($submitLabels as $submitLabel) {
                if (count($forms['submit_texts']) >= 10) {
                    break;
                }
                $forms['submit_texts'][] = $submitLabel;
            }
        }
        $forms['submit_texts'] = array_values(array_unique($forms['submit_texts']));

        foreach ($xpath->query('//a[@href]') as $link) {
            if (!$link instanceof DOMElement) {
                continue;
            }

            $href = trim($link->getAttribute('href'));
            $anchorText = $this->normalizeWhitespace($link->textContent);

            if (str_starts_with(strtolower($href), 'mailto:')) {
                $email = preg_replace('/^mailto:/i', '', $href);
                if ($email !== '') {
                    $contact['emails'][] = $email;
                }
                continue;
            }

            if (str_starts_with(strtolower($href), 'tel:')) {
                $phone = preg_replace('/^tel:/i', '', $href);
                if ($phone !== '') {
                    $contact['phones'][] = $phone;
                }
                continue;
            }

            if (str_contains(strtolower($href), 'wa.me') || str_contains(strtolower($href), 'whatsapp')) {
                $contact['whatsapp'] = true;
            }

            $resolvedUrl = $this->resolveUrl($href, $baseUrl);
            if ($resolvedUrl === null) {
                continue;
            }

            $links['total']++;
            if ($this->isInternalUrl($resolvedUrl, $host)) {
                $links['internal']++;
                $bucket = $this->classifyLinkBucket($resolvedUrl, $anchorText);
                if (count($links['internal_details']) < 40) {
                    $links['internal_details'][] = [
                        'url' => $resolvedUrl,
                        'anchor' => $anchorText,
                        'bucket' => $bucket,
                    ];
                }
            } else {
                $links['external']++;
                $domain = (string) (parse_url($resolvedUrl, PHP_URL_HOST) ?: '');
                if ($domain !== '') {
                    $links['external_domains'][] = strtolower($domain);
                }
            }

            $rel = strtolower($link->getAttribute('rel'));
            if (str_contains($rel, 'nofollow')) {
                $links['nofollow']++;
            }

            if ($anchorText === '') {
                $links['empty_anchor_text']++;
            }
        }
        $links['external_domains'] = array_values(array_slice(array_unique($links['external_domains']), 0, 20));

        $assets['script_files'] = count($assets['script_sources']);
        $assets['inline_scripts'] = (int) $xpath->evaluate('count(//script[not(@src)])');
        $assets['stylesheets'] = (int) $xpath->evaluate("count(//link[contains(concat(' ', translate(normalize-space(@rel), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), ' '), ' stylesheet ')])");
        $assets['style_blocks'] = (int) $xpath->evaluate('count(//style)');

        $structuredDataScripts = [];
        foreach ($xpath->query('//script[@type="application/ld+json"]') as $script) {
            if (!$script instanceof DOMElement) {
                continue;
            }
            $structuredDataScripts[] = trim($script->textContent);
        }

        $enhancements['structured_data_count'] = count($structuredDataScripts);
        $enhancements['structured_data_types'] = $this->extractStructuredDataTypes($structuredDataScripts);
        $enhancements['open_graph']['coverage'] = [
            'og:title' => $this->metaProperty($xpath, 'og:title') !== '',
            'og:description' => $this->metaProperty($xpath, 'og:description') !== '',
            'og:image' => $this->metaProperty($xpath, 'og:image') !== '',
            'og:url' => $this->metaProperty($xpath, 'og:url') !== '',
        ];
        $enhancements['open_graph']['present'] = in_array(true, $enhancements['open_graph']['coverage'], true);
        $enhancements['twitter_cards']['coverage'] = [
            'twitter:card' => $this->metaByNameOrProperty($xpath, 'twitter:card') !== '',
            'twitter:title' => $this->metaByNameOrProperty($xpath, 'twitter:title') !== '',
            'twitter:description' => $this->metaByNameOrProperty($xpath, 'twitter:description') !== '',
        ];
        $enhancements['twitter_cards']['present'] = in_array(true, $enhancements['twitter_cards']['coverage'], true);
        $enhancements['favicon'] = $this->hasIconLink($xpath);

        $plainText = $this->plainTextFromHtml($html);
        $content['word_count'] = $this->countWords($plainText);
        $content['paragraph_count'] = (int) $xpath->evaluate('count(//p)');
        $content['heading_counts'] = $headingCounts;
        $content['text_excerpt'] = $this->textExcerpt($plainText, 280);
        $content['keywords'] = $this->extractKeywords(implode(' ', [
            $title,
            $description,
            implode(' ', $h1),
            implode(' ', $h2),
            $content['text_excerpt'],
        ]));

        $tracking = $this->detectTracking($html, $assets['script_sources']);
        $commerce = $this->detectCommerce($html, $plainText, $buttons, $links['internal_details'], $enhancements['structured_data_types'], $xpath);
        $chatbot = $this->detectChatbot($html, $plainText, $assets['script_sources'], $buttons, $links['internal_details'], $forms, $contact);

        $contact['emails'] = array_values(array_slice(array_unique($contact['emails']), 0, 10));
        $contact['phones'] = array_values(array_slice(array_unique($contact['phones']), 0, 10));

        return [
            'page' => [
                'title' => [
                    'text' => $title,
                    'length' => $this->textLength($title),
                ],
                'description' => [
                    'text' => $description,
                    'length' => $this->textLength($description),
                ],
                'canonical' => $canonical,
                'lang' => $lang,
                'viewport' => $viewport,
                'meta_robots' => $metaRobots,
                'x_robots_tag' => '',
                'charset' => $charset,
                'h1' => $h1,
                'h2' => $h2,
                'url' => $baseUrl,
            ],
            'content' => $content,
            'media' => $images,
            'links' => $links,
            'assets' => $assets,
            'enhancements' => $enhancements,
            'forms' => $forms,
            'tracking' => $tracking,
            'commerce' => $commerce,
            'chatbot' => $chatbot,
            'buttons' => $buttons,
            'contact' => $contact,
        ];
    }

    private function runSiteChecks(string $finalUrl): array
    {
        $siteRoot = $this->siteRoot($finalUrl);
        $robotsUrl = $siteRoot . '/robots.txt';
        $robotsResponse = $this->httpClient->get($robotsUrl, [
            'timeout' => 10,
            'headers' => ['Accept' => 'text/plain,*/*;q=0.8'],
        ]);

        $robotsContent = '';
        $robotsFound = false;
        if ($robotsResponse['success'] && (int) $robotsResponse['status'] === 200) {
            $robotsContent = trim((string) ($robotsResponse['body'] ?? ''));
            $robotsFound = $robotsContent !== '';
        }

        $sitemap = [
            'found' => false,
            'url' => '',
            'status' => 0,
        ];

        foreach ($this->extractSitemapCandidates($siteRoot, $robotsContent) as $candidate) {
            $candidateResponse = $this->httpClient->get($candidate, [
                'timeout' => 10,
                'headers' => ['Accept' => 'application/xml,text/xml,*/*;q=0.8'],
            ]);

            if ($candidateResponse['success'] && (int) $candidateResponse['status'] === 200 && trim((string) ($candidateResponse['body'] ?? '')) !== '') {
                $sitemap = [
                    'found' => true,
                    'url' => $candidate,
                    'status' => (int) $candidateResponse['status'],
                ];
                break;
            }

            if ($sitemap['url'] === '') {
                $sitemap['url'] = $candidate;
                $sitemap['status'] = (int) ($candidateResponse['status'] ?? 0);
            }
        }

        return [
            'https' => str_starts_with($finalUrl, 'https://'),
            'robots_txt' => [
                'found' => $robotsFound,
                'url' => $robotsUrl,
                'status' => (int) ($robotsResponse['status'] ?? 0),
            ],
            'sitemap' => $sitemap,
        ];
    }

    private function collectSupportingPages(string $finalUrl, array $mainDocument): array
    {
        $siteRoot = $this->siteRoot($finalUrl);
        $path = strtolower((string) (parse_url($finalUrl, PHP_URL_PATH) ?: '/'));
        $candidates = $this->buildSupportingCandidates($siteRoot, $mainDocument['links']['internal_details'] ?? []);

        $pages = [];
        $fetchedUrls = [$finalUrl => true];
        $maxFetches = 6;
        $fetchCount = 0;

        foreach (['product', 'cart', 'checkout', 'pricing', 'contact', 'faq'] as $bucket) {
            if ($this->pathMatchesBucket($path, $bucket) || ($bucket === 'product' && ($mainDocument['commerce']['is_product_like'] ?? false))) {
                $pages[$bucket] = [
                    'found' => true,
                    'url' => $finalUrl,
                    'status' => 200,
                    'metrics' => $mainDocument,
                ];
                continue;
            }

            $pages[$bucket] = [
                'found' => false,
                'url' => $candidates[$bucket][0] ?? '',
                'status' => 0,
                'metrics' => null,
            ];

            foreach ($candidates[$bucket] ?? [] as $candidate) {
                if (isset($fetchedUrls[$candidate]) || $fetchCount >= $maxFetches) {
                    continue;
                }

                $response = $this->httpClient->get($candidate, [
                    'timeout' => 12,
                    'headers' => [
                        'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    ],
                ]);

                $fetchCount++;
                $fetchedUrls[$candidate] = true;

                $pages[$bucket]['url'] = $candidate;
                $pages[$bucket]['status'] = (int) ($response['status'] ?? 0);

                if (!$response['success']) {
                    continue;
                }

                $contentType = strtolower((string) ($response['content_type'] ?? ''));
                if ((int) ($response['status'] ?? 0) !== 200 || ($contentType !== '' && !str_contains($contentType, 'html'))) {
                    continue;
                }

                $metrics = $this->analyzeDocument((string) ($response['body'] ?? ''), (string) ($response['final_url'] ?: $candidate));
                if (!$this->bucketLooksRelevant($bucket, $metrics)) {
                    continue;
                }
                $pages[$bucket] = [
                    'found' => true,
                    'url' => (string) ($response['final_url'] ?: $candidate),
                    'status' => (int) ($response['status'] ?? 0),
                    'metrics' => $metrics,
                ];
                break;
            }
        }

        return $pages;
    }

    private function normalizeCrawlOptions(array $options): array
    {
        $scope = strtolower(trim((string) ($options['crawl_scope'] ?? 'page')));
        if (!in_array($scope, ['page', 'site'], true)) {
            $scope = 'page';
        }

        $limit = (int) ($options['crawl_limit'] ?? 12);
        $limit = max(5, min(25, $limit));

        return [
            'scope' => $scope,
            'limit' => $limit,
        ];
    }

    private function runSiteCrawl(string $finalUrl, array $mainDocument, array $mainResponse, array $crawlOptions): array
    {
        $mainSummary = $this->buildCrawlPageSummary(
            $mainDocument,
            (int) ($mainResponse['status'] ?? 0),
            (int) ($mainResponse['duration_ms'] ?? 0)
        );

        $pages = [$mainSummary];
        $summary = $this->summarizeCrawlPages($pages);

        if (($crawlOptions['scope'] ?? 'page') !== 'site') {
            return [
                'enabled' => false,
                'scope' => 'page',
                'limit' => 1,
                'pages_crawled' => 1,
                'failed_fetches' => 0,
                'summary' => $summary,
                'top_keywords' => $summary['top_keywords'],
                'pages' => $pages,
            ];
        }

        $limit = (int) ($crawlOptions['limit'] ?? 12);
        $host = (string) (parse_url($finalUrl, PHP_URL_HOST) ?: '');
        $queue = [];
        $queued = [];
        $visited = [$this->normalizeCrawlUrl($finalUrl) => true];
        $failedFetches = 0;

        foreach ($mainDocument['links']['internal_details'] ?? [] as $detail) {
            $candidate = $this->prepareCrawlCandidate((string) ($detail['url'] ?? ''), $host);
            if ($candidate === null || isset($visited[$candidate]) || isset($queued[$candidate])) {
                continue;
            }
            $queue[] = $candidate;
            $queued[$candidate] = true;
        }

        while ($queue !== [] && count($pages) < $limit) {
            $candidate = array_shift($queue);
            if ($candidate === null) {
                break;
            }

            unset($queued[$candidate]);

            if (isset($visited[$candidate])) {
                continue;
            }

            $visited[$candidate] = true;

            $response = $this->httpClient->get($candidate, [
                'timeout' => 10,
                'headers' => [
                    'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                ],
            ]);

            if (!$response['success']) {
                $failedFetches++;
                continue;
            }

            $status = (int) ($response['status'] ?? 0);
            $contentType = strtolower((string) ($response['content_type'] ?? ''));
            if ($status !== 200 || ($contentType !== '' && !str_contains($contentType, 'html'))) {
                $failedFetches++;
                continue;
            }

            $resolvedUrl = (string) ($response['final_url'] ?: $candidate);
            $resolvedCandidate = $this->prepareCrawlCandidate($resolvedUrl, $host);
            if ($resolvedCandidate === null) {
                $failedFetches++;
                continue;
            }
            if ($resolvedCandidate !== $candidate && isset($visited[$resolvedCandidate])) {
                continue;
            }

            $visited[$resolvedCandidate] = true;
            $document = $this->analyzeDocument((string) ($response['body'] ?? ''), $resolvedUrl);
            $document['page']['x_robots_tag'] = $this->headerValue($response['headers'] ?? [], 'x-robots-tag');
            $pages[] = $this->buildCrawlPageSummary(
                $document,
                $status,
                (int) ($response['duration_ms'] ?? 0)
            );

            foreach ($document['links']['internal_details'] ?? [] as $detail) {
                $nextCandidate = $this->prepareCrawlCandidate((string) ($detail['url'] ?? ''), $host);
                if ($nextCandidate === null || isset($visited[$nextCandidate]) || isset($queued[$nextCandidate])) {
                    continue;
                }
                if (count($queue) >= ($limit * 12)) {
                    break;
                }
                $queue[] = $nextCandidate;
                $queued[$nextCandidate] = true;
            }
        }

        $summary = $this->summarizeCrawlPages($pages);

        return [
            'enabled' => true,
            'scope' => 'site',
            'limit' => $limit,
            'pages_crawled' => count($pages),
            'failed_fetches' => $failedFetches,
            'summary' => $summary,
            'top_keywords' => $summary['top_keywords'],
            'pages' => $pages,
        ];
    }

    private function buildCrawlPageSummary(array $document, int $statusCode, int $responseTimeMs): array
    {
        $wordCount = (int) ($document['content']['word_count'] ?? 0);
        $missingTitle = trim((string) ($document['page']['title']['text'] ?? '')) === '';
        $missingDescription = trim((string) ($document['page']['description']['text'] ?? '')) === '';
        $missingH1 = count($document['page']['h1'] ?? []) === 0;
        $noindex = $this->containsNoindex((string) ($document['page']['meta_robots'] ?? ''))
            || $this->containsNoindex((string) ($document['page']['x_robots_tag'] ?? ''));
        $canonicalMissing = trim((string) ($document['page']['canonical'] ?? '')) === '';
        $thinContent = $wordCount < 300;
        $issueCount = count(array_filter([
            $missingTitle,
            $missingDescription,
            $missingH1,
            $noindex,
            $canonicalMissing,
            $thinContent,
        ]));

        return [
            'url' => (string) ($document['page']['url'] ?? ''),
            'title' => (string) ($document['page']['title']['text'] ?? ''),
            'status_code' => $statusCode,
            'response_time_ms' => $responseTimeMs,
            'word_count' => $wordCount,
            'h1_count' => count($document['page']['h1'] ?? []),
            'h2_count' => count($document['page']['h2'] ?? []),
            'internal_links' => (int) ($document['links']['internal'] ?? 0),
            'keywords' => array_values(array_slice($document['content']['keywords'] ?? [], 0, 8)),
            'missing_title' => $missingTitle,
            'missing_description' => $missingDescription,
            'missing_h1' => $missingH1,
            'noindex' => $noindex,
            'canonical_missing' => $canonicalMissing,
            'thin_content' => $thinContent,
            'issue_count' => $issueCount,
        ];
    }

    private function summarizeCrawlPages(array $pages): array
    {
        $summary = [
            'pages_analyzed' => count($pages),
            'missing_titles' => 0,
            'missing_descriptions' => 0,
            'missing_h1_pages' => 0,
            'thin_content_pages' => 0,
            'noindex_pages' => 0,
            'canonical_gaps' => 0,
            'average_word_count' => 0,
            'top_keywords' => [],
            'pages_with_most_gaps' => [],
        ];

        $keywordCounts = [];
        $wordTotal = 0;

        foreach ($pages as $page) {
            $wordTotal += (int) ($page['word_count'] ?? 0);
            $summary['missing_titles'] += !empty($page['missing_title']) ? 1 : 0;
            $summary['missing_descriptions'] += !empty($page['missing_description']) ? 1 : 0;
            $summary['missing_h1_pages'] += !empty($page['missing_h1']) ? 1 : 0;
            $summary['thin_content_pages'] += !empty($page['thin_content']) ? 1 : 0;
            $summary['noindex_pages'] += !empty($page['noindex']) ? 1 : 0;
            $summary['canonical_gaps'] += !empty($page['canonical_missing']) ? 1 : 0;

            foreach ($page['keywords'] ?? [] as $keyword) {
                $keywordCounts[$keyword] = ($keywordCounts[$keyword] ?? 0) + 1;
            }
        }

        if ($pages !== []) {
            $summary['average_word_count'] = (int) round($wordTotal / count($pages));
        }

        arsort($keywordCounts);
        $summary['top_keywords'] = array_slice(array_keys($keywordCounts), 0, 10);

        $pagesWithMostGaps = $pages;
        usort($pagesWithMostGaps, static function (array $left, array $right): int {
            $leftScore = (int) ($left['issue_count'] ?? 0);
            $rightScore = (int) ($right['issue_count'] ?? 0);
            if ($leftScore === $rightScore) {
                return (int) ($left['word_count'] ?? 0) <=> (int) ($right['word_count'] ?? 0);
            }

            return $rightScore <=> $leftScore;
        });

        $summary['pages_with_most_gaps'] = array_map(
            static fn(array $page): array => [
                'url' => $page['url'] ?? '',
                'title' => $page['title'] ?? '',
                'issue_count' => $page['issue_count'] ?? 0,
                'word_count' => $page['word_count'] ?? 0,
            ],
            array_slice($pagesWithMostGaps, 0, 5)
        );

        return $summary;
    }

    private function buildAnalyticsModule(array $document, array $supportingPages): array
    {
        $documents = $this->documentSet($document, $supportingPages);
        $tools = [];
        $events = [];
        $conversionEvents = [];
        $pagesChecked = [];
        $hasGtm = false;
        $hasGoogleAnalytics = false;
        $hasMetaPixel = false;

        foreach ($documents as $bucket => $doc) {
            $tools = array_merge($tools, $doc['tracking']['tools'] ?? []);
            $events = array_merge($events, $doc['tracking']['events'] ?? []);
            $conversionEvents = array_merge($conversionEvents, $doc['tracking']['conversion_events'] ?? []);
            $pagesChecked[] = $doc['page']['url'] ?? $bucket;
            $hasGtm = $hasGtm || in_array('Google Tag Manager', $doc['tracking']['tools'] ?? [], true);
            $hasGoogleAnalytics = $hasGoogleAnalytics || in_array('Google Analytics 4', $doc['tracking']['tools'] ?? [], true) || in_array('Universal Analytics', $doc['tracking']['tools'] ?? [], true);
            $hasMetaPixel = $hasMetaPixel || in_array('Meta Pixel', $doc['tracking']['tools'] ?? [], true);
        }

        $tools = array_values(array_unique($tools));
        $events = array_values(array_unique($events));
        $conversionEvents = array_values(array_unique($conversionEvents));

        $isEcommerce = (bool) ($document['commerce']['is_product_like'] ?? false)
            || (($supportingPages['product']['found'] ?? false) || ($supportingPages['cart']['found'] ?? false) || ($supportingPages['checkout']['found'] ?? false));
        $contactLeadForms = 0;
        if (($supportingPages['contact']['found'] ?? false) && isset($supportingPages['contact']['metrics']) && is_array($supportingPages['contact']['metrics'])) {
            $contactLeadForms = (int) ($supportingPages['contact']['metrics']['forms']['lead_forms'] ?? 0);
        }
        $hasLeadCapture = (int) ($document['forms']['lead_forms'] ?? 0) > 0 || $contactLeadForms > 0;
        $hasChatbot = (bool) ($document['chatbot']['detected'] ?? false);

        $expectedEvents = [];
        if ($hasLeadCapture) {
            $expectedEvents[] = 'generate_lead';
        }
        if ($isEcommerce) {
            $expectedEvents = array_merge($expectedEvents, ['view_item', 'add_to_cart', 'begin_checkout', 'purchase']);
        }
        if ($hasChatbot) {
            $expectedEvents = array_merge($expectedEvents, ['chat_start', 'chatbot_lead']);
        }
        $expectedEvents = array_values(array_unique($expectedEvents));

        $missingEvents = array_values(array_diff($expectedEvents, $events));
        $requiresConversionTracking = $hasLeadCapture || $isEcommerce || $hasChatbot;

        $findings = [];
        $recommendations = [];
        $score = 100;

        if (!$hasGoogleAnalytics && !$hasGtm) {
            $findings[] = 'No Google Analytics or Google Tag Manager implementation was detected in the audited pages.';
            $recommendations[] = 'Deploy GA4 directly or through GTM so traffic and conversion flows have a consistent source of truth.';
            $score -= 25;
        } else {
            $findings[] = 'Detected tracking stack: ' . implode(', ', $tools) . '.';
        }

        if (!$hasMetaPixel && ($hasLeadCapture || $isEcommerce)) {
            $findings[] = 'Meta Pixel was not detected on a site that appears to rely on lead generation or ecommerce actions.';
            $recommendations[] = 'If paid social matters for this funnel, add Meta Pixel and mirror the core conversion events there.';
            $score -= 10;
        }

        if ($requiresConversionTracking && $conversionEvents === []) {
            $findings[] = 'No explicit conversion event was detected even though the site shows lead or commerce intent.';
            $recommendations[] = 'Track the final conversion moments such as generate_lead, begin_checkout, purchase, or chatbot-qualified lead.';
            $score -= 22;
        }

        if ($missingEvents !== []) {
            $findings[] = 'Expected funnel events appear to be missing: ' . implode(', ', $missingEvents) . '.';
            $recommendations[] = 'Create a clear event map and push each funnel step into GTM or your analytics library with a normalized naming convention.';
            $score -= min(30, count($missingEvents) * 7);
        }

        if (($hasGoogleAnalytics || $hasGtm) && $events === []) {
            $findings[] = 'Tracking libraries were found, but no explicit custom event calls were detected in the inspected markup.';
            $recommendations[] = 'Audit the live data layer and add custom event instrumentation for forms, clicks, chat starts, and checkout steps.';
            $score -= 10;
        }

        $recommendations[] = 'Use one canonical event taxonomy across analytics, ad pixels, CRM handoffs, and server-side conversions to keep attribution clean.';

        $score = max(0, $score);

        return [
            'score' => $score,
            'headline' => $score >= 80
                ? 'Tracking coverage looks broadly healthy, but event depth should still be checked in production.'
                : 'Tracking coverage has gaps that can distort attribution or hide conversion leaks.',
            'detected_tools' => $tools,
            'detected_events' => $events,
            'conversion_events' => $conversionEvents,
            'missing_events' => $missingEvents,
            'requires_conversion_tracking' => $requiresConversionTracking,
            'pages_checked' => array_values(array_unique($pagesChecked)),
            'findings' => array_values(array_slice(array_unique($findings), 0, 6)),
            'recommendations' => array_values(array_slice(array_unique($recommendations), 0, 5)),
        ];
    }

    private function buildCompetitorModule(array $document, array $competitorUrls): array
    {
        if ($competitorUrls === []) {
            return [
                'status' => 'requires_input',
                'score' => null,
                'headline' => 'Add competitor URLs to unlock keyword, depth, and proxy-authority comparisons.',
                'note' => 'Backlink comparison stays disabled until competitor pages are supplied.',
                'target_keywords' => $document['content']['keywords'] ?? [],
                'authority_proxy_note' => 'Authority is benchmarked with an on-page heuristic because no external backlink index is configured.',
                'comparison_rows' => [],
                'outrank_reasons' => [],
                'recommendations' => [],
            ];
        }

        $targetKeywordSet = $document['content']['keywords'] ?? [];
        $targetWordCount = (int) ($document['content']['word_count'] ?? 0);
        $targetH2Count = count($document['page']['h2'] ?? []);
        $targetSchemaCount = (int) ($document['enhancements']['structured_data_count'] ?? 0);
        $targetAuthorityProxy = $this->authorityProxyScore($document);

        $comparisonRows = [];
        $reasonCounts = [];
        $recommendations = [];
        $successfulCompetitors = 0;

        foreach (array_slice($competitorUrls, 0, 3) as $competitorUrl) {
            $response = $this->httpClient->get($competitorUrl, [
                'timeout' => 12,
                'headers' => [
                    'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                ],
            ]);

            if (!$response['success'] || (int) ($response['status'] ?? 0) !== 200) {
                $comparisonRows[] = [
                    'url' => $competitorUrl,
                    'host' => (string) (parse_url($competitorUrl, PHP_URL_HOST) ?: $competitorUrl),
                    'keyword_overlap_pct' => null,
                    'word_count' => null,
                    'h2_count' => null,
                    'authority_proxy' => null,
                    'content_gap' => null,
                    'status' => (int) ($response['status'] ?? 0),
                ];
                continue;
            }

            $competitorDocument = $this->analyzeDocument((string) ($response['body'] ?? ''), (string) ($response['final_url'] ?: $competitorUrl));
            $successfulCompetitors++;

            $competitorKeywords = $competitorDocument['content']['keywords'] ?? [];
            $overlap = $this->keywordOverlapPercent($targetKeywordSet, $competitorKeywords);
            $competitorWordCount = (int) ($competitorDocument['content']['word_count'] ?? 0);
            $competitorH2Count = count($competitorDocument['page']['h2'] ?? []);
            $competitorSchemaCount = (int) ($competitorDocument['enhancements']['structured_data_count'] ?? 0);
            $authorityProxy = $this->authorityProxyScore($competitorDocument);

            if ($competitorWordCount > $targetWordCount + 250) {
                $reasonCounts['Competitors cover the topic in materially greater depth.'] = ($reasonCounts['Competitors cover the topic in materially greater depth.'] ?? 0) + 1;
            }
            if ($competitorH2Count > $targetH2Count + 2) {
                $reasonCounts['Competitor pages are structured around more supporting subtopics.'] = ($reasonCounts['Competitor pages are structured around more supporting subtopics.'] ?? 0) + 1;
            }
            if ($competitorSchemaCount > $targetSchemaCount) {
                $reasonCounts['Competitors expose richer schema or structured data signals.'] = ($reasonCounts['Competitors expose richer schema or structured data signals.'] ?? 0) + 1;
            }
            if ($authorityProxy > $targetAuthorityProxy + 10) {
                $reasonCounts['Competitors show stronger authority proxies than the target page.'] = ($reasonCounts['Competitors show stronger authority proxies than the target page.'] ?? 0) + 1;
            }
            if ($overlap < 45) {
                $reasonCounts['The target page does not align tightly enough with the competitor keyword cluster.'] = ($reasonCounts['The target page does not align tightly enough with the competitor keyword cluster.'] ?? 0) + 1;
            }

            $comparisonRows[] = [
                'url' => $competitorDocument['page']['url'] ?? $competitorUrl,
                'host' => (string) (parse_url((string) ($competitorDocument['page']['url'] ?? $competitorUrl), PHP_URL_HOST) ?: $competitorUrl),
                'keyword_overlap_pct' => $overlap,
                'word_count' => $competitorWordCount,
                'h2_count' => $competitorH2Count,
                'authority_proxy' => $authorityProxy,
                'content_gap' => $competitorWordCount - $targetWordCount,
                'status' => 200,
            ];
        }

        if ($successfulCompetitors === 0) {
            return [
                'status' => 'unavailable',
                'score' => null,
                'headline' => 'Competitor URLs were provided, but none of them could be fetched successfully.',
                'note' => 'Check that the competitor URLs are public and not blocking server-side requests.',
                'target_keywords' => $targetKeywordSet,
                'authority_proxy_note' => 'Authority is benchmarked with an on-page heuristic because no external backlink index is configured.',
                'comparison_rows' => $comparisonRows,
                'outrank_reasons' => [],
                'recommendations' => [],
            ];
        }

        arsort($reasonCounts);
        $outrankReasons = array_slice(array_keys($reasonCounts), 0, 4);

        if ($outrankReasons === []) {
            $outrankReasons[] = 'No single dominant gap stood out; the target page is broadly competitive on the inspected signals.';
        }

        if (in_array('Competitors cover the topic in materially greater depth.', $outrankReasons, true)) {
            $recommendations[] = 'Expand the page around supporting subtopics, FAQs, proof points, and decision-stage objections.';
        }
        if (in_array('The target page does not align tightly enough with the competitor keyword cluster.', $outrankReasons, true)) {
            $recommendations[] = 'Tighten title, headings, and supporting copy so the page targets the same search intent as the ranking cluster.';
        }
        if (in_array('Competitors expose richer schema or structured data signals.', $outrankReasons, true)) {
            $recommendations[] = 'Add richer schema where relevant so engines understand entities, products, FAQs, or business context more clearly.';
        }
        if (in_array('Competitors show stronger authority proxies than the target page.', $outrankReasons, true)) {
            $recommendations[] = 'Strengthen authority signals with reviews, trust markers, stronger internal linking, and credible supporting references.';
        }
        $recommendations[] = 'Use the overlap and depth gaps to brief new sections rather than just rewriting existing paragraphs.';

        $score = 100;
        foreach ($outrankReasons as $reason) {
            if (str_contains($reason, 'greater depth')) {
                $score -= 16;
            } elseif (str_contains($reason, 'keyword cluster')) {
                $score -= 14;
            } elseif (str_contains($reason, 'schema')) {
                $score -= 10;
            } elseif (str_contains($reason, 'authority proxies')) {
                $score -= 12;
            }
        }
        $score = max(0, $score);

        return [
            'status' => 'complete',
            'score' => $score,
            'headline' => $score >= 80
                ? 'The target page is broadly competitive on the inspected content and intent signals.'
                : 'Competitor pages show clearer signals on intent fit, depth, or authority-readiness.',
            'note' => 'Backlink comparison is heuristic only. No third-party backlink index is configured in this tool.',
            'target_keywords' => $targetKeywordSet,
            'authority_proxy_note' => 'Authority is benchmarked with an on-page heuristic because no external backlink index is configured.',
            'comparison_rows' => $comparisonRows,
            'outrank_reasons' => $outrankReasons,
            'recommendations' => array_values(array_slice(array_unique($recommendations), 0, 5)),
        ];
    }

    private function buildEcommerceModule(array $document, array $supportingPages): array
    {
        $mainLooksLikeProduct = (bool) ($document['commerce']['is_product_like'] ?? false);
        $hasStorePages = (bool) ($supportingPages['product']['found'] ?? false)
            || (bool) ($supportingPages['cart']['found'] ?? false)
            || (bool) ($supportingPages['checkout']['found'] ?? false);
        $applicable = $mainLooksLikeProduct || $hasStorePages;

        if (!$applicable) {
            return [
                'applicable' => false,
                'score' => null,
                'headline' => 'No strong ecommerce signals were detected on the audited page set.',
                'pages' => $this->modulePageRefs($supportingPages),
                'signals' => [
                    'price_samples' => [],
                    'compare_at_price' => false,
                    'discount_mentions' => false,
                    'bundle_mentions' => false,
                ],
                'product_description_gaps' => [],
                'checkout_friction_points' => [],
                'pricing_signals' => [],
                'findings' => [],
                'recommendations' => [],
            ];
        }

        $productDocument = $mainLooksLikeProduct ? $document : ($supportingPages['product']['metrics'] ?? $document);
        $cartDocument = $supportingPages['cart']['metrics'] ?? null;
        $checkoutDocument = $supportingPages['checkout']['metrics'] ?? null;

        $gaps = [];
        $friction = [];
        $pricingSignals = [];
        $findings = [];
        $recommendations = [];
        $score = 100;

        if (($productDocument['page']['description']['text'] ?? '') === '') {
            $gaps[] = 'Product or offer page is missing a meta description.';
            $score -= 8;
        }
        if ((int) ($productDocument['content']['word_count'] ?? 0) < 180) {
            $gaps[] = 'Product copy is thin and may not handle objections, benefits, or use cases well.';
            $score -= 12;
        }
        if (!(bool) ($productDocument['commerce']['product_schema'] ?? false)) {
            $gaps[] = 'Product schema was not detected on the product-like page.';
            $score -= 14;
        }
        if ((int) ($productDocument['commerce']['price_count'] ?? 0) === 0) {
            $gaps[] = 'No price signal was detected on the main commerce page.';
            $score -= 10;
        }
        if (!(bool) ($productDocument['commerce']['review_mentions'] ?? false)) {
            $gaps[] = 'Review or testimonial proof is not obvious on the inspected product page.';
            $score -= 8;
        }
        if (!(bool) ($productDocument['commerce']['shipping_mentions'] ?? false) || !(bool) ($productDocument['commerce']['return_mentions'] ?? false)) {
            $gaps[] = 'Shipping and return reassurance is weak or missing in the inspected commerce flow.';
            $score -= 8;
        }

        if ($cartDocument === null) {
            $friction[] = 'No cart page was discovered, so cart-stage friction could not be verified.';
            $score -= 6;
        } else {
            if (!(bool) ($cartDocument['commerce']['trust_mentions'] ?? false)) {
                $friction[] = 'Cart page does not clearly surface trust or security reassurance.';
                $score -= 8;
            }
            if ((bool) ($cartDocument['commerce']['coupon_mentions'] ?? false)) {
                $friction[] = 'Coupon prompts are present in cart and may distract buyers if discount codes are not part of the strategy.';
                $score -= 4;
            }
        }

        if ($checkoutDocument === null) {
            $friction[] = 'No checkout page was discovered, so checkout UX could not be reviewed directly.';
            $score -= 8;
        } else {
            if ((int) ($checkoutDocument['forms']['field_count'] ?? 0) > 12) {
                $friction[] = 'Checkout appears to request many fields, which can increase abandonment.';
                $score -= 10;
            }
            if (!(bool) ($checkoutDocument['commerce']['guest_checkout_mentions'] ?? false) && (int) ($checkoutDocument['forms']['password_fields'] ?? 0) > 0) {
                $friction[] = 'Checkout may force account creation or obscure guest checkout.';
                $score -= 10;
            }
            if (!(bool) ($checkoutDocument['commerce']['trust_mentions'] ?? false)) {
                $friction[] = 'Checkout page lacks obvious trust or secure-payment reassurance.';
                $score -= 8;
            }
        }

        if ((bool) ($productDocument['commerce']['compare_at_price'] ?? false)) {
            $pricingSignals[] = 'Compare-at or struck-through pricing is present.';
        }
        if ((bool) ($productDocument['commerce']['discount_mentions'] ?? false)) {
            $pricingSignals[] = 'Discount language or savings messaging is present.';
        }
        if ((bool) ($productDocument['commerce']['bundle_mentions'] ?? false)) {
            $pricingSignals[] = 'Bundle or kit framing is present.';
        }
        if ($this->pricesUsePsychologicalEnds($productDocument['commerce']['price_samples'] ?? [])) {
            $pricingSignals[] = 'Psychological pricing endings such as .99 or .95 were detected.';
        }
        if ($pricingSignals === []) {
            $pricingSignals[] = 'Pricing psychology cues were not obvious in the inspected markup.';
            $score -= 6;
        }

        if ($gaps !== []) {
            $findings[] = 'Product-page persuasion is underdeveloped in one or more key areas.';
        }
        if ($friction !== []) {
            $findings[] = 'The cart or checkout flow shows friction risks that can raise abandonment.';
        }
        if ($pricingSignals !== []) {
            $findings[] = 'Pricing presentation was reviewed using static page cues.';
        }

        $recommendations[] = 'Expand product copy around outcomes, objections, use cases, proof, shipping, and returns so the page sells before checkout begins.';
        if ($friction !== []) {
            $recommendations[] = 'Trim checkout inputs, make guest checkout obvious, and surface secure-payment reassurance near the primary CTA.';
        }
        if (!in_array('Compare-at or struck-through pricing is present.', $pricingSignals, true)) {
            $recommendations[] = 'Test pricing anchors such as compare-at prices, bundles, or savings framing where commercially appropriate.';
        }
        if (!(bool) ($productDocument['commerce']['product_schema'] ?? false)) {
            $recommendations[] = 'Add Product schema with price, availability, brand, and review fields where possible.';
        }

        $score = max(0, $score);

        $pageRefs = $this->modulePageRefs($supportingPages);
        if ($mainLooksLikeProduct) {
            $pageRefs['product'] = [
                'found' => true,
                'url' => (string) ($document['page']['url'] ?? ''),
                'status' => 200,
            ];
        }

        return [
            'applicable' => true,
            'score' => $score,
            'headline' => $score >= 80
                ? 'The inspected ecommerce flow is reasonably healthy, though persuasive depth and checkout polish can still improve.'
                : 'The ecommerce flow shows copy, trust, or checkout friction issues that can suppress conversion rate.',
            'pages' => $pageRefs,
            'signals' => [
                'price_samples' => $productDocument['commerce']['price_samples'] ?? [],
                'compare_at_price' => (bool) ($productDocument['commerce']['compare_at_price'] ?? false),
                'discount_mentions' => (bool) ($productDocument['commerce']['discount_mentions'] ?? false),
                'bundle_mentions' => (bool) ($productDocument['commerce']['bundle_mentions'] ?? false),
            ],
            'product_description_gaps' => array_values(array_slice(array_unique($gaps), 0, 6)),
            'checkout_friction_points' => array_values(array_slice(array_unique($friction), 0, 6)),
            'pricing_signals' => array_values(array_slice(array_unique($pricingSignals), 0, 5)),
            'findings' => array_values(array_slice(array_unique($findings), 0, 4)),
            'recommendations' => array_values(array_slice(array_unique($recommendations), 0, 5)),
        ];
    }

    private function buildChatbotModule(array $document, array $supportingPages, array $ecommerceModule): array
    {
        $documents = $this->documentSet($document, $supportingPages);
        $vendors = [];
        $knownIntents = [];
        $leadCaptureCtas = [];
        $knowledgeBaseSignals = false;
        $humanHandoff = false;
        $leadForms = 0;
        $chatbotDetected = false;

        foreach ($documents as $doc) {
            $vendors = array_merge($vendors, $doc['chatbot']['vendors'] ?? []);
            $knownIntents = array_merge($knownIntents, $doc['chatbot']['detected_intents'] ?? []);
            $leadCaptureCtas = array_merge($leadCaptureCtas, $doc['chatbot']['lead_capture_ctas'] ?? []);
            $knowledgeBaseSignals = $knowledgeBaseSignals || (bool) ($doc['chatbot']['knowledge_base_signals'] ?? false);
            $humanHandoff = $humanHandoff || (bool) ($doc['chatbot']['human_handoff'] ?? false);
            $leadForms += (int) ($doc['forms']['lead_forms'] ?? 0);
            $chatbotDetected = $chatbotDetected || (bool) ($doc['chatbot']['detected'] ?? false);
        }

        $vendors = array_values(array_unique($vendors));
        $knownIntents = array_values(array_unique($knownIntents));
        $leadCaptureCtas = array_values(array_slice(array_unique($leadCaptureCtas), 0, 10));

        $expectedIntents = $ecommerceModule['applicable']
            ? ['shipping', 'returns', 'order tracking', 'product help', 'payment']
            : ['pricing', 'demo', 'contact sales', 'support', 'implementation'];
        $missingIntents = [];
        foreach ($expectedIntents as $intent) {
            if (!$this->intentCovered($intent, $knownIntents)) {
                $missingIntents[] = $intent;
            }
        }

        $responseAccuracyEstimate = match (true) {
            $chatbotDetected && $knowledgeBaseSignals && count($missingIntents) <= 1 => 'High readiness',
            $chatbotDetected && ($knowledgeBaseSignals || count($missingIntents) <= 2) => 'Moderate readiness',
            $chatbotDetected => 'Low readiness',
            default => 'No conversational layer detected',
        };

        $leadCaptureEffectiveness = match (true) {
            $leadForms > 0 && count($leadCaptureCtas) >= 2 => 'Strong',
            $leadForms > 0 || count($leadCaptureCtas) >= 1 => 'Moderate',
            default => 'Weak',
        };

        $findings = [];
        $recommendations = [];
        $score = 100;

        if (!$chatbotDetected) {
            $findings[] = 'No chatbot or live-chat vendor was detected in the inspected pages.';
            $recommendations[] = 'If conversational assistance matters for sales or support, add a chatbot or live chat with clear escalation paths.';
            $score -= 18;
        } else {
            $findings[] = $vendors !== []
                ? 'Detected conversational stack: ' . implode(', ', $vendors) . '.'
                : 'Conversational support cues were detected, but the specific vendor could not be identified from static markup.';
        }

        if ($missingIntents !== []) {
            $findings[] = 'The site does not clearly expose coverage for these intents: ' . implode(', ', $missingIntents) . '.';
            $recommendations[] = 'Train the chatbot and supporting knowledge base around the missing intents so visitors do not dead-end in chat.';
            $score -= min(24, count($missingIntents) * 5);
        }

        if (!$knowledgeBaseSignals && $chatbotDetected) {
            $findings[] = 'A chatbot was detected, but FAQ or support content signals are weak.';
            $recommendations[] = 'Back the chatbot with FAQ, policy, pricing, and troubleshooting content so responses stay accurate.';
            $score -= 12;
        }

        if ($leadCaptureEffectiveness === 'Weak') {
            $findings[] = 'Lead capture signals are weak across forms and CTAs.';
            $recommendations[] = 'Improve lead capture with clearer demo, quote, trial, or contact CTAs tied to the conversational flow.';
            $score -= 14;
        }

        if (!$humanHandoff) {
            $findings[] = 'A clear human handoff path was not obvious in the inspected pages.';
            $recommendations[] = 'Expose email, phone, WhatsApp, or contact-sales escalation paths from chat and support journeys.';
            $score -= 12;
        }

        $recommendations[] = 'Map conversation flows around high-intent paths such as pricing, returns, shipping, support, and qualified lead capture.';

        $score = max(0, $score);

        return [
            'applicable' => true,
            'score' => $score,
            'headline' => $score >= 80
                ? 'Customer-experience signals are solid, but intent coverage and lead routing can still be tightened.'
                : 'Conversational support or lead-capture readiness shows meaningful gaps.',
            'chatbot_detected' => $chatbotDetected,
            'detected_vendors' => $vendors,
            'response_accuracy_estimate' => $responseAccuracyEstimate,
            'lead_capture_effectiveness' => $leadCaptureEffectiveness,
            'knowledge_base_signals' => $knowledgeBaseSignals,
            'human_handoff_available' => $humanHandoff,
            'known_intents' => $knownIntents,
            'missing_intents' => $missingIntents,
            'lead_capture_ctas' => $leadCaptureCtas,
            'findings' => array_values(array_slice(array_unique($findings), 0, 6)),
            'recommendations' => array_values(array_slice(array_unique($recommendations), 0, 5)),
        ];
    }

    private function buildIssues(array $audit): array
    {
        $issues = [];
        $statusCode = (int) ($audit['response']['status_code'] ?? 0);
        $contentType = strtolower((string) ($audit['response']['content_type'] ?? ''));
        $page = $audit['metrics']['page'] ?? [];
        $content = $audit['metrics']['content'] ?? [];
        $media = $audit['metrics']['media'] ?? [];
        $links = $audit['metrics']['links'] ?? [];
        $assets = $audit['metrics']['assets'] ?? [];
        $enhancements = $audit['metrics']['enhancements'] ?? [];
        $checks = $audit['checks'] ?? [];
        $analytics = $audit['modules']['analytics'] ?? [];
        $competitor = $audit['modules']['competitor'] ?? [];
        $ecommerce = $audit['modules']['ecommerce'] ?? [];
        $chatbot = $audit['modules']['chatbot'] ?? [];
        $crawl = $audit['crawl'] ?? [];
        $crawlSummary = $crawl['summary'] ?? [];
        $xRobotsTag = (string) ($page['x_robots_tag'] ?? '');

        if ($statusCode !== 200) {
            $issues[] = $this->issue('critical', 'crawlability', 'Page is not returning HTTP 200', 'Search engines treat non-200 pages as lower quality landing targets.', 'Fix server-side errors or redirect chains so the audited URL resolves directly with HTTP 200.', 'HTTP status code: ' . $statusCode, 28);
        }

        if ($contentType !== '' && !str_contains($contentType, 'text/html')) {
            $issues[] = $this->issue('high', 'crawlability', 'Page is not served as HTML', 'A non-HTML response limits how search engines parse the page.', 'Serve the target as `text/html` when it should rank as a page.', 'Content-Type: ' . $contentType, 14);
        }

        if (!($checks['https'] ?? false)) {
            $issues[] = $this->issue('high', 'crawlability', 'Page is not served over HTTPS', 'Insecure URLs weaken trust signals and can create duplicate indexing paths.', 'Redirect all HTTP traffic to HTTPS and update canonical links to the secure URL.', 'Final URL: ' . ($audit['target']['final_url'] ?? ''), 16);
        }

        if ((int) ($audit['response']['redirect_count'] ?? 0) > 1) {
            $issues[] = $this->issue('medium', 'crawlability', 'URL relies on multiple redirects', 'Long redirect chains waste crawl budget and slow users down.', 'Shorten the chain so the public URL resolves in a single hop.', 'Redirect count: ' . (int) ($audit['response']['redirect_count'] ?? 0), 6);
        }

        if (($page['title']['text'] ?? '') === '') {
            $issues[] = $this->issue('critical', 'metadata', 'Missing title tag', 'The title tag is one of the strongest on-page ranking and click-through signals.', 'Add a unique title between 30 and 60 characters that reflects the page intent.', 'No `<title>` tag detected.', 18);
        } else {
            $titleLength = (int) ($page['title']['length'] ?? 0);
            if ($titleLength < 30 || $titleLength > 60) {
                $issues[] = $this->issue('medium', 'metadata', 'Title length is outside the ideal range', 'Titles that are too short or too long reduce clarity in search results.', 'Aim for a focused title between 30 and 60 characters.', 'Title length: ' . $titleLength . ' characters.', 7);
            }
        }

        if (($page['description']['text'] ?? '') === '') {
            $issues[] = $this->issue('high', 'metadata', 'Missing meta description', 'Google may rewrite snippets when the description is missing or weak.', 'Write a unique 140 to 160 character description that explains the page value.', 'No `<meta name="description">` found.', 14);
        } else {
            $descriptionLength = (int) ($page['description']['length'] ?? 0);
            if ($descriptionLength < 70 || $descriptionLength > 160) {
                $issues[] = $this->issue('medium', 'metadata', 'Meta description length is off target', 'Poor snippet length reduces message control in SERPs.', 'Keep the description concise and informative, ideally 140 to 160 characters.', 'Description length: ' . $descriptionLength . ' characters.', 5);
            }
        }

        if (($page['canonical'] ?? '') === '') {
            $issues[] = $this->issue('high', 'crawlability', 'Canonical tag is missing', 'Canonical links help search engines consolidate duplicate URL signals.', 'Add a self-referencing canonical tag for indexable pages.', 'No canonical URL detected.', 10);
        }

        if ($this->containsNoindex((string) ($page['meta_robots'] ?? '')) || $this->containsNoindex($xRobotsTag)) {
            $issues[] = $this->issue('critical', 'crawlability', 'Page is marked as noindex', 'Noindex instructions prevent the page from appearing in search results.', 'Remove the noindex directive if this page is intended to rank.', 'Robots directives: ' . trim((string) (($page['meta_robots'] ?? '') . ' ' . $xRobotsTag)), 25);
        }

        $h1Count = count($page['h1'] ?? []);
        if ($h1Count === 0) {
            $issues[] = $this->issue('high', 'content', 'Missing H1 heading', 'Search engines and users both rely on a clear primary heading.', 'Add one descriptive H1 that matches the page topic and search intent.', 'No `<h1>` detected.', 12);
        } elseif ($h1Count > 1) {
            $issues[] = $this->issue('medium', 'content', 'Multiple H1 headings found', 'Multiple H1 tags can dilute the main content focus.', 'Keep a single primary H1 and use H2/H3 tags for subsections.', 'H1 count: ' . $h1Count, 6);
        }

        if (count($page['h2'] ?? []) === 0) {
            $issues[] = $this->issue('low', 'content', 'No H2 subheadings found', 'A weak heading structure makes long-form content harder to scan.', 'Add H2 sections to organize supporting topics and related keywords.', 'H2 count: 0', 3);
        }

        if (($page['lang'] ?? '') === '') {
            $issues[] = $this->issue('medium', 'metadata', 'HTML lang attribute is missing', 'Language metadata helps search engines and assistive technology interpret the page.', 'Set the `<html lang="...">` attribute to the primary page language.', 'No language attribute found on the root HTML element.', 4);
        }

        if (($page['viewport'] ?? '') === '') {
            $issues[] = $this->issue('medium', 'enhancements', 'Viewport meta tag is missing', 'Missing viewport signals can hurt mobile rendering quality.', 'Add a responsive viewport tag such as `width=device-width, initial-scale=1`.', 'No viewport tag found.', 5);
        }

        $wordCount = (int) ($content['word_count'] ?? 0);
        if ($wordCount < 150) {
            $issues[] = $this->issue('high', 'content', 'Page content is extremely thin', 'Thin content gives search engines very little context to rank the page.', 'Expand the page with useful, original copy that answers the search intent completely.', 'Word count: ' . $wordCount, 12);
        } elseif ($wordCount < 300) {
            $issues[] = $this->issue('medium', 'content', 'Page content is light for SEO', 'Short pages often miss supporting entities, FAQs, and trust-building details.', 'Increase topical depth with supporting sections, FAQs, examples, or proof points.', 'Word count: ' . $wordCount, 7);
        }

        if ((int) ($links['internal'] ?? 0) < 3) {
            $issues[] = $this->issue('medium', 'content', 'Internal linking is sparse', 'Internal links help distribute authority and guide crawlers to related pages.', 'Add contextual internal links to relevant category, service, or supporting pages.', 'Internal links found: ' . (int) ($links['internal'] ?? 0), 6);
        }

        if ((int) ($links['empty_anchor_text'] ?? 0) > 0) {
            $issues[] = $this->issue('medium', 'media', 'Some links have empty anchor text', 'Empty links weaken accessibility and reduce topical relevance signals.', 'Give icon-only or image links a readable text alternative.', 'Empty anchor count: ' . (int) ($links['empty_anchor_text'] ?? 0), 5);
        }

        $missingAlt = (int) ($media['missing_alt'] ?? 0);
        $imageTotal = (int) ($media['total'] ?? 0);
        if ($missingAlt > 0) {
            $severity = $imageTotal > 0 && ($missingAlt / max($imageTotal, 1)) >= 0.4 ? 'high' : 'medium';
            $penalty = $severity === 'high' ? 10 : 6;
            $issues[] = $this->issue($severity, 'media', 'Some images are missing alt text', 'Alt text improves accessibility and helps image search understand page assets.', 'Add descriptive alt text to meaningful images and leave decorative assets empty on purpose.', 'Missing alt text on ' . $missingAlt . ' of ' . $imageTotal . ' images.', $penalty);
        }

        if (!(bool) ($checks['robots_txt']['found'] ?? false)) {
            $issues[] = $this->issue('medium', 'crawlability', 'robots.txt could not be found', 'Search engines expect a crawl policy file at the site root.', 'Publish a robots.txt file that allows important sections and references the sitemap.', 'robots.txt status: ' . (int) ($checks['robots_txt']['status'] ?? 0), 8);
        }

        if (!(bool) ($checks['sitemap']['found'] ?? false)) {
            $issues[] = $this->issue('medium', 'crawlability', 'XML sitemap could not be found', 'A sitemap helps search engines discover canonical URLs more efficiently.', 'Publish a sitemap.xml or sitemap index and reference it inside robots.txt.', 'Sitemap check status: ' . (int) ($checks['sitemap']['status'] ?? 0), 10);
        }

        if ((int) ($enhancements['structured_data_count'] ?? 0) === 0) {
            $issues[] = $this->issue('medium', 'enhancements', 'Structured data is missing', 'Schema markup can improve eligibility for enhanced search results.', 'Add relevant JSON-LD schema such as Organization, WebSite, Product, Article, or FAQ.', 'No JSON-LD blocks detected.', 7);
        }

        if (!in_array(true, $enhancements['open_graph']['coverage'] ?? [], true)) {
            $issues[] = $this->issue('medium', 'enhancements', 'Open Graph tags are missing', 'Social previews affect click-through when pages are shared.', 'Add core Open Graph tags for title, description, image, and URL.', 'No Open Graph metadata detected.', 5);
        }

        if (!in_array(true, $enhancements['twitter_cards']['coverage'] ?? [], true)) {
            $issues[] = $this->issue('low', 'enhancements', 'Twitter card metadata is missing', 'Card metadata improves consistency when the page is shared on social networks.', 'Add twitter:card, twitter:title, and twitter:description metadata.', 'No Twitter card metadata detected.', 2);
        }

        if (!(bool) ($enhancements['favicon'] ?? false)) {
            $issues[] = $this->issue('low', 'enhancements', 'Favicon link is missing', 'A favicon supports browser tab recognition and visual trust.', 'Add a favicon link in the document head.', 'No favicon link detected in the head section.', 1);
        }

        $htmlSizeKb = (float) ($audit['response']['html_size_kb'] ?? 0);
        if ($htmlSizeKb > 300) {
            $severity = $htmlSizeKb > 700 ? 'high' : 'medium';
            $penalty = $severity === 'high' ? 10 : 5;
            $issues[] = $this->issue($severity, 'enhancements', 'HTML payload is large', 'Large HTML files can slow rendering and increase crawl overhead.', 'Trim unused markup, inline payloads, and bloated page builders where possible.', 'HTML size: ' . $htmlSizeKb . ' KB.', $penalty);
        }

        if ((int) ($assets['script_files'] ?? 0) > 12) {
            $issues[] = $this->issue('low', 'enhancements', 'Page loads many external scripts', 'Heavy script usage can slow page experience and reduce crawl efficiency.', 'Audit non-essential third-party scripts and defer what is not critical.', 'External script files: ' . (int) ($assets['script_files'] ?? 0), 3);
        }

        if (($crawl['enabled'] ?? false) && (int) ($crawlSummary['missing_titles'] ?? 0) > 0) {
            $issues[] = $this->issue(
                'medium',
                'metadata',
                'Some crawled pages are missing title tags',
                'Title gaps on internal pages weaken sitewide relevance and click-through quality.',
                'Add unique, intent-matched title tags across the affected internal URLs.',
                'Crawled pages missing titles: ' . (int) ($crawlSummary['missing_titles'] ?? 0),
                8
            );
        }

        if (($crawl['enabled'] ?? false) && (int) ($crawlSummary['thin_content_pages'] ?? 0) >= 2) {
            $issues[] = $this->issue(
                'medium',
                'content',
                'Multiple crawled pages are thin on content',
                'Sitewide thin pages can dilute topical depth and leave important intents under-served.',
                'Expand thin pages with clearer structure, supporting detail, FAQs, and stronger internal linking.',
                'Crawled pages under 300 words: ' . (int) ($crawlSummary['thin_content_pages'] ?? 0),
                10
            );
        }

        if (($crawl['enabled'] ?? false) && (int) ($crawlSummary['noindex_pages'] ?? 0) > 0) {
            $issues[] = $this->issue(
                'high',
                'crawlability',
                'Some crawled pages appear to be noindexed',
                'Unexpected noindex directives can block important internal URLs from ranking.',
                'Review the affected pages and remove noindex only where those URLs should appear in search.',
                'Crawled pages with noindex: ' . (int) ($crawlSummary['noindex_pages'] ?? 0),
                14
            );
        }

        if (($analytics['detected_tools'] ?? []) === []) {
            $issues[] = $this->issue('high', 'analytics', 'No analytics stack was detected', 'Without a reliable analytics layer, traffic and conversion decisions are based on incomplete data.', 'Deploy GA4 directly or through GTM and verify that the base pageview is firing correctly.', 'Detected tools: none', 16);
        }

        if (($analytics['requires_conversion_tracking'] ?? false) && ($analytics['conversion_events'] ?? []) === []) {
            $issues[] = $this->issue('high', 'analytics', 'Conversion tracking appears incomplete', 'Lead or ecommerce flows need conversion events to support attribution and optimization.', 'Track final lead, chat, and checkout conversion points with normalized event names.', 'Detected conversion events: ' . implode(', ', $analytics['conversion_events'] ?? []), 16);
        }

        if (($analytics['missing_events'] ?? []) !== []) {
            $issues[] = $this->issue('medium', 'analytics', 'Funnel events appear to be missing', 'Missing event steps make it hard to diagnose where visitors drop out of the funnel.', 'Instrument the missing funnel events and validate them in a live analytics debugger.', 'Missing events: ' . implode(', ', $analytics['missing_events'] ?? []), min(14, count($analytics['missing_events']) * 4));
        }

        if (($competitor['status'] ?? '') === 'complete' && ($competitor['score'] ?? 100) < 75) {
            $issues[] = $this->issue('medium', 'competition', 'Competitors show stronger positioning signals', 'Competitor pages appear stronger on depth, topical fit, or authority proxies.', 'Use the benchmark table to expand content, reinforce intent alignment, and strengthen authority cues.', 'Top benchmark reasons: ' . implode(' | ', $competitor['outrank_reasons'] ?? []), 12);
        }

        if (($ecommerce['applicable'] ?? false) && ($ecommerce['product_description_gaps'] ?? []) !== []) {
            $issues[] = $this->issue('high', 'ecommerce', 'Product-page persuasion is underdeveloped', 'Product or offer pages need stronger copy, proof, and reassurance to convert search traffic.', 'Strengthen benefits, objections, proof, shipping, return copy, and structured data on product pages.', 'Key gaps: ' . implode(' | ', $ecommerce['product_description_gaps'] ?? []), 14);
        }

        if (($ecommerce['applicable'] ?? false) && ($ecommerce['checkout_friction_points'] ?? []) !== []) {
            $issues[] = $this->issue('high', 'ecommerce', 'Checkout flow shows friction risk', 'Checkout complexity or weak trust signals can increase abandonment.', 'Reduce unnecessary fields, make guest checkout obvious, and surface trust cues near checkout CTAs.', 'Checkout friction: ' . implode(' | ', $ecommerce['checkout_friction_points'] ?? []), 16);
        }

        if (($chatbot['missing_intents'] ?? []) !== []) {
            $issues[] = $this->issue('medium', 'chatbot', 'Important chatbot or support intents are not clearly covered', 'Visitors need clear support for the questions they ask most often.', 'Train the chatbot and supporting knowledge base around the missing intents.', 'Missing intents: ' . implode(', ', $chatbot['missing_intents'] ?? []), min(12, count($chatbot['missing_intents']) * 3));
        }

        if (!(bool) ($chatbot['human_handoff_available'] ?? true)) {
            $issues[] = $this->issue('medium', 'chatbot', 'Human escalation path is weak or missing', 'Bots and self-serve content need a clear fallback when visitors need help from a person.', 'Expose email, phone, WhatsApp, or contact-sales escalation inside the support journey.', 'Human handoff detected: no', 10);
        }

        usort($issues, function (array $left, array $right): int {
            $severityComparison = $this->severityWeights[$right['severity']] <=> $this->severityWeights[$left['severity']];
            if ($severityComparison !== 0) {
                return $severityComparison;
            }

            return $right['penalty'] <=> $left['penalty'];
        });

        return array_map(fn(array $issue): array => $this->enrichIssueWithFixGuidance($issue, $audit), $issues);
    }

    private function calculateScores(array $issues, array $modules): array
    {
        $applicableCategories = ['crawlability', 'metadata', 'content', 'media', 'enhancements', 'analytics', 'chatbot'];
        if (($modules['competitor']['status'] ?? '') === 'complete') {
            $applicableCategories[] = 'competition';
        }
        if (($modules['ecommerce']['applicable'] ?? false) === true) {
            $applicableCategories[] = 'ecommerce';
        }

        $scores = array_fill_keys(array_keys($this->categoryDefaults), null);
        foreach ($applicableCategories as $category) {
            $scores[$category] = 100;
        }

        $issueSummary = [
            'critical' => 0,
            'high' => 0,
            'medium' => 0,
            'low' => 0,
        ];

        foreach ($issues as $issue) {
            $category = $issue['category'];
            $penalty = (int) $issue['penalty'];
            $issueSummary[$issue['severity']]++;

            if (!array_key_exists($category, $scores) || $scores[$category] === null) {
                continue;
            }

            $scores[$category] = max(0, (int) $scores[$category] - $penalty);
        }

        $activeScores = array_values(array_filter($scores, static fn($value): bool => $value !== null));
        $overall = $activeScores === [] ? 0 : (int) round(array_sum($activeScores) / count($activeScores));

        return [
            'overall' => $overall,
            'grade' => $this->gradeForScore($overall),
            'categories' => $scores,
            'issue_summary' => $issueSummary,
        ];
    }

    private function buildHighlights(array $audit): array
    {
        $page = $audit['metrics']['page'] ?? [];
        $content = $audit['metrics']['content'] ?? [];
        $media = $audit['metrics']['media'] ?? [];
        $checks = $audit['checks'] ?? [];
        $enhancements = $audit['metrics']['enhancements'] ?? [];
        $analytics = $audit['modules']['analytics'] ?? [];
        $ecommerce = $audit['modules']['ecommerce'] ?? [];
        $chatbot = $audit['modules']['chatbot'] ?? [];
        $crawl = $audit['crawl'] ?? [];
        $highlights = [];

        if ((int) ($audit['response']['status_code'] ?? 0) === 200) {
            $highlights[] = 'The page resolves successfully with HTTP 200.';
        }

        if ((bool) ($checks['https'] ?? false)) {
            $highlights[] = 'The audited URL resolves over HTTPS.';
        }

        $titleLength = (int) ($page['title']['length'] ?? 0);
        if ($titleLength >= 30 && $titleLength <= 60) {
            $highlights[] = 'The title length is within the ideal search snippet range.';
        }

        $descriptionLength = (int) ($page['description']['length'] ?? 0);
        if ($descriptionLength >= 140 && $descriptionLength <= 160) {
            $highlights[] = 'The meta description is close to the ideal snippet length.';
        }

        if (count($page['h1'] ?? []) === 1) {
            $highlights[] = 'The page uses a single H1 heading.';
        }

        if ((int) ($content['word_count'] ?? 0) >= 300) {
            $highlights[] = 'The page has enough body copy to support topical relevance.';
        }

        if ((int) ($media['total'] ?? 0) > 0 && (int) ($media['missing_alt'] ?? 0) === 0) {
            $highlights[] = 'All discovered images include alt text.';
        }

        if ((bool) ($checks['robots_txt']['found'] ?? false)) {
            $highlights[] = 'A robots.txt file is present at the site root.';
        }

        if ((bool) ($checks['sitemap']['found'] ?? false)) {
            $highlights[] = 'An XML sitemap is discoverable from the site root.';
        }

        if ((int) ($enhancements['structured_data_count'] ?? 0) > 0) {
            $highlights[] = 'Structured data markup is present on the page.';
        }

        if (($analytics['detected_tools'] ?? []) !== []) {
            $highlights[] = 'Tracking tools were detected: ' . implode(', ', array_slice($analytics['detected_tools'], 0, 3)) . '.';
        }

        if (($ecommerce['applicable'] ?? false) && !($ecommerce['product_description_gaps'] ?? [])) {
            $highlights[] = 'The inspected ecommerce page shows a reasonably complete product-detail baseline.';
        }

        if (($chatbot['chatbot_detected'] ?? false) && ($chatbot['human_handoff_available'] ?? false)) {
            $highlights[] = 'Conversational support appears to have a human escalation path.';
        }

        if (($crawl['enabled'] ?? false) && (int) ($crawl['pages_crawled'] ?? 0) > 1) {
            $highlights[] = 'Whole-site crawl inspected ' . (int) ($crawl['pages_crawled'] ?? 0) . ' internal pages for page-level content and metadata gaps.';
        }

        return array_slice($highlights, 0, 10);
    }

    private function buildAiSummaryPayload(array $audit): array
    {
        return [
            'url' => $audit['target']['final_url'] ?? '',
            'overall_score' => $audit['scores']['overall'] ?? 0,
            'grade' => $audit['scores']['grade'] ?? 'F',
            'category_scores' => $audit['scores']['categories'] ?? [],
            'response' => [
                'status_code' => $audit['response']['status_code'] ?? 0,
                'response_time_ms' => $audit['response']['response_time_ms'] ?? 0,
                'redirect_count' => $audit['response']['redirect_count'] ?? 0,
                'html_size_kb' => $audit['response']['html_size_kb'] ?? 0,
            ],
            'page' => [
                'title' => $audit['metrics']['page']['title']['text'] ?? '',
                'description' => $audit['metrics']['page']['description']['text'] ?? '',
                'keywords' => $audit['metrics']['content']['keywords'] ?? [],
                'title_length' => $audit['metrics']['page']['title']['length'] ?? 0,
                'meta_description_length' => $audit['metrics']['page']['description']['length'] ?? 0,
                'h1_count' => count($audit['metrics']['page']['h1'] ?? []),
                'h2_count' => count($audit['metrics']['page']['h2'] ?? []),
                'word_count' => $audit['metrics']['content']['word_count'] ?? 0,
                'internal_links' => $audit['metrics']['links']['internal'] ?? 0,
                'external_links' => $audit['metrics']['links']['external'] ?? 0,
                'images_total' => $audit['metrics']['media']['total'] ?? 0,
                'images_missing_alt' => $audit['metrics']['media']['missing_alt'] ?? 0,
                'structured_data_types' => $audit['metrics']['enhancements']['structured_data_types'] ?? [],
            ],
            'technical_checks' => [
                'https' => $audit['checks']['https'] ?? false,
                'robots_txt' => $audit['checks']['robots_txt']['found'] ?? false,
                'sitemap' => $audit['checks']['sitemap']['found'] ?? false,
                'viewport' => ($audit['metrics']['page']['viewport'] ?? '') !== '',
                'open_graph' => $audit['metrics']['enhancements']['open_graph']['present'] ?? false,
                'twitter_cards' => $audit['metrics']['enhancements']['twitter_cards']['present'] ?? false,
            ],
            'modules' => [
                'analytics' => [
                    'score' => $audit['modules']['analytics']['score'] ?? null,
                    'tools' => $audit['modules']['analytics']['detected_tools'] ?? [],
                    'events' => $audit['modules']['analytics']['detected_events'] ?? [],
                    'missing_events' => $audit['modules']['analytics']['missing_events'] ?? [],
                    'conversion_events' => $audit['modules']['analytics']['conversion_events'] ?? [],
                ],
                'competitor' => [
                    'status' => $audit['modules']['competitor']['status'] ?? '',
                    'score' => $audit['modules']['competitor']['score'] ?? null,
                    'comparison_rows' => $audit['modules']['competitor']['comparison_rows'] ?? [],
                    'outrank_reasons' => $audit['modules']['competitor']['outrank_reasons'] ?? [],
                    'note' => $audit['modules']['competitor']['note'] ?? '',
                ],
                'ecommerce' => [
                    'applicable' => $audit['modules']['ecommerce']['applicable'] ?? false,
                    'score' => $audit['modules']['ecommerce']['score'] ?? null,
                    'product_description_gaps' => $audit['modules']['ecommerce']['product_description_gaps'] ?? [],
                    'checkout_friction_points' => $audit['modules']['ecommerce']['checkout_friction_points'] ?? [],
                    'pricing_signals' => $audit['modules']['ecommerce']['pricing_signals'] ?? [],
                ],
                'chatbot' => [
                    'score' => $audit['modules']['chatbot']['score'] ?? null,
                    'chatbot_detected' => $audit['modules']['chatbot']['chatbot_detected'] ?? false,
                    'vendors' => $audit['modules']['chatbot']['detected_vendors'] ?? [],
                    'missing_intents' => $audit['modules']['chatbot']['missing_intents'] ?? [],
                    'response_accuracy_estimate' => $audit['modules']['chatbot']['response_accuracy_estimate'] ?? '',
                    'lead_capture_effectiveness' => $audit['modules']['chatbot']['lead_capture_effectiveness'] ?? '',
                ],
            ],
            'crawl' => [
                'enabled' => $audit['crawl']['enabled'] ?? false,
                'pages_crawled' => $audit['crawl']['pages_crawled'] ?? 1,
                'summary' => $audit['crawl']['summary'] ?? [],
                'top_keywords' => $audit['crawl']['top_keywords'] ?? [],
            ],
            'top_issues' => array_map(
                static fn(array $issue): array => [
                    'severity' => $issue['severity'],
                    'category' => $issue['category'],
                    'title' => $issue['title'],
                    'details' => $issue['details'],
                    'recommendation' => $issue['recommendation'],
                    'evidence' => $issue['evidence'],
                    'how_to_fix' => $issue['how_to_fix'] ?? [],
                    'example_fix' => $issue['example_fix'] ?? '',
                ],
                array_slice($audit['issues'] ?? [], 0, 10)
            ),
        ];
    }

    private function buildFallbackInsights(array $audit): array
    {
        $issues = $audit['issues'] ?? [];
        $topIssues = array_slice($issues, 0, 3);
        $priorities = [];
        foreach ($topIssues as $issue) {
            $priorities[] = [
                'title' => $issue['title'],
                'why_it_matters' => $issue['details'],
                'action' => $issue['recommendation'],
            ];
        }
        while (count($priorities) < 3) {
            $priorities[] = [
                'title' => 'Strengthen topical coverage',
                'why_it_matters' => 'Content breadth, data integrity, and crawl readiness compound together.',
                'action' => 'Use the audit findings to expand weak sections, fix measurement gaps, and tighten sitewide metadata.',
            ];
        }

        $quickWins = [];
        foreach ($issues as $issue) {
            if (in_array($issue['severity'], ['medium', 'low'], true)) {
                $quickWins[] = $issue['recommendation'];
            }
        }
        $quickWins = array_values(array_slice(array_unique($quickWins), 0, 5));

        $contentStrategy = [];
        $wordCount = (int) ($audit['metrics']['content']['word_count'] ?? 0);
        if ($wordCount < 300) {
            $contentStrategy[] = 'Expand the page with supporting sections, FAQs, proof, and real objections so search intent is handled more completely.';
        }
        if (count($audit['metrics']['page']['h2'] ?? []) === 0) {
            $contentStrategy[] = 'Introduce H2-led subsections to cover secondary questions and improve content scanability.';
        }
        $contentStrategy[] = 'Align title, H1, and supporting copy around one primary intent instead of broad generic wording.';
        $contentStrategy = array_values(array_slice(array_unique($contentStrategy), 0, 4));

        $keywordOpportunities = $this->buildLocalKeywordOpportunities($audit);
        $contentSuggestions = $this->buildLocalContentSuggestions($audit);
        $importantSuggestions = $this->buildLocalImportantSuggestions($audit);

        $analyticsStrategy = array_values(array_slice(array_unique($audit['modules']['analytics']['recommendations'] ?? []), 0, 4));
        $competitorReasons = array_values(array_slice(array_unique($audit['modules']['competitor']['outrank_reasons'] ?? []), 0, 4));
        $competitorStrategy = array_values(array_slice(array_unique($audit['modules']['competitor']['recommendations'] ?? []), 0, 4));
        $ecommerceStrategy = array_values(array_slice(array_unique($audit['modules']['ecommerce']['recommendations'] ?? []), 0, 4));
        $chatbotStrategy = array_values(array_slice(array_unique($audit['modules']['chatbot']['recommendations'] ?? []), 0, 4));

        $criticalCount = (int) ($audit['scores']['issue_summary']['critical'] ?? 0);
        $summary = $criticalCount > 0
            ? 'The audit shows blocking issues that should be fixed before scaling content, traffic acquisition, or funnel optimization.'
            : 'The site is workable, but the highest-impact SEO, tracking, funnel, and customer-experience gaps should be tightened before further scaling.';

        return [
            'executive_summary' => $summary,
            'top_priorities' => $priorities,
            'quick_wins' => $quickWins,
            'content_strategy' => $contentStrategy,
            'analytics_strategy' => $analyticsStrategy,
            'competitor_outrank_reasons' => $competitorReasons,
            'competitor_strategy' => $competitorStrategy,
            'ecommerce_strategy' => $ecommerceStrategy,
            'chatbot_strategy' => $chatbotStrategy,
            'keyword_opportunities' => $keywordOpportunities,
            'content_suggestions' => $contentSuggestions,
            'important_suggestions' => $importantSuggestions,
            'growth_plan' => $this->buildLocalGrowthPlan($audit),
            'stakeholder_note' => 'Fix data integrity and crawl/index fundamentals first, then move into competitor-informed content expansion and funnel refinement so improvements compound instead of masking root causes.',
        ];
    }

    private function mergeAiModuleStrategies(array $modules, array $aiInsights): array
    {
        $modules['analytics']['ai_recommendations'] = $aiInsights['analytics_strategy'] ?? [];
        $modules['competitor']['ai_recommendations'] = $aiInsights['competitor_strategy'] ?? [];
        $modules['competitor']['ai_outrank_reasons'] = $aiInsights['competitor_outrank_reasons'] ?? [];
        $modules['ecommerce']['ai_recommendations'] = $aiInsights['ecommerce_strategy'] ?? [];
        $modules['chatbot']['ai_recommendations'] = $aiInsights['chatbot_strategy'] ?? [];

        return $modules;
    }

    private function buildContentLab(array $audit): array
    {
        $ai = $audit['ai'] ?? [];
        $crawl = $audit['crawl'] ?? [];

        return [
            'keyword_opportunities' => array_values(array_slice(array_unique(array_merge(
                $ai['keyword_opportunities'] ?? [],
                $this->buildLocalKeywordOpportunities($audit)
            )), 0, 6)),
            'content_suggestions' => array_values(array_slice(array_unique(array_merge(
                $ai['content_suggestions'] ?? [],
                $this->buildLocalContentSuggestions($audit)
            )), 0, 6)),
            'important_suggestions' => array_values(array_slice(array_unique(array_merge(
                $ai['important_suggestions'] ?? [],
                $this->buildLocalImportantSuggestions($audit)
            )), 0, 6)),
            'generator_defaults' => $this->buildGeneratorDefaults($audit),
            'crawl' => [
                'enabled' => $crawl['enabled'] ?? false,
                'scope' => $crawl['scope'] ?? 'page',
                'limit' => $crawl['limit'] ?? 1,
                'pages_crawled' => $crawl['pages_crawled'] ?? 1,
                'failed_fetches' => $crawl['failed_fetches'] ?? 0,
                'summary' => $crawl['summary'] ?? [],
                'top_keywords' => $crawl['top_keywords'] ?? [],
                'pages' => $crawl['pages'] ?? [],
            ],
        ];
    }

    private function buildLocalGrowthPlan(array $audit): array
    {
        $technicalTasks = [
            'Resolve the highest-severity crawlability and metadata issues on the audited money pages first.',
            'Fix canonical, noindex, robots.txt, sitemap, title, and meta description gaps before expanding content.',
            'Re-run the audit after deployment so the technical baseline is verified, not assumed.',
        ];

        $measurementTasks = [
            'Deploy or validate GA4 or GTM on all key templates and confirm the base pageview is firing.',
            'Map and implement the missing conversion events so form, chat, cart, and checkout actions are measurable.',
            'Test events in a live debugger and document a single naming convention for reporting.',
        ];

        $contentTasks = [
            'Rewrite the weakest titles, descriptions, H1s, and H2 structures on the pages with the biggest content gaps.',
            'Publish or expand supporting pages around the top keyword opportunities surfaced in the audit.',
            'Use competitor and crawl findings to add proof, FAQs, internal links, and deeper subtopic coverage.',
        ];

        $growthTasks = ($audit['modules']['ecommerce']['applicable'] ?? false)
            ? [
                'Improve product, cart, and checkout persuasion with clearer trust, shipping, return, and CTA copy.',
                'Trim visible checkout friction and test stronger pricing or offer framing where appropriate.',
                'Review conversion data weekly and prioritize the step with the largest drop-off.',
            ]
            : [
                'Tighten landing-page CTAs, lead capture paths, and contact prompts on high-intent pages.',
                'Add or improve chatbot, FAQ, and human handoff flows for the missing support or sales intents.',
                'Review weekly lead quality and adjust page copy, form friction, and CTA placement based on actual behavior.',
            ];

        return [
            [
                'week' => 'Week 1',
                'focus' => 'Fix technical SEO and indexability',
                'tasks' => $technicalTasks,
                'goal' => 'Make the site crawlable, indexable, and technically consistent.',
            ],
            [
                'week' => 'Week 2',
                'focus' => 'Repair tracking and conversion measurement',
                'tasks' => $measurementTasks,
                'goal' => 'Make traffic and conversion data reliable enough to guide the next decisions.',
            ],
            [
                'week' => 'Week 3',
                'focus' => 'Upgrade core page content and publish supporting assets',
                'tasks' => $contentTasks,
                'goal' => 'Increase topical depth, intent coverage, and internal authority flow.',
            ],
            [
                'week' => 'Week 4',
                'focus' => 'Improve conversion, lead capture, and growth loops',
                'tasks' => $growthTasks,
                'goal' => 'Turn stronger visibility into more qualified leads, sales, or conversations.',
            ],
        ];
    }

    private function enrichIssueWithFixGuidance(array $issue, array $audit): array
    {
        $suggestedTitle = $this->buildSuggestedTitle($audit);
        $suggestedMetaDescription = $this->buildSuggestedMetaDescription($audit);
        $suggestedH1 = $this->buildSuggestedH1($audit);
        $suggestedH2s = $this->buildSuggestedH2s($audit);
        $canonicalUrl = (string) ($audit['target']['final_url'] ?? $audit['target']['requested_url'] ?? '');
        $missingEvents = $audit['modules']['analytics']['missing_events'] ?? [];
        $eventExamples = $this->buildEventTrackingExample($missingEvents);
        $internalLinks = $this->buildInternalLinkTargets($audit);
        $crawlTargets = $this->buildCrawlPriorityTargets($audit);

        $guidance = match ($issue['title']) {
            'Page is not returning HTTP 200' => [
                'how_to_fix' => [
                    'Check the audited URL directly in the browser and in server logs to confirm whether it is returning 404, 500, or redirecting unexpectedly.',
                    'Update the route, rewrite rule, or redirect so the public URL resolves in a single request to the final page.',
                    'Re-test the exact URL after deployment until it returns a clean HTTP 200 response.',
                ],
                'example_fix' => 'Target fix: make `' . $canonicalUrl . '` return HTTP 200 without an intermediate error or redirect chain.',
            ],
            'Page is not served as HTML' => [
                'how_to_fix' => [
                    'Confirm the URL is meant to rank as a webpage and not as a file download or API response.',
                    'Set the route or controller to return `Content-Type: text/html; charset=UTF-8` for the page template.',
                    'Re-crawl the page and confirm the HTML source contains the main SEO tags in the response body.',
                ],
                'example_fix' => 'Expected response header: `Content-Type: text/html; charset=UTF-8`',
            ],
            'Page is not served over HTTPS' => [
                'how_to_fix' => [
                    'Install or renew the SSL certificate on the domain.',
                    '301 redirect the HTTP version of the URL to the HTTPS version at the server or load-balancer level.',
                    'Update canonical tags, sitemap entries, and internal links so they all point to HTTPS.',
                ],
                'example_fix' => 'Expected canonical URL: `' . preg_replace('#^http://#', 'https://', $canonicalUrl) . '`',
            ],
            'URL relies on multiple redirects' => [
                'how_to_fix' => [
                    'List the full redirect chain for the audited URL.',
                    'Change the first public URL so it redirects straight to the final destination instead of bouncing through multiple hops.',
                    'Update internal links and canonicals to use the final destination directly.',
                ],
                'example_fix' => 'Preferred path: public URL -> final URL in one 301 hop only.',
            ],
            'Missing title tag', 'Title length is outside the ideal range' => [
                'how_to_fix' => [
                    'Write a single 30 to 60 character title that leads with the main topic and adds the brand only if space remains.',
                    'Place the tag inside the page head and make sure no duplicate title tags are being injected by the CMS or template.',
                    'Re-check the rendered source after publishing so the final HTML contains the exact title you intended.',
                ],
                'example_fix' => '<title>' . $this->attributeSafe($suggestedTitle) . '</title>',
            ],
            'Missing meta description', 'Meta description length is off target' => [
                'how_to_fix' => [
                    'Write one unique 140 to 160 character description that explains the page value and intent clearly.',
                    'Mention the core topic once, add a concrete benefit, and end with a soft action or trust cue.',
                    'Place it in the head and preview the final length before publishing.',
                ],
                'example_fix' => '<meta name="description" content="' . $this->attributeSafe($suggestedMetaDescription) . '">',
            ],
            'Canonical tag is missing' => [
                'how_to_fix' => [
                    'Choose the final preferred URL for the page, including the correct protocol and path.',
                    'Add a self-referencing canonical tag inside the head section of the HTML template.',
                    'Make sure redirects, sitemap entries, and internal links all point to the same canonical URL.',
                ],
                'example_fix' => '<link rel="canonical" href="' . $this->attributeSafe($canonicalUrl) . '">',
            ],
            'Page is marked as noindex' => [
                'how_to_fix' => [
                    'Check the page source, CMS SEO plugin, and response headers to find where the noindex directive is coming from.',
                    'Remove the noindex instruction if the page should rank, then keep a self-referencing canonical in place.',
                    'Request re-crawl after deployment so search engines can see the updated directive.',
                ],
                'example_fix' => '<meta name="robots" content="index,follow">',
            ],
            'Missing H1 heading', 'Multiple H1 headings found' => [
                'how_to_fix' => [
                    'Keep exactly one H1 that matches the main topic of the page.',
                    'Move supporting headings down to H2 or H3 so the structure is clear for users and crawlers.',
                    'Make sure the H1 stays visible in the rendered page body and is not hidden behind a script or widget.',
                ],
                'example_fix' => '<h1>' . $this->attributeSafe($suggestedH1) . '</h1>',
            ],
            'No H2 subheadings found' => [
                'how_to_fix' => [
                    'Break the body into logical sections so the reader can scan the page quickly.',
                    'Use H2s to cover supporting subtopics, proof, FAQs, pricing, or objections depending on the page intent.',
                    'Keep the H2 language specific instead of generic so each section targets a real question or angle.',
                ],
                'example_fix' => implode("\n", array_map(static fn(string $heading): string => '<h2>' . $heading . '</h2>', $suggestedH2s)),
            ],
            'HTML lang attribute is missing' => [
                'how_to_fix' => [
                    'Set the language on the root HTML element of the page template.',
                    'Use the primary language of the content, not the market name or country code by itself.',
                    'If the site is multilingual, make sure each language template sets its own correct lang value.',
                ],
                'example_fix' => '<html lang="en">',
            ],
            'Viewport meta tag is missing' => [
                'how_to_fix' => [
                    'Add the viewport tag to the head template used by the page.',
                    'Use the standard responsive setting so mobile browsers render the layout at device width.',
                    'Verify the page again on a real mobile screen or responsive browser mode.',
                ],
                'example_fix' => '<meta name="viewport" content="width=device-width, initial-scale=1">',
            ],
            'Page content is extremely thin', 'Page content is light for SEO' => [
                'how_to_fix' => [
                    'Expand the page until it answers the primary intent, the next obvious questions, and the main objections in one place.',
                    'Add structured sections for benefits, process, proof, FAQs, and next steps instead of padding the same paragraph.',
                    'Use the crawl and keyword suggestions to prioritize the sections that will add the most topical coverage first.',
                ],
                'example_fix' => "Suggested section outline:\n- " . implode("\n- ", $suggestedH2s),
            ],
            'Internal linking is sparse' => [
                'how_to_fix' => [
                    'Add contextual links from this page to the most relevant service, category, FAQ, pricing, or contact pages.',
                    'Use descriptive anchor text that tells the reader and search engines what they will get after the click.',
                    'Place the links inside body copy near related sections rather than clustering them only in the footer.',
                ],
                'example_fix' => 'Link this page to: ' . implode(' | ', $internalLinks),
            ],
            'Some links have empty anchor text' => [
                'how_to_fix' => [
                    'Find icon-only or empty links in the template and replace them with readable anchor text or an accessible label.',
                    'If the link is an image, give the image meaningful alt text so the destination still has context.',
                    'Re-test with a DOM inspector to confirm no empty anchors remain in the rendered markup.',
                ],
                'example_fix' => '<a href="/contact">Contact sales</a>',
            ],
            'Some images are missing alt text' => [
                'how_to_fix' => [
                    'Write concise alt text for every meaningful image based on what the user needs to understand from it.',
                    'Leave decorative images with empty alt text on purpose instead of stuffing keywords into them.',
                    'Update the CMS media library or template so the missing-alt pattern does not repeat on future pages.',
                ],
                'example_fix' => 'Example alt text: `SEO audit dashboard showing crawl issues and recommended fixes`',
            ],
            'robots.txt could not be found' => [
                'how_to_fix' => [
                    'Create a plain-text `robots.txt` file at the root of the domain.',
                    'Allow crawling of public sections and add a sitemap reference to the same file.',
                    'Upload it so it is reachable at `/robots.txt` and re-test the URL directly.',
                ],
                'example_fix' => "User-agent: *\nAllow: /\nSitemap: " . $this->siteRoot($canonicalUrl) . "/sitemap.xml",
            ],
            'XML sitemap could not be found' => [
                'how_to_fix' => [
                    'Generate a sitemap file that lists the canonical public URLs you want crawled.',
                    'Publish it at `/sitemap.xml` or a sitemap index and reference it from `robots.txt`.',
                    'Make sure non-indexable or duplicate URLs are excluded from the sitemap.',
                ],
                'example_fix' => 'Expected sitemap location: ' . $this->siteRoot($canonicalUrl) . '/sitemap.xml',
            ],
            'Structured data is missing' => [
                'how_to_fix' => [
                    'Choose the schema type that matches the page, such as WebPage, Product, Article, FAQ, or Organization.',
                    'Add one JSON-LD block in the page head or body template with the main entities filled out accurately.',
                    'Validate the markup after deployment so required fields are present and the JSON is valid.',
                ],
                'example_fix' => $this->buildStructuredDataExample($audit),
            ],
            'Open Graph tags are missing' => [
                'how_to_fix' => [
                    'Add Open Graph tags in the page head for title, description, image, and URL.',
                    'Keep the Open Graph title and description aligned with the on-page intent rather than using generic brand copy.',
                    'Use a real social preview image that matches the page topic or offer.',
                ],
                'example_fix' => $this->buildOpenGraphExample($audit),
            ],
            'Twitter card metadata is missing' => [
                'how_to_fix' => [
                    'Add the core Twitter card tags to the page head.',
                    'Use the same core message as the Open Graph preview so social sharing stays consistent.',
                    'Preview the card after deployment if the page will be shared in social channels.',
                ],
                'example_fix' => $this->buildTwitterCardExample($audit),
            ],
            'Favicon link is missing' => [
                'how_to_fix' => [
                    'Add a favicon asset to the public site root or assets directory.',
                    'Reference it from the page head so browsers can load it consistently across templates.',
                    'Clear browser cache and confirm the icon appears in the tab after deployment.',
                ],
                'example_fix' => '<link rel="icon" href="/favicon.ico" sizes="any">',
            ],
            'HTML payload is large' => [
                'how_to_fix' => [
                    'Audit the page template for repeated markup, oversized inline JSON, and hidden widgets that load in the initial HTML.',
                    'Move non-critical blocks behind lazy rendering or template includes so the first HTML response is smaller.',
                    'Re-test the page size after each cleanup step so the HTML drops steadily instead of only shifting weight into scripts.',
                ],
                'example_fix' => 'Target outcome: reduce the initial HTML response below roughly 300 KB by removing unused markup and delaying non-critical embeds.',
            ],
            'Page loads many external scripts' => [
                'how_to_fix' => [
                    'List every third-party script on the page and remove the ones that are not essential for this template.',
                    'Defer or delay non-critical tags until consent, interaction, or later page stages where possible.',
                    'Consolidate overlapping marketing and analytics tags through GTM or another tag manager.',
                ],
                'example_fix' => 'Review these script sources first: ' . implode(' | ', array_slice($audit['metrics']['assets']['script_sources'] ?? [], 0, 4)),
            ],
            'Some crawled pages are missing title tags' => [
                'how_to_fix' => [
                    'Use the crawl table to identify the affected URLs and fix them template by template, not one by one if the same bug repeats.',
                    'Write unique titles for the highest-value missing pages first, starting with money pages and core supporting assets.',
                    'Re-run the site crawl after deployment so the count of missing titles drops to zero.',
                ],
                'example_fix' => 'Fix these pages first: ' . implode(' | ', $crawlTargets),
            ],
            'Multiple crawled pages are thin on content' => [
                'how_to_fix' => [
                    'Start with the thin pages that sit closest to revenue or lead intent, then work down through the support pages.',
                    'Expand each page with unique sections, FAQs, proof, and internal links instead of copying boilerplate between pages.',
                    'Track word count and content quality together so you increase usefulness, not just length.',
                ],
                'example_fix' => 'Expand these pages first: ' . implode(' | ', $crawlTargets),
            ],
            'Some crawled pages appear to be noindexed' => [
                'how_to_fix' => [
                    'Review the noindex source on each affected page and confirm whether the directive is intentional.',
                    'Remove accidental noindex settings from public pages, then keep them out of the sitemap until fixed.',
                    'Request a fresh crawl after deployment so the corrected index directives are seen quickly.',
                ],
                'example_fix' => 'Review these affected pages first: ' . implode(' | ', $crawlTargets),
            ],
            'No analytics stack was detected' => [
                'how_to_fix' => [
                    'Install GA4 directly or through GTM on the global page template so every important page loads the base tracking setup.',
                    'Verify the pageview in Realtime or Tag Assistant before moving on to deeper event work.',
                    'Document the measurement ID or container ID in your deployment notes so it stays consistent across environments.',
                ],
                'example_fix' => $this->buildAnalyticsSetupExample(),
            ],
            'Conversion tracking appears incomplete', 'Funnel events appear to be missing' => [
                'how_to_fix' => [
                    'Create an event map for every critical action in the funnel, then implement each event where that action actually completes.',
                    'Pass the same event names into analytics, ads, and CRM workflows so reporting stays consistent.',
                    'Validate each event in a live debugger using the real funnel path before calling the setup complete.',
                ],
                'example_fix' => $eventExamples,
            ],
            'Competitors show stronger positioning signals' => [
                'how_to_fix' => [
                    'Use the competitor table and outrank reasons to identify the missing subtopics, proof points, or authority cues.',
                    'Improve the audited page first, then publish supporting assets around the adjacent keyword opportunities.',
                    'Measure changes in content depth, intent alignment, and internal linking after the rewrite rather than only counting words.',
                ],
                'example_fix' => "Suggested section brief:\n- " . implode("\n- ", $suggestedH2s),
            ],
            'Product-page persuasion is underdeveloped' => [
                'how_to_fix' => [
                    'Rewrite the product or offer page so it explains outcomes, objections, proof, pricing context, shipping, and returns in one place.',
                    'Add visible trust elements such as reviews, policy reassurance, and structured data where appropriate.',
                    'Make the primary CTA clearer and place it next to the strongest persuasion blocks, not just at the top of the page.',
                ],
                'example_fix' => "Suggested product sections:\n- Benefits and outcomes\n- Pricing and value explanation\n- Reviews and proof\n- Shipping and returns\n- FAQs before purchase",
            ],
            'Checkout flow shows friction risk' => [
                'how_to_fix' => [
                    'Reduce the number of fields and remove anything not essential to complete the transaction.',
                    'Surface trust, payment, shipping, and guest-checkout reassurance next to the primary checkout CTA.',
                    'Watch the checkout event flow after the changes so you can confirm drop-off improves at the right step.',
                ],
                'example_fix' => "Checkout checklist:\n- Keep guest checkout visible\n- Show payment security reassurance\n- Minimize fields above the fold\n- Delay coupon fields if they hurt completion",
            ],
            'Important chatbot or support intents are not clearly covered' => [
                'how_to_fix' => [
                    'List the missing intents and create direct answers for each one in the chatbot, FAQ, or help content.',
                    'Link those intents to the right destination, such as pricing, returns, support, or contact-sales pages.',
                    'Review real conversations weekly so new missing intents are added before they become dead ends.',
                ],
                'example_fix' => 'Create chatbot or FAQ coverage for: ' . implode(', ', $audit['modules']['chatbot']['missing_intents'] ?? []),
            ],
            'Human escalation path is weak or missing' => [
                'how_to_fix' => [
                    'Add a clear human contact option inside the main support, sales, and checkout journeys.',
                    'Place the escalation path near the chatbot, FAQ, or contact CTA so users do not need to hunt for it.',
                    'Measure whether users reaching the escalation path actually convert into qualified conversations or tickets.',
                ],
                'example_fix' => "Example escalation block:\nNeed help from a person?\nEmail: sales@example.com\nPhone: +1 555 555 5555\nCTA: Talk to a specialist",
            ],
            default => [
                'how_to_fix' => [
                    'Apply the fix on the audited URL first so the highest-impact page is corrected immediately.',
                    'Roll the same change into any shared templates or CMS patterns so similar pages do not keep reproducing the issue.',
                    'Re-run the audit after deployment to confirm the signal is now present in the rendered HTML.',
                ],
                'example_fix' => $issue['recommendation'],
            ],
        };

        $issue['how_to_fix'] = $guidance['how_to_fix'];
        $issue['example_fix'] = $guidance['example_fix'];

        return $issue;
    }

    private function buildSuggestedTitle(array $audit): string
    {
        $topic = $this->primaryTopicLabel($audit);
        $brand = $this->brandNameFromAudit($audit);
        $candidate = $topic;

        if ($brand !== '' && stripos($candidate, $brand) === false) {
            $candidate .= ' | ' . $brand;
        }

        return $this->trimToWordBoundary($candidate, 60);
    }

    private function buildSuggestedMetaDescription(array $audit): string
    {
        $topic = $this->primaryTopicLabel($audit);
        $candidate = match (true) {
            ($audit['metrics']['commerce']['is_product_like'] ?? false) === true
                => 'Explore ' . $topic . ' with clearer benefits, trust signals, pricing context, and a smoother path from product view to conversion.',
            ($audit['modules']['ecommerce']['applicable'] ?? false) === true
                => 'Explore ' . $topic . ' with clearer pricing, trust signals, and next steps that move buyers from comparison to conversion.',
            default
                => 'Get ' . $topic . ' with clear next steps, practical fixes, and a smoother path to stronger visibility, cleaner tracking, and better conversion flow.',
        };

        return $this->trimToWordBoundary($candidate, 160);
    }

    private function buildSuggestedH1(array $audit): string
    {
        $currentTitle = trim((string) ($audit['metrics']['page']['title']['text'] ?? ''));
        if ($currentTitle !== '') {
            $cleanTitle = preg_replace('/\s*[|\-–].*$/u', '', $currentTitle);
            if (trim((string) $cleanTitle) !== '') {
                return trim((string) $cleanTitle);
            }
        }

        return $this->primaryTopicLabel($audit);
    }

    private function buildSuggestedH2s(array $audit): array
    {
        $topic = $this->primaryTopicLabel($audit);

        if (($audit['modules']['ecommerce']['applicable'] ?? false) === true) {
            return [
                'Why ' . $topic . ' matters',
                'Pricing, shipping, and returns',
                'Reviews, trust, and common questions',
            ];
        }

        return [
            'How ' . $topic . ' works',
            'What to check before choosing a solution',
            'Pricing, proof, and next steps',
        ];
    }

    private function primaryTopicLabel(array $audit): string
    {
        $h1 = trim((string) (($audit['metrics']['page']['h1'][0] ?? '')));
        if ($h1 !== '') {
            return $h1;
        }

        $title = trim((string) ($audit['metrics']['page']['title']['text'] ?? ''));
        if ($title !== '') {
            $cleanTitle = preg_replace('/\s*[|\-–].*$/u', '', $title);
            if (trim((string) $cleanTitle) !== '') {
                return trim((string) $cleanTitle);
            }
        }

        $keyword = trim((string) (($audit['metrics']['content']['keywords'][0] ?? '')));
        if ($keyword !== '') {
            return $this->titleCase($keyword);
        }

        $brand = $this->brandNameFromAudit($audit);

        return $brand !== '' ? $brand : 'Core page topic';
    }

    private function brandNameFromAudit(array $audit): string
    {
        $host = strtolower((string) ($audit['target']['host'] ?? ''));
        $host = preg_replace('/^www\./', '', $host);
        $host = preg_replace('/\.[a-z]{2,}$/', '', (string) $host);
        $host = str_replace(['-', '_'], ' ', (string) $host);

        return $this->titleCase(trim((string) $host));
    }

    private function buildInternalLinkTargets(array $audit): array
    {
        $targets = [];
        foreach ($audit['metrics']['links']['internal_details'] ?? [] as $detail) {
            $url = trim((string) ($detail['url'] ?? ''));
            if ($url === '') {
                continue;
            }
            $targets[] = $url;
            if (count($targets) >= 3) {
                break;
            }
        }

        if ($targets === []) {
            $siteRoot = $this->siteRoot((string) ($audit['target']['final_url'] ?? $audit['target']['requested_url'] ?? ''));
            $targets = [$siteRoot . '/pricing', $siteRoot . '/contact', $siteRoot . '/faq'];
        }

        return array_values(array_unique($targets));
    }

    private function buildCrawlPriorityTargets(array $audit): array
    {
        $targets = [];
        foreach ($audit['crawl']['summary']['pages_with_most_gaps'] ?? [] as $page) {
            $url = trim((string) ($page['url'] ?? ''));
            if ($url !== '') {
                $targets[] = $url;
            }
            if (count($targets) >= 3) {
                break;
            }
        }

        return $targets !== [] ? $targets : [$audit['target']['final_url'] ?? $audit['target']['requested_url'] ?? ''];
    }

    private function buildStructuredDataExample(array $audit): string
    {
        $url = (string) ($audit['target']['final_url'] ?? $audit['target']['requested_url'] ?? '');
        $description = $this->buildSuggestedMetaDescription($audit);

        if (($audit['metrics']['commerce']['is_product_like'] ?? false) === true) {
            $data = [
                '@context' => 'https://schema.org',
                '@type' => 'Product',
                'name' => $this->primaryTopicLabel($audit),
                'description' => $description,
                'url' => $url,
            ];
        } else {
            $data = [
                '@context' => 'https://schema.org',
                '@type' => 'WebPage',
                'name' => $this->primaryTopicLabel($audit),
                'description' => $description,
                'url' => $url,
            ];
        }

        return "<script type=\"application/ld+json\">\n"
            . json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
            . "\n</script>";
    }

    private function buildOpenGraphExample(array $audit): string
    {
        $url = (string) ($audit['target']['final_url'] ?? $audit['target']['requested_url'] ?? '');

        return implode("\n", [
            '<meta property="og:title" content="' . $this->attributeSafe($this->buildSuggestedTitle($audit)) . '">',
            '<meta property="og:description" content="' . $this->attributeSafe($this->buildSuggestedMetaDescription($audit)) . '">',
            '<meta property="og:url" content="' . $this->attributeSafe($url) . '">',
            '<meta property="og:type" content="website">',
            '<meta property="og:image" content="' . $this->attributeSafe($this->siteRoot($url) . '/og-image.jpg') . '">',
        ]);
    }

    private function buildTwitterCardExample(array $audit): string
    {
        return implode("\n", [
            '<meta name="twitter:card" content="summary_large_image">',
            '<meta name="twitter:title" content="' . $this->attributeSafe($this->buildSuggestedTitle($audit)) . '">',
            '<meta name="twitter:description" content="' . $this->attributeSafe($this->buildSuggestedMetaDescription($audit)) . '">',
        ]);
    }

    private function buildAnalyticsSetupExample(): string
    {
        return implode("\n", [
            '<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>',
            '<script>',
            'window.dataLayer = window.dataLayer || [];',
            'function gtag(){dataLayer.push(arguments);}',
            "gtag('js', new Date());",
            "gtag('config', 'G-XXXXXXXXXX');",
            '</script>',
        ]);
    }

    private function buildEventTrackingExample(array $events): string
    {
        if ($events === []) {
            $events = ['generate_lead'];
        }

        $lines = [];
        foreach (array_slice($events, 0, 4) as $event) {
            $lines[] = "gtag('event', '" . $event . "', {});";
        }

        return implode("\n", $lines);
    }

    private function attributeSafe(string $value): string
    {
        return str_replace('"', "'", trim($value));
    }

    private function titleCase(string $value): string
    {
        $words = preg_split('/\s+/', strtolower(trim($value))) ?: [];
        $words = array_map(static fn(string $word): string => ucfirst($word), $words);

        return trim(implode(' ', $words));
    }

    private function trimToWordBoundary(string $value, int $limit): string
    {
        if ($this->textLength($value) <= $limit) {
            return $value;
        }

        $trimmed = function_exists('mb_substr') ? mb_substr($value, 0, $limit) : substr($value, 0, $limit);
        $trimmed = preg_replace('/\s+\S*$/u', '', (string) $trimmed);

        return trim((string) $trimmed, " ,;:-");
    }

    private function buildLocalKeywordOpportunities(array $audit): array
    {
        $mainKeywords = $audit['metrics']['content']['keywords'] ?? [];
        $crawlKeywords = $audit['crawl']['top_keywords'] ?? [];
        $keywordPool = array_values(array_slice(array_unique(array_merge($mainKeywords, $crawlKeywords)), 0, 8));
        $opportunities = [];

        foreach (array_slice($keywordPool, 0, 4) as $keyword) {
            $opportunities[] = 'Build or expand intent-matched sections around "' . $keyword . '" using original examples, objections, and decision-stage detail.';
        }

        if (($audit['modules']['competitor']['status'] ?? '') === 'complete' && ($audit['modules']['competitor']['score'] ?? 100) < 80) {
            $opportunities[] = 'Close the keyword overlap gap against competitors by adding missing subtopics their pages cover more clearly.';
        }

        if (($audit['crawl']['enabled'] ?? false) && (int) ($audit['crawl']['summary']['thin_content_pages'] ?? 0) >= 2) {
            $opportunities[] = 'Use the crawl results to prioritize thin internal pages that can be expanded into stronger supporting keyword targets.';
        }

        if ($opportunities === []) {
            $opportunities[] = 'Clarify one primary keyword theme for the page, then support it with adjacent questions and real buyer language.';
        }

        return array_values(array_slice(array_unique($opportunities), 0, 5));
    }

    private function buildLocalContentSuggestions(array $audit): array
    {
        $suggestions = [];
        $wordCount = (int) ($audit['metrics']['content']['word_count'] ?? 0);

        if ($wordCount < 300) {
            $suggestions[] = 'Expand the main page with supporting sections that answer follow-up questions instead of leaving the topic at headline level.';
        }
        if (count($audit['metrics']['page']['h2'] ?? []) === 0) {
            $suggestions[] = 'Introduce H2-led sections so the page covers subtopics, use cases, proof, and FAQs in a scannable structure.';
        }
        if (($audit['modules']['ecommerce']['applicable'] ?? false) && ($audit['modules']['ecommerce']['product_description_gaps'] ?? []) !== []) {
            $suggestions[] = 'Rewrite product or offer copy around benefits, objections, shipping, returns, and proof instead of surface-level feature language.';
        }
        if (($audit['modules']['chatbot']['missing_intents'] ?? []) !== []) {
            $suggestions[] = 'Turn missing chatbot intents into FAQ blocks, support content, or sales-enablement sections that reduce dead-end conversations.';
        }
        if (($audit['crawl']['enabled'] ?? false) && (int) ($audit['crawl']['summary']['missing_descriptions'] ?? 0) > 0) {
            $suggestions[] = 'Use the site crawl to rewrite weak page titles and descriptions so supporting pages reinforce the main topic cluster.';
        }

        $suggestions[] = 'Favor specific claims, examples, and practical language over generic marketing filler so the page feels useful and credible.';

        return array_values(array_slice(array_unique($suggestions), 0, 5));
    }

    private function buildLocalImportantSuggestions(array $audit): array
    {
        $suggestions = [];

        foreach (array_slice($audit['issues'] ?? [], 0, 3) as $issue) {
            $suggestions[] = $issue['recommendation'];
        }

        if (($audit['modules']['analytics']['missing_events'] ?? []) !== []) {
            $suggestions[] = 'Fix the analytics event map before judging content performance so attribution is based on real conversion data.';
        }

        if (($audit['crawl']['enabled'] ?? false) && (int) ($audit['crawl']['summary']['pages_analyzed'] ?? 0) > 1) {
            $suggestions[] = 'Treat the site crawl as a prioritization queue: repair the highest-gap pages first, then expand the strongest topical cluster.';
        }

        if (($audit['modules']['competitor']['status'] ?? '') === 'complete') {
            $suggestions[] = 'Use competitor depth gaps to brief better sections, not just to pad word count.';
        }

        return array_values(array_slice(array_unique($suggestions), 0, 5));
    }

    private function buildGeneratorDefaults(array $audit): array
    {
        $keywordPool = array_values(array_slice(array_unique(array_merge(
            $audit['metrics']['content']['keywords'] ?? [],
            $audit['crawl']['top_keywords'] ?? []
        )), 0, 8));

        $primaryKeyword = $keywordPool[0] ?? $this->fallbackKeywordFromPage($audit);
        $secondaryKeywords = array_values(array_slice(array_filter(
            $keywordPool,
            static fn(string $keyword): bool => $keyword !== $primaryKeyword
        ), 0, 4));

        return [
            'page_type' => $this->guessPageType($audit),
            'primary_keyword' => $primaryKeyword,
            'secondary_keywords' => $secondaryKeywords,
            'tone' => ($audit['modules']['ecommerce']['applicable'] ?? false)
                ? 'specific, persuasive, trustworthy'
                : 'clear, expert, human',
            'target_word_count' => $this->recommendedWordTarget($audit),
            'audience' => ($audit['modules']['ecommerce']['applicable'] ?? false)
                ? 'buyers comparing options'
                : 'high-intent visitors researching a solution',
            'brief' => $this->generatorBrief($audit),
        ];
    }

    private function guessPageType(array $audit): string
    {
        $path = strtolower((string) (parse_url((string) ($audit['target']['final_url'] ?? ''), PHP_URL_PATH) ?: '/'));

        if (($audit['metrics']['commerce']['is_product_like'] ?? false) === true) {
            return 'product page';
        }
        if ($path === '/' || $path === '' || preg_match('#^/index\.(?:html|php)$#', $path) === 1) {
            return 'homepage';
        }
        if (($audit['modules']['ecommerce']['applicable'] ?? false) === true && preg_match('/shop|store|collection|category|catalog|product/', $path) === 1) {
            return 'category or collection page';
        }
        if (preg_match('/blog|article|guide|resources?/', $path) === 1) {
            return 'article';
        }
        if ((int) ($audit['metrics']['forms']['lead_forms'] ?? 0) > 0 || preg_match('/service|solution|pricing|contact|demo/', $path) === 1) {
            return 'service or landing page';
        }

        return 'landing page';
    }

    private function recommendedWordTarget(array $audit): int
    {
        $currentWordCount = (int) ($audit['metrics']['content']['word_count'] ?? 0);
        $comparisonRows = $audit['modules']['competitor']['comparison_rows'] ?? [];
        $competitorWordCounts = [];

        foreach ($comparisonRows as $row) {
            if (($row['status'] ?? 0) === 200 && isset($row['word_count']) && is_numeric($row['word_count'])) {
                $competitorWordCounts[] = (int) $row['word_count'];
            }
        }

        if ($competitorWordCounts !== []) {
            $average = (int) round(array_sum($competitorWordCounts) / count($competitorWordCounts));
            return $this->roundToNearestHundred(max($currentWordCount + 150, $average));
        }

        $pageType = $this->guessPageType($audit);

        return match ($pageType) {
            'product page' => $this->roundToNearestHundred(max(450, $currentWordCount + 150)),
            'article' => $this->roundToNearestHundred(max(900, $currentWordCount + 250)),
            'homepage' => $this->roundToNearestHundred(max(700, $currentWordCount + 150)),
            default => $this->roundToNearestHundred(max(800, $currentWordCount + 200)),
        };
    }

    private function generatorBrief(array $audit): string
    {
        $brief = [];

        if (($audit['modules']['competitor']['status'] ?? '') === 'complete' && ($audit['modules']['competitor']['outrank_reasons'] ?? []) !== []) {
            $brief[] = 'Address competitor gaps around depth, subtopics, and authority cues.';
        }
        if (($audit['modules']['ecommerce']['applicable'] ?? false) && ($audit['modules']['ecommerce']['checkout_friction_points'] ?? []) !== []) {
            $brief[] = 'Reduce buyer friction with clearer reassurance and stronger explanation of value.';
        }
        if (($audit['modules']['chatbot']['missing_intents'] ?? []) !== []) {
            $brief[] = 'Answer the missing support or sales intents directly in the copy.';
        }
        if (($audit['crawl']['enabled'] ?? false) && (int) ($audit['crawl']['summary']['thin_content_pages'] ?? 0) > 0) {
            $brief[] = 'Make the page strong enough to serve as a central node in a broader content cluster.';
        }

        if ($brief === []) {
            $brief[] = 'Write for clarity, specificity, and intent match rather than generic marketing language.';
        }

        return implode(' ', $brief);
    }

    private function fallbackKeywordFromPage(array $audit): string
    {
        $title = trim((string) ($audit['metrics']['page']['title']['text'] ?? ''));
        if ($title !== '') {
            return strtolower($title);
        }

        $host = strtolower((string) ($audit['target']['host'] ?? ''));
        $host = preg_replace('/^www\./', '', $host);
        $host = preg_replace('/\.[a-z]{2,}$/', '', (string) $host);
        $host = str_replace(['-', '_'], ' ', (string) $host);

        return trim((string) $host) !== '' ? trim((string) $host) : 'core topic';
    }

    private function roundToNearestHundred(int $value): int
    {
        return max(300, (int) (round($value / 100) * 100));
    }

    private function normalizeUrl(string $inputUrl): string
    {
        $normalized = trim($inputUrl);
        if ($normalized === '') {
            throw new InvalidArgumentException('Please enter a URL to audit.');
        }

        if (!preg_match('#^https?://#i', $normalized)) {
            $normalized = 'https://' . $normalized;
        }

        if (!filter_var($normalized, FILTER_VALIDATE_URL)) {
            throw new InvalidArgumentException('The URL format is invalid. Please enter a full website or page URL.');
        }

        $parts = parse_url($normalized);
        if (!$parts || empty($parts['host']) || !in_array(strtolower((string) ($parts['scheme'] ?? '')), ['http', 'https'], true)) {
            throw new InvalidArgumentException('Only HTTP and HTTPS URLs can be audited.');
        }

        return $normalized;
    }

    private function normalizeCompetitorUrls(string $input, string $targetUrl): array
    {
        $urls = preg_split('/[\r\n,]+/', $input) ?: [];
        $normalized = [];
        $targetHost = preg_replace('#^www\.#', '', strtolower((string) (parse_url($targetUrl, PHP_URL_HOST) ?: '')));

        foreach ($urls as $candidate) {
            $candidate = trim($candidate);
            if ($candidate === '') {
                continue;
            }

            if (!preg_match('#^https?://#i', $candidate)) {
                $candidate = 'https://' . $candidate;
            }

            if (!filter_var($candidate, FILTER_VALIDATE_URL)) {
                continue;
            }

            $host = preg_replace('#^www\.#', '', strtolower((string) (parse_url($candidate, PHP_URL_HOST) ?: '')));
            if ($host === '' || $host === $targetHost) {
                continue;
            }

            $normalized[] = $candidate;
        }

        return array_values(array_slice(array_unique($normalized), 0, 3));
    }

    private function issue(string $severity, string $category, string $title, string $details, string $recommendation, string $evidence, int $penalty): array
    {
        return [
            'severity' => $severity,
            'category' => $category,
            'title' => $title,
            'details' => $details,
            'recommendation' => $recommendation,
            'evidence' => $evidence,
            'penalty' => $penalty,
        ];
    }

    private function metaContent(DOMXPath $xpath, string $name): string
    {
        return $this->normalizeWhitespace((string) $xpath->evaluate(
            'string(//meta[translate(@name, "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz") = "' . strtolower($name) . '"][1]/@content)'
        ));
    }

    private function metaProperty(DOMXPath $xpath, string $property): string
    {
        return $this->normalizeWhitespace((string) $xpath->evaluate(
            'string(//meta[translate(@property, "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz") = "' . strtolower($property) . '"][1]/@content)'
        ));
    }

    private function metaByNameOrProperty(DOMXPath $xpath, string $key): string
    {
        $content = $this->metaContent($xpath, $key);
        if ($content !== '') {
            return $content;
        }

        return $this->metaProperty($xpath, $key);
    }

    private function linkHref(DOMXPath $xpath, string $rel): string
    {
        $query = 'string(//link[contains(concat(" ", translate(normalize-space(@rel), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), " "), " ' . strtolower($rel) . ' ")][1]/@href)';
        return trim((string) $xpath->evaluate($query));
    }

    private function hasIconLink(DOMXPath $xpath): bool
    {
        return (bool) $xpath->evaluate('count(//link[contains(translate(@rel, "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "icon")]) > 0');
    }

    private function nodeTexts(?DOMNodeList $nodes): array
    {
        if ($nodes === null) {
            return [];
        }

        $texts = [];
        foreach ($nodes as $node) {
            $value = $this->normalizeWhitespace($node->textContent ?? '');
            if ($value !== '') {
                $texts[] = $value;
            }
        }

        return array_values(array_unique($texts));
    }

    private function plainTextFromHtml(string $html): string
    {
        $text = preg_replace('#<(script|style|noscript|svg)[^>]*>.*?</\1>#is', ' ', $html);
        $text = html_entity_decode(strip_tags((string) $text), ENT_QUOTES | ENT_HTML5, 'UTF-8');

        return $this->normalizeWhitespace($text);
    }

    private function countWords(string $text): int
    {
        if ($text === '') {
            return 0;
        }

        $parts = preg_split('/\s+/u', $text) ?: [];
        $parts = array_filter($parts, static fn(string $part): bool => $part !== '');

        return count($parts);
    }

    private function textLength(string $text): int
    {
        return function_exists('mb_strlen') ? mb_strlen($text) : strlen($text);
    }

    private function textExcerpt(string $text, int $limit): string
    {
        if ($this->textLength($text) <= $limit) {
            return $text;
        }

        return rtrim(function_exists('mb_substr') ? mb_substr($text, 0, $limit) : substr($text, 0, $limit)) . '...';
    }

    private function extractStructuredDataTypes(array $scripts): array
    {
        $types = [];

        foreach ($scripts as $script) {
            $decoded = json_decode($script, true);
            if ($decoded === null) {
                continue;
            }

            $this->walkStructuredData($decoded, $types);
        }

        $types = array_values(array_unique(array_filter($types, static fn(string $value): bool => $value !== '')));
        sort($types);

        return array_slice($types, 0, 12);
    }

    private function walkStructuredData(mixed $node, array &$types): void
    {
        if (is_array($node)) {
            if (isset($node['@type'])) {
                if (is_array($node['@type'])) {
                    foreach ($node['@type'] as $item) {
                        $types[] = trim((string) $item);
                    }
                } else {
                    $types[] = trim((string) $node['@type']);
                }
            }

            foreach ($node as $value) {
                $this->walkStructuredData($value, $types);
            }
        }
    }

    private function resolveUrl(string $href, string $baseUrl): ?string
    {
        $href = trim($href);
        if ($href === '' || str_starts_with($href, '#')) {
            return null;
        }

        $scheme = strtolower((string) (parse_url($href, PHP_URL_SCHEME) ?: ''));
        if (in_array($scheme, ['mailto', 'tel', 'javascript', 'data'], true)) {
            return null;
        }

        if (preg_match('#^https?://#i', $href)) {
            return $href;
        }

        $base = parse_url($baseUrl);
        if (!$base || empty($base['scheme']) || empty($base['host'])) {
            return null;
        }

        $origin = $base['scheme'] . '://' . $base['host'] . (isset($base['port']) ? ':' . $base['port'] : '');
        if (str_starts_with($href, '//')) {
            return $base['scheme'] . ':' . $href;
        }

        if (str_starts_with($href, '/')) {
            return $origin . $href;
        }

        $path = $base['path'] ?? '/';
        $directory = preg_replace('#/[^/]*$#', '/', $path) ?: '/';
        $combined = $directory . $href;

        $pathPart = $combined;
        $query = '';
        if (str_contains($combined, '?')) {
            [$pathPart, $query] = explode('?', $combined, 2);
            $query = '?' . $query;
        }

        $segments = [];
        foreach (explode('/', $pathPart) as $segment) {
            if ($segment === '' || $segment === '.') {
                continue;
            }
            if ($segment === '..') {
                array_pop($segments);
                continue;
            }
            $segments[] = $segment;
        }

        return $origin . '/' . implode('/', $segments) . $query;
    }

    private function isInternalUrl(string $url, string $host): bool
    {
        $targetHost = strtolower((string) (parse_url($url, PHP_URL_HOST) ?: ''));
        $normalizedTarget = preg_replace('#^www\.#', '', $targetHost);
        $normalizedHost = preg_replace('#^www\.#', '', strtolower($host));

        return $normalizedTarget === $normalizedHost;
    }

    private function siteRoot(string $url): string
    {
        $parts = parse_url($url);
        if (!$parts || empty($parts['scheme']) || empty($parts['host'])) {
            return rtrim($url, '/');
        }

        $root = $parts['scheme'] . '://' . $parts['host'];
        if (isset($parts['port'])) {
            $root .= ':' . $parts['port'];
        }

        return $root;
    }

    private function prepareCrawlCandidate(string $url, string $host): ?string
    {
        $normalized = $this->normalizeCrawlUrl($url);
        if ($normalized === '') {
            return null;
        }

        $candidateHost = strtolower((string) (parse_url($normalized, PHP_URL_HOST) ?: ''));
        $normalizedCandidateHost = preg_replace('#^www\.#', '', $candidateHost);
        $normalizedHost = preg_replace('#^www\.#', '', strtolower($host));

        if ($normalizedCandidateHost === '' || $normalizedCandidateHost !== $normalizedHost) {
            return null;
        }

        $path = strtolower((string) (parse_url($normalized, PHP_URL_PATH) ?: '/'));
        if (preg_match('/\.(?:jpg|jpeg|png|gif|svg|webp|pdf|zip|xml|json|js|css|mp4|mp3|woff2?)$/', $path) === 1) {
            return null;
        }

        return $normalized;
    }

    private function normalizeCrawlUrl(string $url): string
    {
        $url = preg_replace('/#.*$/', '', trim($url));
        if ($url === '') {
            return '';
        }

        $parts = parse_url($url);
        if (!$parts || empty($parts['scheme']) || empty($parts['host'])) {
            return '';
        }

        $path = $parts['path'] ?? '/';
        if ($path === '') {
            $path = '/';
        }

        $path = preg_replace('#/{2,}#', '/', $path);
        if ($path !== '/' && str_ends_with($path, '/')) {
            $path = rtrim($path, '/');
        }

        $normalized = strtolower((string) $parts['scheme']) . '://' . strtolower((string) $parts['host']);
        if (isset($parts['port'])) {
            $normalized .= ':' . (int) $parts['port'];
        }
        $normalized .= $path;

        return $normalized;
    }

    private function extractSitemapCandidates(string $siteRoot, string $robotsContent): array
    {
        $candidates = [];
        foreach (preg_split('/\r\n|\r|\n/', $robotsContent) ?: [] as $line) {
            if (preg_match('/^\s*sitemap\s*:\s*(.+)$/i', $line, $matches)) {
                $candidate = trim($matches[1]);
                if ($candidate !== '') {
                    $candidates[] = $candidate;
                }
            }
        }

        $candidates[] = $siteRoot . '/sitemap.xml';
        $candidates[] = $siteRoot . '/sitemap_index.xml';

        return array_values(array_unique($candidates));
    }

    private function containsNoindex(string $value): bool
    {
        return str_contains(strtolower($value), 'noindex');
    }

    private function headerValue(array $headers, string $name): string
    {
        $value = $headers[strtolower($name)] ?? '';
        if (is_array($value)) {
            return implode(', ', array_map('strval', $value));
        }

        return (string) $value;
    }

    private function normalizeWhitespace(string $value): string
    {
        $value = preg_replace('/\s+/u', ' ', $value);

        return trim((string) $value);
    }

    private function gradeForScore(int $score): string
    {
        return match (true) {
            $score >= 90 => 'A',
            $score >= 80 => 'B',
            $score >= 70 => 'C',
            $score >= 60 => 'D',
            default => 'F',
        };
    }

    private function classifyLinkBucket(string $url, string $anchorText): string
    {
        $haystack = strtolower($url . ' ' . $anchorText);

        return match (true) {
            preg_match('/checkout|payment|billing|order-now/', $haystack) === 1 => 'checkout',
            preg_match('/cart|bag|basket/', $haystack) === 1 => 'cart',
            preg_match('/product|shop|store|buy|item|catalog|collection/', $haystack) === 1 => 'product',
            preg_match('/pricing|plans?|quote|cost/', $haystack) === 1 => 'pricing',
            preg_match('/contact|demo|sales|consult/', $haystack) === 1 => 'contact',
            preg_match('/faq|help|support|knowledge|docs?/', $haystack) === 1 => 'faq',
            preg_match('/blog|article|guide|resource/', $haystack) === 1 => 'blog',
            default => 'other',
        };
    }

    private function pathMatchesBucket(string $path, string $bucket): bool
    {
        return match ($bucket) {
            'product' => preg_match('/product|shop|store|item|collection/', $path) === 1,
            'cart' => preg_match('/cart|bag|basket/', $path) === 1,
            'checkout' => preg_match('/checkout|payment|billing/', $path) === 1,
            'pricing' => preg_match('/pricing|plan/', $path) === 1,
            'contact' => preg_match('/contact|demo|sales|quote/', $path) === 1,
            'faq' => preg_match('/faq|help|support|knowledge|docs?/', $path) === 1,
            default => false,
        };
    }

    private function buildSupportingCandidates(string $siteRoot, array $internalDetails): array
    {
        $grouped = [
            'product' => [],
            'cart' => [],
            'checkout' => [],
            'pricing' => [],
            'contact' => [],
            'faq' => [],
        ];

        foreach ($internalDetails as $detail) {
            $bucket = $detail['bucket'] ?? 'other';
            if (!array_key_exists($bucket, $grouped)) {
                continue;
            }

            $grouped[$bucket][] = $detail['url'];
        }

        $guesses = [
            'product' => [$siteRoot . '/shop', $siteRoot . '/products', $siteRoot . '/store'],
            'cart' => [$siteRoot . '/cart'],
            'checkout' => [$siteRoot . '/checkout'],
            'pricing' => [$siteRoot . '/pricing', $siteRoot . '/plans'],
            'contact' => [$siteRoot . '/contact', $siteRoot . '/demo', $siteRoot . '/contact-us'],
            'faq' => [$siteRoot . '/faq', $siteRoot . '/help', $siteRoot . '/support'],
        ];

        foreach ($grouped as $bucket => $urls) {
            $grouped[$bucket] = array_values(array_unique(array_merge($urls, $guesses[$bucket])));
        }

        return $grouped;
    }

    private function detectTracking(string $html, array $scriptSources): array
    {
        $haystack = strtolower($html . ' ' . implode(' ', $scriptSources));
        $tools = [];

        if (str_contains($haystack, 'googletagmanager.com/gtm.js') || preg_match('/gtm-[a-z0-9]+/i', $html)) {
            $tools[] = 'Google Tag Manager';
        }
        if (str_contains($haystack, 'gtag/js?id=g-') || preg_match('/\bg-[a-z0-9]+\b/i', $html)) {
            $tools[] = 'Google Analytics 4';
        }
        if (str_contains($haystack, 'analytics.js') || preg_match('/\bua-\d+-\d+\b/i', $html)) {
            $tools[] = 'Universal Analytics';
        }
        if (preg_match('/\baw-\d+\b/i', $html) || str_contains($haystack, 'googleadservices.com')) {
            $tools[] = 'Google Ads';
        }
        if (str_contains($haystack, 'fbevents.js') || str_contains($haystack, 'fbq(')) {
            $tools[] = 'Meta Pixel';
        }
        if (str_contains($haystack, 'clarity.ms/tag')) {
            $tools[] = 'Microsoft Clarity';
        }
        if (str_contains($haystack, 'analytics.track(') || str_contains($haystack, 'segment.com')) {
            $tools[] = 'Segment';
        }

        $events = [];
        $events = array_merge($events, $this->extractEventNames('/gtag\(\s*[\'"]event[\'"]\s*,\s*[\'"]([^\'"]+)[\'"]/i', $html));
        $events = array_merge($events, $this->extractEventNames('/fbq\(\s*[\'"](?:track|trackCustom)[\'"]\s*,\s*[\'"]([^\'"]+)[\'"]/i', $html));
        $events = array_merge($events, $this->extractEventNames('/analytics\.track\(\s*[\'"]([^\'"]+)[\'"]/i', $html));
        $events = array_merge($events, $this->extractEventNames('/event\s*:\s*[\'"]([^\'"]+)[\'"]/i', $html));
        $events = array_values(array_unique(array_filter(array_map([$this, 'normalizeEventName'], $events))));

        $conversionEvents = array_values(array_filter($events, function (string $event): bool {
            return in_array($event, ['generate_lead', 'purchase', 'begin_checkout', 'chatbot_lead', 'submit_application'], true);
        }));

        return [
            'tools' => array_values(array_unique($tools)),
            'events' => $events,
            'conversion_events' => $conversionEvents,
            'data_layer_present' => str_contains($haystack, 'datalayer'),
        ];
    }

    private function extractEventNames(string $pattern, string $html): array
    {
        preg_match_all($pattern, $html, $matches);

        return $matches[1] ?? [];
    }

    private function normalizeEventName(string $event): string
    {
        $normalized = strtolower(trim($event));
        $normalized = preg_replace('/[^a-z0-9]+/', '_', $normalized);
        $normalized = trim((string) $normalized, '_');

        return match (true) {
            str_contains($normalized, 'view_item') => 'view_item',
            str_contains($normalized, 'add_to_cart') || str_contains($normalized, 'cart_add') => 'add_to_cart',
            str_contains($normalized, 'begin_checkout') || str_contains($normalized, 'checkout_start') => 'begin_checkout',
            str_contains($normalized, 'purchase') || str_contains($normalized, 'order_complete') => 'purchase',
            str_contains($normalized, 'lead') || str_contains($normalized, 'form_submit') || str_contains($normalized, 'contact_submit') => 'generate_lead',
            str_contains($normalized, 'chat_start') || str_contains($normalized, 'start_chat') => 'chat_start',
            str_contains($normalized, 'chatbot_lead') || str_contains($normalized, 'chat_qualified') => 'chatbot_lead',
            default => $normalized,
        };
    }

    private function detectCommerce(string $html, string $plainText, array $buttons, array $internalDetails, array $structuredTypes, DOMXPath $xpath): array
    {
        $lowerText = strtolower($plainText . ' ' . implode(' ', $buttons));
        $priceSamples = $this->extractPriceSamples($html);
        $cartLinks = 0;
        $checkoutLinks = 0;

        foreach ($internalDetails as $detail) {
            if (($detail['bucket'] ?? '') === 'cart') {
                $cartLinks++;
            }
            if (($detail['bucket'] ?? '') === 'checkout') {
                $checkoutLinks++;
            }
        }

        $hasAddToCart = false;
        foreach ($buttons as $button) {
            $buttonText = strtolower($button);
            if (preg_match('/add to cart|buy now|purchase|subscribe now|book now/', $buttonText)) {
                $hasAddToCart = true;
                break;
            }
        }

        $compareAt = (bool) $xpath->evaluate('count(//del|//s|//*[contains(translate(@class, "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"), "compare")]) > 0');

        return [
            'is_product_like' => in_array('Product', $structuredTypes, true) || $hasAddToCart || count($priceSamples) > 0,
            'product_schema' => in_array('Product', $structuredTypes, true),
            'has_add_to_cart' => $hasAddToCart,
            'price_samples' => $priceSamples,
            'price_count' => count($priceSamples),
            'cart_links' => $cartLinks,
            'checkout_links' => $checkoutLinks,
            'review_mentions' => preg_match('/review|rating|testimonial|stars?/', $lowerText) === 1,
            'trust_mentions' => preg_match('/secure checkout|trusted|money back|guarantee|encrypted|ssl/', $lowerText) === 1,
            'shipping_mentions' => preg_match('/shipping|delivery|dispatch/', $lowerText) === 1,
            'return_mentions' => preg_match('/return|refund|exchange/', $lowerText) === 1,
            'guest_checkout_mentions' => preg_match('/guest checkout|checkout as guest|continue as guest/', $lowerText) === 1,
            'coupon_mentions' => preg_match('/coupon|promo code|discount code/', $lowerText) === 1,
            'compare_at_price' => $compareAt || preg_match('/\bwas\s*(?:₹|rs\.?|inr|\$|€|£)/i', $html) === 1,
            'discount_mentions' => preg_match('/% off|save \d+|discount|sale/', $lowerText) === 1,
            'bundle_mentions' => preg_match('/bundle|kit|pack of|starter pack/', $lowerText) === 1,
        ];
    }

    private function detectChatbot(string $html, string $plainText, array $scriptSources, array $buttons, array $internalDetails, array $forms, array $contact): array
    {
        $haystack = strtolower($html . ' ' . implode(' ', $scriptSources));
        $vendors = [];
        $vendorPatterns = [
            'Intercom' => 'intercom',
            'Drift' => 'drift',
            'Tidio' => 'tidio',
            'Crisp' => 'crisp',
            'HubSpot Chat' => 'hubspot',
            'Zendesk Chat' => 'zendesk',
            'Tawk.to' => 'tawk',
            'LiveChat' => 'livechat',
            'Botpress' => 'botpress',
            'Freshchat' => 'freshchat',
        ];
        foreach ($vendorPatterns as $label => $pattern) {
            if (str_contains($haystack, strtolower($pattern))) {
                $vendors[] = $label;
            }
        }

        $leadCaptureCtas = [];
        foreach ($buttons as $button) {
            $buttonText = strtolower($button);
            if (preg_match('/demo|quote|free trial|contact sales|talk to expert|book call|chat now|whatsapp|request/i', $buttonText)) {
                $leadCaptureCtas[] = $button;
            }
        }

        $intentMap = [
            'pricing' => '/pricing|plans?|cost/',
            'demo' => '/demo|book call|schedule/',
            'contact sales' => '/contact|sales|quote|talk to/',
            'support' => '/support|help|customer service|faq/',
            'implementation' => '/implementation|onboarding|setup/',
            'shipping' => '/shipping|delivery/',
            'returns' => '/return|refund|exchange/',
            'order tracking' => '/track order|order status|tracking/',
            'product help' => '/product|feature|how it works/',
            'payment' => '/payment|billing|invoice/',
        ];

        $intentHaystack = strtolower($plainText . ' ' . implode(' ', array_map(static fn(array $detail): string => ($detail['anchor'] ?? '') . ' ' . ($detail['url'] ?? ''), $internalDetails)));
        $detectedIntents = [];
        foreach ($intentMap as $label => $pattern) {
            if (preg_match($pattern, $intentHaystack) === 1) {
                $detectedIntents[] = $label;
            }
        }

        $knowledgeBaseSignals = false;
        foreach ($internalDetails as $detail) {
            if (in_array($detail['bucket'] ?? '', ['faq', 'blog'], true)) {
                $knowledgeBaseSignals = true;
                break;
            }
        }

        $visibleChatSignals = preg_match('/live chat|chat with us|start chat|chat now|message us|virtual assistant|support bot/i', $plainText . ' ' . implode(' ', $buttons)) === 1;

        return [
            'detected' => $vendors !== [] || $visibleChatSignals,
            'vendors' => array_values(array_unique($vendors)),
            'lead_capture_ctas' => array_values(array_unique($leadCaptureCtas)),
            'detected_intents' => $detectedIntents,
            'knowledge_base_signals' => $knowledgeBaseSignals || str_contains(strtolower($plainText), 'faq'),
            'human_handoff' => $contact['emails'] !== [] || $contact['phones'] !== [] || (bool) ($contact['whatsapp'] ?? false) || (int) ($forms['lead_forms'] ?? 0) > 0,
        ];
    }

    private function extractPriceSamples(string $html): array
    {
        preg_match_all('/(?:₹|rs\.?|inr|\$|€|£)\s?\d[\d,]*(?:\.\d{2})?/iu', $html, $matches);
        $prices = array_map(static fn(string $value): string => trim($value), $matches[0] ?? []);
        $prices = array_values(array_unique($prices));

        return array_slice($prices, 0, 6);
    }

    private function pricesUsePsychologicalEnds(array $prices): bool
    {
        foreach ($prices as $price) {
            if (preg_match('/(?:\.99|\.95|99)$/', $price) === 1) {
                return true;
            }
        }

        return false;
    }

    private function extractKeywords(string $text, int $limit = 12): array
    {
        $stopWords = [
            'about', 'after', 'again', 'also', 'and', 'are', 'been', 'before', 'best', 'between', 'both',
            'but', 'can', 'could', 'each', 'for', 'from', 'have', 'into', 'just', 'more', 'most', 'only',
            'over', 'page', 'that', 'their', 'them', 'then', 'there', 'these', 'they', 'this', 'those',
            'under', 'very', 'what', 'when', 'where', 'which', 'with', 'your', 'you', 'our', 'ours',
            'the', 'www', 'http', 'https', 'com', 'html', 'home', 'site', 'page', 'feature', 'features',
        ];

        $tokens = preg_split('/[^a-z0-9]+/i', strtolower($text)) ?: [];
        $counts = [];
        foreach ($tokens as $token) {
            if ($token === '' || strlen($token) < 3 || in_array($token, $stopWords, true) || ctype_digit($token)) {
                continue;
            }
            $counts[$token] = ($counts[$token] ?? 0) + 1;
        }

        arsort($counts);

        return array_slice(array_keys($counts), 0, $limit);
    }

    private function keywordOverlapPercent(array $targetKeywords, array $competitorKeywords): int
    {
        if ($targetKeywords === []) {
            return 0;
        }

        $overlap = array_intersect($targetKeywords, $competitorKeywords);

        return (int) round((count($overlap) / count($targetKeywords)) * 100);
    }

    private function authorityProxyScore(array $document): int
    {
        $score = 0;
        $titleLength = (int) ($document['page']['title']['length'] ?? 0);
        $descriptionText = (string) ($document['page']['description']['text'] ?? '');
        $wordCount = (int) ($document['content']['word_count'] ?? 0);
        $h2Count = count($document['page']['h2'] ?? []);
        $schemaCount = (int) ($document['enhancements']['structured_data_count'] ?? 0);
        $reviewMentions = (bool) ($document['commerce']['review_mentions'] ?? false);
        $trustMentions = (bool) ($document['commerce']['trust_mentions'] ?? false);
        $externalDomains = count($document['links']['external_domains'] ?? []);
        $contactSignals = count($document['contact']['emails'] ?? []) + count($document['contact']['phones'] ?? []);

        if ($titleLength >= 30 && $titleLength <= 60) {
            $score += 8;
        }
        if ($descriptionText !== '') {
            $score += 6;
        }
        if ($wordCount >= 600) {
            $score += 18;
        } elseif ($wordCount >= 300) {
            $score += 10;
        } elseif ($wordCount >= 150) {
            $score += 5;
        }
        if ($h2Count >= 4) {
            $score += 10;
        } elseif ($h2Count >= 2) {
            $score += 5;
        }
        if ($schemaCount > 0) {
            $score += 12;
        }
        if ($reviewMentions) {
            $score += 10;
        }
        if ($trustMentions) {
            $score += 8;
        }
        if ($externalDomains >= 4) {
            $score += 8;
        } elseif ($externalDomains >= 1) {
            $score += 4;
        }
        if ($contactSignals > 0 || (bool) ($document['contact']['whatsapp'] ?? false)) {
            $score += 6;
        }
        if ((bool) ($document['chatbot']['knowledge_base_signals'] ?? false)) {
            $score += 6;
        }

        return min(100, $score);
    }

    private function documentSet(array $document, array $supportingPages): array
    {
        $set = ['main' => $document];
        foreach ($supportingPages as $bucket => $page) {
            if (($page['found'] ?? false) && isset($page['metrics']) && is_array($page['metrics'])) {
                $set[$bucket] = $page['metrics'];
            }
        }

        return $set;
    }

    private function modulePageRefs(array $supportingPages): array
    {
        $refs = [];
        foreach (['product', 'cart', 'checkout', 'pricing', 'contact', 'faq'] as $bucket) {
            $refs[$bucket] = [
                'found' => (bool) ($supportingPages[$bucket]['found'] ?? false),
                'url' => (string) ($supportingPages[$bucket]['url'] ?? ''),
                'status' => (int) ($supportingPages[$bucket]['status'] ?? 0),
            ];
        }

        return $refs;
    }

    private function intentCovered(string $expectedIntent, array $knownIntents): bool
    {
        foreach ($knownIntents as $knownIntent) {
            if ($knownIntent === $expectedIntent) {
                return true;
            }
        }

        return false;
    }

    private function bucketLooksRelevant(string $bucket, array $metrics): bool
    {
        $haystack = strtolower(implode(' ', array_filter([
            (string) ($metrics['page']['title']['text'] ?? ''),
            implode(' ', $metrics['page']['h1'] ?? []),
            implode(' ', $metrics['page']['h2'] ?? []),
            (string) ($metrics['content']['text_excerpt'] ?? ''),
        ])));

        return match ($bucket) {
            'product' => (bool) ($metrics['commerce']['is_product_like'] ?? false),
            'cart' => preg_match('/cart|bag|basket/', $haystack) === 1,
            'checkout' => preg_match('/checkout|payment|billing|guest checkout/', $haystack) === 1,
            'pricing' => preg_match('/pricing|plan|cost|quote/', $haystack) === 1,
            'contact' => preg_match('/contact|sales|demo|quote|book call/', $haystack) === 1
                || (int) ($metrics['forms']['lead_forms'] ?? 0) > 0
                || count($metrics['contact']['emails'] ?? []) > 0
                || count($metrics['contact']['phones'] ?? []) > 0,
            'faq' => preg_match('/faq|help|support|knowledge/', $haystack) === 1
                || (bool) ($metrics['chatbot']['knowledge_base_signals'] ?? false),
            default => false,
        };
    }
}
