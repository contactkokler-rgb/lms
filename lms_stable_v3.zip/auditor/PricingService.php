<?php
/**
 * PricingService — Plan management, subscriptions, usage tracking
 */
class PricingService {

    /**
     * Get all active plans
     */
    public static function getAllPlans() {
        return db_fetch_all(
            'SELECT * FROM pricing_plans WHERE is_active = 1 ORDER BY price_monthly ASC'
        );
    }

    /**
     * Get plan by ID
     */
    public static function getPlan($plan_id) {
        return db_fetch(
            'SELECT * FROM pricing_plans WHERE id = ? AND is_active = 1',
            'i', $plan_id
        );
    }

    /**
     * Get plan by slug
     */
    public static function getPlanBySlug($slug) {
        return db_fetch(
            'SELECT * FROM pricing_plans WHERE slug = ? AND is_active = 1',
            's', $slug
        );
    }

    /**
     * Get account subscription with plan details
     */
    public static function getAccountSubscription($account_id) {
        return db_fetch(
            'SELECT s.*, p.* FROM account_subscriptions s
             JOIN pricing_plans p ON s.plan_id = p.id
             WHERE s.account_id = ?',
            'i', $account_id
        );
    }

    /**
     * Create subscription (trial or active)
     */
    public static function createSubscription($account_id, $plan_id, $is_trial = true) {
        $plan = self::getPlan($plan_id);
        if (!$plan) return false;

        $now = date('Y-m-d H:i:s');
        $trial_ends_at = $is_trial ? date('Y-m-d H:i:s', strtotime('+' . $plan['trial_days'] . ' days')) : null;

        $stmt = db()->prepare(
            'INSERT INTO account_subscriptions
             (account_id, plan_id, status, trial_started_at, trial_ends_at, subscription_started_at)
             VALUES (?, ?, ?, ?, ?, ?)'
        );

        $status = $is_trial ? 'trial' : 'active';
        $started = $is_trial ? $now : null;

        $stmt->bind_param('iissss', $account_id, $plan_id, $status, $now, $trial_ends_at, $started);
        return $stmt->execute();
    }

    /**
     * Upgrade/change plan
     */
    public static function changePlan($account_id, $new_plan_id) {
        return db()->query(
            "UPDATE account_subscriptions SET plan_id = $new_plan_id, updated_at = NOW()
             WHERE account_id = $account_id"
        );
    }

    /**
     * Check if account trial is still active
     */
    public static function isTrialActive($account_id) {
        $sub = db_fetch(
            'SELECT status, trial_ends_at FROM account_subscriptions WHERE account_id = ?',
            'i', $account_id
        );

        return $sub && $sub['status'] === 'trial' && strtotime($sub['trial_ends_at']) > time();
    }

    /**
     * Check if subscription is active (trial or paid)
     */
    public static function isSubscriptionActive($account_id) {
        $sub = db_fetch(
            'SELECT status, trial_ends_at, subscription_ends_at FROM account_subscriptions WHERE account_id = ?',
            'i', $account_id
        );

        if (!$sub) return false;

        if ($sub['status'] === 'trial') {
            return strtotime($sub['trial_ends_at']) > time();
        }

        if ($sub['status'] === 'active') {
            return strtotime($sub['subscription_ends_at']) > time();
        }

        return false;
    }

    /**
     * Get current usage for account in current month
     */
    public static function getCurrentUsage($account_id) {
        $billing_month = date('Y-m');
        return db_fetch(
            'SELECT * FROM usage_tracking WHERE account_id = ? AND billing_month = ?',
            'is', $account_id, $billing_month
        ) ?? [
            'domains_used' => 0,
            'forms_created' => 0,
            'leads_count' => 0,
            'team_members_added' => 0
        ];
    }

    /**
     * Increment usage counters
     */
    public static function trackUsage($account_id, $type, $quantity = 1) {
        $billing_month = date('Y-m');
        $field_map = [
            'domain' => 'domains_used',
            'form' => 'forms_created',
            'lead' => 'leads_count',
            'team_member' => 'team_members_added'
        ];

        if (!isset($field_map[$type])) return false;

        $field = $field_map[$type];

        $stmt = db()->prepare(
            "INSERT INTO usage_tracking (account_id, billing_month, $field)
             VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE $field = $field + ?"
        );

        $stmt->bind_param('isii', $account_id, $billing_month, $quantity, $quantity);
        return $stmt->execute();
    }

    /**
     * Check if usage limit exceeded
     */
    public static function checkUsageLimit($account_id, $type) {
        $sub = self::getAccountSubscription($account_id);
        if (!$sub) return true;

        $usage = self::getCurrentUsage($account_id);

        $limits = [
            'domain' => $sub['domains_limit'],
            'form' => $sub['forms_limit'],
            'lead' => $sub['leads_per_month'],
            'team_member' => $sub['team_members_limit']
        ];

        $usage_map = [
            'domain' => $usage['domains_used'],
            'form' => $usage['forms_created'],
            'lead' => $usage['leads_count'],
            'team_member' => $usage['team_members_added']
        ];

        if (!isset($limits[$type]) || !isset($usage_map[$type])) return true;

        return $usage_map[$type] < $limits[$type];
    }

    /**
     * Get plan services
     */
    public static function getPlanServices($plan_id) {
        return db_fetch_all(
            'SELECT s.* FROM services s
             JOIN plan_services ps ON s.id = ps.service_id
             WHERE ps.plan_id = ?',
            'i', $plan_id
        );
    }

    /**
     * Create invoice
     */
    public static function createInvoice($account_id, $plan_id, $amount) {
        $invoice_number = 'INV-' . date('Ym') . '-' . uniqid();
        $billing_date = date('Y-m-d');
        $due_date = date('Y-m-d', strtotime('+30 days'));

        $stmt = db()->prepare(
            'INSERT INTO invoices
             (account_id, invoice_number, plan_id, amount, billing_date, due_date, status)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );

        $status = 'pending';
        $stmt->bind_param('isidsss', $account_id, $invoice_number, $plan_id, $amount, $billing_date, $due_date, $status);
        return $stmt->execute() ? $invoice_number : false;
    }

    /**
     * Mark invoice as paid
     */
    public static function markInvoicePaid($invoice_id, $payment_method_id = null) {
        $stmt = db()->prepare(
            'UPDATE invoices SET status = ?, paid_at = NOW(), payment_method_id = ? WHERE id = ?'
        );

        $status = 'paid';
        $stmt->bind_param('sii', $status, $payment_method_id, $invoice_id);
        return $stmt->execute();
    }

    /**
     * Get invoices for account
     */
    public static function getInvoices($account_id, $limit = 10, $offset = 0) {
        return db_fetch_all(
            'SELECT * FROM invoices WHERE account_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?',
            'iii', $account_id, $limit, $offset
        );
    }

    /**
     * Add payment method
     */
    public static function addPaymentMethod($account_id, $provider, $provider_customer_id, $provider_payment_method_id, $card_data) {
        $stmt = db()->prepare(
            'INSERT INTO payment_methods
             (account_id, provider, provider_customer_id, provider_payment_method_id, card_last_four, card_brand, card_exp_month, card_exp_year)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );

        $stmt->bind_param(
            'isssssii',
            $account_id,
            $provider,
            $provider_customer_id,
            $provider_payment_method_id,
            $card_data['last_four'],
            $card_data['brand'],
            $card_data['exp_month'],
            $card_data['exp_year']
        );

        return $stmt->execute();
    }

    /**
     * Get payment methods for account
     */
    public static function getPaymentMethods($account_id) {
        return db_fetch_all(
            'SELECT * FROM payment_methods WHERE account_id = ? ORDER BY is_default DESC, created_at DESC',
            'i', $account_id
        );
    }

    /**
     * Log billing email
     */
    public static function logBillingEmail($account_id, $email_type, $recipient_email, $reference_id = null) {
        $stmt = db()->prepare(
            'INSERT INTO billing_emails (account_id, email_type, recipient_email, sent_at, reference_id)
             VALUES (?, ?, ?, NOW(), ?)'
        );

        $stmt->bind_param('issi', $account_id, $email_type, $recipient_email, $reference_id);
        return $stmt->execute();
    }

    /**
     * Check if subscription expired
     */
    public static function isSubscriptionExpired($account_id) {
        return !self::isSubscriptionActive($account_id);
    }

    /**
     * Get expiration restrictions based on plan
     */
    public static function getExpirationRestrictions() {
        return [
            'allow_edit' => false,
            'allow_new_campaign' => false,
            'allow_new_domain' => false,
            'allow_new_landing_page' => false,
            'allow_new_form' => false,
            'allow_add_team_member' => false,
            'allow_tools_access' => false,
            'allow_landing_pages_live' => true,
            'allow_forms_collecting' => true
        ];
    }
}
