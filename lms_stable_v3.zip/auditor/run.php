<?php


// Bootstrap LMS (gives us db(), ps(), auth etc.)
require_once __DIR__ . '/../config/auth.php';
$user = require_permission('auditor', 'run');

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success'=>false,'error'=>'POST only']); exit;
}

if (!csrf_verify()) {
    http_response_code(403);
    echo json_encode(['success'=>false,'error'=>'Invalid CSRF token']); exit;
}

set_time_limit(180);

// Autoload auditor classes from this directory
spl_autoload_register(static function (string $class): void {
    $path = __DIR__ . '/' . $class . '.php';
    if (is_file($path)) require $path;
});

// Stub app_config so auditor classes don't break (real config via LMS ps())
if (!function_exists('app_config')) {
    function app_config(?string $key = null, mixed $default = null): mixed { return $default; }
}

$url            = trim((string)($_POST['url']            ?? ''));
$competitorUrls = trim((string)($_POST['competitor_urls']?? ''));
$crawlScope     = trim((string)($_POST['crawl_scope']    ?? 'page'));
$crawlLimit     = (int)($_POST['crawl_limit'] ?? 12);

try {
    $httpClient       = new HttpClient();
    $openRouterClient = new OpenRouterClient($httpClient);
    $auditService     = new SeoAuditService($httpClient, $openRouterClient);

    $data = $auditService->run($url, [
        'competitor_urls' => $competitorUrls,
        'crawl_scope'     => $crawlScope,
        'crawl_limit'     => $crawlLimit,
    ]);

    // Return audit data to front-end — saving is manual via auditor/save.php
    echo json_encode(
        ['success' => true, 'data' => $data],
        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
    );

} catch (InvalidArgumentException $e) {
    http_response_code(422);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}