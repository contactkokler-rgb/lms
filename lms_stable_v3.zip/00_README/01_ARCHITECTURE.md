# LeadPro System Architecture & Data Flow

## 🏗️ High-Level Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                     EXTERNAL USERS                              │
├─────────────────────────────────────────────────────────────────┤
│  Potential Leads  │  Team Members   │  Admins         │ API Users│
│  (fill forms)     │  (manage leads) │  (config)       │(webhooks)│
└──────────┬────────┴────────┬────────┴────────┬────────┴────────┬─┘
           │                 │                 │                  │
           │ HTTP/HTTPS      │                 │                  │
           ▼                 ▼                 ▼                  ▼
┌─────────────────────────────────────────────────────────────────┐
│                   WEB BROWSER / CLIENT                          │
├─────────────────────────────────────────────────────────────────┤
│  HTML + Nova CSS + Vanilla JS                                   │
│  ├─ Modal dialogs (forms, confirmations)                        │
│  ├─ Drag-drop builders (forms, pages)                           │
│  ├─ Real-time charts (reports dashboard)                        │
│  └─ AJAX form submission (no page reload)                       │
└──────────┬────────────────────────────────────────────────────┬─┘
           │ HTTP POST/GET with CSRF token                       │
           │ Session cookie (lp_session)                         │
           ▼                                                      ▼
╔═════════════════════════════════════════════════════════════════╗
║                    PHP WEB APPLICATION                         ║
╠═════════════════════════════════════════════════════════════════╣
║                                                                 ║
║  ┌──────────────────────────────────────────────────────────┐  ║
║  │  ENTRY POINT: Single PHP file per module                │  ║
║  │  ├─ index.php (dashboard)                               │  ║
║  │  ├─ leads.php (lead list)                               │  ║
║  │  ├─ campaigns.php (campaign list)                       │  ║
║  │  ├─ form_builder.php (form designer)                    │  ║
║  │  ├─ login.php (auth)                                    │  ║
║  │  └─ ... 30+ more pages                                  │  ║
║  └──────────────────────────────────────────────────────────┘  ║
║                            │                                    ║
║              ┌─────────────┴─────────────┐                     ║
║              │                           │                     ║
║              ▼                           ▼                     ║
║  ┌─────────────────────┐     ┌─────────────────────┐           ║
║  │ CONFIG LAYER        │     │ MIDDLEWARE CHECKS   │           ║
║  ├─────────────────────┤     ├─────────────────────┤           ║
║  │ • config.php        │     │ • require_auth()    │           ║
║  │ • config.local.php  │     │ • require_permission│           ║
║  │ • auth.php          │     │ • csrf_verify()     │           ║
║  │ • ai.php            │     │ • audit()           │           ║
║  │ • BillingService    │     │ • maintenance check │           ║
║  │ • mailer.php        │     └─────────────────────┘           ║
║  │ • knowledge.php     │                                        ║
║  │ • scoring.php       │                                        ║
║  │ • reminders.php     │                                        ║
║  └─────────────────────┘                                        ║
║              │                                                  ║
║              ▼                                                  ║
║  ┌─────────────────────┐                                        ║
║  │ BUSINESS LOGIC      │                                        ║
║  ├─────────────────────┤                                        ║
║  │ • Lead capture      │                                        ║
║  │ • Campaign mgmt     │                                        ║
║  │ • Form processing   │                                        ║
║  │ • Email automation  │                                        ║
║  │ • AI content gen    │                                        ║
║  │ • Engagement scoring│                                        ║
║  │ • Deduplication     │                                        ║
║  │ • Billing enforcement│                                       ║
║  │ • SEO audits        │                                        ║
║  └─────────────────────┘                                        ║
║              │                                                  ║
║              ▼                                                  ║
║  ┌─────────────────────┐                                        ║
║  │ DATA ACCESS LAYER   │                                        ║
║  ├─────────────────────┤                                        ║
║  │ • db_fetch()        │                                        ║
║  │ • db_fetch_all()    │                                        ║
║  │ • db_insert()       │                                        ║
║  │ • db_query()        │                                        ║
║  │                     │                                        ║
║  │ All use MySQLi      │                                        ║
║  │ with prepared stmts │                                        ║
║  └─────────────────────┘                                        ║
║              │                                                  ║
║              ▼                                                  ║
║  ┌─────────────────────────────────────────────────────────┐  ║
║  │ RESPONSE LAYER                                          │  ║
║  ├─────────────────────────────────────────────────────────┤  ║
║  │ • Render HTML from layouts/header.php                   │  ║
║  │ • Include assets/css/nova.css                           │  ║
║  │ • Send JSON for AJAX (forms, pagination)                │  ║
║  │ • Redirect on success/error                             │  ║
║  └─────────────────────────────────────────────────────────┘  ║
║                                                                 ║
╚═════════════════════════════════════════════════════════════════╝
           │                                                  │
           │ MySQLi prepared statement                        │
           │ (SQL injection prevented)                       │
           │                                                  │
           ▼                                                  ▼
┌──────────────────────────────────────────────────────────────────┐
│              EXTERNAL INTEGRATIONS                              │
├──────────────────────────────────────────────────────────────────┤
│ ┌─────────────┐  ┌─────────────┐  ┌──────────────┐             │
│ │   MySQL DB  │  │ SMTP Server │  │  AI APIs     │             │
│ │             │  │             │  │              │             │
│ │ Stores:     │  │ Sends:      │  │ • Groq       │             │
│ │ • Accounts  │  │ • Lead email│  │ • Gemini     │             │
│ │ • Users     │  │ • Campaigns │  │ • OpenRouter │             │
│ │ • Leads     │  │ • Invoices  │  │              │             │
│ │ • Campaigns │  │             │  │ For:         │             │
│ │ • Forms     │  │ Config from │  │ • Content gen│             │
│ │ • Settings  │  │ admin       │  │ • Variations │             │
│ │ • Audit log │  │ settings.   │  │ • Training   │             │
│ └─────────────┘  └─────────────┘  └──────────────┘             │
│                                                                 │
│ ┌──────────────┐  ┌──────────────┐  ┌──────────────┐           │
│ │  Stripe API  │  │   DNS        │  │   External   │           │
│ │              │  │              │  │   Webhooks   │           │
│ │ For:         │  │ For:         │  │              │           │
│ │ • Payments   │  │ • Domain     │  │ Form submit  │           │
│ │ • Billing    │  │   verify     │  │ on 3rd-party │           │
│ │ • Subscript. │  │ • CNAME setup│  │ sites        │           │
│ └──────────────┘  └──────────────┘  └──────────────┘           │
└──────────────────────────────────────────────────────────────────┘
```

---

## 🔄 Lead Capture Data Flow

```
┌──────────────────────────────────┐
│  Visitor on 3rd-party Website    │
│  Sees embedded form               │
└──────────┬───────────────────────┘
           │ Fills form & clicks Submit
           ▼
┌──────────────────────────────────┐
│  embed/loader.js                 │
│  (loads form dynamically)         │
└──────────┬───────────────────────┘
           │ Submits AJAX to embed/form.php
           ▼
┌──────────────────────────────────┐
│  embed/form.php                  │
│  ├─ Validate CSRF                │
│  ├─ Validate spam (CAPTCHA)      │
│  ├─ Sanitize input               │
│  └─ Save to database             │
└──────────┬───────────────────────┘
           │ Triggers INSERT into 'leads'
           ▼
┌──────────────────────────────────┐
│  LeadPro Database                │
│  ├─ Create lead record           │
│  ├─ Assign reference (LD-*)      │
│  ├─ Link to campaign             │
│  └─ Set initial score            │
└──────────┬───────────────────────┘
           │ 
           ├─→ Email notification sent to team
           │   (via config/mailer.php)
           │
           ├─→ Audit log entry created
           │   (audit_log table)
           │
           ├─→ Engagement score initialized
           │   (scoring.php logic)
           │
           ├─→ Reminder created if high-value
           │   (reminders table)
           │
           └─→ Deduplication check
               (deduplication.php)
               If duplicate found:
               ├─ Merge with existing lead
               └─ Update score if higher

           ▼
┌──────────────────────────────────┐
│  Team Member Dashboard           │
│  Lead appears in:                │
│  ├─ leads.php (list)             │
│  ├─ lead_view.php (detail)       │
│  ├─ Priority inbox (if VIP)      │
│  └─ Reminders (if high score)    │
└──────────────────────────────────┘
```

---

## 🚀 Campaign Workflow Data Flow

```
┌──────────────────────────────────┐
│  Manager creates Campaign        │
│  (campaigns.php)                 │
│  ├─ Name, objective, dates       │
│  ├─ Owner, color                 │
│  └─ Status: draft/active/paused  │
└──────────┬───────────────────────┘
           │ Billing check (plan allows?)
           │ -> BillingService::enforce()
           ▼
┌──────────────────────────────────┐
│  INSERT campaigns table          │
│  ├─ Create audit log entry       │
│  └─ Redirect to campaign_view.php│
└──────────┬───────────────────────┘
           │
           ├──────────────────────────────────┐
           │                                  │
           ▼                                  ▼
┌──────────────────────────┐  ┌──────────────────────────┐
│ Add Campaign Knowledge   │  │ Create Landing Pages     │
│ (campaign_knowledge.php) │  │ (page_builder.php)       │
│                          │  │                          │
│ ├─ Set target audience   │  │ ├─ Drag-drop builder     │
│ ├─ Define tone/style     │  │ ├─ Embed forms           │
│ ├─ Set goals/objectives  │  │ ├─ Add CTA blocks        │
│ └─ Add training data     │  │ ├─ SEO settings          │
│   (for AI)               │  │ └─ Publish               │
└──────────┬───────────────┘  └──────────┬───────────────┘
           │                             │
           │        Stored in DB         │
           │        campaign_knowledge   │
           │        campaign_pages       │
           │                             │
           └──────────────┬──────────────┘
                          │
                          ▼
┌──────────────────────────────────┐
│  Distribute Campaign             │
├──────────────────────────────────┤
│ Option 1: Email to list          │
│ ├─ Compose in email template     │
│ ├─ Add tracking pixels           │
│ └─ Send via SMTP                 │
│                                  │
│ Option 2: Embed forms on site    │
│ ├─ Get embed code                │
│ ├─ Paste on 3rd-party site       │
│ └─ Forms capture leads           │
│                                  │
│ Option 3: Direct landing page    │
│ ├─ Share campaign LP URL         │
│ ├─ Visitors see landing page     │
│ └─ Fill form to become lead      │
└──────────┬───────────────────────┘
           │
           ▼
┌──────────────────────────────────┐
│  Track Campaign Performance      │
│  (reports.php)                   │
├──────────────────────────────────┤
│ ├─ Lead count                    │
│ ├─ Conversion rate               │
│ ├─ Page views                    │
│ ├─ Form submissions              │
│ ├─ Email opens/clicks            │
│ ├─ Engagement score              │
│ └─ Revenue impact                │
└──────────────────────────────────┘
```

---

## 🔐 Authentication & Permission Flow

```
┌──────────────────────────┐
│ User visits /login.php   │
└──────────┬───────────────┘
           │
           ▼
┌──────────────────────────────────┐
│ Redirect check:                  │
│ auth_user() already logged in?   │
│ ├─ Yes → redirect to index.php   │
│ └─ No  → show login form         │
└──────────┬───────────────────────┘
           │
           ▼
┌──────────────────────────────────┐
│ User submits email + password    │
├──────────────────────────────────┤
│ ├─ CSRF token validation         │
│ └─ Proceed if valid              │
└──────────┬───────────────────────┘
           │
           ▼
┌──────────────────────────────────┐
│ login() function:                │
│ ├─ db_fetch() user by email      │
│ ├─ Check status (not suspended)  │
│ ├─ password_verify() against hash│
│ └─ On success:                   │
│    ├─ session_regenerate_id()    │
│    ├─ Set $_SESSION variables    │
│    ├─ Update last_login_at       │
│    └─ Audit log entry            │
└──────────┬───────────────────────┘
           │ Success
           ▼
┌──────────────────────────────────┐
│ Session created:                 │
│ $_SESSION['user_id'] = 123       │
│ $_SESSION['account_id'] = 5      │
│ $_SESSION['role'] = 'manager'    │
│ $_SESSION['csrf_token'] = '...'  │
└──────────┬───────────────────────┘
           │ Redirect to index.php
           ▼
┌──────────────────────────────────┐
│ Any page access:                 │
│                                  │
│ 1. require_auth()                │
│    ├─ Check $_SESSION['user_id'] │
│    ├─ If not → redirect login    │
│    ├─ Fetch user from DB (cache) │
│    └─ Check maintenance mode     │
│                                  │
│ 2. require_permission()          │
│    ├─ Check can($module, $action)│
│    ├─ Super admin? → allow       │
│    ├─ Fetch user permissions     │
│    ├─ Match module.action        │
│    └─ If no → 403 forbidden      │
└──────────┬───────────────────────┘
           │ All checks pass
           ▼
┌──────────────────────────────────┐
│ Load page + render              │
│                                  │
│ ├─ Include layouts/header.php   │
│ ├─ Display user data            │
│ ├─ Include content              │
│ └─ Include layouts/footer.php   │
└──────────────────────────────────┘


Permission Check Detail:
═════════════════════════════════════════

User: John (manager role, account 5)
Action: Create campaign

┌─────────────────────────────────┐
│ can('campaigns', 'create')      │
└─────────────────────────────────┘
        │
        ├─→ Super admin? → YES → return true
        │
        └─→ Not super admin
           │
           ▼
        ┌──────────────────────────┐
        │ Fetch role_permissions   │
        │ WHERE role_id = 2        │
        │ (manager role)           │
        └──────────────────────────┘
           │
           ▼
        ┌──────────────────────────┐
        │ Build permission array   │
        │ perms['campaigns.create']│
        │ perms['campaigns.edit']  │
        │ perms['leads.view']      │
        │ ...                      │
        └──────────────────────────┘
           │
           ▼
        ┌──────────────────────────┐
        │ Check if              │
        │ 'campaigns.create'       │
        │ in perms array?          │
        │ YES → return true        │
        │ NO  → return false       │
        └──────────────────────────┘
```

---

## 💾 Database Relationships (ERD-style)

```
┌─────────────┐         ┌──────────────┐         ┌────────────┐
│  accounts   │◄────────│    users     │────────►│   roles    │
│             │ (1:M)   │              │         │            │
│ id          │         │ id           │         │ id         │
│ name        │         │ account_id   │         │ name       │
│ plan        │         │ role_id      │         │ label      │
│ status      │         │ email        │         │ name       │
│ timezone    │         │ password_hash│         │            │
└─────────────┘         │ status       │         └────────────┘
        │               │ last_login_at│
        │               └──────────────┘
        │                      ▲
        │                      │ (1:M)
        │              ┌───────┴────────┐
        │              │                │
        │     ┌────────────────┐  ┌──────────────┐
        │     │ roles          │  │  permissions │
        │     │                │  │              │
        │     │ (many-to-many) │  │ id           │
        │     │                │  │ module       │
        │     │ role_id        │  │ action       │
        │     │ permission_id  │  └──────────────┘
        │     └────────────────┘
        │
        │
        ├─────────────────┬──────────────────┬──────────────────┐
        │                 │                  │                  │
        ▼                 ▼                  ▼                  ▼
   ┌────────┐       ┌──────────┐      ┌──────────┐        ┌──────────┐
   │ leads  │       │campaigns │      │ domains  │        │   forms  │
   │        │       │          │      │          │        │          │
   │ id     │       │ id       │      │ id       │        │ id       │
   │ email  │       │ name     │      │ domain   │        │ name     │
   │ score  │       │ status   │      │ verified │        │ fields   │
   │ source │       │ owner_id │      │ account_ │        │ status   │
   │ status │       │ account_ │      │ id       │        │ account_ │
   │ account│   ┌───│ id       │      │          │        │ id       │
   │ _id    │   │   │ campaign_│      └──────────┘        │ slug     │
   │ campaign   │   │ knowledge        (1:M)              │ created_ │
   │ _id    │   │   │                                     │ at       │
   └────────┘   │   └──────────┘                          └──────────┘
        │       │        │
        │       │        │
        │ (1:M) │   (1:M) │ ┌─────────────────┐
        │       │        │ │campaign_knowledge│
        │       └────────┼─│                  │
        │                │ │ id               │
        │                │ │ campaign_id      │
        │                │ │ tone             │
        │                │ │ audience         │
        │                │ │ training_data    │
        │                └─┤                  │
        │                  │ ai_knowledge     │
        │                  └─────────────────┘
        │
        └──────────────────────┐
                               │
                               ▼
                        ┌──────────────┐
                        │  audit_log   │
                        │              │
                        │ id           │
                        │ user_id      │
                        │ account_id   │
                        │ action       │
                        │ target       │
                        │ ip_address   │
                        │ created_at   │
                        └──────────────┘


Billing Tables:
┌──────────────┐      ┌────────────┐      ┌───────────────┐
│account_plans │      │pricing_    │      │account_usage  │
│              │      │plans       │      │               │
│ id           │      │            │      │ id            │
│ account_id   │◄─────│ id         │      │ account_id    │
│ plan_id      │      │ name       │      │ billing_month │
│ plan_expires │      │ price      │      │ domains_      │
│ _at          │      │ domains_   │      │ created       │
│              │      │ limit      │      │ forms_created │
│              │      │ forms_limit│      │ leads_count   │
└──────────────┘      │ leads_per_ │      │ team_members_ │
                      │ month      │      │ added         │
                      │ team_      │      └───────────────┘
                      │ members_   │
                      │ limit      │
                      └────────────┘
```

---

## 🔌 External API Integration Flow

### AI Content Generation

```
User requests: "Generate campaign email subject"
        │
        ▼
┌────────────────────────────┐
│ AI Enabled?                │
│ ai_enabled() == true?      │
│ ├─ Master switch ON        │
│ └─ At least 1 API key set  │
└────────────────────┬───────┘
                     │ Yes
                     ▼
┌────────────────────────────┐
│ Get providers (priority):  │
│ 1. Groq (fastest, 14.4k)   │
│ 2. Gemini (250-1k)         │
│ 3. OpenRouter (200)        │
└────────────────────┬───────┘
                     │
                     ▼
┌────────────────────────────┐
│ ai_call_provider():        │
│ ├─ Build request from msg  │
│ ├─ Set max_tokens          │
│ ├─ Include campaign knowledge
│ │  (tone, audience, goals) │
│ └─ Call HTTP API           │
└────────────────────┬───────┘
                     │
        ┌────────────┴────────────┐
        │                         │
        ▼                         ▼
   ┌─────────┐             ┌─────────────┐
   │ Success │             │ Error/Rate  │
   │         │             │ Limited     │
   │ Return: │             │             │
   │ • text  │             │ Retry with  │
   │ • usage │             │ next provider
   │ • model │             └──────┬──────┘
   └────┬────┘                    │
        │                  ┌──────┴────────┐
        │                  │               │
        │         ┌────────▼────┐  ┌───────▼──────┐
        │         │ Try Gemini  │  │ Try OpenRouter
        │         └─────┬──────┘  └───────┬──────┘
        │               │                 │
        └───────────────┼─────────────────┘
                        │
                        ▼
                 ┌──────────────┐
                 │ Return result│
                 │ or fallback  │
                 │ error msg    │
                 └──────────────┘
```

### Email Sending

```
User creates email template & sets trigger
        │
        ▼
┌──────────────────────┐
│ Trigger fires        │
│ (e.g., lead score>50)│
└──────────┬───────────┘
           │
           ▼
┌──────────────────────────┐
│ Load SMTP config from    │
│ admin settings:          │
│ ├─ smtp_host             │
│ ├─ smtp_user             │
│ ├─ smtp_password         │
│ ├─ smtp_port             │
│ └─ from_email            │
└──────────┬───────────────┘
           │
           ▼
┌──────────────────────────┐
│ Compose email:           │
│ ├─ Load template         │
│ ├─ Replace merge tags    │
│ │  ({{lead.first_name}}) │
│ ├─ Add tracking pixel    │
│ ├─ Add unsubscribe link  │
│ └─ Build MIME message    │
└──────────┬───────────────┘
           │
           ▼
┌──────────────────────────┐
│ Send via SMTP:           │
│ (config/mailer.php)      │
│                          │
│ ├─ Connect SMTP          │
│ ├─ Authenticate          │
│ ├─ Send message          │
│ └─ Close connection      │
└──────────┬───────────────┘
           │
        ┌──┴──┐
        │     │
        ▼     ▼
    Success  Failure
        │     │
        ├─────┤
        │
        ▼
┌──────────────────────────┐
│ Log in database:         │
│ ├─ Email sent timestamp  │
│ ├─ Recipient email       │
│ ├─ Subject line          │
│ ├─ Send status           │
│ └─ Error msg (if failed) │
└──────────┬───────────────┘
           │
           ▼
┌──────────────────────────┐
│ Track opens & clicks:    │
│ ├─ Tracking pixel fires  │
│ │  when email opened     │
│ ├─ Link rewrites for     │
│ │  click tracking        │
│ └─ Updates lead score    │
└──────────────────────────┘
```

---

## 🧮 Engagement Scoring Algorithm

```
Lead created/modified
        │
        ▼
┌────────────────────────────┐
│ Scoring Engine Runs        │
│ (config/scoring.php)       │
│ config/engagement.php      │
└────────────────────┬───────┘
                     │
          ┌──────────┼──────────┐
          │          │          │
          ▼          ▼          ▼
    ┌────────┐  ┌────────┐  ┌────────┐
    │Time on │  │Email   │  │Landing │
    │Landing │  │Metrics │  │Page    │
    │Page    │  │        │  │Actions │
    └────┬───┘  └───┬────┘  └───┬────┘
         │          │           │
         ▼          ▼           ▼
    ┌─────────────────────────────────┐
    │ Per metric: assign points       │
    │ • < 10 sec:    0 points         │
    │ • 10-30 sec:   5 points         │
    │ • 30-60 sec:  10 points         │
    │ • > 60 sec:   15 points         │
    │                                 │
    │ • Email open:  3 points         │
    │ • Link click:  5 points         │
    │ • Form submit: 20 points        │
    │                                 │
    │ • Page visit:  2 points         │
    │ • Repeat visit: 3 points        │
    └────────────┬────────────────────┘
                 │
                 ▼
    ┌─────────────────────────────────┐
    │ Sum all points for this lead    │
    │                                 │
    │ Total Score = Σ all events      │
    │                                 │
    │ Cap at 100 (max score)          │
    └────────────┬────────────────────┘
                 │
                 ▼
    ┌─────────────────────────────────┐
    │ Score used for:                 │
    │ ├─ Priority inbox ranking       │
    │ ├─ Auto-trigger reminders       │
    │ ├─ Lead status suggestions      │
    │ ├─ Campaign analytics           │
    │ └─ Lead scoring rules           │
    └─────────────────────────────────┘
```

---

## 🔔 Reminder System Flow

```
Lead action occurs (form submit, email open, etc)
        │
        ▼
┌──────────────────────────┐
│ Scoring runs             │
│ Score updates to, say, 75│
└──────────┬───────────────┘
           │
           ▼
┌──────────────────────────┐
│ Check score_rules table: │
│ IF score > 60            │
│ THEN create reminder     │
└──────────┬───────────────┘
           │
           ▼
┌──────────────────────────┐
│ INSERT into reminders:   │
│ ├─ user_id: owner       │
│ ├─ lead_id: this lead   │
│ ├─ type: 'hot_lead'     │
│ ├─ message: "Score: 75" │
│ ├─ due_at: NOW()        │
│ └─ status: 'pending'    │
└──────────┬───────────────┘
           │
           ▼
┌──────────────────────────┐
│ Team member logs in      │
│ (index.php loads)       │
│                          │
│ reminder_get_pending() │
│ fetches 10 pending      │
│ reminders for user      │
└──────────┬───────────────┘
           │
           ▼
┌──────────────────────────┐
│ Display reminders on     │
│ dashboard banner:        │
│ "Hot lead: Contact now" │
│                          │
│ ├─ Snooze (60 min)      │
│ ├─ Mark Done             │
│ └─ View Lead             │
└──────────┬───────────────┘
           │
        ┌──┴──┐
        │     │
        ▼     ▼
    Mark Done Snooze
        │     │
        ▼     ▼
    Update   Update
    reminder_reminder_
    status=  snooze_
    'done'   until=NOW
               +60min

    ▼
┌──────────────────────────┐
│ Next login:              │
│ Snoozed reminders        │
│ hidden until snooze time │
│ expires                  │
└──────────────────────────┘
```

---

## 📊 Billing Usage Tracking Flow

```
User creates new resource
        │
        ├──────────────────────┐
        │                      │
        ▼                      ▼
   ┌─────────────┐        ┌──────────────┐
   │ Create Form │        │ Create Domain│
   └──────┬──────┘        └───────┬──────┘
          │                       │
          ▼                       ▼
    ┌─────────────┐        ┌──────────────────┐
    │ BillingService::    │BillingService::   │
    │checkLimit(         │checkLimit(        │
    │account_id,         │account_id,        │
    │'form')             │'domain')          │
    └──────┬──────┘        └────────┬─────────┘
           │                        │
           ├─ Get plan              ├─ Get plan
           ├─ Get current usage     ├─ Get current usage
           │  (this month)          │  (this month)
           ├─ Check if              ├─ Check if
           │  forms_created <       │  domains_created <
           │  forms_limit           │  domains_limit
           │                        │
           ▼                        ▼
    ┌─────────────┐        ┌──────────────┐
    │ Return: true│        │ Return: true │
    │ (under limit)         │ (under limit)│
    └──────┬──────┘        └────────┬─────┘
           │                        │
           ├────────────┬───────────┤
           │            │           │
           ▼            │           ▼
    Allow creation     │      Allow creation
           │            │           │
           ├────────────┼───────────┤
           │            │           │
           ▼            ▼           ▼
    ┌───────────────────────────────────────────┐
    │ After creation:                           │
    │ BillingService::trackUsage(               │
    │   account_id,                             │
    │   'form'/'domain',                        │
    │   1                                       │
    │ );                                        │
    │                                           │
    │ Increment field in account_usage table    │
    │ billing_month = current month             │
    └───────────┬───────────────────────────────┘
                │
                ▼
    ┌───────────────────────────────────────────┐
    │ account_usage updated:                    │
    │ forms_created: 4 → 5                      │
    │                                           │
    │ Email alerts if approaching limit         │
    │ (80% of limit)                            │
    └───────────────────────────────────────────┘


If limit exceeded:
════════════════════════════════════════

Plan allows: 5 forms max
Current usage: 5 forms
User tries to create 6th form
        │
        ▼
BillingService::enforce(
  account_id,
  'can_create_form',
  'create a new form'
)
        │
        ├─ Check limit → false (at limit)
        ├─ Return error message
        └─ Display to user:
           "Upgrade your plan to create more forms"

Plus suggest upgrade to higher tier
```

---

## 🔄 Form Submission to Lead Flow

```
EXTERNAL WEBSITE
┌──────────────────┐
│ <script>embed    │
│ <div form-id>    │
│ Visitor fills    │
└────────┬─────────┘
         │ AJAX POST
         ▼
    embed/form.php
         │
         ├─ CSRF check ✓
         ├─ Spam check ✓
         ├─ Validate email ✓
         ├─ Sanitize inputs ✓
         │
         ▼
    INSERT lead:
    ├─ account_id
    ├─ email, name, phone
    ├─ source: 'form'
    ├─ form_id
    ├─ campaign_id (if linked)
    ├─ reference: LD-YYYYMMDD-#####
    ├─ score: 0 (initial)
    ├─ status: 'new'
    └─ submitted_at: NOW()
         │
         ├─ Dedup check
         │  ├─ Similar email found?
         │  ├─ Merge with existing
         │  └─ Update score if higher
         │
         ├─ Trigger email to team
         │  (if configured)
         │
         ├─ Create audit log
         │  'lead.created'
         │
         ├─ Create initial reminder
         │  (if score > threshold)
         │
         └─ Return success JSON
             {ok:true, redirect:...}
         │
         ▼
    EXTERNAL SITE:
    ├─ Show thank you message
    ├─ Redirect to page (if set)
    └─ Log form analytics


LEADPRO DASHBOARD
         │
         ▼
    Dashboard updates:
    ├─ New lead count +1
    ├─ Leads list shows new lead
    ├─ Recent activity shows submission
    │
    ▼
    Team member opens /leads.php
    ├─ Sees new lead
    ├─ Click to view /lead_view.php
    │  ├─ Email field populated
    ├─ See full lead details
    ├─ Timeline starts (0 events)
    │
    └─ Team member takes action:
       ├─ Send email follow-up
       ├─ Add note/comment
       ├─ Change status
       ├─ Assign to self
       └─ Convert to customer


Engagement Tracking:
    If lead clicks email link
    ├─ Pixel fires
    ├─ Score +5
    ├─ Timeline updated
    └─ Reminder might trigger
```

---

*Architecture last updated: March 27, 2026*
*Stable Build: lms_stable_2*
