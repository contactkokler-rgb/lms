# LeadPro Quick Reference Guide

## 🚀 Quick Start Checklist

### Setup
- [ ] Configure MySQL database in `config/config.php`
- [ ] Set timezone and locale in `config/config.local.php`
- [ ] Add API keys for AI (Groq, Gemini, OpenRouter) in admin settings
- [ ] Configure SMTP email settings
- [ ] Set up SSL certificate & HTTPS
- [ ] Configure custom domain(s) if needed

### Key File Locations
| Task | File |
|------|------|
| Change DB credentials | `config/config.php` |
| Add API keys | Admin Settings page (`settings.php`) |
| Email setup | `config/mailer.php` |
| User permissions | `config/auth.php` or `roles.php` |
| App branding | `settings.php` (white-label) |
| AI providers | `config/ai.php` |
| Billing logic | `config/BillingService.php` |

---

## 🔑 Important Constants

```php
APP_NAME          'LeadPro'
APP_VERSION       '1.0.0'
APP_URL           auto-detected (https/http + domain)
APP_HTTPS         true/false (auto-detect)

DB_HOST           'localhost'
DB_USER           'u963423741_lms'
DB_PASS           'T7q@;KeN'
DB_NAME           'u963423741_lms'

SESSION_LIFETIME  28800 seconds (8 hours)
SESSION_COOKIE    'lp_session'
BCRYPT_COST       12 (password strength)
INVITATION_TTL    259200 seconds (72 hours)
```

---

## 🔐 Role & Permission Quick Reference

### Default Roles
| Role | Capabilities |
|------|--------------|
| Super Admin | Full platform access, all accounts |
| Account Owner | Manage account, team, billing, settings |
| Manager | Create campaigns, view analytics, manage team tasks |
| Agent | Access assigned campaigns, submit leads, view own activity |

### Common Permissions Checked
```
can('dashboard', 'view')
can('campaigns', 'create')
can('campaigns', 'edit')
can('leads', 'view')
can('leads', 'import')
can('forms', 'create')
can('team', 'manage')
can('billing', 'manage')
can('settings', 'edit')
```

---

## 📊 Database Quick Reference

### Core Tables

**Users & Auth**
```sql
accounts              -- Multi-tenant accounts
users                 -- User profiles + password_hash
roles                 -- Role definitions
permissions           -- Granular actions (module.action)
role_permissions      -- Role → permissions mapping
```

**Leads & Campaigns**
```sql
leads                 -- Captured leads (with reference: LD-YYYYMMDD-#####)
campaigns             -- Marketing campaigns
campaign_pages        -- Landing pages linked to campaigns
campaign_knowledge    -- AI training data (tone, audience)
lead_forms            -- Embedded/standalone forms
forms                 -- Form definitions
```

**Billing & Plans**
```sql
account_plans         -- Current plan per account
pricing_plans         -- Plan definitions (limits, price)
account_usage         -- Monthly usage tracking (forms, leads, team)
```

**System**
```sql
platform_settings     -- Global config (key → value pairs)
audit_log             -- Full audit trail (user, action, target, IP, timestamp)
reminders             -- Task/reminder queue (snooze, mark_done)
templates             -- Reusable email/form templates
domains               -- Verified domains
```

### Important Fields

**Leads**
```sql
id                    -- Unique lead ID
account_id            -- Which account owns this lead
reference             -- Human-readable ID (LD-20250327-00001)
email, first_name, last_name
phone, company, title
source                -- Lead source (form, import, manual)
score                 -- Engagement score (0-100)
status                -- new, contacted, qualified, converted, lost
campaign_id           -- Associated campaign
owner_id              -- Assigned team member
submitted_at          -- Lead capture timestamp
created_at, updated_at
```

**Forms**
```sql
id, account_id
name, slug            -- Unique slug for embedding
fields                -- JSON array of form fields
submission_count      -- Total submissions
created_at, updated_at
```

---

## 🎯 Page-by-Page Module Guide

### Dashboard & Admin
| Page | Purpose | Key Features |
|------|---------|--------------|
| `index.php` | Dashboard | Stats, recent activity, reminders |
| `settings.php` | Admin settings | White-label, SMTP, API keys, platform config |
| `roles.php` | Role editor | Create/edit roles with permissions |
| `team.php` | Team mgmt | Add/remove users, assign roles |

### Lead Management
| Page | Purpose | Key Features |
|------|---------|--------------|
| `leads.php` | Lead list | Filter, sort, bulk actions, import |
| `lead_view.php` | Lead detail | Timeline, emails, notes, scoring |
| `import.php` | Lead import | CSV upload, field mapping, dedup |

### Campaigns & Content
| Page | Purpose | Key Features |
|------|---------|--------------|
| `campaigns.php` | Campaign list | CRUD, archive, assign owner |
| `campaign_view.php` | Campaign detail | Stats, linked pages, analytics |
| `campaign_knowledge.php` | AI training | Set tone, audience, goals |
| `page_builder.php` | Landing page builder | Drag-drop, templates, forms, SEO |
| `form_builder.php` | Form designer | Drag-drop fields, logic, styling |

### Email & Messaging
| Page | Purpose | Key Features |
|------|---------|--------------|
| `priority_inbox.php` | Inbox | All lead emails, priority flags |
| `templates.php` | Email templates | Template list, preview |

### Content Generation
| Page | Purpose | Key Features |
|------|---------|--------------|
| `ai_campaign.php` | AI campaign builder | Auto-generate copy |
| `ai_content.php` | Content generator | AI variations & templates |

### Analytics
| Page | Purpose | Key Features |
|------|---------|--------------|
| `reports.php` | Analytics dashboard | Custom filters, export |
| `sales_report.php` | Sales metrics | Pipeline, forecast, velocity |
| `seo_audits.php` | SEO audit list | Track audits, view reports |
| `seo_auditor.php` | Audit trigger | Start new SEO audit |
| `seo_report.php` | Audit results | Detailed findings |

### Technical
| Page | Purpose | Key Features |
|------|---------|--------------|
| `domains.php` | Domain mgmt | Add custom domains, verify DNS |
| `billing.php` | Billing | Invoices, payment history |
| `pricing.php` | Pricing table | View available plans |
| `upload.php` | File upload | Image/document upload |
| `invite.php` | Invitations | Generate team invites |

### Embeds & Landing Pages
| Page | Purpose | Key Features |
|------|---------|--------------|
| `embed/form.php` | Embed handler | Form submission on external sites |
| `embed/loader.js` | Embed script | Load forms from any website |
| `lp/index.php` | LP builder | Standalone landing page creation |

---

## 🔌 Integration Points

### Email (SMTP)
```php
// Configured in admin settings
// Sent via config/mailer.php
// Tracked in lead timeline
```

### AI Providers
```php
// Priority order:
// 1. Groq (14,400 req/day, fastest)
// 2. Gemini (250-1000 req/day)
// 3. OpenRouter (200 req/day)

// API keys configured in admin settings
// Usage: ai_call_provider($provider, $messages, $max_tokens)
```

### Payment Gateway (Stripe)
```php
// Configured in admin settings
// Used for SEO audit subscriptions
// Billing endpoint in auditor/PaymentGateway.php
```

### Forms Embedding
```html
<!-- Add to external website: -->
<script src="https://yourdomain.com/embed/loader.js"></script>
<div data-form-id="12345"></div>
```

---

## 💡 Common Tasks

### Add a New Role
1. Go to `/roles.php`
2. Create new role with name & label
3. Select permissions (module.action)
4. Save
5. Assign users to role in `/team.php`

### Create a Lead Capture Form
1. Go to `/form_builder.php`
2. Drag fields (email, name, etc.)
3. Add conditional logic if needed
4. Configure submit action (email, webhook)
5. Publish
6. Get embed code: `<script src="/embed/loader.js"></script><div data-form-id="X"></div>`
7. Paste on external website

### Generate AI Content
1. Go to `/campaign_knowledge.php`
2. Set tone, audience, goals
3. Go to `/ai_content.php`
4. Write brief or select template
5. Click "Generate"
6. Review, edit, use in email/page

### Create Landing Page
1. Go to `/page_builder.php`
2. Select template or start blank
3. Add blocks (hero, CTA, features, form)
4. Configure form for lead capture
5. Set SEO meta tags
6. Publish
7. Get URL: `/lp/{slug}`

### Track Lead Performance
1. Go to `/reports.php`
2. Filter by date, campaign, source
3. View conversion metrics
4. Export to Excel
5. Or view individual lead in `/lead_view.php`

### Configure Email Automation
1. Go to `/settings.php`
2. Enable SMTP
3. Set "from" email address
4. Create template in `/templates.php`
5. Set trigger (lead score, form submission, etc.)
6. System auto-sends based on trigger

### Manage Team Permissions
1. Go to `/roles.php`
2. Edit role
3. Toggle module.action permissions
4. Save
5. All users with that role get updated permissions

---

## 🐛 Debugging Tips

### Check Audit Log
```sql
SELECT * FROM audit_log 
WHERE account_id = ? OR user_id = ? 
ORDER BY created_at DESC 
LIMIT 50;
```
Shows all user actions, IPs, timestamps for debugging.

### Check Lead Score
```php
// In lead_view.php, score calculated from:
// - Time spent on landing page
// - Email opens
// - Link clicks
// - Form field fills
// - Page visits
```

### Test Email Sending
```php
// Edit config/mailer.php
// Add test recipient
// Try sending test email from settings
// Check error logs
```

### Check AI Provider Status
```php
// Go to admin settings
// Verify API keys are set
// Try generating content
// Check error messages if fails
// System falls back to next provider
```

### Database Connection Issues
```php
// Check config/config.php for:
// - DB_HOST, DB_USER, DB_PASS, DB_NAME
// - Verify database exists
// - Check user has all privileges
// - Try connecting via MySQL CLI
```

### Permission Denied
```php
// Check roles.php for user's role
// Check roles.php for role's permissions
// Ensure permission matches module.action being tested
// Super admin should always have access
```

---

## 📈 Performance Optimization Tips

1. **Page Builder:** Cache form/page definitions
2. **Reports:** Add indexes on frequently filtered columns (campaign_id, status, created_at)
3. **Email:** Consider adding job queue for bulk sends
4. **AI:** Implement request caching to avoid duplicate API calls
5. **Leads:** Add pagination to lead_view timeline (avoid loading all history)
6. **Forms:** Increase form submission rate limiting if needed
7. **Database:** Regular backups, query log analysis

---

## 🚨 Security Reminders

1. **Always use CSRF tokens** in forms: `<?= csrf_field() ?>`
2. **Always check permissions:** `require_permission($module, $action)`
3. **Always escape output:** `<?= h($variable) ?>`
4. **Never log passwords** in audit trail
5. **Rotate API keys** regularly
6. **Enable HTTPS** in production
7. **Regular backups** of database
8. **Monitor audit logs** for suspicious activity

---

## 📚 Code Snippets

### Check if User Can Do Something
```php
if (!can('forms', 'create')) {
    http_response_code(403);
    die('Permission denied');
}
```

### Get Current User
```php
$user = auth_user();
$account_id = $user['account_id'];
$role = $user['role_name']; // super_admin, account_owner, manager, agent
```

### Fetch Leads for Account
```php
$leads = db_fetch_all(
    'SELECT * FROM leads WHERE account_id = ? ORDER BY created_at DESC',
    'i', $account_id
);
```

### Create Audit Log Entry
```php
audit('action.name', 'target_reference', [
    'details' => 'value',
    'more' => 'data'
]);
```

### Format Datetime in Account Timezone
```php
$formatted = format_dt(
    $utc_datetime_from_db,
    'd M Y, g:ia',
    get_account_tz()
);
```

### Check Plan Limit
```php
if (!BillingService::checkLimit($account_id, 'form')) {
    die('Form limit reached for your plan');
}
BillingService::trackUsage($account_id, 'form');
```

### Call AI API
```php
$providers = ai_get_providers();
if (!empty($providers)) {
    $result = ai_call_provider($providers[0], $messages, 1000);
    // Retry with next provider if fails
}
```

### Escape HTML Output
```php
<?= h($user['first_name']) ?>
```

### CSRF Token in Form
```html
<form method="POST">
    <?= csrf_field() ?>
    <input type="text" name="email">
    <button type="submit">Save</button>
</form>
```

---

## 🎓 Learning Path

1. **Start here:** `config/auth.php` (understand auth & permissions)
2. **Then:** `config/config.php` (understand DB helpers & app config)
3. **Then:** `index.php` (understand page structure & data fetching)
4. **Then:** `leads.php` (understand list page pattern)
5. **Then:** `campaigns.php` (understand create/edit/delete pattern)
6. **Then:** `form_builder.php` (understand complex form handling)
7. **Then:** `page_builder.php` (understand complex editing)
8. **Then:** Review `config/ai.php` and `config/BillingService.php` for advanced features

---

## 📞 Common Issues & Solutions

| Issue | Cause | Solution |
|-------|-------|----------|
| "DB connection failed" | DB credentials wrong | Check `config/config.php` |
| "Permission denied" | User missing permission | Check `roles.php`, assign correct role |
| "CSRF token mismatch" | Form missing `csrf_field()` | Add `<?= csrf_field() ?>` to form |
| "Email not sending" | SMTP not configured | Check admin settings, test SMTP connection |
| "AI not working" | API key missing/invalid | Check admin settings, verify API key |
| "Page builder is slow" | Large form/page | Consider pagination or lazy loading |
| "Lead timeline is slow" | Too many interactions | Add pagination to timeline queries |
| "Forms not capturing" | Form not embedded correctly | Check embed script in external site |

---

*Last Updated: March 27, 2026*
*Stable Build: lms_stable_2*
