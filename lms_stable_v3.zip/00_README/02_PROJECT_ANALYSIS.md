# LeadPro LMS — Complete Project Analysis

**Build Version:** Stable 2 (lms_stable_2.zip)  
**Language:** PHP 7.4+ (MVC-style modular architecture)  
**Framework:** Custom PHP framework (no Laravel/Symfony)  
**Database:** MySQL/MariaDB  
**Frontend:** HTML5 + CSS (Nova design system) + Vanilla JavaScript  
**Latest Update:** March 27, 2026

---

## 📋 Executive Summary

**LeadPro** is an all-in-one CRM and lead management platform designed for modern sales teams. It's a multi-tenant SaaS application with advanced features including lead capture, campaign management, AI-powered content generation, email automation, and comprehensive analytics.

- **Total Code Lines:** ~21,912 lines (main PHP files only)
- **Core Modules:** 35+ pages/modules
- **Primary Users:** Sales teams, marketing teams, account owners, admins
- **Architecture:** Modular single-entry-point with permission-based access control

---

## 🏗️ Architecture Overview

### Directory Structure

```
/
├── config/                    # Core configuration & shared services
│   ├── config.php            # DB connection, helpers, platform settings
│   ├── config.local.php      # Environment-specific settings
│   ├── auth.php              # Auth, permissions, CSRF, auditing
│   ├── ai.php                # AI provider management (Groq, Gemini, OpenRouter)
│   ├── BillingService.php    # Plan enforcement, usage tracking
│   ├── BillingEmails.php     # Payment & notification emails
│   ├── mailer.php            # Email sending infrastructure
│   ├── knowledge.php         # AI training data & prompts
│   ├── engagement.php        # Engagement scoring logic
│   ├── scoring.php           # Lead scoring algorithm
│   ├── notifications.php     # Real-time notifications
│   ├── reminders.php         # Task/reminder engine
│   ├── deduplication.php     # Lead dedup logic
│   └── billing_helpers.php   # Billing utility functions
├── layouts/                   # Template partials
│   ├── header.php            # Main navbar, navigation
│   ├── footer.php            # Page footer
│   └── 403.php               # Forbidden access layout
├── assets/                    # Frontend resources
│   ├── css/                  # Nova design system CSS
│   │   ├── nova.css          # Main stylesheet
│   │   ├── app.css           # Custom app styles
│   │   ├── _base.css         # Base resets
│   │   ├── _components.css   # Component styles
│   │   ├── _animations.css   # Animations
│   │   └── ...
│   └── auditor/              # SEO auditor frontend
│       └── app.js
├── auditor/                   # SEO audit service (proprietary)
│   ├── SeoAuditService.php   # Core audit logic (167KB!)
│   ├── OpenRouterClient.php  # External API integration
│   ├── HttpClient.php        # HTTP wrapper
│   ├── PaymentGateway.php    # Stripe/payment integration
│   ├── PricingService.php    # Plan/subscription management
│   ├── SubscriptionMiddleware.php
│   ├── generate.php          # Audit generation endpoint
│   ├── save.php              # Save audit results
│   ├── email_report.php      # Email audit reports
│   └── ...
├── embed/                     # Embeddable form system
│   ├── form.php              # Embedded form handler
│   ├── loader.js             # Form loader script
│   ├── submit_test.php       # Form submission test
│   └── debug.php
├── lp/                        # Landing page builder
│   ├── index.php             # Landing page editor
│   └── .htaccess
│
├── Main Pages (35 PHP files)
│   ├── index.php             # Dashboard
│   ├── login.php             # Authentication
│   ├── logout.php            # Sign out
│   ├── accounts.php          # Account management (multi-tenant)
│   ├── team.php              # Team members & roles
│   ├── roles.php             # Role & permission editor
│   ├── users.php             # User management
│   │
│   ├── LEAD MANAGEMENT:
│   ├── leads.php             # Lead list with filters
│   ├── lead_view.php         # Lead detail & timeline (94KB)
│   ├── import.php            # Lead import (CSV, etc.)
│   │
│   ├── CAMPAIGNS:
│   ├── campaigns.php         # Campaign management
│   ├── campaign_view.php     # Campaign detail page
│   ├── campaign_knowledge.php # Campaign AI training
│   │
│   ├── FORMS & PAGES:
│   ├── forms.php             # Form list
│   ├── form_builder.php      # Form designer (42KB)
│   ├── page_builder.php      # Landing page builder (149KB, 2610 lines!)
│   ├── templates.php         # Form templates
│   ├── template_manager.php  # Template editor
│   │
│   ├── EMAIL & MESSAGING:
│   ├── priority_inbox.php    # Email inbox with priority
│   ├── submit.php            # Lead form submission handler
│   │
│   ├── CONTENT & AI:
│   ├── ai_campaign.php       # AI campaign builder
│   ├── ai_content.php        # AI content generator
│   │
│   ├── ANALYTICS & REPORTING:
│   ├── reports.php           # Comprehensive reporting (103KB)
│   ├── sales_report.php      # Sales-specific analytics
│   ├── seo_audits.php        # SEO audit tracking
│   ├── seo_auditor.php       # SEO audit initiator
│   ├── seo_report.php        # SEO audit results
│   ├── score_rules.php       # Engagement scoring config
│   │
│   ├── TECHNICAL:
│   ├── spam.php              # Spam detection/management
│   ├── domains.php           # Domain management
│   ├── billing.php           # Billing & invoices
│   ├── pricing.php           # Pricing & plans table
│   ├── payment_gateways.php  # Payment integrations
│   ├── settings.php          # Platform settings (78KB)
│   ├── upload.php            # File upload handler
│   ├── invite.php            # Invite link generation
│   ├── kanban.php            # Kanban board view
│   │
│   └── TESTING:
│   └── test_stable.php       # Stability test script
│
├── nova.html                  # Nova design system reference (67KB)
└── lms_stable_2.zip          # This archive
```

---

## 🔐 Authentication & Authorization System

### Multi-Level Role System

**Role Hierarchy:**
1. **Super Admin** — Platform owner, global access
2. **Account Owner** — Account-level admin, can manage team, billing
3. **Manager** — Team lead, can create campaigns & view analytics
4. **Agent** — Standard user, limited to assigned campaigns/leads

### Permission Model

Stored in database with structure:
- `roles` — Role definitions
- `permissions` — Granular action permissions (module.action)
- `role_permissions` — Role-permission mapping

**Key Checks:**
- `require_permission($module, $action)` — Enforces permission before page load
- `can($module, $action)` — Boolean permission check
- `is_super_admin()` — Super admin exemption

### Authentication Flow

1. User submits email + password on `/login.php`
2. `login()` function validates credentials via bcrypt
3. Session created with user ID, account ID, role
4. CSRF token generated per session
5. Audit log recorded for all logins/logouts
6. Optional maintenance mode blocks non-admins

---

## 💾 Database Schema (Key Tables)

```
accounts              — Multi-tenant accounts
users                 — User accounts
roles                 — Role definitions
permissions           — Permission registry
role_permissions      — Role-permission mapping
account_plans         — Subscription plans per account
pricing_plans         — Plan definitions
account_usage         — Monthly usage tracking
platforms_settings    — Global config (white-label, theme, etc.)

leads                 — All captured leads
lead_forms            — Embedded forms
campaigns             — Campaign definitions
campaign_pages        — Campaign landing pages
campaign_knowledge    — AI training data per campaign
domains               — Custom/managed domains
forms                 — Form definitions
templates             — Email/form templates
audit_log             — Full audit trail (user actions, IPs)
reminders             — Task/reminder queue
```

---

## 🎯 Key Features & Modules

### 1. Lead Management (`leads.php`, `lead_view.php`)
- **Lead List:** Filter by status, source, owner, date range
- **Lead Detail:** Full timeline with emails, calls, notes, interactions
- **Lead Scoring:** Engagement-based (time spent, clicks, opens)
- **Bulk Actions:** Assign, tag, export, delete
- **Deduplication:** Smart merge/dedupe logic
- **Import:** CSV/bulk lead import with field mapping

### 2. Campaign Management (`campaigns.php`, `campaign_view.php`)
- **Campaign CRUD:** Create, edit, archive campaigns
- **Campaign Pages:** Link multiple landing pages per campaign
- **Campaign Knowledge:** AI training data (tone, audience, goals)
- **Status Tracking:** Draft → Active → Paused → Archived
- **Owner Assignment:** Assign campaigns to team members
- **Analytics:** Lead count, page performance, engagement metrics

### 3. Form Builder (`form_builder.php`) — 42KB, Complex
- **Drag-Drop Form Builder:** Custom form creation
- **Field Types:** Text, email, phone, dropdown, checkbox, textarea, etc.
- **Conditional Logic:** Show/hide fields based on responses
- **Form Actions:** Email on submit, webhook, lead capture
- **Styling:** Inline CSS, custom fonts, colors
- **Multi-page Forms:** Step-by-step lead qualification
- **Spam Detection:** CAPTCHA, rate limiting, keyword filtering
- **Submission Tracking:** All responses logged per lead

### 4. Landing Page Builder (`page_builder.php`) — 149KB, Massive
- **Visual Editor:** Drag-drop page builder
- **Pre-built Blocks:** Hero, CTA, features, testimonials, footer
- **Template Gallery:** Ready-made page templates
- **Mobile Responsive:** Auto-responsive design
- **SEO Settings:** Meta tags, OG tags, schema markup
- **Custom CSS:** Inline editor for advanced styling
- **Form Integration:** Embed forms anywhere on page
- **A/B Testing:** Multiple page versions for campaigns
- **Analytics:** Page views, click heatmaps, form conversion

### 5. Email & Messaging (`priority_inbox.php`, `submit.php`)
- **Integrated Inbox:** All lead emails in one place
- **Email Automation:** Trigger emails on lead actions
- **Email Templates:** Drag-drop email builder
- **SMTP Integration:** Custom SMTP or platform's
- **Tracking:** Open rates, click tracking, bounce handling
- **Two-way Sync:** Emails parsed into lead timeline
- **Priority System:** VIP leads get priority inbox flags

### 6. AI Features (`ai_campaign.php`, `ai_content.php`, `config/ai.php`)
- **Multi-Provider Support:**
  - **Groq:** Fast, 14,400 req/day (free)
  - **Gemini:** Google AI, 250-1000 req/day (free)
  - **OpenRouter:** Multi-model, 200 req/day (free)
- **AI-Generated Content:**
  - Campaign copy & subject lines
  - Lead follow-up templates
  - Content variations for A/B testing
- **Training Data:** Campaign knowledge (audience, tone, goals)
- **Rate Limiting:** Provider fallback if rate limited

### 7. SEO Auditor (`auditor/SeoAuditService.php`) — 167KB Monster!
- **Domain Analysis:** Crawl website, analyze pages
- **Metrics Tracked:**
  - Page speed (Core Web Vitals)
  - Mobile friendliness
  - Meta tags (title, description)
  - Header hierarchy
  - Image alt text
  - Internal/external links
  - Schema markup
- **Issue Detection:** Scoring & recommendations
- **Report Generation:** PDF/HTML audit reports
- **Email Reports:** Automated scheduling
- **Integration:** Stripe payment for premium audits

### 8. Analytics & Reporting (`reports.php`, `sales_report.php`)
- **Dashboard Stats:**
  - Leads by source, status, owner
  - Campaign performance (leads, conversions)
  - Team activity (calls, emails, tasks)
  - Revenue forecast
- **Custom Reports:** Filter by any field, export to Excel
- **Sales Report:** Pipeline value, close rate, avg deal size
- **Engagement Scoring:** Time on page, email opens, link clicks
- **Audit Trail:** All user actions logged with IP, timestamp

### 9. Billing & Subscriptions (`billing.php`, `config/BillingService.php`)
- **Plan Enforcement:**
  - Domain limits per plan
  - Form creation limits
  - Lead capture limits
  - Team member limits
  - Monthly usage tracking
- **Payment Gateways:** Stripe integration
- **Plan Features:**
  - Basic: Limited leads, 1 form, limited team
  - Pro: More leads, unlimited forms, 5 team members
  - Enterprise: Custom limits, API access
- **Invoice Generation:** Automatic invoicing
- **Usage Alerts:** Email when approaching limits

### 10. Team & Roles (`team.php`, `roles.php`)
- **Team Member Management:** Add, edit, remove users
- **Role Assignment:** Assign roles with custom permissions
- **Permission Matrix:** Granular per-module permission control
- **Invitation System:** Email invitations (72-hour expiry)
- **User Status:** Active, inactive, suspended, invited
- **Activity Log:** Track what each user does

### 11. Settings & Admin (`settings.php`, `config/config.php`)
- **White-Label Options:**
  - App name, logo, favicon
  - Brand colors (500, 600, 50, 100, 700)
  - Font selection (body, monospace)
  - Custom CSS injection
  - Footer copyright text
- **Email Settings:** SMTP config, from address, templates
- **Domain Management:** Add, verify, configure custom domains
- **Maintenance Mode:** Block users during updates
- **Platform Settings:** Global settings accessible to super admin

### 12. Embeddable Forms (`embed/form.php`, `embed/loader.js`)
- **Embed Code:** Script tag to embed forms on external sites
- **Form Customization:** Per-embed styling, prefill, redirect
- **Lead Capture:** Forms work across any website
- **Webhook Integration:** Trigger external actions
- **AJAX Submission:** No page reload required

### 13. Landing Pages (`lp/index.php`)
- **Standalone Page Builder:** Create stand-alone landing pages
- **URL Structure:** `/lp/{slug}.php` or `/lp/?id={id}`
- **Template Gallery:** Pre-built templates
- **Lead Capture:** Forms embedded in landing pages
- **Conversion Tracking:** CTA clicks, form submissions

---

## 🔄 Key Workflows

### Lead Capture Workflow
1. User creates form via `/form_builder.php`
2. Form embedded via `/embed/loader.js` or on landing page
3. Visitor fills form at `/embed/submit_test.php`
4. Lead created in database with auto-reference (LD-YYYYMMDD-##### format)
5. Email sent to team (if configured)
6. Lead appears in `/leads.php` dashboard
7. Scoring engine evaluates lead (engagement, qualification)
8. Reminder system flags high-value leads
9. Team member can action lead from `/lead_view.php`

### Campaign Workflow
1. Manager creates campaign (name, dates, objective)
2. Campaign knowledge trained via `campaign_knowledge.php` (tone, audience)
3. Landing pages created via `page_builder.php`, linked to campaign
4. Forms created & linked to campaign
5. Forms embedded on external sites or linked from landing pages
6. Leads captured are tagged with campaign ID
7. Analytics tracked in `reports.php`
8. Team follows up via inbox/email

### Email Automation Workflow
1. User creates email template
2. Trigger configured (e.g., "lead score > 50")
3. System automatically sends email via SMTP (configured in settings)
4. Email opens/clicks tracked
5. Engagement recorded to lead timeline
6. Lead score updated
7. Next action triggered if configured

### AI Content Generation
1. User writes brief (goal, tone, target audience)
2. System calls AI provider (Groq → Gemini → OpenRouter, in priority)
3. AI generates content based on campaign knowledge
4. User reviews & edits
5. Content published to email template or landing page

---

## 🛠️ Core Technical Stack

### Backend
- **Language:** PHP 7.4+ (procedural, no OOP framework)
- **Database:** MySQL/MariaDB (via MySQLi)
- **Session Management:** PHP $_SESSION with CSRF tokens
- **Authentication:** bcrypt password hashing (cost 12)
- **Auditing:** Full audit trail per user action

### Frontend
- **Framework:** Vanilla HTML + CSS + JavaScript (no React/Vue)
- **Design System:** "Nova" custom CSS framework
  - Uses CSS custom properties (variables)
  - Color tokens (brand colors)
  - Animation/transition library
  - Responsive grid system
- **Fonts:** Google Fonts (Sora, JetBrains Mono configurable)
- **Icons:** Custom icon set (HHGi)

### Integrations
- **AI:** Groq, Google Gemini, OpenRouter
- **Email:** Custom SMTP integration
- **Payments:** Stripe (for billing)
- **Domain:** DNS verification, CNAME setup
- **Hosting:** Designed for shared hosting (Hostinger mentioned)

---

## 🔒 Security Features

1. **CSRF Protection:** Token generation & validation
2. **Password Security:** bcrypt (cost 12, very secure)
3. **Session Security:**
   - HTTPOnly cookies
   - Secure flag (HTTPS enforced in prod)
   - SameSite=Lax
   - 8-hour lifetime
4. **SQL Injection Prevention:** Prepared statements (mysqli)
5. **Input Sanitization:** `h()` function for HTML escaping
6. **Audit Logging:** All user actions, IP addresses, timestamps
7. **Invitation TTL:** 72-hour expiry for team invitations
8. **Maintenance Mode:** Block users during updates
9. **Rate Limiting:** Form submission rate limiting (spam protection)
10. **IP Tracking:** Last login IP, action IP logged

---

## 📊 Database Connection & Config

**From `config/config.php`:**
```php
DB_HOST = 'localhost'
DB_USER = 'u963423741_lms'
DB_PASS = 'T7q@;KeN'
DB_NAME = 'u963423741_lms'
```

**Connection Details:**
- Uses MySQLi (PHP's native MySQL interface)
- utf8mb4 charset for full emoji/Unicode support
- Connection pooled (singleton pattern)
- Error logging on prepare failures

---

## 📈 File Size Analysis

**Largest/Most Complex Files:**
1. **`page_builder.php`** — 2,610 lines, 149KB (landing page builder)
2. **`lead_view.php`** — ~2,000 lines, 94KB (lead detail page)
3. **`auditor/SeoAuditService.php`** — 167KB (SEO audit engine)
4. **`reports.php`** — 2,188 lines, 103KB (analytics)
5. **`settings.php`** — 1,420 lines, 78KB (admin settings)
6. **`campaigns.php`** — 1,200+ lines, 41KB (campaign CRUD)
7. **`form_builder.php`** — 2,000+ lines, 42KB (form designer)

**Most Integrated:**
- `index.php` — Dashboard (multi-role, stats, reminders)
- `config/auth.php` — Auth, permissions, CSRF, audit
- `config/config.php` — DB helpers, platform settings, datetime formatting

---

## 🎨 Design System (Nova)

Located in `/assets/css/`:
- **nova.css** — Main compiled stylesheet
- **_base.css** — CSS resets, base elements
- **_components.css** — Buttons, cards, modals, inputs
- **_animations.css** — Transitions, hover effects
- **_layout.css** — Grid, flexbox, spacing
- **_patterns.css** — Common patterns (badges, alerts)
- **_colors.css** — Color palette
- **_tokens.css** — CSS variables
- **_app.css** — App-specific overrides

**Customizable via Platform Settings:**
- Brand color (500, 600, 50, 100, 700)
- Sidebar background & text color
- Fonts (body, monospace)
- Custom CSS injection

---

## 🚀 Deployment Notes

1. **Requirements:**
   - PHP 7.4+ with mysqli extension
   - MySQL 5.7+ or MariaDB 10.2+
   - HTTPS (enforced for production domains)

2. **Setup:**
   - Copy files to web root
   - Edit `config/config.php` for DB credentials
   - Create database tables (schema not provided)
   - Configure SMTP in settings
   - Add API keys (Groq, Gemini, OpenRouter)

3. **White-Label:**
   - All branding in `platform_settings` table
   - Can customize app name, logo, colors, fonts, CSS

4. **Multi-Tenant:**
   - Each account isolated by `account_id`
   - Super admin has global view
   - Team members see only their account's data

---

## 📝 Usage of Key Functions

### Database Functions
```php
db_fetch($sql, $types, ...$params)           // Single row
db_fetch_all($sql, $types, ...$params)       // Multiple rows
db_query($sql, $types, ...$params)           // Raw query
db_insert($sql, $types, ...$params)          // Insert & return ID
```

### Auth Functions
```php
require_auth()                                // Check logged in
require_permission($module, $action)         // Enforce permission
can($module, $action)                        // Check permission
is_super_admin()                             // Check super admin
csrf_token()                                 // Get/create CSRF token
csrf_verify()                                // Verify CSRF
csrf_field()                                 // HTML input
audit($action, $target, $meta)              // Log audit event
```

### Helper Functions
```php
h($string)                                   // HTML escape
format_dt($utc_datetime, $format, $tz)      // Format datetime (account TZ)
get_account_tz()                            // Get account timezone
ps($key, $default)                          // Get platform setting
ps_save($key, $value)                       // Save platform setting
ps_theme_css()                              // Generate theme CSS
ps_copyright()                              // Get copyright text
```

### AI Functions
```php
ai_enabled()                                 // Check if AI active
ai_get_providers()                           // Get configured providers
ai_call_provider($provider, $messages, $max_tokens)  // Call AI
```

### Billing Functions
```php
BillingService::getAccountPlan($account_id)
BillingService::isPlanActive($account_id)
BillingService::checkLimit($account_id, $type)
BillingService::trackUsage($account_id, $type)
BillingService::enforce($account_id, $feature, $msg)
```

---

## 🔗 Key Relationships

**Account Hierarchy:**
```
Account (parent, multi-tenant)
├── Users (team members)
├── Domains (email, CNAME)
├── Forms (lead capture)
├── Campaigns (marketing initiatives)
│   └── Campaign Pages (landing pages)
│   └── Campaign Knowledge (AI training)
├── Leads (captured contacts)
└── Settings (account-level config)
```

**Permission Flow:**
```
Role (e.g., "manager")
└── Role Permissions (module.action pairs)
    └── User assigned to Role
        └── Checks can($module, $action) before allowing action
```

---

## 📋 Testing & Stability

- **Test File:** `test_stable.php` (27 lines, minimal)
- **Suggests:** Manual testing or external test suite
- **No:** Unit tests, integration tests found in codebase
- **Audit Trail:** Full audit log for debugging issues

---

## ⚠️ Known Considerations

1. **Page Builder Complexity:** `page_builder.php` (2,610 lines) is very large, could benefit from refactoring
2. **SEO Auditor Size:** `auditor/SeoAuditService.php` (167KB) is massive, suggests heavy logic
3. **No Framework:** Using procedural PHP with custom patterns (not OOP framework)
4. **Database Credentials:** Hardcoded in `config/config.php` (should use env vars in production)
5. **Single Entry Points:** No API layer; all pages are direct PHP files
6. **Email System:** Custom SMTP integration; no email queuing visible
7. **Rate Limiting:** Basic form rate limiting, could benefit from distributed cache

---

## 🎯 Next Steps for Development

1. **Review** `config/config.local.php` for environment-specific overrides
2. **Check** database schema in actual MySQL for table structure
3. **Test** email integration (SMTP setup required)
4. **Configure** AI provider keys (Groq, Gemini, OpenRouter)
5. **Set up** SSL certificate for HTTPS
6. **Load test** form submissions & analytics generation
7. **Review** audit logs for production behavior
8. **Plan** refactoring of large files (page_builder, auditor)

---

## 📞 Support Resources

- **Config:** `config/` directory for all settings
- **Auth:** `config/auth.php` for permission system
- **DB Helpers:** `config/config.php` for database functions
- **AI:** `config/ai.php` for LLM integration
- **Billing:** `config/BillingService.php` for subscription logic
- **Email:** `config/mailer.php` for SMTP setup
- **Errors:** Check PHP error logs for debugging

---

**Total Project Size:** ~2.7GB (with dependencies)  
**Stable Build Date:** March 27, 2026  
**Last Update:** March 27, 2026

---

*This analysis was generated after comprehensive code inspection of all 35+ PHP modules, configuration files, and related systems.*
