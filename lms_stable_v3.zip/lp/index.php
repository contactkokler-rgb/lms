<?php
/**
 * LeadPro — Public Landing Page Renderer (clean rewrite)
 */
define('NO_SESSION', true);
require_once __DIR__ . '/../config/config.php';

$slug = trim($_GET['slug'] ?? '');
if (!$slug || !preg_match('/^[a-z0-9\-]+$/', $slug)) {
    http_response_code(404); echo '<h1>404</h1>'; exit;
}

$page = db_fetch(
    "SELECT cp.*, c.name AS campaign_name, c.account_id AS acc_id
     FROM campaign_pages cp
     JOIN campaigns c ON c.id = cp.campaign_id
     WHERE cp.slug = ? AND cp.status = 'published'",
    's', $slug
);

if (!$page) {
    http_response_code(404);
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Not Found</title></head>
    <body style="font-family:sans-serif;text-align:center;padding:80px;color:#64748b;">
    <h1 style="font-size:3rem;color:#cbd5e1;">404</h1><p>This page is not available.</p>
    </body></html>';
    exit;
}

db_query('UPDATE campaign_pages SET views = views + 1 WHERE id = ?', 'i', (int)$page['id']);

$page_data   = json_decode($page['page_data'] ?? '[]', true) ?: [];
$account_id  = (int)$page['acc_id'];
$campaign_id = (int)$page['campaign_id'];
$page_id     = (int)$page['id'];
$form_id     = (int)($page['form_id'] ?? 0);

$form   = null;
$fields = [];
if ($form_id) {
    $form = db_fetch(
        'SELECT f.*, d.domain AS allowed_domain
         FROM lead_forms f JOIN domains d ON d.id = f.domain_id
         WHERE f.id = ? AND f.is_active = 1',
        'i', $form_id
    );
    if ($form) {
        $fields = db_fetch_all(
            'SELECT * FROM form_fields WHERE form_id = ? AND is_visible = 1 ORDER BY sort_order, id',
            'i', $form_id
        );
    }
}

$submitted    = false;
$submit_error = null;
$submit_msg   = 'Thank you! We will be in touch soon.';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['lp_submit']) && $form) {
    $settings   = json_decode($form['settings'] ?? '{}', true) ?: [];
    $submit_msg = $settings['success_msg'] ?? $submit_msg;

    $ip = '';
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP']))    $ip = trim($_SERVER['HTTP_CF_CONNECTING_IP']);
    elseif (!empty($_SERVER['HTTP_X_REAL_IP']))       $ip = trim($_SERVER['HTTP_X_REAL_IP']);
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) $ip = trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
    else                                              $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $ip = substr($ip, 0, 45);
    $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500);

    $posted = [];
    foreach ($fields as $f) {
        $posted[$f['field_key']] = trim((string)($_POST[$f['field_key']] ?? ''));
    }

    $errors = [];
    foreach ($fields as $f) {
        $v = $posted[$f['field_key']] ?? '';
        if ($f['is_required'] && $v === '') $errors[] = $f['field_label'] . ' is required.';
        if ($f['field_type'] === 'email' && $v && !filter_var($v, FILTER_VALIDATE_EMAIL))
            $errors[] = $f['field_label'] . ' must be a valid email.';
    }

    if ($errors) {
        $submit_error = implode(' ', $errors);
    } else {
        $ref     = generate_reference($account_id);
        $lead_id = db_insert(
            'INSERT INTO leads (account_id,form_id,domain_id,reference_no,status,source_url,ip_address,user_agent,utm_source,utm_medium,utm_campaign) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
            'iiissssssss',
            $account_id, $form_id, (int)$form['domain_id'],
            $ref, 'new',
            APP_URL . '/lp/' . $slug, $ip, $ua,
            $_GET['utm_source'] ?? '', $_GET['utm_medium'] ?? '', $_GET['utm_campaign'] ?? ''
        );
        if ($lead_id) {
            $db2 = db();
            if ($db2->query("SHOW COLUMNS FROM leads LIKE 'campaign_id'")->num_rows > 0) {
                db_query('UPDATE leads SET campaign_id=?,campaign_page_id=? WHERE id=?', 'iii', $campaign_id, $page_id, $lead_id);
            }
            foreach ($fields as $f) {
                $v = $posted[$f['field_key']] ?? '';
                if ($v !== '') db_insert('INSERT INTO lead_values (lead_id,field_id,field_key,field_label,value) VALUES (?,?,?,?,?)', 'iisss', $lead_id, (int)$f['id'], $f['field_key'], $f['field_label'], $v);
            }
            db_query('UPDATE lead_forms SET submission_count=submission_count+1 WHERE id=?', 'i', $form_id);
            try { require_once __DIR__ . '/../config/scoring.php'; apply_lead_score($lead_id, $account_id); } catch (Throwable $ex) {}
            // In-app notification
            try {
                require_once __DIR__ . '/../config/notifications.php';
                notify_role($account_id, 'account_owner', 'lead.new', 'New lead from landing page: ' . $page['title'], 'Ref ' . $ref, '/lead_view.php?id=' . $lead_id, ['lead_id' => $lead_id, 'campaign_id' => $campaign_id]);
            } catch (Throwable $ex) {}

            // Email notifications using template system
            try {
                require_once __DIR__ . '/../config/mailer.php';
                $lp_settings    = json_decode($form['settings'] ?? '{}', true) ?: [];
                $lp_notify_from = trim($lp_settings['notify_email'] ?? '');
                $app_name       = ps('app_name', 'LeadPro');
                $lead_view_url  = (defined('APP_URL') ? APP_URL : '') . '/lead_view.php?id=' . $lead_id;

                // Build template vars
                $lp_lead     = db_fetch('SELECT * FROM leads WHERE id=?', 'i', $lead_id) ?: [];
                $lp_fields   = [];
                foreach ($fields as $f) {
                    $lp_fields[] = ['field_key'=>$f['field_key'],'field_label'=>$f['field_label'],'value'=>$posted[$f['field_key']] ?? ''];
                }
                $lp_campaign = db_fetch('SELECT * FROM campaigns WHERE id=?', 'i', $campaign_id) ?: [];
                $tpl_vars    = build_template_vars($lp_lead, $lp_fields, $form, $lp_campaign);

                // ── Notify staff ─────────────────────────────────
                $notify_tpl     = get_form_template((int)$form['id'], 'notify');
                $notify_subject = $notify_tpl ? template_replace($notify_tpl['subject'], $tpl_vars) : "New Lead: {$ref} — {$page['title']}";
                $notify_body    = $notify_tpl ? template_replace($notify_tpl['body'], $tpl_vars)
                    : "New lead from: {$page['title']}\n\nRef: {$ref}\n\n" . implode("\n", array_map(fn($f)=>$f['field_label'].': '.$f['value'], array_filter($lp_fields, fn($f)=>$f['value']!==''))) . "\n\nView: {$lead_view_url}";

                $notify_emails = [];
                if ($lp_notify_from && filter_var($lp_notify_from, FILTER_VALIDATE_EMAIL))
                    $notify_emails[] = ['email'=>$lp_notify_from, 'name'=>$app_name];
                $camp_owner = db_fetch('SELECT u.email, u.first_name, u.last_name FROM campaigns c JOIN users u ON u.id=c.owner_id WHERE c.id=? AND c.owner_id IS NOT NULL', 'i', $campaign_id);
                if ($camp_owner && filter_var($camp_owner['email'], FILTER_VALIDATE_EMAIL))
                    $notify_emails[] = ['email'=>$camp_owner['email'], 'name'=>trim($camp_owner['first_name'].' '.$camp_owner['last_name'])];

                $sent_to = [];
                foreach ($notify_emails as $r) {
                    if (in_array($r['email'], $sent_to)) continue;
                    $sent_to[] = $r['email'];
                    send_email_from_form($r['email'], $r['name'], $notify_subject, $notify_body, $lp_notify_from);
                }

                // ── Auto-reply to lead ────────────────────────────
                $auto_tpl = get_form_template((int)$form['id'], 'auto_reply');
                if ($auto_tpl) {
                    $lead_email_val = '';
                    foreach ($lp_fields as $f2) { if ($f2['field_key']==='email' && $f2['value']) { $lead_email_val=$f2['value']; break; } }
                    if ($lead_email_val && filter_var($lead_email_val, FILTER_VALIDATE_EMAIL)) {
                        $ar_subj = template_replace($auto_tpl['subject'], $tpl_vars);
                        $ar_body = template_replace($auto_tpl['body'], $tpl_vars);
                        send_email_from_form($lead_email_val, $tpl_vars['name'], $ar_subj, $ar_body, $lp_notify_from);
                    }
                }
            } catch (Throwable $mail_ex) {
                error_log('[LeadPro LP] Email notify failed: ' . $mail_ex->getMessage());
            }

            $submitted = true;
            if (!empty($settings['redirect_url'])) { header('Location: ' . $settings['redirect_url']); exit; }
        } else {
            $submit_error = 'Submission failed. Please try again.';
        }
    }
}

// ── Helpers ──────────────────────────────────────────────────
function lp_e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function lp_block_wrap($html, $pad, $block_style, $anim_class, $hide_class) {
    $cls = trim($anim_class . ' ' . $hide_class);
    return "<div" . ($cls ? " class=\"{$cls}\"" : '') . " style=\"padding:{$pad}px 32px;width:100%;box-sizing:border-box;{$block_style}\">{$html}</div>";
}

function lp_render_block(array $b, array $fields_data, $form, bool $submitted, string $submit_error = '', string $submit_msg = ''): string {
    $pad         = (int)($b['padding'] ?? 20);
    $block_style = '';

    if (!empty($b['gradFrom']) && !empty($b['gradTo'])) {
        $dir = lp_e($b['gradDir'] ?? '135deg');
        $block_style .= "background:linear-gradient({$dir}," . lp_e($b['gradFrom']) . "," . lp_e($b['gradTo']) . ");";
    } elseif (!empty($b['blockBg'])) {
        $block_style .= "background:" . lp_e($b['blockBg']) . ";";
    }
    if (!empty($b['marginTop'])    && (int)$b['marginTop']    > 0) $block_style .= "margin-top:"    . (int)$b['marginTop']    . "px;";
    if (!empty($b['marginBottom']) && (int)$b['marginBottom'] > 0) $block_style .= "margin-bottom:" . (int)$b['marginBottom'] . "px;";
    if (!empty($b['borderWidth'])  && (int)$b['borderWidth']  > 0) {
        $block_style .= "border:" . (int)$b['borderWidth'] . "px solid " . lp_e($b['borderColor'] ?? '#e2e8f0') . ";";
        $block_style .= "border-radius:" . (int)($b['borderRadius'] ?? 0) . "px;";
    }
    $shadows = ['sm'=>'0 1px 3px rgba(0,0,0,.1)','md'=>'0 4px 16px rgba(0,0,0,.12)','lg'=>'0 8px 32px rgba(0,0,0,.16)','xl'=>'0 20px 60px rgba(0,0,0,.2)'];
    if (!empty($shadows[$b['boxShadow'] ?? ''])) $block_style .= "box-shadow:" . $shadows[$b['boxShadow']] . ";";

    $anim_map  = ['fade-up'=>'lp-animate','fade-left'=>'lp-animate-left','scale'=>'lp-animate-scale'];
    $anim_class= $anim_map[$b['animation'] ?? ''] ?? '';
    $hide_class= '';
    if (!empty($b['hideOnMobile']))  $hide_class .= ' lp-hide-mobile';
    if (!empty($b['hideOnTablet']))  $hide_class .= ' lp-hide-tablet';
    if (!empty($b['hideOnDesktop'])) $hide_class .= ' lp-hide-desktop';

    $wrap = function($html) use ($pad, $block_style, $anim_class, $hide_class) {
        return lp_block_wrap($html, $pad, $block_style, $anim_class, $hide_class);
    };

    switch ($b['type'] ?? '') {

        // ── Text ──────────────────────────────────────────────
        case 'headline':
            $fw = !empty($b['bold']) ? '800' : '500';
            return $wrap("<h1 style=\"font-size:" . lp_e($b['size'] ?? '2.2rem') . ";color:" . lp_e($b['color'] ?? '#0f172a') . ";text-align:" . lp_e($b['align'] ?? 'center') . ";font-weight:{$fw};line-height:1.2;margin:0;\">" . lp_e($b['text'] ?? '') . "</h1>");
        case 'subheadline':
            $fw = !empty($b['bold']) ? '700' : '500';
            return $wrap("<h2 style=\"font-size:" . lp_e($b['size'] ?? '1.3rem') . ";color:" . lp_e($b['color'] ?? '#1e293b') . ";text-align:" . lp_e($b['align'] ?? 'center') . ";font-weight:{$fw};line-height:1.3;margin:0;\">" . lp_e($b['text'] ?? '') . "</h2>");
        case 'paragraph':
            return $wrap("<p style=\"font-size:" . lp_e($b['size'] ?? '1rem') . ";color:" . lp_e($b['color'] ?? '#475569') . ";text-align:" . lp_e($b['align'] ?? 'left') . ";line-height:1.7;margin:0;\">" . lp_e($b['text'] ?? '') . "</p>");
        case 'section_title':
            return $wrap("<div style=\"font-size:" . lp_e($b['size'] ?? '1.1rem') . ";font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:" . lp_e($b['color'] ?? '#2563eb') . ";text-align:" . lp_e($b['align'] ?? 'center') . ";\">" . lp_e($b['text'] ?? '') . "</div>");
        case 'bullet_list': {
            $items = '';
            foreach ((array)($b['items'] ?? []) as $i) {
                $items .= "<li style=\"display:flex;align-items:flex-start;gap:10px;margin-bottom:10px;font-size:.95rem;line-height:1.5;\"><span style=\"color:#16a34a;font-weight:800;flex-shrink:0;\">&#10003;</span>" . lp_e($i) . "</li>";
            }
            return $wrap("<ul style=\"list-style:none;padding:0;margin:0;color:" . lp_e($b['color'] ?? '#475569') . ";\">{$items}</ul>");
        }
        case 'divider':
            return "<div style=\"padding:{$pad}px 32px;{$block_style}\"><hr style=\"border:none;border-top:1px solid " . lp_e($b['color'] ?? '#e2e8f0') . ";\"></div>";
        case 'spacer':
            return "<div style=\"height:" . (int)($b['height'] ?? 40) . "px;{$block_style}\"></div>";

        // ── Media ─────────────────────────────────────────────
        case 'image':
            if (empty($b['src'])) return '';
            return $wrap("<div style=\"text-align:center;\"><img src=\"" . lp_e($b['src']) . "\" alt=\"" . lp_e($b['alt'] ?? '') . "\" style=\"max-width:100%;width:" . (int)($b['width'] ?? 100) . "%;border-radius:" . (int)($b['imgRadius'] ?? 8) . "px;\"></div>");
        case 'video':
            return $wrap("<div style=\"position:relative;padding-bottom:56.25%;height:0;overflow:hidden;border-radius:8px;\"><iframe src=\"" . lp_e($b['url'] ?? '') . "\" style=\"position:absolute;inset:0;width:100%;height:100%;border:none;\" allowfullscreen></iframe></div>");
        case 'logo_gallery': {
            $logos = '';
            foreach ((array)($b['logos'] ?? []) as $l) {
                $logos .= "<span style=\"font-size:1.2rem;font-weight:900;color:#94a3b8;\">" . lp_e($l) . "</span>";
            }
            return $wrap("<div style=\"display:flex;flex-wrap:wrap;gap:20px;justify-content:center;align-items:center;padding:16px 0;opacity:.7;\">{$logos}</div>");
        }

        // ── Conversion ────────────────────────────────────────
        case 'cta_button':
            return $wrap("<div style=\"text-align:" . lp_e($b['align'] ?? 'center') . ";\"><a href=\"" . lp_e($b['url'] ?? '#') . "\" style=\"display:inline-block;padding:14px 32px;background:" . lp_e($b['bg'] ?? '#2563eb') . ";color:" . lp_e($b['color'] ?? '#fff') . ";font-weight:800;font-size:1rem;border-radius:" . (int)($b['radius'] ?? 10) . "px;text-decoration:none;\">" . lp_e($b['text'] ?? 'Click Here') . "</a></div>");
        case 'appointment':
            return $wrap("<div style=\"text-align:center;\"><p style=\"font-size:1rem;color:#475569;margin:0 0 14px;\">" . lp_e($b['label'] ?? 'Book a time that works for you') . "</p><a href=\"" . lp_e($b['url'] ?? '#') . "\" target=\"_blank\" style=\"display:inline-block;padding:14px 32px;background:" . lp_e($b['bg'] ?? '#2563eb') . ";color:" . lp_e($b['color'] ?? '#fff') . ";font-weight:800;font-size:1rem;border-radius:10px;text-decoration:none;\">" . lp_e($b['btnText'] ?? 'Book a Call') . "</a></div>");

        // ── Lead Form ─────────────────────────────────────────
        case 'lead_form': {
            if (!$form) return $wrap("<div style=\"background:#fef3c7;border-radius:8px;padding:20px;text-align:center;color:#92400e;font-size:.85rem;\">No form attached to this page.</div>");
            if ($submitted) return $wrap("<div id=\"lp-form\" style=\"background:#f0fdf4;border:1.5px solid #86efac;border-radius:12px;padding:28px;text-align:center;\"><div style=\"font-size:2rem;margin-bottom:10px;\">&#10003;</div><div style=\"font-size:1.1rem;font-weight:700;color:#15803d;margin-bottom:6px;\">Thank you!</div><div style=\"color:#64748b;font-size:.88rem;\">" . lp_e($submit_msg) . "</div></div>");
            $err  = $submit_error ? "<div style=\"background:#fef2f2;border:1px solid #fca5a5;color:#991b1b;padding:10px 14px;border-radius:8px;font-size:.82rem;margin-bottom:14px;\">" . lp_e($submit_error) . "</div>" : '';
            $fhtml = '';
            foreach ($fields_data as $f) {
                $req  = $f['is_required'] ? '*' : '';
                $nm   = lp_e($f['field_key']);
                $lb   = lp_e($f['field_label']);
                $ph   = lp_e($f['placeholder'] ?? '');
                $ist  = "width:100%;padding:10px 12px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:.9rem;outline:none;box-sizing:border-box;font-family:inherit;";
                $lbl  = "<label style=\"display:block;font-size:.78rem;font-weight:700;color:#475569;margin-bottom:5px;\">{$lb}{$req}</label>";
                if ($f['field_type'] === 'textarea') {
                    $fhtml .= "<div style=\"margin-bottom:14px;\">{$lbl}<textarea name=\"{$nm}\" placeholder=\"{$ph}\" rows=\"4\" style=\"{$ist}resize:vertical;\"></textarea></div>";
                } elseif ($f['field_type'] === 'select') {
                    $opts = "<option value=\"\">Select...</option>";
                    foreach (explode(',', $f['options'] ?? '') as $o) {
                        $ov = lp_e(trim($o));
                        $opts .= "<option value=\"{$ov}\">{$ov}</option>";
                    }
                    $fhtml .= "<div style=\"margin-bottom:14px;\">{$lbl}<select name=\"{$nm}\" style=\"{$ist}background:#fff;\">{$opts}</select></div>";
                } else {
                    $types_ok = ['email','tel','url','number','date'];
                    $tp = in_array($f['field_type'], $types_ok) ? $f['field_type'] : 'text';
                    $fhtml .= "<div style=\"margin-bottom:14px;\">{$lbl}<input type=\"{$tp}\" name=\"{$nm}\" placeholder=\"{$ph}\" style=\"{$ist}\"></div>";
                }
            }
            $bg  = lp_e($b['bg'] ?? '#f8fafc');
            $ttl = lp_e($b['title'] ?? 'Get Started');
            $btn = lp_e($b['submitText'] ?? 'Submit');
            return $wrap("<div id=\"lp-form\" style=\"background:{$bg};border-radius:12px;padding:24px;border:1.5px solid #e2e8f0;\"><div style=\"font-size:1.1rem;font-weight:700;color:#0f172a;margin-bottom:16px;text-align:center;\">{$ttl}</div>{$err}<form method=\"POST\" action=\"\"><input type=\"hidden\" name=\"lp_submit\" value=\"1\">{$fhtml}<button type=\"submit\" style=\"width:100%;padding:14px;background:#2563eb;color:#fff;font-weight:800;font-size:.95rem;border:none;border-radius:8px;cursor:pointer;font-family:inherit;\">{$btn}</button></form></div>");
        }

        // ── Social proof ──────────────────────────────────────
        case 'testimonial':
            return $wrap("<div style=\"background:#f8fafc;border-left:4px solid " . lp_e($b['color'] ?? '#2563eb') . ";border-radius:0 12px 12px 0;padding:24px 28px;max-width:700px;margin:0 auto;\"><p style=\"font-size:1.05rem;color:#1e293b;line-height:1.7;margin:0 0 16px;font-style:italic;\">&ldquo;" . lp_e($b['quote'] ?? '') . "&rdquo;</p><div style=\"font-size:.85rem;font-weight:700;color:#0f172a;\">" . lp_e($b['author'] ?? '') . "</div><div style=\"font-size:.78rem;color:#64748b;\">" . lp_e($b['role'] ?? '') . "</div></div>");
        case 'trust_badges': {
            $bgs = '';
            foreach ((array)($b['badges'] ?? []) as $bg) {
                $bgs .= "<span style=\"display:inline-flex;align-items:center;gap:6px;padding:8px 14px;background:#f0fdf4;border:1.5px solid #86efac;color:#15803d;border-radius:8px;font-size:.8rem;font-weight:600;\">&#10003; " . lp_e($bg) . "</span>";
            }
            return $wrap("<div style=\"display:flex;flex-wrap:wrap;gap:10px;justify-content:center;\">{$bgs}</div>");
        }
        case 'reviews': {
            $stars = str_repeat('<span style="color:#f59e0b;">&#9733;</span>', 5);
            $items_r = '';
            foreach ((array)($b['reviews'] ?? []) as $r) {
                $items_r .= "<div style=\"background:#fff;border:1.5px solid #e2e8f0;border-radius:12px;padding:20px;\">{$stars}<p style=\"font-size:.88rem;color:#475569;line-height:1.6;margin:10px 0;font-style:italic;\">&ldquo;" . lp_e($r['text'] ?? '') . "&rdquo;</p><div style=\"font-size:.8rem;font-weight:700;color:#0f172a;\">" . lp_e($r['author'] ?? '') . "</div></div>";
            }
            return $wrap("<div style=\"display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px;\">{$items_r}</div>");
        }

        // ── Marketing ─────────────────────────────────────────
        case 'offer_banner':
            return "<div style=\"padding:{$pad}px 32px;background:linear-gradient(135deg," . lp_e($b['bg1'] ?? '#2563eb') . "," . lp_e($b['bg2'] ?? '#7c3aed') . ");text-align:center;{$block_style}\"><div style=\"font-size:1.3rem;font-weight:900;color:#fff;margin-bottom:6px;\">" . lp_e($b['headline'] ?? '') . "</div><div style=\"font-size:.95rem;color:rgba(255,255,255,.85);\">" . lp_e($b['text'] ?? '') . "</div></div>";
        case 'announcement_bar':
            return "<div style=\"padding:12px 32px;background:" . lp_e($b['bgColor'] ?? '#2563eb') . ";text-align:center;{$block_style}\"><span style=\"color:" . lp_e($b['textColor'] ?? '#fff') . ";font-size:.88rem;font-weight:600;\">" . lp_e($b['text'] ?? '') . "</span>" . (!empty($b['linkText']) ? " <a href=\"" . lp_e($b['linkUrl'] ?? '#') . "\" style=\"color:#fff;font-weight:800;margin-left:8px;text-decoration:underline;\">" . lp_e($b['linkText']) . "</a>" : '') . "</div>";
        case 'countdown': {
            $target = lp_e($b['targetDate'] ?? date('Y-m-d', strtotime('+7 days')));
            $bid    = preg_replace('/[^a-z0-9]/', '', $b['id'] ?? 'cd');
            $label  = lp_e($b['label'] ?? 'Offer ends in:');
            $unit   = function($k, $lbl) use ($bid) {
                return "<div style=\"text-align:center;min-width:64px;\"><div id=\"cd_{$bid}_{$k}\" style=\"font-size:2rem;font-weight:900;color:#0f172a;\">00</div><div style=\"font-size:.65rem;text-transform:uppercase;color:#94a3b8;letter-spacing:.05em;\">{$lbl}</div></div>";
            };
            $sep    = "<div style=\"font-size:2rem;font-weight:900;color:#94a3b8;padding:0 4px;\">:</div>";
            $timer  = $unit('d','Days') . $sep . $unit('h','Hours') . $sep . $unit('m','Min') . $sep . $unit('s','Sec');
            $js     = "<script>(function(){var t=new Date('{$target}');function tick(){var d=t-new Date();if(d<=0)return;var v=[Math.floor(d/86400000),Math.floor((d%86400000)/3600000),Math.floor((d%3600000)/60000),Math.floor((d%60000)/1000)];['d','h','m','s'].forEach(function(k,i){var el=document.getElementById('cd_{$bid}_'+k);if(el)el.textContent=String(v[i]).padStart(2,'0');});}tick();setInterval(tick,1000);})();</script>";
            return $wrap("<div style=\"text-align:center;\"><div style=\"font-size:.85rem;font-weight:600;color:#64748b;margin-bottom:12px;\">{$label}</div><div style=\"display:inline-flex;align-items:flex-start;gap:4px;\">{$timer}</div>{$js}</div>");
        }
        case 'pricing': {
            $feats = '';
            foreach ((array)($b['features'] ?? []) as $f) {
                $feats .= "<li style=\"padding:6px 0;border-bottom:1px solid #f1f5f9;font-size:.85rem;color:#475569;\">&#10003; " . lp_e($f) . "</li>";
            }
            $bg2 = lp_e($b['btnBg'] ?? '#2563eb');
            return $wrap("<div style=\"max-width:340px;margin:0 auto;border:2px solid {$bg2};border-radius:16px;overflow:hidden;text-align:center;\"><div style=\"background:{$bg2};padding:20px;\"><div style=\"font-size:1rem;font-weight:700;color:#fff;\">" . lp_e($b['name'] ?? '') . "</div></div><div style=\"padding:24px;\"><div style=\"font-size:2.8rem;font-weight:900;color:#0f172a;\">\$" . lp_e($b['price'] ?? '0') . "</div><div style=\"font-size:.8rem;color:#94a3b8;margin-bottom:16px;\">per " . lp_e($b['period'] ?? 'month') . "</div><ul style=\"list-style:none;padding:0;margin:0 0 20px;text-align:left;\">{$feats}</ul><a href=\"#lp-form\" style=\"display:block;padding:12px;background:{$bg2};color:#fff;font-weight:700;font-size:.9rem;border-radius:8px;text-decoration:none;\">" . lp_e($b['btnText'] ?? 'Get Started') . "</a></div></div>");
        }
        case 'faq': {
            $items_faq = '';
            foreach ((array)($b['items'] ?? []) as $i => $item) {
                $fid = preg_replace('/[^a-z0-9]/', '', $b['id'] ?? 'faq') . "_{$i}";
                $items_faq .= "<div style=\"border-bottom:1px solid #e2e8f0;\"><div onclick=\"(function(){var a=document.getElementById('fa_{$fid}');a.style.display=a.style.display==='none'?'block':'none';})()\" style=\"display:flex;justify-content:space-between;align-items:center;padding:14px 4px;cursor:pointer;font-size:.92rem;font-weight:600;color:#1e293b;gap:12px;user-select:none;\"><span>" . lp_e($item['q'] ?? '') . "</span><span style=\"color:#94a3b8;\">&#9660;</span></div><div id=\"fa_{$fid}\" style=\"display:none;font-size:.88rem;color:#475569;line-height:1.7;padding:0 4px 14px;\">" . lp_e($item['a'] ?? '') . "</div></div>";
            }
            $ttl_faq = !empty($b['title']) ? "<div style=\"text-align:center;font-size:1.1rem;font-weight:800;color:#0f172a;margin-bottom:20px;\">" . lp_e($b['title']) . "</div>" : '';
            return $wrap("{$ttl_faq}<div style=\"max-width:640px;margin:0 auto;\">{$items_faq}</div>");
        }
        case 'progress_bars': {
            $bars = '';
            foreach ((array)($b['items'] ?? []) as $it) {
                $pct = min(100, max(0, (int)($it['value'] ?? 0)));
                $bars .= "<div style=\"margin-bottom:16px;\"><div style=\"display:flex;justify-content:space-between;font-size:.82rem;font-weight:600;color:#475569;margin-bottom:6px;\"><span>" . lp_e($it['label'] ?? '') . "</span><span>{$pct}%</span></div><div style=\"background:#f1f5f9;border-radius:999px;height:8px;overflow:hidden;\"><div style=\"width:{$pct}%;background:" . lp_e($it['color'] ?? '#2563eb') . ";height:100%;border-radius:999px;\"></div></div></div>";
            }
            $hl_pb = !empty($b['headline']) ? "<h3 style=\"font-size:1.1rem;font-weight:700;color:#0f172a;margin-bottom:20px;\">" . lp_e($b['headline']) . "</h3>" : '';
            return $wrap("{$hl_pb}{$bars}");
        }

        // ── Layout ────────────────────────────────────────────
        case 'hero_section': {
            $bg_h = !empty($b['bgImage'])
                ? "background-image:url('" . lp_e($b['bgImage']) . "');background-size:cover;background-position:center;"
                : "background:" . lp_e($b['bgColor'] ?? '#1e293b') . ";";
            $ov_h = !empty($b['overlayColor']) ? "<div style=\"position:absolute;inset:0;background:" . lp_e($b['overlayColor']) . ";\"></div>" : '';
            $tc_h = "<div><h1 style=\"font-size:" . lp_e($b['headlineSize'] ?? '2.8rem') . ";font-weight:900;line-height:1.1;margin:0 0 16px;color:#fff;\">" . lp_e($b['headline'] ?? '') . "</h1><p style=\"font-size:1.1rem;opacity:.85;color:#fff;margin:0 0 28px;line-height:1.6;\">" . lp_e($b['subheadline'] ?? '') . "</p><a href=\"" . lp_e($b['btnUrl'] ?? '#') . "\" style=\"display:inline-block;padding:14px 32px;background:" . lp_e($b['btnBg'] ?? '#2563eb') . ";color:#fff;font-weight:800;font-size:1rem;border-radius:10px;text-decoration:none;\">" . lp_e($b['btnText'] ?? 'Get Started') . "</a></div>";
            $full_h = ($b['layout'] ?? '') === 'full';
            $fc_h   = (!$full_h && !empty($b['showForm'])) ? "<div style=\"background:rgba(255,255,255,.95);border-radius:16px;padding:28px;box-shadow:0 20px 60px rgba(0,0,0,.3);\">" . lp_render_block(array_merge($b, ['type'=>'lead_form']), $fields_data, $form, $submitted, $submit_error, $submit_msg) . "</div>" : '';
            $inner_h = $fc_h ? "<div style=\"display:grid;grid-template-columns:1fr 1fr;gap:40px;align-items:center;max-width:1100px;margin:0 auto;\">{$tc_h}{$fc_h}</div>" : "<div style=\"max-width:760px;margin:0 auto;text-align:center;\">{$tc_h}</div>";
            return "<div style=\"position:relative;min-height:" . (int)($b['minHeight'] ?? 480) . "px;display:flex;align-items:center;{$bg_h}\">{$ov_h}<div style=\"position:relative;z-index:2;width:100%;padding:60px 40px;\">{$inner_h}</div></div>";
        }
        case 'two_col': {
            $img_tc = !empty($b['imgUrl']) ? "<img src=\"" . lp_e($b['imgUrl']) . "\" alt=\"" . lp_e($b['imgAlt'] ?? '') . "\" style=\"width:100%;border-radius:" . (int)($b['imgRadius'] ?? 12) . "px;\">" : "<div style=\"background:#f1f5f9;border-radius:12px;height:300px;display:flex;align-items:center;justify-content:center;color:#94a3b8;\">Image</div>";
            $bl_tc  = '';
            foreach ((array)($b['bullets'] ?? []) as $bx) $bl_tc .= "<li style=\"display:flex;gap:8px;margin-bottom:8px;font-size:.88rem;\"><span style=\"color:#16a34a;font-weight:800;\">&#10003;</span>" . lp_e($bx) . "</li>";
            $eye_tc = !empty($b['eyebrow']) ? "<div style=\"font-size:.72rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:" . lp_e($b['headlineColor'] ?? '#2563eb') . ";margin-bottom:8px;\">" . lp_e($b['eyebrow']) . "</div>" : '';
            $txt_tc = "<div>{$eye_tc}<h2 style=\"font-size:1.8rem;font-weight:800;color:" . lp_e($b['headlineColor'] ?? '#0f172a') . ";margin:0 0 12px;\">" . lp_e($b['headline'] ?? '') . "</h2><p style=\"color:" . lp_e($b['bodyColor'] ?? '#475569') . ";line-height:1.7;margin:0 0 16px;\">" . lp_e($b['body'] ?? '') . "</p>" . ($bl_tc ? "<ul style=\"list-style:none;padding:0;margin:0 0 20px;\">{$bl_tc}</ul>" : '') . (!empty($b['showBtn']) ? "<a href=\"" . lp_e($b['btnUrl'] ?? '#') . "\" style=\"display:inline-block;padding:12px 28px;background:" . lp_e($b['btnBg'] ?? '#2563eb') . ";color:#fff;font-weight:700;border-radius:8px;text-decoration:none;font-size:.9rem;\">" . lp_e($b['btnText'] ?? 'Learn More') . "</a>" : '') . "</div>";
            $left_tc = ($b['imgPosition'] ?? 'right') === 'left';
            $cols_tc = $left_tc ? "{$img_tc}{$txt_tc}" : "{$txt_tc}{$img_tc}";
            return "<div style=\"padding:{$pad}px 40px;background:" . lp_e($b['blockBg'] ?? '#fff') . ";{$block_style}\"><div style=\"display:grid;grid-template-columns:1fr 1fr;gap:" . (int)($b['gap'] ?? 48) . "px;align-items:center;max-width:1100px;margin:0 auto;\">{$cols_tc}</div></div>";
        }
        case 'feature_grid': {
            $cols_fg = (int)($b['cols'] ?? 3);
            $cards_fg = '';
            foreach ((array)($b['items'] ?? []) as $it) {
                $cards_fg .= "<div style=\"background:" . lp_e($b['cardBg'] ?? '#fff') . ";border:1.5px solid " . lp_e($b['cardBorder'] ?? '#e2e8f0') . ";border-radius:14px;padding:24px;\"><div style=\"font-size:1.8rem;margin-bottom:12px;\">" . lp_e($it['icon'] ?? '') . "</div><div style=\"font-size:.95rem;font-weight:700;color:#0f172a;margin-bottom:8px;\">" . lp_e($it['title'] ?? '') . "</div><div style=\"font-size:.82rem;color:#64748b;line-height:1.6;\">" . lp_e($it['desc'] ?? '') . "</div></div>";
            }
            $hl_fg  = !empty($b['headline'])    ? "<h2 style=\"font-size:1.6rem;font-weight:800;color:#0f172a;text-align:center;margin-bottom:8px;\">" . lp_e($b['headline']) . "</h2>" : '';
            $sub_fg = !empty($b['subheadline']) ? "<p style=\"font-size:1rem;color:#64748b;text-align:center;margin-bottom:28px;\">" . lp_e($b['subheadline']) . "</p>" : '';
            return "<div style=\"padding:{$pad}px 40px;background:" . lp_e($b['bgColor'] ?? '#fff') . ";{$block_style}\">{$hl_fg}{$sub_fg}<div style=\"display:grid;grid-template-columns:repeat({$cols_fg},1fr);gap:20px;max-width:1100px;margin:0 auto;\">{$cards_fg}</div></div>";
        }
        case 'stats_row': {
            $items_sr = '';
            foreach ((array)($b['items'] ?? []) as $it) {
                $items_sr .= "<div style=\"text-align:center;padding:20px;\"><div style=\"font-size:2.4rem;font-weight:900;color:" . lp_e($b['numColor'] ?? '#0f172a') . ";line-height:1;\">" . lp_e($it['number'] ?? '') . "</div><div style=\"font-size:.8rem;color:#94a3b8;margin-top:6px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;\">" . lp_e($it['label'] ?? '') . "</div></div>";
            }
            return "<div style=\"padding:{$pad}px 40px;background:" . lp_e($b['bgColor'] ?? '#f8fafc') . ";{$block_style}\"><div style=\"display:flex;flex-wrap:wrap;justify-content:center;max-width:900px;margin:0 auto;\">{$items_sr}</div></div>";
        }
        case 'nav_bar': {
            $links_nb = '';
            foreach ((array)($b['links'] ?? []) as $l) {
                $links_nb .= "<a href=\"" . lp_e($l['url'] ?? '#') . "\" style=\"text-decoration:none;color:" . lp_e($b['textColor'] ?? '#475569') . ";font-size:.88rem;font-weight:500;\">" . lp_e($l['label'] ?? '') . "</a>";
            }
            $cta_nb = !empty($b['ctaText']) ? "<a href=\"" . lp_e($b['ctaUrl'] ?? '#') . "\" style=\"padding:9px 20px;background:" . lp_e($b['ctaBg'] ?? '#2563eb') . ";color:#fff;border-radius:8px;text-decoration:none;font-size:.82rem;font-weight:700;\">" . lp_e($b['ctaText']) . "</a>" : '';
            return "<nav style=\"padding:16px 40px;background:" . lp_e($b['bgColor'] ?? '#fff') . ";border-bottom:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;gap:20px;\"><a href=\"#\" style=\"font-weight:900;font-size:1.1rem;color:#0f172a;text-decoration:none;\">" . lp_e($b['brand'] ?? 'Brand') . "</a><div style=\"display:flex;align-items:center;gap:24px;\">{$links_nb}{$cta_nb}</div></nav>";
        }
        case 'footer_block': {
            $cols_fb = '';
            foreach ((array)($b['columns'] ?? []) as $col) {
                $col_links_fb = '';
                foreach ((array)($col['links'] ?? []) as $l) {
                    $col_links_fb .= "<a href=\"" . lp_e($l['url'] ?? '#') . "\" style=\"display:block;color:" . lp_e($b['textColor'] ?? '#94a3b8') . ";text-decoration:none;font-size:.82rem;padding:3px 0;\">" . lp_e($l['label'] ?? '') . "</a>";
                }
                $cols_fb .= "<div><div style=\"font-weight:700;color:" . lp_e($b['brandColor'] ?? '#fff') . ";font-size:.82rem;margin-bottom:10px;text-transform:uppercase;letter-spacing:.05em;\">" . lp_e($col['title'] ?? '') . "</div>{$col_links_fb}</div>";
            }
            $ncols = count((array)($b['columns'] ?? []));
            return "<footer style=\"padding:40px;background:" . lp_e($b['bgColor'] ?? '#0f172a') . ";\"><div style=\"max-width:1100px;margin:0 auto;\"><div style=\"display:grid;grid-template-columns:2fr " . str_repeat('1fr ', $ncols) . ";gap:32px;margin-bottom:32px;\"><div><div style=\"font-weight:900;font-size:1.2rem;color:" . lp_e($b['brandColor'] ?? '#fff') . ";margin-bottom:8px;\">" . lp_e($b['brand'] ?? '') . "</div><p style=\"font-size:.82rem;color:" . lp_e($b['textColor'] ?? '#94a3b8') . ";line-height:1.6;margin:0;\">" . lp_e($b['description'] ?? '') . "</p></div>{$cols_fb}</div><div style=\"border-top:1px solid rgba(255,255,255,.08);padding-top:20px;font-size:.78rem;color:" . lp_e($b['textColor'] ?? '#94a3b8') . ";\">" . lp_e($b['copyright'] ?? '') . "</div></div></footer>";
        }
        case 'contact_info': {
            $items_ci = '';
            foreach ((array)($b['items'] ?? []) as $it) {
                $items_ci .= "<div style=\"display:flex;align-items:flex-start;gap:12px;padding:12px;background:#fff;border:1.5px solid #e2e8f0;border-radius:10px;\"><span style=\"font-size:1.2rem;\">" . lp_e($it['icon'] ?? '') . "</span><div><div style=\"font-size:.72rem;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.05em;\">" . lp_e($it['label'] ?? '') . "</div><div style=\"font-size:.88rem;color:#0f172a;font-weight:600;\">" . lp_e($it['value'] ?? '') . "</div></div></div>";
            }
            $hl_ci = !empty($b['headline']) ? "<h3 style=\"font-size:1.2rem;font-weight:800;color:#0f172a;margin-bottom:16px;\">" . lp_e($b['headline']) . "</h3>" : '';
            return $wrap("{$hl_ci}<div style=\"display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;\">{$items_ci}</div>");
        }
        case 'social_links': {
            $btns_sl = '';
            foreach ((array)($b['items'] ?? []) as $it) {
                $btns_sl .= "<a href=\"" . lp_e($it['url'] ?? '#') . "\" target=\"_blank\" style=\"display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:10px;background:" . lp_e($it['bg'] ?? '#2563eb') . ";color:" . lp_e($it['color'] ?? '#fff') . ";font-weight:900;font-size:.82rem;text-decoration:none;\">" . lp_e($it['icon'] ?? '') . "</a>";
            }
            $lbl_sl = !empty($b['label']) ? "<div style=\"font-size:.82rem;font-weight:600;color:#475569;margin-bottom:10px;\">" . lp_e($b['label']) . "</div>" : '';
            return $wrap("<div style=\"text-align:center;\">{$lbl_sl}<div style=\"display:flex;gap:8px;justify-content:center;\">{$btns_sl}</div></div>");
        }

        // ── Interactive ───────────────────────────────────────
        case 'map_embed':
            if (empty($b['embedUrl'])) return '';
            return $wrap("<div style=\"border-radius:12px;overflow:hidden;\"><iframe src=\"" . lp_e($b['embedUrl']) . "\" width=\"100%\" height=\"" . (int)($b['height'] ?? 400) . "\" style=\"border:none;\" loading=\"lazy\" allowfullscreen></iframe>" . (!empty($b['label']) ? "<div style=\"font-size:.82rem;color:#64748b;text-align:center;margin-top:8px;\">" . lp_e($b['label']) . "</div>" : '') . "</div>");
        case 'image_gallery': {
            $cols_ig = (int)($b['cols'] ?? 3);
            $imgs_ig = '';
            foreach ((array)($b['images'] ?? []) as $img_url) {
                $imgs_ig .= "<img src=\"" . lp_e($img_url) . "\" style=\"width:100%;aspect-ratio:4/3;object-fit:cover;border-radius:8px;\" loading=\"lazy\">";
            }
            return $wrap("<div style=\"display:grid;grid-template-columns:repeat({$cols_ig},1fr);gap:12px;\">{$imgs_ig}</div>");
        }
        case 'tabs_widget': {
            $btns_tw = ''; $panes_tw = '';
            foreach ((array)($b['tabs'] ?? []) as $i => $tab) {
                $active_tw = ($i === 0);
                $bid_tw    = preg_replace('/[^a-z0-9]/', '', $b['id'] ?? 'tab') . "_{$i}";
                $bc        = $active_tw ? '#2563eb' : 'transparent';
                $fw        = $active_tw ? '700' : '500';
                $fc        = $active_tw ? '#2563eb' : '#64748b';
                $btns_tw  .= "<button onclick='lpPubTab(\"{$bid_tw}\",{$i},this)' id='tbb_{$bid_tw}' style='padding:9px 18px;border:none;border-bottom:2px solid {$bc};background:transparent;font-size:.85rem;font-weight:{$fw};color:{$fc};cursor:pointer;white-space:nowrap;'>" . lp_e($tab['label'] ?? '') . "</button>";
                $panes_tw .= "<div id='tbp_{$bid_tw}' style='" . ($active_tw ? '' : 'display:none;') . "padding:20px 4px;font-size:.9rem;color:#475569;line-height:1.7;'>" . lp_e($tab['content'] ?? '') . "</div>";
            }
            return $wrap("<div style='display:flex;border-bottom:1px solid #e2e8f0;overflow-x:auto;'>{$btns_tw}</div>{$panes_tw}");
        }
        case 'counter_widget': {
            $items_cnt = '';
            foreach ((array)($b['items'] ?? []) as $idx => $it) {
                $bid_cnt    = preg_replace('/[^a-z0-9]/', '', $b['id'] ?? 'cnt') . "_{$idx}";
                $items_cnt .= "<div style='text-align:center;padding:24px 16px;'><div class='lp-counter' id='{$bid_cnt}' data-target='" . lp_e($it['number'] ?? 0) . "' data-suffix='" . lp_e($it['suffix'] ?? '') . "' style='font-size:2.4rem;font-weight:900;color:" . lp_e($b['color'] ?? '#2563eb') . ";line-height:1;'>0</div><div style='font-size:.8rem;color:#94a3b8;margin-top:6px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;'>" . lp_e($it['label'] ?? '') . "</div></div>";
            }
            return "<div style='padding:" . (int)($b['padding'] ?? 20) . "px 0;background:" . lp_e($b['blockBg'] ?? '#fff') . ";'><div style='display:flex;flex-wrap:wrap;justify-content:center;max-width:900px;margin:0 auto;'>{$items_cnt}</div></div>";
        }
        case 'timeline_widget': {
            $tl = '';
            foreach ((array)($b['items'] ?? []) as $it) {
                $dc = lp_e($b['dotColor'] ?? '#2563eb');
                $tl .= "<div style='position:relative;margin-bottom:28px;'><div style='position:absolute;left:-24px;top:4px;width:12px;height:12px;border-radius:50%;background:{$dc};border:2px solid #fff;box-shadow:0 0 0 2px {$dc};'></div>" . (!empty($it['date']) ? "<div style='font-size:.72rem;font-weight:700;color:#94a3b8;margin-bottom:4px;text-transform:uppercase;letter-spacing:.05em;'>" . lp_e($it['date']) . "</div>" : '') . "<div style='font-size:.95rem;font-weight:700;color:#0f172a;margin-bottom:4px;'>" . lp_e($it['title'] ?? '') . "</div><div style='font-size:.85rem;color:#475569;line-height:1.6;'>" . lp_e($it['desc'] ?? '') . "</div></div>";
            }
            $hl_tl = !empty($b['headline']) ? "<h2 style='font-size:1.6rem;font-weight:800;color:#0f172a;margin-bottom:28px;'>" . lp_e($b['headline']) . "</h2>" : '';
            return $wrap("{$hl_tl}<div style='position:relative;padding-left:28px;max-width:640px;'><div style='position:absolute;left:9px;top:0;bottom:0;width:2px;background:#e2e8f0;'></div>{$tl}</div>");
        }
        case 'carousel_widget': {
            $cols_cw = (int)($b['cols'] ?? 3);
            $cards_cw = '';
            foreach ((array)($b['items'] ?? []) as $it) {
                $cards_cw .= "<div style='flex-shrink:0;width:calc(100%/{$cols_cw} - 14px);background:#fff;border-radius:14px;border:1.5px solid #e2e8f0;padding:24px;'><div style='font-size:1.6rem;margin-bottom:12px;'>" . lp_e($it['icon'] ?? '') . "</div><div style='font-size:.95rem;font-weight:700;color:#0f172a;margin-bottom:8px;'>" . lp_e($it['title'] ?? '') . "</div><div style='font-size:.82rem;color:#64748b;line-height:1.6;'>" . lp_e($it['desc'] ?? '') . "</div>" . (!empty($it['name']) ? "<div style='font-size:.78rem;font-weight:700;color:#0f172a;margin-top:12px;'>" . lp_e($it['name']) . "</div>" : '') . (!empty($it['role']) ? "<div style='font-size:.72rem;color:#94a3b8;'>" . lp_e($it['role']) . "</div>" : '') . "</div>";
            }
            $cid_cw = preg_replace('/[^a-z0-9]/', '', $b['id'] ?? 'cr');
            $hl_cw  = !empty($b['headline']) ? "<h2 style='font-size:1.6rem;font-weight:800;color:#0f172a;text-align:center;margin-bottom:28px;'>" . lp_e($b['headline']) . "</h2>" : '';
            return "<div style='padding:" . (int)($b['padding'] ?? 40) . "px 40px;background:" . lp_e($b['blockBg'] ?? '#fff') . ";overflow:hidden;'>{$hl_cw}<div id='lpcr_{$cid_cw}' style='overflow:hidden;'><div id='lpct_{$cid_cw}' style='display:flex;gap:20px;transition:transform .35s ease;'>{$cards_cw}</div></div><div style='display:flex;justify-content:center;gap:10px;margin-top:16px;'><button onclick='lpPubCarousel(\"{$cid_cw}\",-1)' style='padding:8px 16px;border-radius:8px;border:1.5px solid #e2e8f0;background:#fff;cursor:pointer;font-size:.8rem;font-weight:600;'>&#8249; Prev</button><button onclick='lpPubCarousel(\"{$cid_cw}\",1)' style='padding:8px 16px;border-radius:8px;border:1.5px solid #e2e8f0;background:#fff;cursor:pointer;font-size:.8rem;font-weight:600;'>Next &#8250;</button></div></div>";
        }
        case 'image_slider': {
            $imgs_sl = (array)($b['images'] ?? []);
            $h_sl    = (int)($b['height'] ?? 420);
            $r_sl    = (int)($b['radius'] ?? 12);
            $sid_sl  = preg_replace('/[^a-z0-9]/', '', $b['id'] ?? 'sl');
            $slides_sl = '';
            foreach ($imgs_sl as $u) $slides_sl .= "<div style='flex-shrink:0;width:100%;'><img src='" . lp_e($u) . "' style='width:100%;height:{$h_sl}px;object-fit:cover;' loading='lazy'></div>";
            $dots_sl = '';
            foreach (array_keys($imgs_sl) as $di) $dots_sl .= "<button onclick='lpPubSlide(\"{$sid_sl}\",{$di})' id='lpdot_{$sid_sl}_{$di}' style='width:8px;height:8px;border-radius:50%;border:none;background:" . ($di === 0 ? '#2563eb' : '#cbd5e1') . ";cursor:pointer;padding:0;'></button>";
            $auto_sl = (!empty($b['autoplay']) && count($imgs_sl) > 1) ? "<script>setInterval(function(){lpPubSlideStep('{$sid_sl}',1)},4000);</script>" : '';
            return "<div><div style='position:relative;overflow:hidden;border-radius:{$r_sl}px;height:{$h_sl}px;' id='lps_{$sid_sl}'><div id='lpst_{$sid_sl}' style='display:flex;transition:transform .4s ease;height:100%;'>{$slides_sl}</div><button onclick='lpPubSlideStep(\"{$sid_sl}\",-1)' style='position:absolute;left:10px;top:50%;transform:translateY(-50%);background:rgba(0,0,0,.5);color:#fff;border:none;width:36px;height:36px;border-radius:50%;cursor:pointer;font-size:1.1rem;z-index:2;'>&#8249;</button><button onclick='lpPubSlideStep(\"{$sid_sl}\",1)' style='position:absolute;right:10px;top:50%;transform:translateY(-50%);background:rgba(0,0,0,.5);color:#fff;border:none;width:36px;height:36px;border-radius:50%;cursor:pointer;font-size:1.1rem;z-index:2;'>&#8250;</button></div><div style='display:flex;gap:6px;justify-content:center;margin-top:10px;'>{$dots_sl}</div>{$auto_sl}</div>";
        }
        case 'bg_video':
            return "<div style='position:relative;overflow:hidden;min-height:" . (int)($b['minHeight'] ?? 400) . "px;display:flex;align-items:center;'><video autoplay muted loop playsinline style='position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:0;'><source src='" . lp_e($b['videoUrl'] ?? '') . "' type='video/mp4'></video><div style='position:absolute;inset:0;background:" . lp_e($b['overlayColor'] ?? 'rgba(0,0,0,0.5)') . ";z-index:1;'></div><div style='position:relative;z-index:2;width:100%;padding:60px 40px;text-align:center;'>" . (!empty($b['headline']) ? "<h2 style='font-size:2.5rem;font-weight:900;color:#fff;margin:0 0 14px;'>" . lp_e($b['headline']) . "</h2>" : '') . (!empty($b['subheadline']) ? "<p style='font-size:1.1rem;color:rgba(255,255,255,.85);margin:0 0 24px;'>" . lp_e($b['subheadline']) . "</p>" : '') . (!empty($b['btnText']) ? "<a href='" . lp_e($b['btnUrl'] ?? '#') . "' style='display:inline-block;padding:14px 32px;background:" . lp_e($b['btnBg'] ?? '#fff') . ";color:" . lp_e($b['btnColor'] ?? '#0f172a') . ";font-weight:800;font-size:1rem;border-radius:10px;text-decoration:none;'>" . lp_e($b['btnText']) . "</a>" : '') . "</div></div>";
        case 'icon_widget':
            return $wrap("<div style='display:flex;align-items:center;justify-content:" . lp_e($b['align'] ?? 'center') . ";'><span style='font-size:" . lp_e($b['size'] ?? '3rem') . ";color:" . lp_e($b['color'] ?? '#2563eb') . ";'>" . lp_e($b['icon'] ?? '') . "</span></div>");
        case 'badge_widget':
            return "<div style='text-align:" . lp_e($b['align'] ?? 'left') . ";padding:" . (int)($b['padding'] ?? 10) . "px;'><span style='display:inline-flex;align-items:center;background:" . lp_e($b['bg'] ?? '#eff6ff') . ";color:" . lp_e($b['color'] ?? '#2563eb') . ";font-size:" . lp_e($b['size'] ?? '.82rem') . ";font-weight:700;padding:" . (int)($b['py'] ?? 5) . "px " . (int)($b['px'] ?? 14) . "px;border-radius:" . lp_e($b['radius'] ?? '999px') . ";'>" . lp_e($b['text'] ?? 'Badge') . "</span></div>";
        case 'newsletter_bar': {
            $bg_nl   = lp_e($b['bgColor'] ?? '#f8fafc');
            $hl_nl   = !empty($b['headline'])    ? "<div style='font-size:1.3rem;font-weight:800;color:#0f172a;text-align:center;margin-bottom:8px;'>" . lp_e($b['headline']) . "</div>" : '';
            $sub_nl  = !empty($b['subheadline']) ? "<div style='font-size:.9rem;color:#64748b;text-align:center;margin-bottom:20px;'>" . lp_e($b['subheadline']) . "</div>" : '';
            return "<div style='padding:" . (int)($b['padding'] ?? 40) . "px 40px;background:{$bg_nl};'>{$hl_nl}{$sub_nl}<form method='POST' action='' style='display:flex;flex-wrap:wrap;gap:10px;align-items:center;max-width:560px;margin:0 auto;'><input type='hidden' name='lp_submit' value='1'><input type='email' name='email' placeholder='" . lp_e($b['placeholder'] ?? 'Enter your email') . "' required style='flex:1;min-width:220px;padding:12px 16px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:.9rem;'><button type='submit' style='padding:12px 24px;background:" . lp_e($b['btnBg'] ?? '#2563eb') . ";color:" . lp_e($b['btnColor'] ?? '#fff') . ";border:none;border-radius:8px;font-weight:700;font-size:.88rem;cursor:pointer;'>" . lp_e($b['btnText'] ?? 'Subscribe') . "</button></form></div>";
        }
        case 'raw_html':
            return $b['html'] ?? '';
        default:
            return '';
    }
}

// ── Render page ──────────────────────────────────────────────
$meta_title = $page['meta_title'] ?: $page['title'];
$meta_desc  = $page['meta_desc']  ?: ($page['campaign_name'] . ' — ' . $page['title']);
$og_image   = $page['og_image']   ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($meta_title, ENT_QUOTES, 'UTF-8') ?></title>
<meta name="description" content="<?= htmlspecialchars($meta_desc, ENT_QUOTES, 'UTF-8') ?>">
<meta property="og:title" content="<?= htmlspecialchars($meta_title, ENT_QUOTES, 'UTF-8') ?>">
<meta property="og:description" content="<?= htmlspecialchars($meta_desc, ENT_QUOTES, 'UTF-8') ?>">
<?php if ($og_image): ?>
<meta property="og:image" content="<?= htmlspecialchars($og_image, ENT_QUOTES, 'UTF-8') ?>">
<?php endif; ?>
<meta property="og:type" content="website">
<meta name="twitter:card" content="<?= $og_image ? 'summary_large_image' : 'summary' ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;}
body{margin:0;padding:0;font-family:'Sora',sans-serif;background:#fff;color:#0f172a;}
img{max-width:100%;height:auto;}
input,select,textarea,button{font-family:inherit;}
input:focus,select:focus,textarea:focus{border-color:#2563eb!important;outline:none!important;box-shadow:0 0 0 3px rgba(37,99,235,.15)!important;}
.lp-animate{opacity:0;transform:translateY(30px);transition:opacity .6s ease,transform .6s ease;}
.lp-animate.animated{opacity:1;transform:none;}
.lp-animate-left{opacity:0;transform:translateX(-40px);transition:opacity .6s ease,transform .6s ease;}
.lp-animate-left.animated{opacity:1;transform:none;}
.lp-animate-scale{opacity:0;transform:scale(.9);transition:opacity .5s ease,transform .5s ease;}
.lp-animate-scale.animated{opacity:1;transform:none;}
@media(max-width:768px){
  .lp-hide-mobile{display:none!important;}
  h1{font-size:1.6rem!important;}
  [style*="grid-template-columns:1fr 1fr"],[style*="grid-template-columns:repeat(3"],[style*="grid-template-columns:repeat(4"]{grid-template-columns:1fr!important;}
}
@media(min-width:769px) and (max-width:1024px){.lp-hide-tablet{display:none!important;}}
@media(min-width:1025px){.lp-hide-desktop{display:none!important;}}
</style>
</head>
<body>
<?php
foreach ($page_data as $block) {
    try {
        echo lp_render_block($block, $fields, $form, $submitted, $submit_error ?? '', $submit_msg);
    } catch (Throwable $err) {
        error_log('[LeadPro LP] Block render error (' . ($block['type'] ?? '?') . '): ' . $err->getMessage());
    }
}
?>
<script>
var _sliderPos={},_carouselPos={};
function lpPubTab(bid,idx,btn){
  var i=bid.lastIndexOf('_'),prefix=bid.substring(0,i)+'_';
  document.querySelectorAll('[id^="tbb_'+prefix+'"]').forEach(function(b,j){
    b.style.borderBottomColor=j===idx?'#2563eb':'transparent';
    b.style.fontWeight=j===idx?'700':'500';
    b.style.color=j===idx?'#2563eb':'#64748b';
  });
  document.querySelectorAll('[id^="tbp_'+prefix+'"]').forEach(function(p,j){
    p.style.display=j===idx?'':'none';
  });
}
function lpPubSlide(id,idx){
  var track=document.getElementById('lpst_'+id);
  if(!track)return;
  var n=track.children.length,i=((idx%n)+n)%n;
  _sliderPos[id]=i;
  track.style.transform='translateX(-'+(i*100)+'%)';
  document.querySelectorAll('[id^="lpdot_'+id+'_"]').forEach(function(d,j){
    d.style.background=j===i?'#2563eb':'#cbd5e1';
  });
}
function lpPubSlideStep(id,dir){lpPubSlide(id,(_sliderPos[id]||0)+dir);}
function lpPubCarousel(id,dir){
  var track=document.getElementById('lpct_'+id);
  if(!track||!track.children.length)return;
  var cardW=track.children[0].offsetWidth+20;
  var cols=Math.round(track.parentElement.offsetWidth/cardW);
  var max=Math.max(0,track.children.length-cols);
  var next=Math.max(0,Math.min(max,(_carouselPos[id]||0)+dir));
  _carouselPos[id]=next;
  track.style.transform='translateX(-'+(next*cardW)+'px)';
}
(function(){
  if(!window.IntersectionObserver)return;
  var obs=new IntersectionObserver(function(entries){
    entries.forEach(function(e){if(e.isIntersecting){e.target.classList.add('animated');obs.unobserve(e.target);}});
  },{threshold:0.15});
  document.querySelectorAll('.lp-animate,.lp-animate-left,.lp-animate-scale').forEach(function(el){obs.observe(el);});
})();
(function(){
  function run(el){var t=parseInt(el.dataset.target)||0,s=el.dataset.suffix||'',d=2000,st=performance.now();function step(ts){var p=Math.min((ts-st)/d,1),v=1-Math.pow(1-p,3);el.textContent=Math.round(v*t).toLocaleString()+s;if(p<1)requestAnimationFrame(step);}requestAnimationFrame(step);}
  if(window.IntersectionObserver){var o=new IntersectionObserver(function(entries){entries.forEach(function(e){if(e.isIntersecting){run(e.target);o.unobserve(e.target);}});},{threshold:0.3});document.querySelectorAll('.lp-counter').forEach(function(el){o.observe(el);});}
})();
</script>
</body>
</html>
