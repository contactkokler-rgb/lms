<?php
require_once __DIR__ . '/config/auth.php';
$user       = require_permission('leads', 'view');
$account_id = (int)($user['account_id'] ?? 0);
$is_super   = is_super_admin();

$page_title = 'Leads';
$active_nav = 'leads';

$statuses = ['new','contacted','qualified','converted','lost','spam'];

// Trigger reminder scan (throttled to once per 30 min — safe to call every page load)
if (!$is_super && $account_id) {
    try { require_once __DIR__ . '/config/reminders.php'; reminder_process_account($account_id); } catch (\Throwable $e) {}
}
$status_colors = [
    'new'=>'badge-blue','contacted'=>'badge-yellow','qualified'=>'badge-purple',
    'converted'=>'badge-green','lost'=>'badge-gray','spam'=>'badge-red',
];

// ── Filters ──────────────────────────────────────────────────
$filter_status   = $_GET['status']    ?? '';
$filter_domain   = (int)($_GET['domain_id'] ?? 0);
$filter_form     = (int)($_GET['form_id']   ?? 0);
$filter_engagement = in_array($_GET['engagement'] ?? '', ['hot','warm','cold']) ? $_GET['engagement'] : '';
$filter_assigned = (int)($_GET['assigned']  ?? 0);
$filter_mine     = isset($_GET['filter']) && $_GET['filter'] === 'mine';
$filter_dupes    = isset($_GET['dupes']) && $_GET['dupes'] === '1';
$filter_campaign = (int)($_GET['campaign_id'] ?? 0);
$filter_page     = (int)($_GET['page_id']     ?? 0);
$filter_utm_src  = trim($_GET['utm_source']   ?? '');
$search          = trim($_GET['q'] ?? '');
$page            = max(1, (int)($_GET['page'] ?? 1));
$per_page        = 25;

// ── CSV Export ────────────────────────────────────────────────
if (isset($_GET['export']) && $_GET['export'] === 'csv' && can('leads', 'export')) {
    // build same query without pagination
    $ew = []; $et = ''; $ep = [];
    if (!$is_super) { $ew[] = 'l.account_id = ?'; $et .= 'i'; $ep[] = $account_id; }
    if ($filter_mine)    { $ew[] = 'l.assigned_to = ?'; $et .= 'i'; $ep[] = $user['id']; }
    if ($filter_status)  { $ew[] = 'l.status = ?';      $et .= 's'; $ep[] = $filter_status; }
    if ($filter_domain)  { $ew[] = 'l.domain_id = ?';   $et .= 'i'; $ep[] = $filter_domain; }
    if ($filter_form)    { $ew[] = 'l.form_id = ?';     $et .= 'i'; $ep[] = $filter_form; }
    $ew_sql = $ew ? 'WHERE '.implode(' AND ', $ew) : '';
    $export_leads = db_fetch_all(
        "SELECT l.reference_no, l.status, l.submitted_at, f.name AS form_name, d.domain,
         CONCAT(ua.first_name,' ',ua.last_name) AS assigned_to, l.utm_source, l.utm_medium, l.utm_campaign, l.source_url
         FROM leads l
         LEFT JOIN lead_forms f ON f.id = l.form_id
         LEFT JOIN domains d ON d.id = l.domain_id
         LEFT JOIN users ua ON ua.id = l.assigned_to
         $ew_sql ORDER BY l.submitted_at DESC", $et, ...$ep);

    // Get all field values
    if ($export_leads) {
        $eids = array_column($export_leads, 'reference_no');
        // we need lead ids — re-query with ids
        $export_with_vals = db_fetch_all(
            "SELECT l.id, l.reference_no FROM leads l $ew_sql ORDER BY l.submitted_at DESC", $et, ...$ep);
        $all_ids = array_column($export_with_vals, 'id');
        $field_vals = [];
        if ($all_ids) {
            $ph = implode(',', array_fill(0, count($all_ids), '?'));
            $rows = db_fetch_all("SELECT lv.lead_id, lv.field_label, lv.value FROM lead_values lv WHERE lv.lead_id IN ($ph) ORDER BY lv.lead_id, lv.id", str_repeat('i',count($all_ids)), ...$all_ids);
            foreach ($rows as $r) $field_vals[$r['lead_id']][] = [$r['field_label'], $r['value']];
        }
    }

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="leads-' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Reference','Status','Form','Domain','Assigned To','Source','UTM Source','UTM Medium','UTM Campaign','Submitted At','Fields...']);
    foreach ($export_leads as $i => $el) {
        $lid = $all_ids[$i] ?? null;
        $fv  = $lid ? ($field_vals[$lid] ?? []) : [];
        $row = [$el['reference_no'], $el['status'], $el['form_name'], $el['domain'],
                trim($el['assigned_to'] ?? ''), $el['source_url'], $el['utm_source'],
                $el['utm_medium'], $el['utm_campaign'], $el['submitted_at']];
        foreach ($fv as [$lbl,$val]) { $row[] = "$lbl: $val"; }
        fputcsv($out, $row);
    }
    fclose($out);
    exit;
}

// ── Actions ──────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { http_response_code(403); die('CSRF'); }
    $act = $_POST['action'] ?? '';

    if ($act === 'update_status' && can('leads', 'edit')) {
        $lid    = (int)($_POST['lead_id'] ?? 0);
        $status = in_array($_POST['status'] ?? '', $statuses) ? $_POST['status'] : 'new';
        $where  = $is_super ? 'id=?' : 'id=? AND account_id=?';
        $params = $is_super ? [$lid] : [$lid, $account_id];
        db_query("UPDATE leads SET status=? WHERE $where", 's'.($is_super?'i':'ii'), $status, ...$params);
        audit('lead.status_changed', "lead:{$lid}", ['status'=>$status]);

    } elseif ($act === 'quick_assign' && can('leads', 'assign')) {
        $lid = (int)($_POST['lead_id'] ?? 0);
        $uid = (int)($_POST['user_id'] ?? 0) ?: null;
        $where  = $is_super ? 'id=?' : 'id=? AND account_id=?';
        $params = $is_super ? [$lid] : [$lid, $account_id];

        // Log ownership change
        $prev = db_fetch("SELECT assigned_to, account_id FROM leads WHERE $where", $is_super?'i':'ii', ...$params);
        if ($prev && (int)($prev['assigned_to']??0) !== (int)($uid??0)) {
            try {
                db_insert('INSERT INTO lead_ownership_log (lead_id,account_id,from_user_id,to_user_id,transferred_by,reason) VALUES (?,?,?,?,?,?)',
                    'iiiiis', $lid, (int)($prev['account_id']??$account_id),
                    $prev['assigned_to'] ?: null, $uid ?: null, $user['id'], 'Quick assign');
            } catch (\Throwable $e) { /* table not yet created */ }
        }

        db_query("UPDATE leads SET assigned_to=? WHERE $where", 'i'.($is_super?'i':'ii'), $uid, ...$params);
        audit('lead.assigned', "lead:{$lid}", ['to'=>$uid]);
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Lead assigned.'];

    } elseif ($act === 'bulk_update' && can('leads', 'edit')) {
        $ids         = array_filter(array_map('intval', $_POST['lead_ids'] ?? []));
        $bulk_status = in_array($_POST['bulk_status'] ?? '', array_merge([''],  $statuses)) ? ($_POST['bulk_status']??'') : '';
        $bulk_assign = $_POST['bulk_assign'] ?? '';
        $bulk_uid    = $bulk_assign !== '' ? ((int)$bulk_assign ?: null) : false; // false = don't change
        $bulk_reason = trim($_POST['bulk_transfer_reason'] ?? '');

        if ($ids) {
            $ph = implode(',', array_fill(0, count($ids), '?'));
            $it = str_repeat('i', count($ids));
            $sets = []; $utypes = ''; $uparams = [];
            if ($bulk_status) { $sets[] = 'status=?';      $utypes .= 's'; $uparams[] = $bulk_status; }
            if ($bulk_uid !== false) { $sets[] = 'assigned_to=?'; $utypes .= 'i'; $uparams[] = $bulk_uid; }
            if ($sets) {
                $set_sql = implode(', ', $sets);
                $scope   = $is_super ? '' : " AND account_id=$account_id";
                // Log ownership transfers for each lead
                if ($bulk_uid !== false && can('leads','assign')) {
                    $prev_leads = db_fetch_all("SELECT id, assigned_to, account_id FROM leads WHERE id IN ($ph)$scope", $it, ...$ids);
                    foreach ($prev_leads as $pl) {
                        if ((int)($pl['assigned_to']??0) !== (int)($bulk_uid??0)) {
                            try {
                                db_insert('INSERT INTO lead_ownership_log (lead_id,account_id,from_user_id,to_user_id,transferred_by,reason) VALUES (?,?,?,?,?,?)',
                                    'iiiiis', (int)$pl['id'], (int)($pl['account_id']??$account_id),
                                    $pl['assigned_to'] ?: null, $bulk_uid ?: null, $user['id'],
                                    $bulk_reason ?: 'Bulk transfer');
                            } catch (\Throwable $e) { /* ok */ }
                        }
                    }
                }
                db_query("UPDATE leads SET $set_sql WHERE id IN ($ph)$scope",
                    $utypes.$it, ...array_merge($uparams, $ids));
                $_SESSION['flash'] = ['type'=>'success','msg'=>count($ids).' leads updated.'];
            }
        }

    } elseif ($act === 'delete' && can('leads', 'delete')) {
        $lid    = (int)($_POST['lead_id'] ?? 0);
        $where  = $is_super ? 'id=?' : 'id=? AND account_id=?';
        $params = $is_super ? [$lid] : [$lid, $account_id];
        db_query("DELETE FROM leads WHERE $where", $is_super?'i':'ii', ...$params);
        audit('lead.deleted', "lead:{$lid}");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Lead deleted.'];
    }

    $qs = http_build_query(array_filter(['status'=>$filter_status,'domain_id'=>$filter_domain?:null,
        'form_id'=>$filter_form?:null,'q'=>$search,'page'=>$page>1?$page:null,'filter'=>$filter_mine?'mine':null,
        'campaign_id'=>$filter_campaign?:null,'page_id'=>$filter_page?:null,'utm_source'=>$filter_utm_src?:null]));
    header('Location: '.APP_URL.'/leads.php'.($qs?"?$qs":'')); exit;
}

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);

// Trigger engagement score bulk update (throttled per-account via DB flag)
if (!$is_super && $account_id) {
    try {
        require_once __DIR__ . '/config/engagement.php';
        $eng_lock_key = "eng_last_run_{$account_id}";
        $eng_last = db_fetch('SELECT value FROM platform_settings WHERE `key`=?', 's', $eng_lock_key);
        if (!$eng_last || !$eng_last['value'] || (time() - strtotime($eng_last['value'])) > 1800) {
            db_query('INSERT INTO platform_settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)',
                'ss', $eng_lock_key, date('Y-m-d H:i:s'));
            engagement_update_bulk($account_id, 150);
        }
    } catch (\Throwable $e) {}
}

// ── Query ────────────────────────────────────────────────────
$where = []; $types = ''; $params = [];
if (!$is_super)      { $where[]='l.account_id=?';  $types.='i'; $params[]=$account_id; }
$where[] = 'l.is_deleted = 0';  // Never show soft-deleted leads in main list
if ($filter_mine)    { $where[]='l.assigned_to=?';  $types.='i'; $params[]=$user['id']; }
if ($filter_status)  { $where[]='l.status=?';       $types.='s'; $params[]=$filter_status; }
if ($filter_domain)  { $where[]='l.domain_id=?';    $types.='i'; $params[]=$filter_domain; }
if ($filter_form)    { $where[]='l.form_id=?';      $types.='i'; $params[]=$filter_form; }
if ($filter_assigned){ $where[]='l.assigned_to=?';  $types.='i'; $params[]=$filter_assigned; }
if ($filter_campaign){ $where[]='l.campaign_id=?';  $types.='i'; $params[]=$filter_campaign; }
if ($filter_page)    { $where[]='l.campaign_page_id=?'; $types.='i'; $params[]=$filter_page; }
if ($filter_utm_src) { $where[]='l.utm_source=?';   $types.='s'; $params[]=$filter_utm_src; }
if ($filter_dupes && $_has_dedup_col) { $where[]='l.has_duplicates=1'; }
if ($filter_engagement) {
    $where[] = 'l.engagement_level=?'; $types .= 's'; $params[] = $filter_engagement;
}
if ($search) {
    $where[] = '(l.reference_no LIKE ? OR lv.value LIKE ?)';
    $types .= 'ss'; $s = "%$search%"; $params = array_merge($params, [$s,$s]);
}
$where_sql = $where ? 'WHERE '.implode(' AND ', $where) : '';

$total = (int)(db_fetch(
    "SELECT COUNT(DISTINCT l.id) AS n FROM leads l LEFT JOIN lead_values lv ON lv.lead_id=l.id $where_sql",
    $types, ...$params)['n'] ?? 0);
$pages  = max(1, (int)ceil($total / $per_page));
$page   = min($page, $pages);
$offset = ($page-1) * $per_page;

$leads = db_fetch_all(
    "SELECT l.*, f.name AS form_name, d.domain,
     CONCAT(ua.first_name,' ',ua.last_name) AS assigned_name, ua.id AS assigned_id,
     c.name AS campaign_name, c.id AS campaign_id_val,
     cp.title AS page_title, cp.id AS page_id_val
     FROM leads l
     LEFT JOIN lead_forms f    ON f.id = l.form_id
     LEFT JOIN domains d       ON d.id = l.domain_id
     LEFT JOIN users ua        ON ua.id = l.assigned_to
     LEFT JOIN campaigns c     ON c.id = l.campaign_id
     LEFT JOIN campaign_pages cp ON cp.id = l.campaign_page_id
     LEFT JOIN lead_values lv  ON lv.lead_id = l.id
     $where_sql GROUP BY l.id ORDER BY l.submitted_at DESC LIMIT ? OFFSET ?",
    $types.'ii', ...[...$params, $per_page, $offset]);

// Fetch preview values
$lead_ids = array_column($leads, 'id');
$lead_values = [];
if ($lead_ids) {
    $ph = implode(',', array_fill(0, count($lead_ids), '?'));
    foreach (db_fetch_all("SELECT lv.lead_id, lv.field_label, lv.value FROM lead_values lv WHERE lv.lead_id IN ($ph) ORDER BY lv.lead_id, lv.id", str_repeat('i',count($lead_ids)), ...$lead_ids) as $r) {
        $lead_values[$r['lead_id']][] = $r;
    }
}

// Filter dropdowns
$domains_list = db_fetch_all($is_super ? 'SELECT id,domain FROM domains ORDER BY domain'
    : 'SELECT id,domain FROM domains WHERE account_id=? ORDER BY domain', $is_super?'':'i', ...($is_super?[]:[$account_id]));
$forms_list = db_fetch_all($is_super ? 'SELECT id,name FROM lead_forms ORDER BY name'
    : 'SELECT id,name FROM lead_forms WHERE account_id=? ORDER BY name', $is_super?'':'i', ...($is_super?[]:[$account_id]));
$team_list = db_fetch_all($is_super ? "SELECT id,first_name,last_name FROM users WHERE status='active' ORDER BY first_name"
    : "SELECT id,first_name,last_name FROM users WHERE account_id=? AND status='active' ORDER BY first_name", $is_super?'':'i', ...($is_super?[]:[$account_id]));
$campaigns_list = $is_super ? [] : db_fetch_all(
    "SELECT id, name FROM campaigns WHERE account_id=? AND status != 'archived' ORDER BY name", 'i', $account_id);
$pages_list = ($filter_campaign && !$is_super) ? db_fetch_all(
    "SELECT id, title FROM campaign_pages WHERE campaign_id=? AND account_id=? ORDER BY title",
    'ii', $filter_campaign, $account_id) : [];
$utm_sources_list = $is_super ? [] : db_fetch_all(
    "SELECT DISTINCT utm_source FROM leads WHERE account_id=? AND utm_source != '' ORDER BY utm_source LIMIT 30",
    'i', $account_id);

// Stats — has_duplicates column only exists after migrate_deduplication.sql
$sw = $is_super ? '' : "WHERE account_id=$account_id AND is_deleted=0";
$_has_dedup_col = db()->query("SHOW COLUMNS FROM leads LIKE 'has_duplicates'")->num_rows > 0;
$_dupes_sql = $_has_dedup_col ? ", SUM(has_duplicates=1) AS dupes" : ", 0 AS dupes";
$stats = db_fetch("SELECT COUNT(*) AS total, SUM(status='new') AS new_count, SUM(status='qualified') AS qualified, SUM(status='converted') AS converted{$_dupes_sql} FROM leads $sw") ?? [];

include __DIR__ . '/layouts/header.php';
?>

<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type'] ?>" data-auto-dismiss><?= $flash['msg'] ?></div>
<?php endif; ?>

<div class="page-header">
  <div>
    <h1 class="page-title"><?= $filter_mine ? 'My Leads' : 'All Leads' ?></h1>
    <p class="page-subtitle"><?= number_format($total) ?> lead<?= $total!==1?'s':'' ?><?= $filter_status?' · '.ucfirst($filter_status):'' ?></p>
  </div>
  <?php if (can('leads','export')): ?>
  <a href="?<?= http_build_query(array_merge($_GET,['export'=>'csv'])) ?>" class="btn btn-secondary">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
    Export CSV
  </a>
  <?php endif; ?>
  <?php if (can('leads','create')): ?>
  <a href="<?= APP_URL ?>/import.php" class="btn btn-secondary">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
    Import CSV
  </a>
  <?php endif; ?>
</div>

<!-- Stats -->
<div class="grid grid-4 gap-grid" style="margin-bottom:20px;">
  <?php foreach([
    ['Total',    $stats['total']??0,     '',''],
    ['New',      $stats['new_count']??0, 'badge-blue','new'],
    ['Qualified',$stats['qualified']??0, 'badge-purple','qualified'],
    ['Converted',$stats['converted']??0, 'badge-green','converted'],
  ] as [$lbl,$val,$badge,$s]): ?>
  <a href="?<?= http_build_query(array_filter(['domain_id'=>$filter_domain,'form_id'=>$filter_form,'q'=>$search,'status'=>$s])) ?>" style="text-decoration:none;">
    <div class="stat-card" style="<?= $filter_status===$s&&$s?'border:2px solid var(--brand-400);':'' ?>">
      <div class="stat-value"><?= number_format((int)$val) ?></div>
      <div class="stat-label"><?= $lbl ?></div>
    </div>
  </a>
  <?php endforeach; ?>
  <?php $dupe_count = (int)($stats['dupes']??0); if ($dupe_count > 0 && can('leads','merge')): ?>
  <a href="?dupes=1" style="text-decoration:none;">
    <div class="stat-card" style="<?= isset($_GET['dupes'])?'border:2px solid #f59e0b;':'' ?>border-color:<?= $dupe_count>0?'#fde68a':'var(--gray-100)' ?>;">
      <div class="stat-value" style="color:#d97706;"><?= number_format($dupe_count) ?></div>
      <div class="stat-label" style="display:flex;align-items:center;gap:4px;">
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#d97706" stroke-width="2.5"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/></svg>
        Duplicates
      </div>
    </div>
  </a>
  <?php endif; ?>
</div>

<!-- Filters -->
<div class="card" style="margin-bottom:16px;">
  <div class="card-body" style="padding:12px 16px;">
    <form method="GET" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
      <?php if ($filter_mine): ?><input type="hidden" name="filter" value="mine"><?php endif; ?>
      <div class="search-wrap" style="flex:1;min-width:160px;max-width:240px;">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <input name="q" type="search" placeholder="Search…" value="<?= h($search) ?>" class="search-input">
      </div>
      <select name="status" class="form-control form-control-sm" style="width:130px;" onchange="this.form.submit()">
        <option value="">All statuses</option>
        <?php foreach($statuses as $s): ?><option value="<?=$s?>" <?=$filter_status===$s?'selected':''?>><?=ucfirst($s)?></option><?php endforeach; ?>
      </select>
      <select name="domain_id" class="form-control form-control-sm" style="width:150px;" onchange="this.form.submit()">
        <option value="">All domains</option>
        <?php foreach($domains_list as $d): ?><option value="<?=$d['id']?>" <?=$filter_domain===$d['id']?'selected':''?>><?=h($d['domain'])?></option><?php endforeach; ?>
      </select>
      <select name="form_id" class="form-control form-control-sm" style="width:140px;" onchange="this.form.submit()">
        <option value="">All forms</option>
        <?php foreach($forms_list as $f): ?><option value="<?=$f['id']?>" <?=$filter_form===$f['id']?'selected':''?>><?=h($f['name'])?></option><?php endforeach; ?>
      </select>
      <?php if ($campaigns_list): ?>
      <select name="campaign_id" class="form-control form-control-sm" style="width:150px;" onchange="this.form.submit()">
        <option value="">All campaigns</option>
        <?php foreach($campaigns_list as $c): ?><option value="<?=$c['id']?>" <?=$filter_campaign===$c['id']?'selected':''?>><?=h($c['name'])?></option><?php endforeach; ?>
      </select>
      <?php endif; ?>
      <?php if ($pages_list): ?>
      <select name="page_id" class="form-control form-control-sm" style="width:150px;" onchange="this.form.submit()">
        <option value="">All pages</option>
        <?php foreach($pages_list as $pg): ?><option value="<?=$pg['id']?>" <?=$filter_page===$pg['id']?'selected':''?>><?=h($pg['title'])?></option><?php endforeach; ?>
      </select>
      <?php endif; ?>
      <?php if ($utm_sources_list): ?>
      <select name="utm_source" class="form-control form-control-sm" style="width:130px;" onchange="this.form.submit()">
        <option value="">All sources</option>
        <?php foreach($utm_sources_list as $us): ?><option value="<?=h($us['utm_source'])?>" <?=$filter_utm_src===$us['utm_source']?'selected':''?>><?=h($us['utm_source'])?></option><?php endforeach; ?>
      </select>
      <?php endif; ?>
      <?php if(can('leads','assign')): ?>
      <select name="assigned" class="form-control form-control-sm" style="width:140px;" onchange="this.form.submit()">
        <option value="">All agents</option>
        <option value="-1" <?=$filter_assigned===-1?'selected':''?>>Unassigned</option>
        <?php foreach($team_list as $t): ?><option value="<?=$t['id']?>" <?=$filter_assigned===$t['id']?'selected':''?>><?=h($t['first_name'].' '.$t['last_name'])?></option><?php endforeach; ?>
      </select>
      <?php endif; ?>
      <select name="engagement" class="form-control form-control-sm" style="width:120px;" onchange="this.form.submit()">
        <option value="">All heat</option>
        <option value="hot"  <?= $filter_engagement==='hot'  ?'selected':'' ?>>🔥 Hot</option>
        <option value="warm" <?= $filter_engagement==='warm' ?'selected':'' ?>>🟡 Warm</option>
        <option value="cold" <?= $filter_engagement==='cold' ?'selected':'' ?>>❄️ Cold</option>
      </select>
      <button type="submit" class="btn btn-secondary btn-sm">Go</button>
      <?php if($search||$filter_status||$filter_domain||$filter_form||$filter_assigned||$filter_engagement||$filter_campaign||$filter_page||$filter_utm_src): ?>
      <a href="leads.php<?=$filter_mine?'?filter=mine':''?>" class="btn btn-secondary btn-sm">Clear</a>
      <?php endif; ?>
      <span style="margin-left:auto;font-size:.75rem;color:var(--gray-400);"><?=number_format($total)?> result<?=$total!==1?'s':''?></span>
    </form>
  </div>
</div>

<!-- Bulk form wrapping table -->
<form method="POST" id="bulkForm">
  <?= csrf_field() ?>
  <input type="hidden" name="action" value="bulk_update">

  <!-- Bulk action bar (hidden until rows selected) -->
  <div id="bulkBar" style="display:none;background:#eff6ff;border:1.5px solid #bfdbfe;border-radius:10px;padding:10px 16px;margin-bottom:10px;align-items:center;gap:10px;flex-wrap:wrap;">
    <span id="bulkCount" style="font-size:.8rem;font-weight:600;color:#1d4ed8;min-width:80px;">0 selected</span>
    <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;">
      <select name="bulk_status" class="form-control form-control-sm" style="width:140px;">
        <option value="">Set status…</option>
        <?php foreach($statuses as $s): ?><option value="<?=$s?>"><?=ucfirst($s)?></option><?php endforeach; ?>
      </select>
      <?php if(can('leads','assign')&&$team_list): ?>
      <select name="bulk_assign" class="form-control form-control-sm" style="width:150px;" id="bulkAssignSel" onchange="toggleBulkReason(this)">
        <option value="">Assign to…</option>
        <option value="0">Unassign</option>
        <?php foreach($team_list as $t): ?><option value="<?=$t['id']?>"><?=h($t['first_name'].' '.$t['last_name'])?></option><?php endforeach; ?>
      </select>
      <input type="text" name="bulk_transfer_reason" id="bulkTransferReason" class="form-control form-control-sm"
        placeholder="Transfer reason (optional)" style="display:none;width:180px;" maxlength="255">
      <?php endif; ?>
      <button type="submit" class="btn btn-primary btn-sm">Apply to selected</button>
      <button type="button" class="btn btn-secondary btn-sm" onclick="clearSelection()">Cancel</button>
    </div>
  </div>

  <div class="card">
    <?php if($leads): ?>
    <div style="overflow-x:auto;">
      <table class="table">
        <thead>
          <tr>
            <th style="width:36px;"><input type="checkbox" id="selectAll" onchange="toggleAll(this)" title="Select all"></th>
            <th>Lead</th>
            <th>Score</th>
            <th title="AI Intent &amp; Sentiment">AI</th>
            <th>Heat</th>
            <th>Status</th>
            <th>Assigned To</th>
            <th>Form · Domain</th>
            <th>Campaign</th>
            <th>Submitted</th>
            <th style="width:80px;">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($leads as $lead):
            $vals = $lead_values[$lead['id']] ?? [];
            $preview_name = $preview_email = '';
            foreach($vals as $v) {
              $lbl = strtolower($v['field_label']);
              if(!$preview_name  && ((strpos($lbl, 'name') !== false) || array_key_exists(0,$vals)&&$v===$vals[0])) $preview_name  = $v['value'];
              if(!$preview_email && (strpos($lbl, 'email') !== false)) $preview_email = $v['value'];
            }
            if(!$preview_name && $vals) $preview_name = $vals[0]['value'];
          ?>
          <tr>
            <td><input type="checkbox" name="lead_ids[]" value="<?=$lead['id']?>" class="lead-cb" onchange="updateBulk()"></td>
            <td>
              <a href="<?=APP_URL?>/lead_view.php?id=<?=$lead['id']?>" style="text-decoration:none;">
                <div style="font-weight:600;color:var(--gray-800);font-size:.84rem;display:flex;align-items:center;gap:5px;">
                  <?=h($preview_name?:'Unknown')?>
                  <?php if (!empty($lead['has_duplicates'])): ?>
                  <span title="Possible duplicate detected" style="display:inline-flex;align-items:center;justify-content:center;width:15px;height:15px;border-radius:50%;background:#fef3c7;flex-shrink:0;">
                    <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="#d97706" stroke-width="3"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                  </span>
                  <?php endif; ?>
                </div>
                <?php if($preview_email): ?><div style="font-size:.73rem;color:var(--gray-400);"><?=h($preview_email)?></div><?php endif; ?>
                <div style="font-size:.68rem;color:var(--gray-300);font-family:var(--font-mono);margin-top:1px;"><?=h($lead['reference_no'])?></div>
              </a>
            </td>
            <td>
              <?php $sc = (int)($lead['score']??0); $scat = $lead['score_category']??'cold'; ?>
              <?php if ($sc > 0): ?>
              <span class="score-pill score-<?= $scat ?>">
                <span class="score-dot"></span><?= $sc ?>
              </span>
              <?php else: ?>
              <span style="font-size:.72rem;color:var(--gray-300);">—</span>
              <?php endif; ?>
              <?php if (!empty($lead['ai_score'])): ?>
              <span class="badge badge-sm ml-1 <?= $lead['ai_score']>=70?'badge-danger':($lead['ai_score']>=40?'badge-warning':'badge-default') ?>"
                title="AI Score <?= $lead['ai_score'] ?>/100">✦<?= $lead['ai_score'] ?></span>
              <?php endif; ?>
            </td>
            <!-- AI intent + sentiment -->
            <td>
              <?php
              $li_intent = $lead['ai_intent']   ?? '';
              $li_sent   = $lead['ai_sentiment'] ?? '';
              $ai_i_icons = [
                'appointment'=>'🗓','pricing'=>'💰','consultation'=>'💬','treatment'=>'🏥',
                'emergency'=>'🚨','general_enquiry'=>'❓','information'=>'ℹ️','complaint'=>'⚠️','other'=>'•',
              ];
              $ai_s_colors = [
                'positive'=>'var(--color-success)','negative'=>'var(--color-danger)',
                'urgent'=>'var(--color-warning)','neutral'=>'var(--neutral-300)',
              ];
              ?>
              <?php if ($li_intent || ($li_sent && $li_sent !== 'neutral')): ?>
              <div class="flex gap-1" style="align-items:center;">
                <?php if ($li_intent && isset($ai_i_icons[$li_intent])): ?>
                <span title="Intent: <?= h(str_replace('_',' ',$li_intent)) ?>"
                  style="font-size:.82rem;line-height:1;"><?= $ai_i_icons[$li_intent] ?></span>
                <?php endif; ?>
                <?php if ($li_sent && $li_sent !== 'neutral'): ?>
                <span title="Sentiment: <?= h($li_sent) ?>"
                  style="width:7px;height:7px;border-radius:50%;background:<?= $ai_s_colors[$li_sent]??'var(--neutral-300)' ?>;flex-shrink:0;"></span>
                <?php endif; ?>
              </div>
              <?php else: ?>
              <span style="font-size:.72rem;color:var(--neutral-300);">—</span>
              <?php endif; ?>
            </td>
            <td>
              <?php
              $eng_level = $lead['engagement_level'] ?? 'cold';
              $eng_score = (int)($lead['engagement_score'] ?? 0);
              if (isset($lead['engagement_at']) && $lead['engagement_at']): ?>
              <?php
              $eng_cfg = [
                'hot'  => ['bg'=>'#fef2f2','border'=>'#fca5a5','dot'=>'#ef4444','text'=>'#991b1b'],
                'warm' => ['bg'=>'#fffbeb','border'=>'#fde68a','dot'=>'#f59e0b','text'=>'#92400e'],
                'cold' => ['bg'=>'#f0f9ff','border'=>'#bae6fd','dot'=>'#38bdf8','text'=>'#0c4a6e'],
              ];
              $ec = $eng_cfg[$eng_level] ?? $eng_cfg['cold'];
              ?>
              <span title="Engagement score: <?= $eng_score ?>" style="display:inline-flex;align-items:center;gap:4px;font-size:.68rem;padding:2px 7px;background:<?= $ec['bg'] ?>;border:1px solid <?= $ec['border'] ?>;color:<?= $ec['text'] ?>;border-radius:12px;font-weight:600;white-space:nowrap;">
                <span style="width:5px;height:5px;border-radius:50%;background:<?= $ec['dot'] ?>;"></span>
                <?= ucfirst($eng_level) ?>
              </span>
              <?php else: ?>
              <span style="font-size:.72rem;color:var(--gray-300);">—</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if(can('leads','edit')): ?>
              <form method="POST" style="display:inline;" class="inline-form">
                <?=csrf_field()?>
                <input type="hidden" name="action" value="update_status">
                <input type="hidden" name="lead_id" value="<?=$lead['id']?>">
                <select name="status" class="form-control form-control-sm" onchange="this.form.submit()" style="font-size:.75rem;min-width:108px;">
                  <?php foreach($statuses as $s): ?><option value="<?=$s?>" <?=$lead['status']===$s?'selected':''?>><?=ucfirst($s)?></option><?php endforeach; ?>
                </select>
              </form>
              <?php else: ?>
              <span class="badge <?=$status_colors[$lead['status']]??'badge-gray'?>"><span class="badge-dot"></span><?=ucfirst($lead['status'])?></span>
              <?php endif; ?>
            </td>
            <td>
              <?php if(can('leads','assign')): ?>
              <form method="POST" style="display:inline;" class="inline-form">
                <?=csrf_field()?>
                <input type="hidden" name="action" value="quick_assign">
                <input type="hidden" name="lead_id" value="<?=$lead['id']?>">
                <select name="user_id" class="form-control form-control-sm" onchange="this.form.submit()" style="font-size:.75rem;min-width:120px;">
                  <option value="0" <?=!$lead['assigned_id']?'selected':''?>>Unassigned</option>
                  <?php foreach($team_list as $t): ?>
                  <option value="<?=$t['id']?>" <?=(int)$lead['assigned_id']===$t['id']?'selected':''?>><?=h($t['first_name'].' '.$t['last_name'])?></option>
                  <?php endforeach; ?>
                </select>
              </form>
              <?php else: ?>
              <span style="font-size:.78rem;color:var(--gray-500);"><?=h($lead['assigned_name']?trim($lead['assigned_name']):'—')?></span>
              <?php endif; ?>
            </td>
            <td>
              <div style="font-size:.78rem;color:var(--gray-600);"><?=h($lead['form_name']??'—')?></div>
              <div style="font-size:.7rem;color:var(--gray-400);"><?=h($lead['domain']??'')?></div>
            </td>
            <td>
              <?php if (!empty($lead['campaign_name'])): ?>
              <a href="<?=APP_URL?>/campaign_view.php?id=<?=(int)$lead['campaign_id_val']?>"
                 style="font-size:.76rem;font-weight:600;color:var(--brand-600);text-decoration:none;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:130px;"
                 title="<?=h($lead['campaign_name'])?>">
                <?=h(mb_substr($lead['campaign_name'],0,20)).(mb_strlen($lead['campaign_name'])>20?'…':'')?>
              </a>
              <?php if (!empty($lead['page_title'])): ?>
              <div style="font-size:.68rem;color:var(--gray-400);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:130px;" title="<?=h($lead['page_title'])?>">
                📄 <?=h(mb_substr($lead['page_title'],0,18)).(mb_strlen($lead['page_title'])>18?'…':'')?>
              </div>
              <?php endif; ?>
              <?php else: ?>
              <span style="font-size:.72rem;color:var(--gray-300);">—</span>
              <?php endif; ?>
            </td>
            <td style="font-size:.75rem;color:var(--gray-500);white-space:nowrap;">
              <?= format_dt($lead['submitted_at'], 'd M Y') ?><br>
              <span style="color:var(--gray-300);"><?= format_dt($lead['submitted_at'], 'g:ia') ?></span>
            </td>
            <td>
              <div style="display:flex;gap:4px;">
                <a href="<?=APP_URL?>/lead_view.php?id=<?=$lead['id']?>" class="btn btn-secondary btn-sm">View</a>
                <?php if(can('leads','delete')): ?>
                <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this lead?')">
                  <?=csrf_field()?>
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="lead_id" value="<?=$lead['id']?>">
                  <button class="btn btn-danger btn-sm">✕</button>
                </form>
                <?php endif; ?>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <?php if($pages>1): ?>
    <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 20px;border-top:1px solid var(--gray-100);">
      <span style="font-size:.78rem;color:var(--gray-400);">
        <?=number_format(($page-1)*$per_page+1)?>–<?=number_format(min($page*$per_page,$total))?> of <?=number_format($total)?>
      </span>
      <div style="display:flex;gap:4px;">
        <?php if($page>1): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$page-1]))?>" class="btn btn-secondary btn-sm">‹ Prev</a><?php endif; ?>
        <?php for($p=max(1,$page-2);$p<=min($pages,$page+2);$p++): ?>
        <a href="?<?=http_build_query(array_merge($_GET,['page'=>$p]))?>" class="btn btn-sm <?=$p===$page?'btn-primary':'btn-secondary'?>"><?=$p?></a>
        <?php endfor; ?>
        <?php if($page<$pages): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$page+1]))?>" class="btn btn-secondary btn-sm">Next ›</a><?php endif; ?>
      </div>
    </div>
    <?php endif; ?>

    <?php else: ?>
    <div class="empty-state">
      <div class="empty-state-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>
      </div>
      <div class="empty-state-title">No leads found</div>
      <div class="empty-state-desc"><?=$search||$filter_status||$filter_domain?'Try adjusting your filters.':'Leads appear here once visitors submit your embedded forms.'?></div>
    </div>
    <?php endif; ?>
  </div>
</form>

<script>
function toggleAll(cb) {
  document.querySelectorAll('.lead-cb').forEach(c => c.checked = cb.checked);
  updateBulk();
}
function updateBulk() {
  const cbs     = document.querySelectorAll('.lead-cb');
  const checked = [...cbs].filter(c => c.checked).length;
  const bar     = document.getElementById('bulkBar');
  document.getElementById('bulkCount').textContent = checked + ' selected';
  bar.style.display = checked > 0 ? 'flex' : 'none';
  document.getElementById('selectAll').indeterminate = checked > 0 && checked < cbs.length;
  document.getElementById('selectAll').checked = checked === cbs.length && cbs.length > 0;
}
function clearSelection() {
  document.querySelectorAll('.lead-cb, #selectAll').forEach(c => { c.checked = false; c.indeterminate = false; });
  updateBulk();
}
function toggleBulkReason(sel) {
  var r = document.getElementById('bulkTransferReason');
  if (r) r.style.display = sel.value ? 'block' : 'none';
}
</script>

<?php include __DIR__ . '/layouts/footer.php'; ?>
