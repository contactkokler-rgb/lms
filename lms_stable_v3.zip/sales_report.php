<?php
require_once __DIR__ . '/config/auth.php';
$user       = require_permission('reports', 'view');
$account_id = (int)($user['account_id'] ?? 0);
$is_super   = is_super_admin();
$role       = $user['role_name'] ?? 'agent';

$can_see_all = ($is_super || in_array($role, ['account_owner','manager']));
$agent_scope = !$can_see_all;

$page_title = 'Sales Performance';
$active_nav = 'sales_report';

// ── Params ────────────────────────────────────────────────────
$range      = $_GET['range']   ?? '30';
$compare_a  = (int)($_GET['agent_a'] ?? 0);
$compare_b  = (int)($_GET['agent_b'] ?? 0);
$range_days = ['7'=>7,'30'=>30,'90'=>90,'year'=>365];
$days       = $range_days[$range] ?? 30;
$date_to    = date('Y-m-d');
$date_from  = date('Y-m-d', strtotime("-{$days} days"));
$prev_from  = date('Y-m-d', strtotime("-".($days*2)." days"));
$prev_to    = date('Y-m-d', strtotime("-{$days} days -1 day"));

// ── Base WHERE ────────────────────────────────────────────────
$base_w = $is_super ? 'WHERE l.is_deleted=0' : 'WHERE l.account_id=? AND l.is_deleted=0';
$base_t = $is_super ? '' : 'i';
$base_p = $is_super ? [] : [$account_id];

$dw = $base_w . ' AND DATE(l.submitted_at) BETWEEN ? AND ?';
$dt = $base_t . 'ss';
$dp = array_merge($base_p, [$date_from, $date_to]);

$pw = $base_w . ' AND DATE(l.submitted_at) BETWEEN ? AND ?';
$pt = $base_t . 'ss';
$pp = array_merge($base_p, [$prev_from, $prev_to]);

// ── Team list ─────────────────────────────────────────────────
$team = $is_super
    ? db_fetch_all("SELECT id,first_name,last_name,email FROM users WHERE status='active' ORDER BY first_name")
    : db_fetch_all("SELECT id,first_name,last_name,email FROM users WHERE account_id=? AND status='active' ORDER BY first_name",'i',$account_id);

// ── Per-agent leaderboard ─────────────────────────────────────
$leaderboard = db_fetch_all(
    "SELECT
        u.id, CONCAT(u.first_name,' ',u.last_name) AS name, u.email,
        COUNT(DISTINCT l.id)                            AS total,
        SUM(l.status='converted')                       AS won,
        SUM(l.status='qualified')                       AS qualified,
        SUM(l.status='contacted')                       AS contacted,
        SUM(l.status='lost')                            AS lost,
        SUM(l.status='new')                             AS still_new,
        ROUND(AVG(COALESCE(l.score,0)),1)               AS avg_score,
        ROUND(AVG(COALESCE(l.engagement_score,0)),1)    AS avg_eng,
        ROUND(AVG(CASE WHEN l.status!='new' AND fc.fc IS NOT NULL
            THEN TIMESTAMPDIFF(MINUTE,l.submitted_at,fc.fc) END)/60,2) AS avg_resp_hrs,
        MIN(l.submitted_at)                             AS first_lead,
        MAX(l.submitted_at)                             AS last_lead
     FROM users u
     JOIN leads l ON l.assigned_to = u.id
     LEFT JOIN (SELECT lead_id, MIN(created_at) AS fc FROM lead_comments GROUP BY lead_id) fc
        ON fc.lead_id = l.id
     {$dw} AND l.assigned_to IS NOT NULL
     GROUP BY u.id
     ORDER BY won DESC, total DESC",
    $dt, ...$dp
);

// Enrich leaderboard
$max_won = 0;
foreach ($leaderboard as &$lb) {
    $lb['conv_rate'] = $lb['total']>0 ? round($lb['won']/$lb['total']*100,1) : 0;
    $lb['qual_rate'] = $lb['total']>0 ? round(($lb['won']+$lb['qualified'])/$lb['total']*100,1) : 0;
    if ((int)$lb['won'] > $max_won) $max_won = (int)$lb['won'];
}
unset($lb);

// ── Account totals ────────────────────────────────────────────
$totals = db_fetch(
    "SELECT COUNT(*) AS total, SUM(status='converted') AS won,
            SUM(status='qualified') AS qualified, SUM(status='lost') AS lost
     FROM leads l {$dw}", $dt, ...$dp
) ?? [];

$prev_totals = db_fetch(
    "SELECT COUNT(*) AS total, SUM(status='converted') AS won FROM leads l {$pw}", $pt, ...$pp
) ?? [];

// ── Weekly close rate trend (last 12 weeks) ───────────────────
$weekly_trend = db_fetch_all(
    "SELECT YEARWEEK(l.submitted_at,1) AS yw,
            COUNT(*) AS total,
            SUM(l.status='converted') AS won
     FROM leads l {$dw}
     GROUP BY yw ORDER BY yw DESC LIMIT 12",
    $dt, ...$dp
);
$weekly_trend = array_reverse($weekly_trend);

// ── Daily won leads for sparkline ─────────────────────────────
$daily_won = db_fetch_all(
    "SELECT DATE(l.submitted_at) AS day,
            SUM(l.status='converted') AS won,
            COUNT(*) AS total
     FROM leads l {$dw}
     GROUP BY DATE(l.submitted_at) ORDER BY day",
    $dt, ...$dp
);

// ── Head-to-head compare ──────────────────────────────────────
$compare_data = [];
if ($compare_a && $compare_b) {
    foreach ([$compare_a, $compare_b] as $cid) {
        $row = db_fetch(
            "SELECT u.id, CONCAT(u.first_name,' ',u.last_name) AS name,
                COUNT(DISTINCT l.id) AS total,
                SUM(l.status='converted') AS won,
                SUM(l.status='qualified') AS qualified,
                SUM(l.status='lost') AS lost,
                ROUND(AVG(COALESCE(l.score,0)),1) AS avg_score,
                ROUND(AVG(COALESCE(l.engagement_score,0)),1) AS avg_eng,
                ROUND(AVG(CASE WHEN l.status!='new' AND fc.fc IS NOT NULL
                    THEN TIMESTAMPDIFF(MINUTE,l.submitted_at,fc.fc) END)/60,2) AS avg_resp
             FROM users u
             JOIN leads l ON l.assigned_to = u.id
             LEFT JOIN (SELECT lead_id,MIN(created_at) AS fc FROM lead_comments GROUP BY lead_id) fc
                ON fc.lead_id=l.id
             {$dw} AND u.id=?",
            $dt.'i', ...array_merge($dp, [$cid])
        );
        if ($row) {
            $row['conv_rate'] = $row['total']>0 ? round($row['won']/$row['total']*100,1) : 0;
            $compare_data[] = $row;
        }
    }
}

// ── Helpers ───────────────────────────────────────────────────
function fmt_hrs_sp(float $h): string {
    if ($h <= 0) return '—';
    if ($h < 1)  return round($h*60).'m';
    if ($h < 48) return number_format($h,1).'h';
    return number_format($h/24,1).'d';
}

function trend_pct_sp($curr, $prev): string {
    if (!$prev || $prev==0) return '';
    $pct = round(($curr-$prev)/$prev*100,1);
    if ($pct>0)  return "<span style='color:#16a34a;font-size:.72rem;'>▲ {$pct}%</span>";
    if ($pct<0)  return "<span style='color:#ef4444;font-size:.72rem;'>▼ ".abs($pct)."%</span>";
    return "<span style='color:#94a3b8;font-size:.72rem;'>→</span>";
}

include __DIR__ . '/layouts/header.php';
$pt = (int)($totals['total'] ?? 0);
$pw_prev = (int)($prev_totals['total'] ?? 0);
$p_won = (int)($totals['won'] ?? 0);
$p_won_prev = (int)($prev_totals['won'] ?? 0);
$p_qual = (int)($totals['qualified'] ?? 0);
$p_lost = (int)($totals['lost'] ?? 0);
$p_cr   = $pt>0 ? round($p_won/$pt*100,1) : 0;
$p_cr_prev = $pw_prev>0 ? round($p_won_prev/$pw_prev*100,1) : 0;
?>

<div class="page-header">
    <div>
        <h1 class="page-title">Sales Performance</h1>
        <p class="page-subtitle"><?= $date_from ?> <i class="hgi hgi-stroke hgi-arrow-right-02"></i> <?= $date_to ?></p>
    </div>
    <div class="flex gap-4 justify-end items-center">
        <div class="nav-pills">
            <?php foreach (['7'=>'7d','30'=>'30d','90'=>'90d','year'=>'1y'] as $rv=>$rl): ?>
            <a href="?range=<?=$rv?>&agent_a=<?=$compare_a?>&agent_b=<?=$compare_b?>" class="nav-pill <?=$range==$rv?'active':''?>"><?=$rl?></a>
            <?php endforeach; ?>
        </div>
        <a href="<?=APP_URL?>/reports.php" class="btn btn-primary btn-sm"><i class="hgi hgi-stroke hgi-chart-line-data-02"></i>Analytics</a>
    </div>
</div>

<!-- KPIs -->
<div class="flex gap-4">
    <?php
        $kpis = [
          ['Total Leads',    number_format($pt),        trend_pct_sp($pt,$pw_prev),         'card-b2',  'user-account'],
          ['Converted',      number_format($p_won),     trend_pct_sp($p_won,$p_won_prev),   'card-b3',  'user-account'],
          ['Close Rate',     $p_cr.'%',                 trend_pct_sp($p_cr,$p_cr_prev),     'card-b4',  'user-account'],
          ['Qualified',      number_format($p_qual),    '',                                 'card-b5',  'user-account'],
          ['Lost',           number_format($p_lost),    '',                                 'card-b1',  'user-account'],
          ['Active Agents',  count($leaderboard),       '',                                 'card-b2',  'user-account'],
        ];
        foreach ($kpis as [$lbl,$val,$tr,$col,$icon]): 
    ?>
    <div class="card card-stat <?= $col ?>">        
        <div>
            <div class="card-label"><?= $lbl ?></div>
            <div class="card-value mt-1"><?= $val ?></div>
        </div>
        <i class="hgi hgi-stroke hgi-<?= $icon ?>"></i>
    </div>
    <?php endforeach; ?>
</div>

<div class="grid grid-cols-2 gap-6">
    <div class="card">
        <!-- Leaderboard -->
        <div class="card-header">
            <div>
                <div class="card-title">Leaderboard</div>
                <div class="card-subtitle">Ranked by conversions in period</div>
            </div>
        </div>

        <div class="card-body">
            
            <?php if ($leaderboard): ?>
            <div class="card-row items-center">
                <?php foreach ($leaderboard as $idx => $lb):
                    $medals = ['medal-first-place','medal-second-place','medal-third-place'];
                    $medal  = $medals[$idx] ?? '#'.($idx+1);
                    $bar_w  = $max_won > 0 ? round($lb['won']/$max_won*100) : 0;
                    $bg     = $idx===0?'var(--warning-10)':($idx===1?'var(--grey-20)':($idx===2?'var(--danger-10)':'var(--info-10)'));
                    $clr    = $idx===0?'var(--warning)':($idx===1?'var(--grey)':($idx===2?'var(--danger)':'var(--info)'));
                ?>
                
                <span class="card-icon" style="background:<?=$bg?>; color:<?=$clr?>;"><i class="hgi hgi-stroke hgi-<?=$medal?>"></i></span>
                <div class="flex-1">
                    <div class="flex justify-between items-center mb-2">
                        <div class="font-semibold"><?=h($lb['name'])?></div>
                        <div>
                            <span class="mr-1 badge badge-sm badge-light-info"><?=$lb['won']?></span>Won
                            <span class="ml-3 mr-1 badge badge-sm badge-light-warning"><?=$lb['conv_rate']?>%</span>Rate
                            <span class="ml-3 mr-1 badge badge-sm badge-light-success"><?=$lb['total']?></span>Leads
                        </div>
                    </div>
                    <div class="progress my-1">
                        <div class="progress-bar" style="background:<?=$clr?>;width:<?=$bar_w?>%;"></div>
                    </div>                    
                </div>
                
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="py-6 text-center text-sm text-muted">No conversion data for this period.</div>
            <?php endif; ?>
            
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <div class="card-title">Close Rate Trend</div>
            <div class="card-subtitle">Weekly conversion rate</div>
        </div>
        <div class="card-body">
            <canvas id="cWeeklyClose" height="240"></canvas>
        </div>
    </div>
</div>


<div class="card">
    <div class="card-header">
        <div class="card-title">Agent Stats</div>
        <div class="card-subtitlte">Full metrics for all agents — period: <?=$date_from?> <i class="hgi hgi-stroke hgi-arrow-right-02"></i> <?=$date_to?></div>
    </div>
    <table class="table mx-table">
        <thead>
            <tr>
                <th>Agent</th>
                <th class="text-center">Leads</th>
                <th class="text-center">Won</th>
                <th class="text-center">Close Rate</th>
                <th class="text-center">Qualified</th>
                <th class="text-center">Lost</th>
                <th class="text-center">Avg Score</th>
                <th class="text-center">Avg Heat</th>
                <th class="text-center">Avg Response</th>
                <th class="text-right">Pipeline</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($leaderboard): ?>
            <?php foreach ($leaderboard as $idx => $lb):
              $cr = (float)$lb['conv_rate'];
              $cr_col = $cr >= (float)$p_cr ? 'text-success' : 'text-danger';
              $won_w  = $lb['total']>0 ? round((int)$lb['won']/(int)$lb['total']*100) : 0;
              $qual_w = $lb['total']>0 ? round(((int)$lb['won']+(int)$lb['qualified'])/(int)$lb['total']*100) : 0;
            ?>
            <tr>
                <td class="flex gap-2 items-center">
                    <?php $medals2=['medal-first-place','medal-second-place','medal-third-place']; ?>
                    <span class="card-icon" style="background:<?=$bg?>; color:<?=$clr?>;"><i class="hgi hgi-stroke hgi-<?php echo $medals2[$idx]??'';?>"></i></span>
                    <a href="<?=APP_URL?>/leads.php?assigned=<?=$lb['id']?>" class="text-md font-semibold"><?=h($lb['name'])?></a>
                </td>
                <td class="text-center"><?=$lb['total']?></td>
                <td class="text-center text-success font-bold"><?=$lb['won']?></td>
                <td class="text-center font-bold <?=$cr_col?>"><?=$cr?>%</td>
                <td class="text-center text-brand"><?=$lb['qualified']?></td>
                <td class="text-center text-danger"><?=$lb['lost']?></td>
                <td class="text-center"><?=$lb['avg_score']>0?$lb['avg_score']:'—'?></td>
                <td class="text-center"><?=$lb['avg_eng']>0?$lb['avg_eng']:'—'?></td>
                <td class="text-center font-bold <?=($lb['avg_resp_hrs']&&(float)$lb['avg_resp_hrs']>4)?'text-danger':'text-success'?>">
                    <?=fmt_hrs_sp((float)($lb['avg_resp_hrs']??0))?>
                </td>
                <td class="text-right" style="min-width:110px;">
                    <div class="progress">
                        <!-- <div class="progress-bar" style="width:<?=$qual_w?>%;background:var(--warning);border-top-right-radius: 0;border-bottom-right-radius: 0;"></div> -->
                        <div class="progress-bar" style="width:<?=$won_w?>%;background:var(--success);border-top-left-radius: 0;border-bottom-left-radius: 0;"></div>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            <?php else: ?>
            <tr>
                <td colspan="10" style="text-align:center;padding:28px;color:var(--gray-400);">No agent data for this period.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>


<div class="card">
    <div class="card-header">
        <div class="card-title">Head-to-Head Compare</div>
        <div class="card-subtitle">Select two agents to compare</div>
    </div>
    <div class="card-body">
        <form method="GET" class="flex gap-2 items-center mb-3">
            <input type="hidden" name="range" value="<?=h($range)?>">
            <select name="agent_a" class="form-control form-control-sm" style="width: 160px;">
                <option value="">Agent A</option>
                <?php foreach ($team as $t): ?>
                <option value="<?=$t['id']?>" <?=$compare_a===$t['id']?'selected':''?>><?=h($t['first_name'].' '.$t['last_name'])?></option>
                <?php endforeach; ?>
            </select>
            <span class="mx-1 text-sm text-muted">vs</span>
            <select name="agent_b" class="form-control form-control-sm" style="width: 160px;">
                <option value="">Agent B</option>
                <?php foreach ($team as $t): ?>
                <option value="<?=$t['id']?>" <?=$compare_b===$t['id']?'selected':''?>><?=h($t['first_name'].' '.$t['last_name'])?></option>
                <?php endforeach; ?>
            </select>
            <button class="btn btn-primary">Compare</button>
        </form>

        <?php if (count($compare_data) === 2): ?>
        <?php [$ca, $cb] = $compare_data; ?>
        <?php
            $metrics = [
                ['Leads',         $ca['total'],     $cb['total'],     false, ''],
                ['Won',           $ca['won'],       $cb['won'],       true,  ''],
                ['Close Rate',    $ca['conv_rate'], $cb['conv_rate'], true,  '%'],
                ['Avg Score',     $ca['avg_score'], $cb['avg_score'], true,  ''],
                ['Avg Engagement',$ca['avg_eng'],   $cb['avg_eng'],   true,  ''],
                ['Avg Response',  $ca['avg_resp']?fmt_hrs_sp((float)$ca['avg_resp']):'—', $cb['avg_resp']?fmt_hrs_sp((float)$cb['avg_resp']):'—', false,''],
            ];
        ?>
        <div style="font-size:.8rem;font-weight:700;color:var(--gray-500);display:flex;margin-bottom:8px;padding:0 4px;">
            <div style="flex:1;color:#0369a1;"><?=h($ca['name'])?></div>
            <div style="flex:0.4;text-align:center;">Metric</div>
            <div style="flex:1;text-align:right;color:#991b1b;"><?=h($cb['name'])?></div>
        </div>
        <?php foreach ($metrics as [$lbl,$va,$vb,$higher_better,$unit]):
          $a_wins = $higher_better && is_numeric($va) && is_numeric($vb) ? (float)$va > (float)$vb : false;
          $b_wins = $higher_better && is_numeric($va) && is_numeric($vb) ? (float)$vb > (float)$va : false;
        ?>
        <div class="cmp-row">
            <div class="cmp-cell">
                <div class="cmp-lbl"><?=$lbl?></div>
                <div class="cmp-val" style="color:#0369a1;<?=$a_wins?'text-shadow:0 0 12px #bae6fd;':''?>"><?=$va?><?=$unit?></div>
                <?php if ($a_wins): ?><div style="font-size:.65rem;color:#16a34a;margin-top:2px;">▲ better</div><?php endif; ?>
            </div>
            <div class="cmp-bar-wrap">
                <?php if (is_numeric($va) && is_numeric($vb) && ((float)$va+(float)$vb)>0):
                  $total_v = (float)$va + (float)$vb;
                  $a_pct = round((float)$va/$total_v*100);
                  $b_pct = 100-$a_pct;
                ?>
                <div style="height:8px;background:#fef2f2;border-radius:4px;overflow:hidden;width:80px;display:flex;">
                    <div style="height:100%;width:<?=$a_pct?>%;background:#0369a1;border-radius:4px 0 0 4px;"></div>
                    <div style="height:100%;width:<?=$b_pct?>%;background:#ef4444;border-radius:0 4px 4px 0;"></div>
                </div>
                <?php else: ?>
                <span style="font-size:.75rem;font-weight:700;color:var(--gray-400);"><?=$lbl?></span>
                <?php endif; ?>
            </div>
            <div class="cmp-cell">
                <div class="cmp-lbl"><?=$lbl?></div>
                <div class="cmp-val" style="color:#991b1b;<?=$b_wins?'text-shadow:0 0 12px #fca5a5;':''?>"><?=$vb?><?=$unit?></div>
                <?php if ($b_wins): ?><div style="font-size:.65rem;color:#16a34a;margin-top:2px;">▲ better</div><?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
        <?php elseif ($compare_a || $compare_b): ?>
        <div class="text-sm text-danger">Select both agents above to compare.</div>
        <?php else: ?>
        <div class="text-sm text-muted">Choose any two agents from the dropdowns above.</div>
        <?php endif; ?>
    </div>
</div>

<!-- Charts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
    Chart.defaults.font.family = "-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif";
    Chart.defaults.color = '#94a3b8';
    const GRID = '#f1f5f9';

    (function() {
        const weeks = <?= json_encode($weekly_trend) ?>;
        if (!weeks.length) return;
        const labels = weeks.map(function(w) {
            var yw = String(w.yw),
                y = yw.slice(0, 4),
                wk = yw.slice(4);
            return 'W' + wk + " '" + y.slice(2);
        });
        const rates = weeks.map(function(w) {
            return w.total > 0 ? Math.round(w.won / w.total * 1000) / 10 : 0;
        });
        const totals = weeks.map(function(w) {
            return parseInt(w.total) || 0;
        });

        new Chart(document.getElementById('cWeeklyClose'), {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                        label: 'Leads',
                        data: totals,
                        backgroundColor: 'rgba(59,130,246,.18)',
                        borderColor: '#3b82f6',
                        borderWidth: 1.5,
                        borderRadius: 4,
                        yAxisID: 'y',
                        order: 2
                    },
                    {
                        label: 'Close %',
                        data: rates,
                        type: 'line',
                        borderColor: '#22c55e',
                        backgroundColor: 'rgba(34,197,94,.08)',
                        borderWidth: 2.5,
                        pointRadius: 3,
                        pointBackgroundColor: '#22c55e',
                        tension: .4,
                        fill: true,
                        yAxisID: 'y1',
                        order: 1
                    }
                ]
            },
            options: {
                responsive: true,
                interaction: {
                    mode: 'index',
                    intersect: false
                },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            boxWidth: 10,
                            padding: 12,
                            font: {
                                size: 10
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            font: {
                                size: 9
                            }
                        }
                    },
                    y: {
                        beginAtZero: true,
                        position: 'left',
                        grid: {
                            color: GRID
                        },
                        ticks: {
                            font: {
                                size: 9
                            }
                        }
                    },
                    y1: {
                        beginAtZero: true,
                        max: 100,
                        position: 'right',
                        grid: {
                            display: false
                        },
                        ticks: {
                            font: {
                                size: 9
                            },
                            callback: function(v) {
                                return v + '%';
                            }
                        }
                    }
                }
            }
        });
    })();
</script>

<?php include __DIR__ . '/layouts/footer.php'; ?>