<?php
set_exception_handler(function($e) {
    error_log('[LeadPro score_rules.php] ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    http_response_code(500);
    echo '<div style="font-family:sans-serif;padding:40px;color:#dc2626"><b>Scoring error:</b> ' . htmlspecialchars($e->getMessage()) . ' <small>(' . basename($e->getFile()) . ':' . $e->getLine() . ')</small></div>';
    exit;
});
require_once __DIR__ . '/config/auth.php';
$user       = require_permission('leads', 'manage_score');
$account_id = (int)($user['account_id'] ?? 0);
$is_super   = is_super_admin();
$page_title = 'Lead Scoring Rules';
$active_nav = 'score_rules';

$operators = [
    'equals'          => 'Equals',
    'not_equals'      => 'Does not equal / Is not empty',
    'contains'        => 'Contains',
    'not_contains'    => 'Does not contain',
    'greater_than'    => 'Greater than',
    'less_than'       => 'Less than',
    'is_business_email' => 'Is business email',
    'is_free_email'   => 'Is free email (Gmail, Yahoo…)',
    'in_list'         => 'Is in list (comma-separated)',
    'not_in_list'     => 'Is NOT in list',
];
$field_options = [
    'email'          => 'Email address',
    'phone'          => 'Phone number',
    'company'        => 'Company name',
    'message_length' => 'Message length (characters)',
    'country'        => 'Country',
    'utm_source'     => 'UTM Source',
    'utm_medium'     => 'UTM Medium',
    'utm_campaign'   => 'UTM Campaign',
    'interactions'   => 'Number of interactions (comments)',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { http_response_code(403); die('CSRF'); }
    $act = isset($_POST['action']) ? $_POST['action'] : '';

    if ($act === 'add_rule') {
        $name   = trim(isset($_POST['name'])     ? $_POST['name']     : '');
        $field  = trim(isset($_POST['field'])    ? $_POST['field']    : '');
        $op     = isset($_POST['operator']) && array_key_exists($_POST['operator'], $operators) ? $_POST['operator'] : 'equals';
        $val    = trim(isset($_POST['value'])    ? $_POST['value']    : '');
        $score  = max(-100, min(100, (int)(isset($_POST['score']) ? $_POST['score'] : 0)));
        $scope  = ($is_super && isset($_POST['scope']) && $_POST['scope'] === 'platform') ? null : $account_id;

        if (!$name || !$field) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Name and field are required.'];
        } else {
            if ($scope === null) {
                db_insert('INSERT INTO lead_score_rules (account_id,name,field,operator,value,score) VALUES (NULL,?,?,?,?,?)', 'ssssi', $name,$field,$op,$val,$score);
            } else {
                db_insert('INSERT INTO lead_score_rules (account_id,name,field,operator,value,score) VALUES (?,?,?,?,?,?)', 'issssi', $scope,$name,$field,$op,$val,$score);
            }
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Rule added.'];
        }

    } elseif ($act === 'delete_rule') {
        $id = (int)(isset($_POST['id']) ? $_POST['id'] : 0);
        if ($is_super) {
            db_query('DELETE FROM lead_score_rules WHERE id = ?', 'i', $id);
        } else {
            db_query('DELETE FROM lead_score_rules WHERE id = ? AND account_id = ?', 'ii', $id, $account_id);
        }
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Rule deleted.'];

    } elseif ($act === 'toggle_rule') {
        $id = (int)(isset($_POST['id']) ? $_POST['id'] : 0);
        if ($is_super) {
            db_query('UPDATE lead_score_rules SET is_active = 1-is_active WHERE id = ?', 'i', $id);
        } else {
            db_query('UPDATE lead_score_rules SET is_active = 1-is_active WHERE id = ? AND account_id = ?', 'ii', $id, $account_id);
        }
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Rule updated.'];

    } elseif ($act === 'rescore_all') {
        require_once __DIR__ . '/config/scoring.php';
        $scope_id = $is_super ? null : $account_id;
        if ($scope_id === null) {
            $all = db_fetch_all('SELECT id, account_id FROM leads WHERE is_deleted=0 LIMIT 2000');
        } else {
            $all = db_fetch_all('SELECT id, account_id FROM leads WHERE account_id=? AND is_deleted=0 LIMIT 2000','i',$scope_id);
        }
        $count = 0;
        foreach ($all as $l) { apply_lead_score((int)$l['id'], (int)$l['account_id']); $count++; }
        $_SESSION['flash'] = ['type'=>'success','msg'=>"Re-scored {$count} leads."];
    }

    header('Location: ' . APP_URL . '/score_rules.php'); exit;
}

$flash = isset($_SESSION['flash']) ? $_SESSION['flash'] : null;
unset($_SESSION['flash']);

// Load rules
if ($is_super) {
    $rules = db_fetch_all('SELECT r.*, a.name AS account_name FROM lead_score_rules r LEFT JOIN accounts a ON a.id=r.account_id ORDER BY r.account_id IS NOT NULL, r.sort_order, r.id');
} else {
    $rules = db_fetch_all('SELECT r.*, NULL AS account_name FROM lead_score_rules r WHERE r.account_id IS NULL OR r.account_id=? ORDER BY r.account_id IS NOT NULL, r.sort_order, r.id', 'i', $account_id);
}

// Stats
if ($is_super) {
    $stats = [
        'hot'  => (int)(db_fetch("SELECT COUNT(*) AS n FROM leads WHERE score_category='hot'  AND is_deleted=0")['n'] ?? 0),
        'warm' => (int)(db_fetch("SELECT COUNT(*) AS n FROM leads WHERE score_category='warm' AND is_deleted=0")['n'] ?? 0),
        'cold' => (int)(db_fetch("SELECT COUNT(*) AS n FROM leads WHERE score_category='cold' AND is_deleted=0")['n'] ?? 0),
    ];
} else {
    $stats = [
        'hot'  => (int)(db_fetch("SELECT COUNT(*) AS n FROM leads WHERE score_category='hot'  AND is_deleted=0 AND account_id=?", 'i', $account_id)['n'] ?? 0),
        'warm' => (int)(db_fetch("SELECT COUNT(*) AS n FROM leads WHERE score_category='warm' AND is_deleted=0 AND account_id=?", 'i', $account_id)['n'] ?? 0),
        'cold' => (int)(db_fetch("SELECT COUNT(*) AS n FROM leads WHERE score_category='cold' AND is_deleted=0 AND account_id=?", 'i', $account_id)['n'] ?? 0),
    ];
}

include __DIR__ . '/layouts/header.php';
?>

<?php if ($flash): ?>
<div class="alert alert-<?= h($flash['type']) ?> mb-4" data-auto-dismiss><?= h($flash['msg']) ?></div>
<?php endif; ?>

<div class="page-header">
    <div>
        <h1 class="page-title">Lead Scoring Rules</h1>
        <p class="page-subtitle">Rule-based scoring engine — leads receive 0–100 points based on criteria</p>
    </div>
    <form method="POST" style="margin-left:auto;" onsubmit="return confirm('Re-score all existing leads with current rules?')">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="rescore_all">
        <button class="btn btn-primary"><i class="hgi hgi-stroke hgi-star-circle"></i>Re-score All Leads</button>
    </form>
</div>

<!-- Heat distribution -->
<div class="grid grid-cols-3 gap-4">
    <?php foreach ([
        ['hot',  'Hot',  'card-b2', $stats['hot'],  'fire'],
        ['warm', 'Warm', 'card-b3', $stats['warm'], 'thermometer-warm'],
        ['cold', 'Cold', 'card-b4', $stats['cold'], 'snow'],
      ] as [$cat,$lbl,$color,$val,$icon]): 
    ?>
    
    <div class="card card-stat <?= $color ?>">        
        <div>
            <div class="card-label"><?= $lbl ?></div>
            <div class="card-value mt-1"><?= number_format($val) ?></div>
        </div>
        <i class="hgi hgi-stroke hgi-<?= $icon ?>"></i>
    </div>
    <?php endforeach; ?>
</div>

<!-- Score threshold explanation -->
<div class="card flex gap-3 items-center p-3">
    <div class="font-semibold">Score Thresholds:</div>
    <?php foreach ([['<i class="hgi hgi-stroke hgi-snow mr-1"></i>Cold','0–34','outline-info'],['<i class="hgi hgi-stroke hgi-thermometer-warm mr-1"></i>Warm','35–69','outline-warning'],['<i class="hgi hgi-stroke hgi-fire mr-1"></i>Hot','70–100','outline-danger']] as [$e,$r,$bg]): ?>
    <div class="badge badge-<?= $bg ?>">
        <span><?= $e ?></span>
        <span><?= $r ?> pts</span>
    </div>
    <?php endforeach; ?>
    <div class="text-sm text-muted text-right flex-1">Rules stack additively. Score is capped at 0–100.</div>
</div>


<div class="page-cols">
    <!-- Add rule form -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">Add Scoring Rule</div>
        </div>
        <form method="POST">
            <div class="card-body">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="add_rule">
                <div class="form-group">
                    <label class="form-label">Rule Name</label>
                    <input type="text" name="name" class="form-control" placeholder="e.g. Business Email" required maxlength="150">
                </div>
                <div class="form-group">
                    <label class="form-label">Field</label>
                    <select name="field" class="form-control">
                        <?php foreach ($field_options as $fk => $fl): ?>
                        <option value="<?= $fk ?>"><?= $fl ?></option>
                        <?php endforeach; ?>
                        <option value="">— Custom field key —</option>
                    </select>
                </div>
                <div class="form-group" id="customFieldGroup" style="display:none;">
                    <label class="form-label">Custom Field Key</label>
                    <input type="text" name="field_custom" class="form-control" placeholder="e.g. budget, company_size" id="customFieldInput">
                </div>
                <div class="form-group">
                    <label class="form-label">Operator</label>
                    <select name="operator" class="form-control" id="operatorSelect">
                        <?php foreach ($operators as $ok => $ol): ?>
                        <option value="<?= $ok ?>"><?= $ol ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group" id="valueGroup">
                    <label class="form-label">Match Value</label>
                    <input type="text" name="value" class="form-control" placeholder="e.g. organic, IN, 50">
                    <div class="form-help">Leave empty for "not empty" checks</div>
                </div>
                <div class="form-group">
                    <label class="form-label">Score Points</label>
                    <input type="number" name="score" class="form-control" value="10" min="-100" max="100" required>
                    <div class="form-help">Use negative values to decrease score</div>
                </div>
                <?php if ($is_super): ?>
                <div class="form-group">
                    <label class="form-label">Scope</label>
                    <select name="scope" class="form-control">
                        <option value="platform">Platform-wide (all accounts)</option>
                        <option value="account">This account only</option>
                    </select>
                </div>
                <?php endif; ?>
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-primary btn-sm w-full"><i class="hgi hgi-stroke hgi-plus-sign"></i>Add Rule</button>
            </div>
        </form>
    </div>
    
    <!-- Rules table -->
    <div class="card">
        <div class="card-header">
            <div class="card-title">Active Rules</div>
            <div class="card-subtitle"><?= count($rules) ?> rules</div>
        </div>
        <?php if ($rules): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Rule</th>
                    <th>Condition</th>
                    <th>Points</th>
                    <?php if($is_super):?><th>Scope</th><?php endif;?>                    
                    <th class="text-right"></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rules as $r):
                    $is_platform = ($r['account_id'] === null);
                    $pts = (int)$r['score'];
                ?>
                <tr class="rule-row" style="<?= !$r['is_active'] ? 'opacity:.45;' : '' ?>">
                    <td><?= h($r['name']) ?></td>
                    <td>
                        <code style="font-size:.7rem;background:var(--gray-100);padding:1px 6px;border-radius:4px;"><?= h($r['field']) ?></code>
                        <?= h($operators[$r['operator']] ?? $r['operator']) ?>
                        <?php if ($r['value']): ?><strong><?= h($r['value']) ?></strong><?php endif; ?>
                    </td>
                    <td>
                        <span class="badge badge-<?= $pts >= 0 ? 'outline-success' : 'outline-danger' ?>">
                            <?= ($pts >= 0 ? '+' : '') . $pts ?>
                        </span>
                    </td>
                    <?php if ($is_super): ?>
                    <td><span class="badge badge-sm <?= $is_platform ? 'badge-outline-info' : 'badge-outline-warning' ?>"><?= $is_platform ? 'Platform' : h($r['account_name'] ?? '') ?></span></td>
                    <?php endif; ?>
                    <td class="flex items-center justify-end gap-2">
                        <?php if ($is_super || !$is_platform): ?>
                        <form method="POST" style="display:inline;">
                            <?= csrf_field() ?><input type="hidden" name="action" value="toggle_rule"><input type="hidden" name="id" value="<?= $r['id'] ?>">
                            <button type="submit" class="btn btn-warning btn-sm btn-icon" title="Toggle"><?= $r['is_active'] ? '<i class="hgi hgi-stroke hgi-pause-circle"></i>' : '<i class="hgi hgi-stroke hgi-play-circle"></i>' ?></button>
                        </form>
                        <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this rule?')">
                            <?= csrf_field() ?><input type="hidden" name="action" value="delete_rule"><input type="hidden" name="id" value="<?= $r['id'] ?>">
                            <button type="submit" class="btn btn-danger btn-sm btn-icon"><i class="hgi hgi-stroke hgi-delete-02"></i></button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div style="text-align:center;padding:40px;color:var(--gray-400);font-size:.82rem;">No rules yet. Add one →</div>
        <?php endif; ?>
    </div>
</div>

<script>
    // Show custom field input when "Custom" selected
    document.querySelector('[name=field]').addEventListener('change', function() {
        var cg = document.getElementById('customFieldGroup');
        cg.style.display = this.value === '' ? 'block' : 'none';
        if (this.value === '') document.getElementById('customFieldInput').focus();
    });
    // Hide value for email checks
    document.getElementById('operatorSelect').addEventListener('change', function() {
        var hide = ['is_business_email', 'is_free_email'];
        document.getElementById('valueGroup').style.display = hide.includes(this.value) ? 'none' : 'block';
    });
    // Swap field to custom input value on submit
    document.querySelector('form:last-of-type').addEventListener('submit', function() {
        var sel = this.querySelector('[name=field]');
        var cust = document.getElementById('customFieldInput');
        if (sel.value === '' && cust.value.trim()) sel.value = cust.value.trim();
    });
</script>

<?php include __DIR__ . '/layouts/footer.php'; ?>