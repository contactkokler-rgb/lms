<?php
require_once __DIR__ . '/config/auth.php';
require_once __DIR__ . '/config/BillingService.php';
require_permission('team', 'invite');
$user = auth_user();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: team.php'); exit;
}
if (!csrf_verify()) { die('CSRF mismatch'); }

$email    = trim(strtolower($_POST['email'] ?? ''));
$role_id  = (int)($_POST['role_id'] ?? 0);
$fname    = trim($_POST['first_name'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header('Location: team.php?msg=invalid_email'); exit;
}

$account_id = $user['account_id'];

// ── Plan enforcement ────────────────────────────────────────
if (!is_super_admin()) {
    BillingService::enforce($account_id, 'can_add_team_member', 'add a new team member');
    if ($err = BillingService::enforceLimit($account_id, 'team_member')) {
        $_SESSION['flash'] = ['type' => 'error', 'msg' => $err];
        header('Location: ' . APP_URL . '/team.php'); exit;
    }
}

// Check role exists and is not super_admin
$role = db_fetch("SELECT * FROM roles WHERE id=? AND name != 'super_admin'", 'i', $role_id);
if (!$role) { header('Location: team.php?msg=invalid_role'); exit; }

// Check not already a member
$exists = db_fetch('SELECT id FROM users WHERE email=? AND account_id=?', 'si', $email, $account_id);
if ($exists) { header('Location: team.php?msg=already_member'); exit; }

// Expire old pending invite for same email
db_query("UPDATE invitations SET status='expired' WHERE email=? AND account_id=? AND status='pending'", 'si', $email, $account_id);

// Create token + insert
$token      = bin2hex(random_bytes(32));
$expires_at = date('Y-m-d H:i:s', time() + INVITATION_TTL);

db_insert(
    'INSERT INTO invitations (account_id, invited_by, email, role_id, token, status, expires_at) VALUES (?,?,?,?,?,?,?)',
    'iisisss', $account_id, $user['id'], $email, $role_id, $token, 'pending', $expires_at
);

// TODO: Send invitation email here
// mail($email, 'You\'ve been invited to LeadPro', "Accept here: " . APP_URL . "/accept-invite.php?token=$token");

audit('invitation.sent', null, ['email' => $email, 'role_id' => $role_id]);

header('Location: team.php?msg=invited'); exit;
