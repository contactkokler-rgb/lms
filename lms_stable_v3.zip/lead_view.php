<?php
require_once __DIR__ . '/config/auth.php';
$user       = require_permission('leads', 'view');
$account_id = (int)($user['account_id'] ?? 0);
$is_super   = is_super_admin();

$lid = (int)($_GET['id'] ?? 0);
if (!$lid) { header('Location: ' . APP_URL . '/leads.php'); exit; }

$where = $is_super ? 'l.id = ?' : 'l.id = ? AND l.account_id = ?';
$types = $is_super ? 'i' : 'ii';
$args  = $is_super ? [$lid] : [$lid, $account_id];

$lead = db_fetch(
    "SELECT l.*, f.name AS form_name, d.domain,
     CONCAT(ua.first_name,' ',ua.last_name) AS assigned_name, ua.email AS assigned_email,
     a.name AS account_name,
     c.name AS campaign_name, c.id AS campaign_id_val, c.color AS campaign_color,
     cp.title AS campaign_page_title, cp.slug AS campaign_page_slug
     FROM leads l
     LEFT JOIN lead_forms f    ON f.id = l.form_id
     LEFT JOIN domains d       ON d.id = l.domain_id
     LEFT JOIN users ua        ON ua.id = l.assigned_to
     LEFT JOIN accounts a      ON a.id = l.account_id
     LEFT JOIN campaigns c     ON c.id = l.campaign_id
     LEFT JOIN campaign_pages cp ON cp.id = l.campaign_page_id
     WHERE $where",
    $types, ...$args
);
if (!$lead) { header('Location: ' . APP_URL . '/leads.php'); exit; }

$fields   = db_fetch_all('SELECT * FROM lead_values WHERE lead_id = ? ORDER BY id', 'i', $lid);
$comments = db_fetch_all(
    'SELECT lc.*, CONCAT(u.first_name," ",u.last_name) AS author_name
     FROM lead_comments lc JOIN users u ON u.id = lc.user_id
     WHERE lc.lead_id = ? ORDER BY lc.created_at ASC',
    'i', $lid
);
$team = $is_super
    ? db_fetch_all('SELECT id, first_name, last_name FROM users WHERE status="active" ORDER BY first_name')
    : db_fetch_all('SELECT id, first_name, last_name FROM users WHERE account_id=? AND status="active" ORDER BY first_name', 'i', $account_id);

$statuses = ['new','contacted','qualified','converted','lost','spam'];
$status_colors = [
    'new'=>'badge-blue','contacted'=>'badge-yellow','qualified'=>'badge-purple',
    'converted'=>'badge-green','lost'=>'badge-gray','spam'=>'badge-red'
];

$page_title = 'Lead · ' . ($lead['reference_no'] ?? '');
$active_nav = 'leads';

// ── Actions ──────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { http_response_code(403); die('CSRF'); }
    $act = isset($_POST['action']) ? $_POST['action'] : '';

    if ($act === 'update' && can('leads', 'edit')) {
        $status = in_array(isset($_POST['status']) ? $_POST['status'] : '', $statuses) ? $_POST['status'] : $lead['status'];
        $assign = (int)(isset($_POST['assigned_to']) ? $_POST['assigned_to'] : 0) ?: null;
        $notes  = trim(isset($_POST['notes']) ? $_POST['notes'] : '');
        $where2 = $is_super ? 'id = ?' : 'id = ? AND account_id = ?';
        $types2 = $is_super ? 'i' : 'ii';
        $params2 = $is_super ? [$lid] : [$lid, $account_id];

        // Log ownership transfer if assignment changed
        $prev_assigned = (int)($lead['assigned_to'] ?? 0);
        $new_assigned  = (int)($assign ?? 0);
        if ($prev_assigned !== $new_assigned) {
            $transfer_reason = trim($_POST['transfer_reason'] ?? '');
            // Log to ownership history
            try {
                db_insert('INSERT INTO lead_ownership_log (lead_id,account_id,from_user_id,to_user_id,transferred_by,reason) VALUES (?,?,?,?,?,?)',
                    'iiiiis',
                    $lid,
                    $is_super ? (int)$lead['account_id'] : $account_id,
                    $prev_assigned ?: null,
                    $new_assigned ?: null,
                    $user['id'],
                    $transfer_reason
                );
            } catch (\Throwable $e) { /* table may not exist yet */ }

            // Add activity comment for the transfer
            $from_name = $prev_assigned ? (function() use ($prev_assigned) {
                $u = db_fetch('SELECT first_name,last_name FROM users WHERE id=?','i',$prev_assigned);
                return $u ? trim($u['first_name'].' '.$u['last_name']) : 'Unassigned';
            })() : 'Unassigned';
            $to_name = $new_assigned ? (function() use ($new_assigned) {
                $u = db_fetch('SELECT first_name,last_name FROM users WHERE id=?','i',$new_assigned);
                return $u ? trim($u['first_name'].' '.$u['last_name']) : 'Unassigned';
            })() : 'Unassigned';

            $transfer_note = "🔄 Ownership transferred: {$from_name} → {$to_name}";
            if ($transfer_reason) $transfer_note .= "\nReason: {$transfer_reason}";
            db_insert('INSERT INTO lead_comments (lead_id,user_id,comment) VALUES (?,?,?)',
                'iis', $lid, $user['id'], $transfer_note);

            // Notify new owner
            if ($new_assigned) {
                try {
                    require_once __DIR__ . '/config/notifications.php';
                    $ref = $lead['reference_no'] ?? '';
                    notify_user($new_assigned, 'lead.assigned',
                        'Lead assigned to you',
                        'Lead '.$ref.' was transferred to you by '.trim($user['first_name'].' '.$user['last_name']).($transfer_reason ? ': '.$transfer_reason : ''),
                        '/lead_view.php?id='.$lid,
                        ['lead_id'=>$lid],
                        $is_super ? (int)$lead['account_id'] : $account_id
                    );
                } catch (\Throwable $e) { /* notifications may not be set up yet */ }
            }
            audit('lead.ownership_transferred', "lead:{$lid}", ['from'=>$prev_assigned,'to'=>$new_assigned,'reason'=>$transfer_reason]);
        }

        db_query("UPDATE leads SET status=?, assigned_to=?, notes=? WHERE $where2",
            'sis' . $types2, $status, $assign, $notes, ...$params2);
        audit('lead.updated', "lead:{$lid}");
        // Refresh engagement score after any status/assignment change
        try { require_once __DIR__ . '/config/engagement.php'; engagement_update($lid); } catch (\Throwable $e) {}
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Lead updated.'];

    } elseif ($act === 'comment' && can('leads', 'view')) {
        $comment = trim(isset($_POST['comment']) ? $_POST['comment'] : '');
        if ($comment) {
            db_insert('INSERT INTO lead_comments (lead_id, user_id, comment) VALUES (?,?,?)',
                'iis', $lid, $user['id'], $comment);
            audit('lead.comment_added', "lead:{$lid}");
            // Refresh engagement score after new comment
            try { require_once __DIR__ . '/config/engagement.php'; engagement_update($lid); } catch (\Throwable $e) {}
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Comment added.'];
        }

    // ── AI: analyze lead ─────────────────────────────────────
    } elseif ($act === 'ai_analyze' && can('leads', 'ai')) {
        require_once __DIR__ . '/config/ai.php';
        if (!ai_enabled()) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'AI is not enabled. Configure it in Platform Settings.'];
        } else {
            $fv = db_fetch_all('SELECT * FROM lead_values WHERE lead_id = ?', 'i', $lid);
            // Fetch campaign AI context — business context lives on the campaign
            $ai_campaign = [];
            if (!empty($lead['campaign_id_val'])) {
                $ai_campaign = db_fetch(
                    'SELECT name, description, objective, ai_service, ai_target_audience,
                            ai_location, ai_pricing, ai_booking_url, ai_context
                     FROM campaigns WHERE id = ?', 'i', (int)$lead['campaign_id_val']
                ) ?: [];
            }
            $result = ai_analyze_lead($lead, $fv, $ai_campaign);
            if ($result['ok']) {
                $db2   = db();
                $has_i = $db2->query("SHOW COLUMNS FROM lead_ai_results LIKE 'intent'")->num_rows        > 0;
                $has_s = $db2->query("SHOW COLUMNS FROM lead_ai_results LIKE 'sentiment'")->num_rows     > 0;
                $has_t = $db2->query("SHOW COLUMNS FROM lead_ai_results LIKE 'tags'")->num_rows          > 0;
                $has_c = $db2->query("SHOW COLUMNS FROM lead_ai_results LIKE 'lead_category'")->num_rows > 0;
                $i_v = $result['intent']        ?? 'general_enquiry';
                $s_v = $result['sentiment']      ?? 'neutral';
                $t_v = json_encode($result['tags'] ?? []);
                $c_v = $result['lead_category']  ?? 'new_lead';
                $existing = db_fetch('SELECT id FROM lead_ai_results WHERE lead_id = ?', 'i', $lid);
                if ($existing) {
                    $ex = ($has_i?',intent=?':'').($has_s?',sentiment=?':'').($has_t?',tags=?':'').($has_c?',lead_category=?':'');
                    $et = ($has_i?'s':'').($has_s?'s':'').($has_t?'s':'').($has_c?'s':'');
                    $ev = array_values(array_filter([$has_i?$i_v:null,$has_s?$s_v:null,$has_t?$t_v:null,$has_c?$c_v:null], fn($v)=>$v!==null));
                    
                    $update_values = array_merge(
                        [
                            $result['score'], 
                            $result['qualification'], 
                            $result['summary'] ?? '', 
                            $result['next_action'] ?? '',
                            $result['conversion_pct'] ?? 0, 
                            $result['reasoning'] ?? '', 
                            $result['model'] ?? '', 
                            $result['tokens'] ?? 0
                        ],
                        $ev, 
                        [$lid]
                    );

                    db_query(
                        "UPDATE lead_ai_results SET score=?,qualification=?,summary=?,next_action=?,conversion_pct=?,reasoning=?,model_used=?,tokens_used=?,updated_at=NOW(){$ex} WHERE lead_id=?",
                        'issssiss' . $et . 'i',
                        ...$update_values
                    );
                } else {
                    $ic='lead_id,score,qualification,summary,next_action,conversion_pct,reasoning,model_used,tokens_used';
                    $ip='?,?,?,?,?,?,?,?,?'; $it='iissssssi';
                    $iv=[$lid,$result['score'],$result['qualification'],$result['summary']??'',$result['next_action']??'',$result['conversion_pct']??0,$result['reasoning']??'',$result['model']??'',$result['tokens']??0];
                    if($has_i){$ic.=',intent';       $ip.=',?';$it.='s';$iv[]=$i_v;}
                    if($has_s){$ic.=',sentiment';    $ip.=',?';$it.='s';$iv[]=$s_v;}
                    if($has_t){$ic.=',tags';         $ip.=',?';$it.='s';$iv[]=$t_v;}
                    if($has_c){$ic.=',lead_category';$ip.=',?';$it.='s';$iv[]=$c_v;}
                    db_insert("INSERT INTO lead_ai_results ({$ic}) VALUES ({$ip})", $it, ...$iv);
                }
                db_query('UPDATE leads SET ai_score=?,ai_qualification=?,ai_summary=?,ai_next_action=?,ai_processed_at=NOW() WHERE id=?',
                    'isssi', $result['score'], $result['qualification'], $result['summary']??'', $result['next_action']??'', $lid);
                $db3 = db();
                if ($db3->query("SHOW COLUMNS FROM leads LIKE 'ai_intent'")->num_rows)
                    db_query('UPDATE leads SET ai_intent=? WHERE id=?',        'si', $i_v, $lid);
                if ($db3->query("SHOW COLUMNS FROM leads LIKE 'ai_sentiment'")->num_rows)
                    db_query('UPDATE leads SET ai_sentiment=? WHERE id=?',     'si', $s_v, $lid);
                if ($db3->query("SHOW COLUMNS FROM leads LIKE 'ai_tags'")->num_rows)
                    db_query('UPDATE leads SET ai_tags=? WHERE id=?',          'si', $t_v, $lid);
                if ($db3->query("SHOW COLUMNS FROM leads LIKE 'ai_lead_category'")->num_rows)
                    db_query('UPDATE leads SET ai_lead_category=? WHERE id=?', 'si', $c_v, $lid);
                if (in_array($c_v, ['spam','bot']))
                    db_query("UPDATE leads SET status='spam' WHERE id=?", 'i', $lid);
                elseif ($result['score'] >= 80)
                    db_query("UPDATE leads SET engagement_level='hot' WHERE id=? AND engagement_level != 'hot'", 'i', $lid);
                audit('lead.ai_analyzed', "lead:{$lid}");
                $_SESSION['flash'] = ['type'=>'success','msg'=>'AI analysis complete.'];
            } else {
                $_SESSION['flash'] = ['type'=>'error','msg'=>'AI error: ' . $result['error']];
            }
        }

    // ── AI: generate email ───────────────────────────────────
    } elseif ($act === 'ai_email' && can('leads', 'ai')) {
        require_once __DIR__ . '/config/ai.php';
        if (!ai_enabled()) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'AI not enabled.'];
        } else {
            $fv     = db_fetch_all('SELECT * FROM lead_values WHERE lead_id = ?', 'i', $lid);
            $tone   = in_array(isset($_POST['tone']) ? $_POST['tone'] : '', ['professional','friendly','urgent']) ? $_POST['tone'] : 'professional';
            $result = ai_generate_email($lead, $fv, $tone);
            if ($result['ok']) {
                db_query('UPDATE lead_ai_results SET email_draft=?,updated_at=NOW() WHERE lead_id=?','si','Subject: '.$result['subject']."\n\n".$result['body'],$lid);
                if (!db_fetch('SELECT id FROM lead_ai_results WHERE lead_id=?','i',$lid)) {
                    db_insert('INSERT INTO lead_ai_results (lead_id,email_draft) VALUES (?,?)', 'is', $lid, 'Subject: '.$result['subject']."\n\n".$result['body']);
                }
                $_SESSION['ai_email'] = ['subject'=>$result['subject'],'body'=>$result['body']];
                $_SESSION['flash'] = ['type'=>'success','msg'=>'Email draft generated.'];
            } else {
                $_SESSION['flash'] = ['type'=>'error','msg'=>'AI email error: ' . $result['error']];
            }
        }

    // ── AI: conversion prediction only ──────────────────────
    } elseif ($act === 'ai_predict' && can('leads', 'ai')) {
        require_once __DIR__ . '/config/ai.php';
        if (!ai_enabled()) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'AI not enabled.'];
        } else {
            $fv      = db_fetch_all('SELECT * FROM lead_values WHERE lead_id = ?', 'i', $lid);
            $context = ai_lead_context($lead, $fv);
            $prompt  = "You are a sales conversion prediction engine. Analyze this lead and respond ONLY with valid JSON — no markdown, no explanation.\n\nLead data:\n{$context}\n\nRespond ONLY with this exact JSON:\n{\"conversion_pct\":<integer 0-100>,\"reasoning\":\"<one sentence rationale>\",\"factors\":[\"<factor1>\",\"<factor2>\",\"<factor3>\"]}\n";
            $raw = ai_call([['role'=>'user','content'=>$prompt]], 300);
            if ($raw['ok']) {
                $clean  = trim(preg_replace('/```json|```/', '', trim($raw['text'])));
                $parsed = json_decode($clean, true);
                if ($parsed && isset($parsed['conversion_pct'])) {
                    $pct       = max(0, min(100, (int)$parsed['conversion_pct']));
                    $reasoning = isset($parsed['reasoning']) ? trim((string)$parsed['reasoning']) : '';
                    $factors   = isset($parsed['factors']) && is_array($parsed['factors']) ? array_slice($parsed['factors'], 0, 3) : [];
                    $stored_r  = $reasoning . ($factors ? ' | Key factors: ' . implode('; ', $factors) : '');
                    $existing  = db_fetch('SELECT id FROM lead_ai_results WHERE lead_id=?','i',$lid);
                    if ($existing) {
                        db_query('UPDATE lead_ai_results SET conversion_pct=?,reasoning=?,updated_at=NOW() WHERE lead_id=?',
                            'isi', $pct, $stored_r, $lid);
                    } else {
                        db_insert('INSERT INTO lead_ai_results (lead_id,conversion_pct,reasoning) VALUES (?,?,?)',
                            'iis', $lid, $pct, $stored_r);
                    }
                    audit('lead.ai_predicted', "lead:{$lid}");
                    $_SESSION['flash'] = ['type'=>'success','msg'=>'Conversion prediction updated.'];
                } else {
                    $_SESSION['flash'] = ['type'=>'error','msg'=>'AI returned an unexpected format.'];
                }
            } else {
                $_SESSION['flash'] = ['type'=>'error','msg'=>'AI error: ' . $raw['error']];
            }
        }

    // ── AI: enrich ───────────────────────────────────────────
    } elseif ($act === 'ai_enrich' && can('leads', 'ai')) {
        require_once __DIR__ . '/config/ai.php';
        if (!ai_enabled()) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'AI not enabled.'];
        } else {
            $fv     = db_fetch_all('SELECT * FROM lead_values WHERE lead_id = ?', 'i', $lid);
            $result = ai_enrich_lead($lead, $fv);
            if ($result['ok']) {
                // Add enrichment as a comment
                $note = "AI Enrichment:\n";
                foreach (['company','industry','job_title','cleaned_phone','notes'] as $k) {
                    if (!empty($result[$k])) $note .= ucfirst(str_replace('_',' ',$k)) . ': ' . $result[$k] . "\n";
                }
                db_insert('INSERT INTO lead_comments (lead_id, user_id, comment) VALUES (?,?,?)', 'iis', $lid, $user['id'], trim($note));
                $_SESSION['flash'] = ['type'=>'success','msg'=>'Enrichment data added to comments.'];
            } else {
                $_SESSION['flash'] = ['type'=>'error','msg'=>'AI enrich error: ' . $result['error']];
            }
        }

    // ── STEP 2: AI Smart Replies (AJAX) ──────────────────────
    } elseif ($act === 'ai_smart_replies' && can('leads', 'ai')) {
        header('Content-Type: application/json');
        require_once __DIR__ . '/config/ai.php';
        require_once __DIR__ . '/config/mailer.php';
        if (!ai_enabled()) { echo json_encode(['ok'=>false,'error'=>'AI not enabled.']); exit; }
        $fv       = db_fetch_all('SELECT field_key, field_label, value FROM lead_values WHERE lead_id = ?', 'i', $lid);
        $comments = db_fetch_all(
            "SELECT lc.comment, CONCAT(u.first_name,' ',u.last_name) AS author_name, lc.created_at
             FROM lead_comments lc JOIN users u ON u.id = lc.user_id
             WHERE lc.lead_id = ? ORDER BY lc.id ASC LIMIT 10", 'i', $lid
        );
        $ai_campaign = [];
        if (!empty($lead['campaign_id_val'])) {
            $ai_campaign = db_fetch(
                'SELECT c.*, kp.tone_of_voice, kp.business_name
                 FROM campaigns c LEFT JOIN campaign_knowledge_profile kp ON kp.campaign_id = c.id
                 WHERE c.id = ?', 'i', (int)$lead['campaign_id_val']
            ) ?: [];
        }
        $tone = in_array($_POST['tone'] ?? '', ['professional','friendly','urgent']) ? $_POST['tone'] : ($ai_campaign['auto_reply_tone'] ?? 'professional');
        $mode = in_array($_POST['mode'] ?? '', ['suggest','auto_instant','auto_intent']) ? $_POST['mode'] : 'suggest';
        $result = ai_smart_replies($lead, $fv, $comments, $ai_campaign, $tone);
        if (!$result['ok']) { echo json_encode($result); exit; }
        // Log replies
        $has_rt = db()->query("SHOW TABLES LIKE 'lead_ai_replies'")->num_rows > 0;
        $reply_ids = [];
        if ($has_rt) {
            foreach ($result['replies'] as $r) {
                $reply_ids[] = db_insert(
                    'INSERT INTO lead_ai_replies (lead_id,account_id,generated_by,reply_text,reply_subject,tone,reply_mode,kb_used,lead_intent) VALUES (?,?,?,?,?,?,?,?,?)',
                    'iiissssis', $lid, $account_id, (int)$user['id'], $r['body'], $r['subject'], $tone, $mode,
                    !empty($ai_campaign['id']) ? 1 : 0, $lead['ai_intent'] ?? ''
                );
            }
        }
        // Auto-send modes
        if (in_array($mode, ['auto_instant','auto_intent']) && !empty($result['replies'])) {
            $should_send = true;
            if ($mode === 'auto_intent') {
                $current_intent = $lead['ai_intent'] ?? '';
                if (!$current_intent) {
                    // Intent not analyzed yet — run quick analysis to get it
                    require_once __DIR__ . '/config/ai.php';
                    if (ai_enabled()) {
                        $quick_fv = db_fetch_all('SELECT field_key,field_label,value FROM lead_values WHERE lead_id=?','i',$lid);
                        $quick_r  = ai_analyze_lead($lead, $quick_fv ?: [], $ai_campaign);
                        if ($quick_r['ok']) {
                            $current_intent = $quick_r['intent'] ?? '';
                            // Save it
                            $db_qi = db();
                            if ($db_qi->query("SHOW COLUMNS FROM leads LIKE 'ai_intent'")->num_rows > 0)
                                db_query('UPDATE leads SET ai_intent=?,ai_sentiment=?,ai_lead_category=? WHERE id=?',
                                    'sssi', $current_intent, $quick_r['sentiment']??'', $quick_r['lead_category']??'', $lid);
                            $result['intent_analyzed'] = $current_intent;
                        }
                    }
                }
                $should_send = in_array($current_intent, ['appointment','pricing','consultation','treatment','emergency']);
                $result['lead_intent_used'] = $current_intent;
            }
            if ($should_send) {
                $first = $result['replies'][0];
                $lead_email = get_lead_email($lid);
                $lead_name  = get_lead_name($lid);
                if ($lead_email) {
                    $html_body   = email_wrap_html($first['body'], $first['subject']);
                    $send_result = send_email($lead_email, $lead_name, $first['subject'], $html_body);
                    $has_les = db()->query("SHOW TABLES LIKE 'lead_emails_sent'")->num_rows > 0;
                    if ($has_les) db_insert(
                        'INSERT INTO lead_emails_sent (lead_id,account_id,sent_by,to_email,subject,body,source,ai_reply_id,status,error) VALUES (?,?,?,?,?,?,?,?,?,?)',
                        'iiisssssss', $lid, $account_id, (int)$user['id'], $lead_email, $first['subject'], $first['body'], 'smart_reply', $reply_ids[0] ?? 0,
                        $send_result['ok'] ? 'sent' : 'failed', $send_result['ok'] ? '' : ($send_result['error'] ?? '')
                    );
                    if ($has_rt && !empty($reply_ids[0])) db_query(
                        'UPDATE lead_ai_replies SET was_sent=?,sent_at=NOW(),sent_to_email=?,send_error=? WHERE id=?',
                        'issi', $send_result['ok'] ? 1 : 0, $lead_email, $send_result['ok'] ? '' : ($send_result['error'] ?? ''), $reply_ids[0]
                    );
                    if ($send_result['ok']) {
                        db_insert('INSERT INTO lead_comments (lead_id, user_id, comment) VALUES (?,?,?)', 'iis', $lid, (int)$user['id'], "✉ Auto-reply sent to {$lead_email}\nSubject: {$first['subject']}");
                        audit('lead.auto_reply_sent', "lead:{$lid}");
                    }
                    $result['auto_sent']    = $send_result['ok'];
                    $result['auto_sent_to'] = $lead_email;
                    $result['auto_send_error'] = $send_result['ok'] ? null : ($send_result['error'] ?? '');
                } else {
                    $result['auto_sent'] = false; $result['no_email'] = true;
                }
            } else {
                $result['auto_sent'] = false; $result['intent_no_match'] = true;
            }
        }
        echo json_encode($result); exit;

    // ── STEP 2: Send a saved reply by email ───────────────────
    } elseif ($act === 'send_reply' && can('leads', 'ai')) {
        header('Content-Type: application/json');
        require_once __DIR__ . '/config/mailer.php';
        $subject  = trim($_POST['subject'] ?? '');
        $body     = trim($_POST['body'] ?? '');
        if (!$subject || !$body) { echo json_encode(['ok'=>false,'error'=>'Subject and body required']); exit; }
        $lead_email = get_lead_email($lid);
        $lead_name  = get_lead_name($lid);
        if (!$lead_email) { echo json_encode(['ok'=>false,'error'=>'No email address found for this lead']); exit; }
        $html_body   = email_wrap_html($body, $subject);
        $send_result = send_email($lead_email, $lead_name, $subject, $html_body);
        if ($send_result['ok']) {
            $has_les = db()->query("SHOW TABLES LIKE 'lead_emails_sent'")->num_rows > 0;
            if ($has_les) db_insert(
                'INSERT INTO lead_emails_sent (lead_id,account_id,sent_by,to_email,subject,body,source,ai_reply_id,status,error) VALUES (?,?,?,?,?,?,?,?,?,?)',
                'iiisssssss', $lid, $account_id, (int)$user['id'], $lead_email, $subject, $body, 'smart_reply', 0, 'sent', ''
            );
            db_insert('INSERT INTO lead_comments (lead_id, user_id, comment) VALUES (?,?,?)', 'iis', $lid, (int)$user['id'], "✉ Email sent to {$lead_email}\nSubject: {$subject}");
            audit('lead.email_sent', "lead:{$lid}");
        }
        echo json_encode(array_merge($send_result, ['sent_to' => $lead_email])); exit;

    // ── Soft delete ──────────────────────────────────────────
    } elseif ($act === 'soft_delete' && can('leads', 'delete')) {
        $where2 = $is_super ? 'id=?' : 'id=? AND account_id=?';
        $types2 = $is_super ? 'i' : 'ii';
        $args2  = $is_super ? [$lid] : [$lid, $account_id];
        db_query("UPDATE leads SET is_deleted=1, deleted_at=NOW() WHERE $where2", $types2, ...$args2);
        audit('lead.deleted', "lead:{$lid}");
        header('Location: ' . APP_URL . '/leads.php'); exit;

    // ── Archive ──────────────────────────────────────────────
    } elseif ($act === 'archive' && can('leads', 'archive')) {
        $where2 = $is_super ? 'id=?' : 'id=? AND account_id=?';
        $types2 = $is_super ? 'i' : 'ii';
        $args2  = $is_super ? [$lid] : [$lid, $account_id];
        db_query("UPDATE leads SET archived_at=NOW() WHERE $where2", $types2, ...$args2);
        audit('lead.archived', "lead:{$lid}");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Lead archived.'];

    } elseif ($act === 'unarchive' && can('leads', 'archive')) {
        $where2 = $is_super ? 'id=?' : 'id=? AND account_id=?';
        $types2 = $is_super ? 'i' : 'ii';
        $args2  = $is_super ? [$lid] : [$lid, $account_id];
        db_query("UPDATE leads SET archived_at=NULL WHERE $where2", $types2, ...$args2);
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Lead unarchived.'];

    // ── GDPR Erase ───────────────────────────────────────────
    } elseif ($act === 'gdpr_erase' && can('leads', 'gdpr_erase')) {
        $where2 = $is_super ? 'id=?' : 'id=? AND account_id=?';
        $types2 = $is_super ? 'i' : 'ii';
        $args2  = $is_super ? [$lid] : [$lid, $account_id];
        // Erase all PII in lead_values
        db_query("DELETE FROM lead_values WHERE lead_id=?", 'i', $lid);
        db_query("DELETE FROM lead_comments WHERE lead_id=?", 'i', $lid);
        db_query("UPDATE leads SET source_url=NULL,ip_address=NULL,user_agent=NULL,referrer=NULL,utm_source=NULL,utm_medium=NULL,utm_campaign=NULL,notes='[GDPR Erased]',gdpr_erased_at=NOW() WHERE $where2", $types2, ...$args2);
        audit('lead.gdpr_erased', "lead:{$lid}");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Lead data permanently erased (GDPR).'];

    // ── Merge leads ──────────────────────────────────────────
    } elseif ($act === 'merge' && can('leads', 'merge')) {
        $target_id   = (int)(isset($_POST['target_lead_id']) ? $_POST['target_lead_id'] : 0);
        $merge_notes = trim($_POST['merge_notes'] ?? '');
        if ($target_id && $target_id !== $lid) {
            require_once __DIR__ . '/config/deduplication.php';
            $ok = dedupe_merge($lid, $target_id, $user['id'], $merge_notes);
            if ($ok) {
                audit('lead.merged', "primary:{$lid},merged:{$target_id}");
                $_SESSION['flash'] = ['type'=>'success','msg'=>'Leads merged. Duplicate has been archived and its data preserved here.'];
            } else {
                $_SESSION['flash'] = ['type'=>'error','msg'=>'Merge failed — lead may already be deleted.'];
            }
        }

    // ── Dismiss duplicate flag ────────────────────────────────
    } elseif ($act === 'dismiss_dupe' && can('leads', 'merge')) {
        $dupe_b = (int)($_POST['dupe_lead_b'] ?? 0);
        if ($dupe_b) {
            $a = min($lid, $dupe_b); $bb = max($lid, $dupe_b);
            db_query('UPDATE lead_duplicates SET resolved=1, resolved_at=NOW(), resolved_by=? WHERE lead_id_a=? AND lead_id_b=?',
                'iii', $user['id'], $a, $bb);
            $remaining = db_fetch('SELECT COUNT(*) AS n FROM lead_duplicates WHERE (lead_id_a=? OR lead_id_b=?) AND resolved=0','ii',$lid,$lid);
            if ((int)($remaining['n']??0)===0) db_query('UPDATE leads SET has_duplicates=0 WHERE id=?','i',$lid);
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Duplicate flag dismissed.'];
        }
    }

    header('Location: ' . APP_URL . '/lead_view.php?id=' . $lid); exit;
}

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);

// Refresh after post
$lead = db_fetch(
    "SELECT l.*, f.name AS form_name, d.domain,
     CONCAT(ua.first_name,' ',ua.last_name) AS assigned_name
     FROM leads l
     LEFT JOIN lead_forms f ON f.id = l.form_id
     LEFT JOIN domains d    ON d.id = l.domain_id
     LEFT JOIN users ua     ON ua.id = l.assigned_to
     WHERE $where",
    $types, ...$args
);
$comments = db_fetch_all(
    'SELECT lc.*, CONCAT(u.first_name," ",u.last_name) AS author_name
     FROM lead_comments lc JOIN users u ON u.id = lc.user_id
     WHERE lc.lead_id = ? ORDER BY lc.created_at ASC',
    'i', $lid
);

include __DIR__ . '/layouts/header.php';
?>

<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type'] ?>" data-auto-dismiss><?= $flash['msg'] ?></div>
<?php endif; ?>

<!-- Back + Header -->
<div style="margin-bottom:20px;">
  <a href="<?= APP_URL ?>/leads.php" style="font-size:.78rem;color:var(--gray-400);text-decoration:none;display:inline-flex;align-items:center;gap:4px;margin-bottom:10px;">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
    Back to Leads
  </a>
  <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;">
    <div>
      <h1 class="page-title" style="margin-bottom:4px;"><?= h($lead['reference_no']) ?></h1>
      <div style="display:flex;align-items:center;gap:8px;">
        <span class="badge <?= $status_colors[$lead['status']] ?? 'badge-gray' ?>">
          <span class="badge-dot"></span><?= ucfirst($lead['status']) ?>
        </span>
        <span style="font-size:.75rem;color:var(--gray-400);"><?= format_dt($lead['submitted_at']) ?></span>
      </div>
    </div>
  </div>
</div>

<div style="display:grid;grid-template-columns:1fr 320px;gap:20px;align-items:start;">

  <!-- Left col -->
  <div>

    <!-- Form data -->
    <div class="card" style="margin-bottom:16px;">
      <div class="card-header">
        <div class="card-title">Form Data</div>
        <div class="card-subtitle"><?= h($lead['form_name'] ?? '—') ?> · <?= h($lead['domain'] ?? '') ?></div>
      </div>
      <div class="card-body">
        <?php if ($fields): ?>
        <div style="display:grid;gap:12px;">
          <?php foreach ($fields as $fv): ?>
          <div style="display:grid;grid-template-columns:160px 1fr;gap:8px;align-items:start;padding-bottom:12px;border-bottom:1px solid var(--gray-100);">
            <div style="font-size:.72rem;font-weight:700;color:var(--gray-400);letter-spacing:.04em;text-transform:uppercase;padding-top:2px;"><?= h($fv['field_label']) ?></div>
            <div style="font-size:.85rem;color:var(--gray-800);word-break:break-word;"><?= h($fv['value'] ?: '—') ?></div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php else: ?>
        <p style="color:var(--gray-400);font-size:.82rem;">No field data captured.</p>
        <?php endif; ?>
      </div>
    </div>

    <!-- Notes -->
    <?php if (can('leads', 'edit')): ?>
    <div class="card" style="margin-bottom:16px;">
      <div class="card-header"><div class="card-title">Notes</div></div>
      <div class="card-body">
        <form method="POST">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="update">
          <input type="hidden" name="status" value="<?= h($lead['status']) ?>">
          <input type="hidden" name="assigned_to" value="<?= (int)$lead['assigned_to'] ?>">
          <textarea name="notes" class="form-control" rows="4" placeholder="Add internal notes…"><?= h($lead['notes'] ?? '') ?></textarea>
          <button type="submit" class="btn btn-primary btn-sm" style="margin-top:10px;">Save Notes</button>
        </form>
      </div>
    </div>
    <?php endif; ?>

    <!-- Comments -->
    <div class="card">
      <div class="card-header"><div class="card-title">Activity</div></div>
      <div class="card-body">
        <?php if ($comments): ?>
        <div style="display:flex;flex-direction:column;gap:14px;margin-bottom:16px;">
          <?php foreach ($comments as $c):
            $initials = strtoupper(substr($c['author_name'],0,1));
            $colors = ['#2563eb','#7c3aed','#0891b2','#16a34a'];
            $col = $colors[crc32($c['author_name']) % count($colors)];
          ?>
          <div style="display:flex;gap:10px;align-items:flex-start;">
            <div style="width:30px;height:30px;border-radius:50%;background:<?= $col ?>;display:flex;align-items:center;justify-content:center;font-size:.72rem;font-weight:700;color:#fff;flex-shrink:0;"><?= $initials ?></div>
            <div style="flex:1;">
              <div style="display:flex;align-items:baseline;gap:6px;margin-bottom:3px;">
                <span style="font-size:.78rem;font-weight:600;color:var(--gray-700);"><?= h($c['author_name']) ?></span>
                <span style="font-size:.7rem;color:var(--gray-300);"><?= format_dt($c['created_at'], 'd M, g:ia') ?></span>
              </div>
              <div style="font-size:.82rem;color:var(--gray-600);line-height:1.5;background:var(--gray-50);padding:8px 10px;border-radius:8px;"><?= nl2br(h($c['comment'])) ?></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <form method="POST" style="display:flex;gap:8px;align-items:flex-end;">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="comment">
          <textarea name="comment" class="form-control" rows="2" placeholder="Add a comment…" style="flex:1;resize:none;" required></textarea>
          <button type="submit" class="btn btn-primary btn-sm" style="flex-shrink:0;">Post</button>
        </form>
      </div>
    </div>

  </div>

  <!-- Right col -->
  <div style="display:flex;flex-direction:column;gap:16px;">

    <!-- Quick update + Ownership Transfer -->
    <?php if (can('leads', 'edit')): ?>
    <?php
    // Load ownership history (safe — table may not exist yet)
    $ownership_log = [];
    try {
        $ownership_log = db_fetch_all(
            "SELECT ol.*,
             CONCAT(fb.first_name,' ',fb.last_name) AS from_name,
             CONCAT(tb.first_name,' ',tb.last_name) AS to_name,
             CONCAT(by_.first_name,' ',by_.last_name) AS by_name
             FROM lead_ownership_log ol
             LEFT JOIN users fb ON fb.id = ol.from_user_id
             LEFT JOIN users tb ON tb.id = ol.to_user_id
             LEFT JOIN users by_ ON by_.id = ol.transferred_by
             WHERE ol.lead_id = ?
             ORDER BY ol.transferred_at DESC LIMIT 10",
            'i', $lid
        );
    } catch (\Throwable $e) { /* table not yet created */ }
    $can_transfer = can('leads', 'assign');
    ?>
    <div class="card">
      <div class="card-header">
        <div class="card-title">Update Lead</div>
      </div>
      <div class="card-body">
        <form method="POST" id="updateLeadForm">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="update">
          <input type="hidden" name="notes" value="<?= h($lead['notes'] ?? '') ?>">
          <div class="form-group">
            <label class="form-label" style="font-size:.72rem;">Status</label>
            <select name="status" class="form-control form-control-sm">
              <?php foreach ($statuses as $s): ?>
              <option value="<?= $s ?>" <?= $lead['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label" style="font-size:.72rem;">
              Assigned To
              <?php if ($can_transfer && $lead['assigned_to']): ?>
              <span style="font-size:.65rem;color:var(--brand-500);margin-left:4px;">· Transfer will be logged</span>
              <?php endif; ?>
            </label>
            <select name="assigned_to" class="form-control form-control-sm" id="assignedSelect"
              onchange="checkTransferReason(this)">
              <option value="">Unassigned</option>
              <?php foreach ($team as $t): ?>
              <option value="<?= $t['id'] ?>" <?= (int)$lead['assigned_to'] === (int)$t['id'] ? 'selected' : '' ?>>
                <?= h($t['first_name'] . ' ' . $t['last_name']) ?>
              </option>
              <?php endforeach; ?>
            </select>
          </div>
          <!-- Transfer reason — shown when assignment changes -->
          <div class="form-group" id="transferReasonGroup" style="display:<?= $can_transfer ? 'none' : 'none' ?>;">
            <label class="form-label" style="font-size:.72rem;">Transfer Reason <span style="color:var(--gray-400);">(optional)</span></label>
            <input type="text" name="transfer_reason" class="form-control form-control-sm"
              placeholder="e.g. Territory change, agent on leave…" maxlength="255">
          </div>
          <button type="submit" class="btn btn-primary btn-sm" style="width:100%;">Save Changes</button>
        </form>
      </div>

      <?php if ($ownership_log): ?>
      <!-- Ownership history accordion -->
      <div style="border-top:1px solid var(--gray-100);">
        <button type="button" onclick="toggleOwnershipLog()" id="ownershipToggle"
          style="width:100%;padding:10px 16px;background:none;border:none;cursor:pointer;display:flex;align-items:center;justify-content:space-between;font-size:.74rem;color:var(--gray-500);">
          <span style="display:flex;align-items:center;gap:5px;">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>
            Ownership History (<?= count($ownership_log) ?>)
          </span>
          <svg id="ownershipArrow" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
        </button>
        <div id="ownershipLog" style="display:none;padding:0 16px 12px;">
          <?php foreach ($ownership_log as $ol): ?>
          <div style="padding:8px 0;border-bottom:1px solid var(--gray-100);font-size:.74rem;">
            <div style="display:flex;align-items:center;gap:5px;color:var(--gray-700);margin-bottom:2px;">
              <span style="font-weight:600;"><?= h(trim($ol['from_name']) ?: 'Unassigned') ?></span>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="var(--gray-400)" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
              <span style="font-weight:600;color:var(--brand-600);"><?= h(trim($ol['to_name']) ?: 'Unassigned') ?></span>
            </div>
            <div style="color:var(--gray-400);font-size:.68rem;">
              By <?= h(trim($ol['by_name'])) ?> · <?= format_dt($ol['transferred_at'], 'd M Y, g:ia') ?>
            </div>
            <?php if ($ol['reason']): ?>
            <div style="color:var(--gray-500);margin-top:2px;font-style:italic;">"<?= h($ol['reason']) ?>"</div>
            <?php endif; ?>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Lead info -->
    <div class="card">
      <div class="card-header"><div class="card-title">Lead Info</div></div>
      <div class="card-body">
        <?php
        $info_rows = [
            ['Form',     $lead['form_name'] ?? '—'],
            ['Domain',   $lead['domain'] ?? '—'],
            ['Assigned', $lead['assigned_name'] ? trim($lead['assigned_name']) : 'Unassigned'],
            ['IP',       $lead['ip_address'] ?? '—'],
            ['Device',   $lead['device_type'] ?? '—'],
            ['Browser',  $lead['browser'] ?? '—'],
            ['Country',  $lead['country'] ?? '—'],
        ];
        foreach ($info_rows as [$lbl, $val]): if (!$val || $val === '—') continue; ?>
        <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--gray-100);font-size:.78rem;">
          <span style="color:var(--gray-400);"><?= $lbl ?></span>
          <span style="color:var(--gray-700);font-weight:500;text-align:right;max-width:160px;word-break:break-all;"><?= h($val) ?></span>
        </div>
        <?php endforeach; ?>

        <?php if (!empty($lead['campaign_name'])): ?>
        <div style="margin-top:10px;padding-top:10px;border-top:1px solid var(--gray-100);">
          <div style="font-size:.68rem;font-weight:700;color:var(--gray-400);letter-spacing:.05em;text-transform:uppercase;margin-bottom:8px;">Campaign Attribution</div>
          <div style="display:flex;align-items:center;gap:8px;padding:8px 10px;background:var(--gray-50);border-radius:8px;border:1px solid var(--gray-100);">
            <span style="width:10px;height:10px;border-radius:50%;background:<?= h($lead['campaign_color'] ?? '#2563eb') ?>;flex-shrink:0;"></span>
            <div style="flex:1;min-width:0;">
              <a href="<?= APP_URL ?>/campaign_view.php?id=<?= (int)$lead['campaign_id_val'] ?>"
                 style="font-size:.78rem;font-weight:700;color:var(--brand-600);text-decoration:none;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                <?= h($lead['campaign_name']) ?>
              </a>
              <?php if (!empty($lead['campaign_page_title'])): ?>
              <div style="font-size:.7rem;color:var(--gray-500);margin-top:1px;">
                📄 <?= h($lead['campaign_page_title']) ?>
                <?php if (!empty($lead['campaign_page_slug'])): ?>
                <a href="<?= APP_URL ?>/lp/<?= h($lead['campaign_page_slug']) ?>" target="_blank"
                   style="color:var(--gray-400);text-decoration:none;margin-left:4px;" title="View page">↗</a>
                <?php endif; ?>
              </div>
              <?php endif; ?>
            </div>
            <a href="<?= APP_URL ?>/campaign_view.php?id=<?= (int)$lead['campaign_id_val'] ?>"
               style="font-size:.68rem;color:var(--brand-500);text-decoration:none;white-space:nowrap;flex-shrink:0;">View →</a>
          </div>
        </div>
        <?php endif; ?>

        <?php if ($lead['referrer']): ?>
        <div style="padding:6px 0;border-bottom:1px solid var(--gray-100);">
          <div style="font-size:.7rem;color:var(--gray-400);margin-bottom:2px;">Referrer</div>
          <a href="<?= h($lead['referrer']) ?>" target="_blank" style="font-size:.72rem;color:var(--brand-500);word-break:break-all;"><?= h($lead['referrer']) ?></a>
        </div>
        <?php endif; ?>

        <?php if ($lead['utm_source'] || $lead['utm_medium'] || $lead['utm_campaign']): ?>
        <div style="margin-top:10px;">
          <div style="font-size:.68rem;font-weight:700;color:var(--gray-400);letter-spacing:.05em;text-transform:uppercase;margin-bottom:6px;">UTM Tracking</div>
          <?php foreach (['utm_source','utm_medium','utm_campaign'] as $u): ?>
          <?php if (!empty($lead[$u])): ?>
          <div style="display:flex;justify-content:space-between;font-size:.74rem;padding:3px 0;">
            <span style="color:var(--gray-400);"><?= str_replace('utm_','',$u) ?></span>
            <span style="color:var(--gray-600);font-weight:500;"><?= h($lead[$u]) ?></span>
          </div>
          <?php endif; ?>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <?php if ($lead['source_url']): ?>
        <div style="margin-top:10px;">
          <div style="font-size:.68rem;font-weight:700;color:var(--gray-400);letter-spacing:.05em;text-transform:uppercase;margin-bottom:4px;">Landing Page</div>
          <a href="<?= h($lead['source_url']) ?>" target="_blank" rel="noopener"
             style="font-size:.72rem;color:var(--brand-500);word-break:break-all;"><?= h($lead['source_url']) ?></a>
        </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Reminders panel -->
    <?php
    $lead_reminders_list = [];
    try {
        require_once __DIR__ . '/config/reminders.php';
        $lead_reminders_list = db_fetch_all(
            "SELECT r.*, CONCAT(u.first_name,' ',u.last_name) AS user_name
             FROM lead_reminders r LEFT JOIN users u ON u.id=r.user_id
             WHERE r.lead_id=? AND r.is_done=0
             ORDER BY r.remind_at ASC LIMIT 10",
            'i', $lid
        );
    } catch (\Throwable $e) {}

    // Handle reminder AJAX from lead view
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['_reminder_action'])) {
        header('Content-Type: application/json');
        if (csrf_verify()) {
            $rid_r = (int)($_POST['reminder_id'] ?? 0);
            if ($_POST['_reminder_action'] === 'done') reminder_mark_done($rid_r, (int)$user['id']);
            elseif ($_POST['_reminder_action'] === 'snooze') reminder_snooze($rid_r, (int)$user['id'], (int)($_POST['minutes'] ?? 60));
            elseif ($_POST['_reminder_action'] === 'create') {
                $msg = trim($_POST['reminder_msg'] ?? '');
                $at  = trim($_POST['reminder_at'] ?? '');
                $uid_r = (int)($_POST['reminder_user'] ?? $user['id']);
                if ($msg && $at) reminder_create_manual($lid, $uid_r, $is_super ? (int)$lead['account_id'] : $account_id, $msg, $at, (int)$user['id']);
            }
        }
        echo json_encode(['ok'=>true]); exit;
    }
    ?>
    <div class="card" style="margin-bottom:0;">
      <div class="card-header">
        <div class="card-title">Reminders</div>
        <button type="button" onclick="toggleNewReminder()" style="background:none;border:none;cursor:pointer;color:var(--brand-500);font-size:.75rem;font-weight:600;padding:0;">+ Add</button>
      </div>

      <!-- New reminder form (hidden by default) -->
      <div id="newReminderForm" style="display:none;padding:12px 16px;background:var(--gray-50);border-bottom:1px solid var(--gray-100);">
        <div class="form-group" style="margin-bottom:8px;">
          <label class="form-label" style="font-size:.7rem;">Note</label>
          <input type="text" id="remMsgInput" class="form-control form-control-sm" placeholder="e.g. Call back to discuss pricing…" maxlength="500">
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px;">
          <div class="form-group" style="margin:0;">
            <label class="form-label" style="font-size:.7rem;">Remind At</label>
            <input type="datetime-local" id="remAtInput" class="form-control form-control-sm">
          </div>
          <div class="form-group" style="margin:0;">
            <label class="form-label" style="font-size:.7rem;">Assign To</label>
            <select id="remUserInput" class="form-control form-control-sm">
              <option value="<?= $user['id'] ?>">Me (<?= h($user['first_name']) ?>)</option>
              <?php foreach ($team as $t): if ((int)$t['id'] === (int)$user['id']) continue; ?>
              <option value="<?= $t['id'] ?>"><?= h($t['first_name'].' '.$t['last_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        <button type="button" onclick="submitNewReminder()" class="btn btn-primary btn-sm">Set Reminder</button>
        <button type="button" onclick="toggleNewReminder()" class="btn btn-secondary btn-sm">Cancel</button>
      </div>

      <!-- Existing reminders -->
      <div id="leadReminderList" style="padding:0 4px 4px;">
        <?php if ($lead_reminders_list): ?>
        <?php foreach ($lead_reminders_list as $r):
          $rc = reminder_type_color($r['type']);
          $rl = reminder_type_label($r['type']);
          $isPast = strtotime($r['remind_at']) <= time();
        ?>
        <div id="lrem_<?= $r['id'] ?>" style="display:flex;align-items:flex-start;gap:8px;padding:10px 12px;border-bottom:1px solid var(--gray-100);">
          <span style="width:7px;height:7px;border-radius:50%;background:<?= $rc ?>;flex-shrink:0;margin-top:4px;"></span>
          <div style="flex:1;min-width:0;">
            <div style="font-size:.78rem;color:var(--gray-700);"><?= h($r['message'] ?? $rl) ?></div>
            <div style="font-size:.68rem;color:var(--gray-400);margin-top:2px;">
              <?= h($r['user_name'] ?? 'You') ?> · <span style="color:<?= $isPast?'#ef4444':'var(--gray-400)'?>"><?= format_dt($r['remind_at'],'d M, g:ia') ?></span>
            </div>
          </div>
          <div style="display:flex;gap:3px;flex-shrink:0;">
            <button onclick="lremDone(<?= $r['id'] ?>)" title="Done"
              style="width:22px;height:22px;border:1px solid #bbf7d0;background:#f0fdf4;border-radius:5px;cursor:pointer;display:flex;align-items:center;justify-content:center;">
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#16a34a" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
            </button>
            <div style="position:relative;">
              <button onclick="lremToggleSnooze(<?= $r['id'] ?>)" title="Snooze"
                style="width:22px;height:22px;border:1px solid var(--gray-200);background:var(--gray-50);border-radius:5px;cursor:pointer;display:flex;align-items:center;justify-content:center;">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="var(--gray-500)" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
              </button>
              <div id="lSnooze_<?= $r['id'] ?>" style="display:none;position:absolute;right:0;top:26px;background:#fff;border:1px solid var(--gray-200);border-radius:8px;box-shadow:0 4px 16px rgba(0,0,0,.1);z-index:99;min-width:120px;">
                <?php foreach ([30=>'30 min',60=>'1 hour',180=>'3 hours',1440=>'Tomorrow'] as $m=>$ml): ?>
                <button onclick="lremSnooze(<?= $r['id'] ?>,<?= $m ?>)"
                  style="display:block;width:100%;text-align:left;padding:7px 12px;font-size:.73rem;color:var(--gray-700);background:none;border:none;cursor:pointer;"
                  onmouseover="this.style.background='var(--gray-50)'" onmouseout="this.style.background=''">
                  <?= $ml ?>
                </button>
                <?php endforeach; ?>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
        <?php else: ?>
        <div style="padding:14px 12px;font-size:.75rem;color:var(--gray-400);text-align:center;">No pending reminders</div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Score panel -->
    <?php
    $score     = (int)($lead['score'] ?? 0);
    $score_cat = $lead['score_category'] ?? 'cold';
    $ai_res    = db_fetch('SELECT * FROM lead_ai_results WHERE lead_id = ?', 'i', $lid);
    ?>
    <div class="card">
      <div class="card-header">
        <div class="card-title">Lead Score</div>
        <span class="score-pill score-<?= $score_cat ?>">
          <span class="score-dot"></span>
          <?= ucfirst($score_cat) ?>
        </span>
      </div>
      <div style="padding:14px 16px;">
        <!-- Rule-based score bar -->
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
          <div style="font-size:.72rem;color:var(--gray-400);width:64px;">Rules</div>
          <div style="flex:1;height:8px;background:var(--gray-100);border-radius:4px;overflow:hidden;">
            <div style="height:100%;width:<?= $score ?>%;background:<?= $score_cat==='hot'?'#ef4444':($score_cat==='warm'?'#f97316':'#94a3b8') ?>;border-radius:4px;transition:width .4s;"></div>
          </div>
          <div style="font-size:.82rem;font-weight:700;color:var(--gray-800);width:30px;text-align:right;"><?= $score ?></div>
        </div>

        <?php if ($ai_res && $ai_res['score'] !== null): ?>
        <!-- AI score bar -->
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
          <div style="font-size:.72rem;color:var(--gray-400);width:64px;">AI</div>
          <div style="flex:1;height:8px;background:var(--gray-100);border-radius:4px;overflow:hidden;">
            <div style="height:100%;width:<?= $ai_res['score'] ?>%;background:linear-gradient(90deg,#6366f1,#8b5cf6);border-radius:4px;"></div>
          </div>
          <div style="font-size:.82rem;font-weight:700;color:#6366f1;width:30px;text-align:right;"><?= $ai_res['score'] ?></div>
        </div>
        <?php if ($ai_res['qualification']): ?>
        <div style="display:flex;justify-content:space-between;align-items:center;font-size:.76rem;margin-bottom:6px;">
          <span style="color:var(--gray-400);">Qualification</span>
          <span class="ai-qual-badge ai-qual-<?= h($ai_res['qualification']) ?>"><?= ucfirst($ai_res['qualification']) ?></span>
        </div>
        <?php endif; ?>
        <?php if ($ai_res['conversion_pct'] !== null):
          $cpct    = (int)$ai_res['conversion_pct'];
          $c_col   = $cpct >= 70 ? '#16a34a' : ($cpct >= 40 ? '#f59e0b' : '#ef4444');
          $c_label = $cpct >= 70 ? 'High' : ($cpct >= 40 ? 'Medium' : 'Low');
          // Parse reasoning for factors
          $raw_r   = $ai_res['reasoning'] ?? '';
          $factors = [];
          if (strpos($raw_r, '| Key factors:') !== false) {
              $parts   = explode('| Key factors:', $raw_r, 2);
              $raw_r   = trim($parts[0]);
              $factors = array_map('trim', explode(';', $parts[1]));
          }
        ?>
        <div style="margin:10px 0 6px;padding:12px;background:var(--gray-50);border-radius:10px;border:1.5px solid var(--gray-100);">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
            <span style="font-size:.72rem;font-weight:700;color:var(--gray-500);text-transform:uppercase;letter-spacing:.05em;">Conversion Prediction</span>
            <span style="font-size:.72rem;font-weight:700;padding:2px 8px;border-radius:10px;background:<?= $c_col ?>22;color:<?= $c_col ?>;"><?= $c_label ?></span>
          </div>
          <!-- Gauge arc (SVG) -->
          <div style="display:flex;align-items:center;gap:12px;">
            <div style="position:relative;width:64px;height:40px;flex-shrink:0;">
              <svg width="64" height="40" viewBox="0 0 64 40">
                <path d="M6 36 A26 26 0 0 1 58 36" fill="none" stroke="#e2e8f0" stroke-width="6" stroke-linecap="round"/>
                <?php
                  $arc_len = 81.7; // approx half-circumference for r=26
                  $dash    = round($arc_len * $cpct / 100, 1);
                  $gap     = $arc_len - $dash;
                ?>
                <path d="M6 36 A26 26 0 0 1 58 36" fill="none" stroke="<?= $c_col ?>" stroke-width="6"
                      stroke-linecap="round"
                      stroke-dasharray="<?= $dash ?> <?= $gap + 50 ?>"
                      style="transition:stroke-dasharray .6s ease;"/>
              </svg>
              <div style="position:absolute;bottom:0;left:0;right:0;text-align:center;font-size:.9rem;font-weight:800;color:<?= $c_col ?>;"><?= $cpct ?>%</div>
            </div>
            <div style="flex:1;min-width:0;">
              <?php if ($raw_r): ?>
              <div style="font-size:.71rem;color:var(--gray-500);line-height:1.5;margin-bottom:5px;"><?= h($raw_r) ?></div>
              <?php endif; ?>
              <?php if ($factors): ?>
              <?php foreach ($factors as $f): if (!trim($f)) continue; ?>
              <div style="font-size:.68rem;color:var(--gray-400);display:flex;align-items:center;gap:4px;">
                <span style="color:<?= $c_col ?>;">•</span> <?= h(trim($f)) ?>
              </div>
              <?php endforeach; ?>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <?php endif; ?>
        <?php endif; ?>

        <?php if (can('leads','manage_score')): ?>
        <a href="<?= APP_URL ?>/score_rules.php" style="font-size:.72rem;color:var(--brand-500);text-decoration:none;display:block;margin-top:8px;">Manage scoring rules →</a>
        <?php endif; ?>
      </div>
    </div>

    <!-- Engagement Heat Score Panel -->
    <?php
    try {
        require_once __DIR__ . '/config/engagement.php';
        $eng_result = engagement_calc($lid);
        $eng_level  = $eng_result['level'];
        $eng_score  = $eng_result['score'];
        $eng_sigs   = $eng_result['signals'];
        $eng_show   = true;
    } catch (\Throwable $e) { $eng_show = false; }
    ?>
    <?php if (!empty($eng_show)): ?>
    <?php
    $eng_clr = ['hot'=>['#fef2f2','#ef4444','#991b1b'],'warm'=>['#fffbeb','#f59e0b','#92400e'],'cold'=>['#f0f9ff','#38bdf8','#0c4a6e']];
    [$eng_bg, $eng_dot, $eng_txt] = $eng_clr[$eng_level] ?? $eng_clr['cold'];
    $eng_label = ['hot'=>'🔥 Hot Lead','warm'=>'🟡 Warm Lead','cold'=>'❄️ Cold Lead'][$eng_level];
    ?>
    <div class="card" style="margin-bottom:0;">
      <div class="card-header">
        <div class="card-title">Engagement Heat</div>
        <span style="display:inline-flex;align-items:center;gap:5px;font-size:.72rem;padding:3px 9px;background:<?= $eng_bg ?>;border:1px solid <?= $eng_dot ?>44;color:<?= $eng_txt ?>;border-radius:12px;font-weight:700;">
          <span style="width:7px;height:7px;border-radius:50%;background:<?= $eng_dot ?>;"></span>
          <?= $eng_label ?>
        </span>
      </div>
      <div style="padding:12px 16px 14px;">
        <!-- Score bar -->
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;">
          <div style="flex:1;height:8px;background:var(--gray-100);border-radius:4px;overflow:hidden;">
            <div style="height:100%;width:<?= $eng_score ?>%;background:<?= $eng_dot ?>;border-radius:4px;transition:width .5s;"></div>
          </div>
          <span style="font-size:.8rem;font-weight:700;color:<?= $eng_txt ?>;min-width:26px;text-align:right;"><?= $eng_score ?></span>
        </div>
        <!-- Signal breakdown -->
        <?php foreach ($eng_sigs as $sig): ?>
        <div style="display:flex;justify-content:space-between;align-items:center;padding:5px 0;border-bottom:1px solid var(--gray-50);">
          <span style="font-size:.74rem;color:var(--gray-500);"><?= h($sig['label']) ?></span>
          <div style="display:flex;align-items:center;gap:7px;">
            <span style="font-size:.7rem;color:var(--gray-400);"><?= h($sig['detail']) ?></span>
            <span style="font-size:.7rem;font-weight:700;color:<?= $sig['pts']>0?'var(--brand-600)':'var(--gray-300)' ?>;">+<?= $sig['pts'] ?></span>
          </div>
        </div>
        <?php endforeach; ?>
        <div style="margin-top:8px;font-size:.68rem;color:var(--gray-300);text-align:right;">Updated on page load</div>
      </div>
    </div>
    <?php endif; ?>

    <!-- AI Panel — Step 2: Smart Reply + Email Engine -->
    <?php if (can('leads','ai')): ?>
    <?php
    require_once __DIR__ . '/config/ai.php';
    require_once __DIR__ . '/config/mailer.php';

    $ai_on       = ai_enabled();
    $lead_email  = get_lead_email($lid);
    $lead_name   = get_lead_name($lid);

    // Step 1 display fields
    $ai_intent   = $ai_res['intent']        ?? ($lead['ai_intent']        ?? '');
    $ai_sent     = $ai_res['sentiment']      ?? ($lead['ai_sentiment']     ?? '');
    $ai_lcat     = $ai_res['lead_category']  ?? ($lead['ai_lead_category'] ?? '');
    $ai_tags_raw = $ai_res['tags']           ?? ($lead['ai_tags']          ?? '[]');
    $ai_tags     = is_array($ai_tags_raw) ? $ai_tags_raw : (json_decode($ai_tags_raw, true) ?: []);

    $intent_map = [
        'appointment'     => ['badge-info',    '🗓 Appointment'],
        'pricing'         => ['badge-warning', '💰 Pricing'],
        'consultation'    => ['badge-brand',   '💬 Consultation'],
        'treatment'       => ['badge-info',    '🏥 Treatment'],
        'emergency'       => ['badge-danger',  '🚨 Emergency'],
        'general_enquiry' => ['badge-default', '❓ Enquiry'],
        'information'     => ['badge-default', 'ℹ️ Information'],
        'complaint'       => ['badge-warning', '⚠️ Complaint'],
        'other'           => ['badge-default', '• Other'],
    ];
    $sent_map = [
        'positive' => ['badge-success', '😊 Positive'],
        'neutral'  => ['badge-default', '😐 Neutral'],
        'negative' => ['badge-danger',  '😟 Negative'],
        'urgent'   => ['badge-warning', '⚡ Urgent'],
    ];
    $cat_map = [
        'new_lead'          => ['badge-brand',   'New Lead'],
        'returning_lead'    => ['badge-info',    'Returning'],
        'existing_customer' => ['badge-success', 'Existing Customer'],
        'duplicate'         => ['badge-warning', 'Duplicate'],
        'spam'              => ['badge-danger',  'Spam'],
        'bot'               => ['badge-danger',  'Bot'],
    ];

    // Campaign reply mode default
    $camp_reply_mode = 'suggest';
    if (!empty($lead['campaign_id_val'])) {
        $camp_data = db_fetch('SELECT reply_mode, auto_reply_tone FROM campaigns WHERE id=?', 'i', (int)$lead['campaign_id_val']);
        $camp_reply_mode = $camp_data['reply_mode'] ?? 'suggest';
    }

    // Email history (last 5 sent)
    $email_history = [];
    $db_les = db();
    if ($db_les->query("SHOW TABLES LIKE 'lead_emails_sent'")->num_rows > 0) {
        $email_history = db_fetch_all(
            "SELECT les.*, CONCAT(u.first_name,' ',u.last_name) AS sent_by_name
             FROM lead_emails_sent les
             LEFT JOIN users u ON u.id = les.sent_by
             WHERE les.lead_id = ? ORDER BY les.id DESC LIMIT 5",
            'i', $lid
        );
    }

    $email_draft = isset($_SESSION['ai_email']) ? $_SESSION['ai_email'] : null;
    unset($_SESSION['ai_email']);
    ?>
    <div class="ai-panel">
      <div class="ai-panel-header">
        <div class="ai-panel-title">
          <i class="hgi hgi-stroke hgi-ai-brain-05"></i>
          AI Intelligence
        </div>
        <?php if ($ai_res && $ai_res['updated_at']): ?>
        <span class="text-muted" style="font-size:.68rem;"><?= format_dt($ai_res['updated_at'], 'd M, H:i') ?></span>
        <?php endif; ?>
      </div>

      <div class="ai-panel-body">
        <?php if (!$ai_on): ?>
        <div class="text-center text-muted" style="padding:12px 0;font-size:.8rem;">
          AI not configured.
          <?php if ($is_super): ?>
          <a href="<?= APP_URL ?>/settings.php?tab=ai" class="text-brand">Set up →</a>
          <?php else: ?>Contact your admin.<?php endif; ?>
        </div>
        <?php else: ?>

        <?php if ($ai_res && $ai_res['summary']): ?>
        <!-- Step 1 Badges -->
        <?php if ($ai_intent || $ai_sent || $ai_lcat): ?>
        <div class="flex flex-wrap gap-1 mb-2">
          <?php if ($ai_intent && isset($intent_map[$ai_intent])): ?>
          <span class="badge <?= $intent_map[$ai_intent][0] ?> badge-sm"><?= $intent_map[$ai_intent][1] ?></span>
          <?php endif; ?>
          <?php if ($ai_sent && isset($sent_map[$ai_sent])): ?>
          <span class="badge <?= $sent_map[$ai_sent][0] ?> badge-sm"><?= $sent_map[$ai_sent][1] ?></span>
          <?php endif; ?>
          <?php if ($ai_lcat && isset($cat_map[$ai_lcat])): ?>
          <span class="badge <?= $cat_map[$ai_lcat][0] ?> badge-sm"><?= $cat_map[$ai_lcat][1] ?></span>
          <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php if (!empty($ai_tags)): ?>
        <div class="flex flex-wrap gap-1 mb-2">
          <?php foreach ($ai_tags as $tag): ?>
          <span class="badge badge-default badge-sm">#<?= h($tag) ?></span>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div style="font-size:.77rem;color:#cbd5e1;line-height:1.6;margin-bottom:8px;"><?= h($ai_res['summary']) ?></div>
        <?php if ($ai_res['next_action']): ?>
        <div class="ai-action-box mb-2">
          <div style="font-size:.63rem;color:#94a3b8;text-transform:uppercase;letter-spacing:.06em;margin-bottom:3px;">Recommended Action</div>
          <div style="font-size:.78rem;"><?= h($ai_res['next_action']) ?></div>
        </div>
        <?php endif; ?>
        <?php endif; ?>

        <!-- Analyze / Predict buttons -->
        <div class="flex flex-wrap gap-1 mb-3">
          <form method="POST" style="display:contents;">
            <?= csrf_field() ?><input type="hidden" name="action" value="ai_analyze">
            <button type="submit" class="ai-btn">
              <i class="hgi hgi-stroke hgi-refresh"></i>
              <?= $ai_res ? 'Re-analyze' : 'Analyze Lead' ?>
            </button>
          </form>
          <form method="POST" style="display:contents;">
            <?= csrf_field() ?><input type="hidden" name="action" value="ai_predict">
            <button type="submit" class="ai-btn">
              <i class="hgi hgi-stroke hgi-target-02"></i>
              <?= ($ai_res && $ai_res['conversion_pct'] !== null) ? 'Re-predict' : 'Predict' ?>
            </button>
          </form>
          <?php if (ai_setting('ai_enrich_enabled','1') === '1'): ?>
          <form method="POST" style="display:contents;">
            <?= csrf_field() ?><input type="hidden" name="action" value="ai_enrich">
            <button type="submit" class="ai-btn"><i class="hgi hgi-stroke hgi-user-search-02"></i> Enrich</button>
          </form>
          <?php endif; ?>
        </div>

        <!-- ── Smart Reply Section ───────────────── -->
        <?php if (ai_setting('ai_smart_reply_enabled','1') === '1'): ?>
        <div style="border-top:1px solid rgba(255,255,255,.1);padding-top:12px;margin-top:4px;">

          <div style="font-size:.68rem;font-weight:700;color:var(--brand-400);text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px;">
            <i class="hgi hgi-stroke hgi-message-01"></i> Smart Replies
            <?php if ($lead_email): ?>
            <span style="font-size:.65rem;color:#64748b;font-weight:400;margin-left:4px;">→ <?= h($lead_email) ?></span>
            <?php endif; ?>
          </div>

          <!-- Controls -->
          <div class="flex gap-1 mb-2" style="flex-wrap:wrap;">
            <select id="srTone" style="font-size:.72rem;padding:4px 8px;border:1px solid rgba(255,255,255,.15);border-radius:6px;color:#e2e8f0;background:rgba(255,255,255,.08);flex:1;min-width:90px;">
              <option value="professional">Professional</option>
              <option value="friendly">Friendly</option>
              <option value="urgent">Urgent</option>
            </select>
            <select id="srMode" style="font-size:.72rem;padding:4px 8px;border:1px solid rgba(255,255,255,.15);border-radius:6px;color:#e2e8f0;background:rgba(255,255,255,.08);flex:1;min-width:120px;">
              <option value="suggest"      <?= $camp_reply_mode==='suggest'       ?'selected':'' ?>>Suggest Only</option>
              <option value="auto_instant" <?= $camp_reply_mode==='auto_instant'  ?'selected':'' ?>>Auto-Send Now</option>
              <option value="auto_intent"  <?= $camp_reply_mode==='auto_intent'   ?'selected':'' ?>>Auto if Intent Matches</option>
            </select>
            <button type="button" id="srGenerateBtn" onclick="srGenerate()"
              class="ai-btn" style="flex-shrink:0;">
              <i class="hgi hgi-stroke hgi-ai-brain-05"></i> Generate
            </button>
          </div>

          <!-- Loading -->
          <div id="srLoading" style="display:none;font-size:.75rem;color:#94a3b8;padding:6px 0;">
            <span style="display:inline-block;width:12px;height:12px;border:2px solid #64748b;border-top-color:var(--brand-400);border-radius:50%;animation:spin .7s linear infinite;vertical-align:middle;margin-right:6px;"></span>
            Generating replies…
          </div>

          <!-- Auto-send result banner -->
          <div id="srAutoResult" style="display:none;margin-bottom:8px;font-size:.75rem;padding:8px 10px;border-radius:7px;"></div>

          <!-- Reply cards -->
          <div id="srList" style="display:flex;flex-direction:column;gap:8px;"></div>

          <!-- Mode info hint -->
          <div id="srModeHint" style="font-size:.67rem;color:#64748b;margin-top:6px;display:none;"></div>

        </div>
        <?php endif; ?>

        <!-- ── Email Draft (legacy) ──────────────── -->
        <?php if (ai_setting('ai_email_enabled','1') === '1'): ?>
        <div style="border-top:1px solid rgba(255,255,255,.1);padding-top:10px;margin-top:8px;">
          <div style="font-size:.68rem;font-weight:700;color:var(--brand-400);text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px;">
            <i class="hgi hgi-stroke hgi-mail-01"></i> Draft Email
          </div>
          <div id="aiEmailPanel" style="display:<?= $email_draft ? 'block' : 'none' ?>;">
            <?php if ($email_draft): ?>
            <div style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:8px;padding:10px;margin-bottom:8px;">
              <div style="font-size:.68rem;color:#a5b4fc;font-weight:700;margin-bottom:4px;">Subject: <?= h($email_draft['subject']) ?></div>
              <div style="font-size:.75rem;color:#e2e8f0;white-space:pre-line;line-height:1.5;"><?= h($email_draft['body']) ?></div>
              <?php if ($lead_email): ?>
              <button type="button" onclick="sendDraftEmail()" class="ai-btn mt-2" style="width:100%;">
                <i class="hgi hgi-stroke hgi-mail-send-01"></i> Send to <?= h($lead_email) ?>
              </button>
              <?php endif; ?>
            </div>
            <?php endif; ?>
            <form method="POST">
              <?= csrf_field() ?><input type="hidden" name="action" value="ai_email">
              <div class="flex gap-1">
                <select name="tone" class="select select-sm" style="background:rgba(255,255,255,.08);color:#e2e8f0;border-color:rgba(255,255,255,.15);">
                  <option value="professional">Professional</option>
                  <option value="friendly">Friendly</option>
                  <option value="urgent">Urgent</option>
                </select>
                <button type="submit" class="ai-btn">Generate</button>
              </div>
            </form>
          </div>
          <?php if (!$email_draft): ?>
          <button type="button" class="ai-btn" style="width:100%;"
            onclick="document.getElementById('aiEmailPanel').style.display='block';this.style.display='none';">
            <i class="hgi hgi-stroke hgi-mail-01"></i> Draft Email
          </button>
          <?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- ── Email History ─────────────────────── -->
        <?php if ($email_history): ?>
        <div style="border-top:1px solid rgba(255,255,255,.1);padding-top:10px;margin-top:8px;">
          <div style="font-size:.68rem;font-weight:700;color:var(--brand-400);text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px;">
            <i class="hgi hgi-stroke hgi-mail-at-sign-02"></i> Emails Sent (<?= count($email_history) ?>)
          </div>
          <div style="display:flex;flex-direction:column;gap:6px;">
            <?php foreach ($email_history as $eh): ?>
            <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:7px;padding:8px 10px;">
              <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:6px;">
                <div style="flex:1;min-width:0;">
                  <div style="font-size:.74rem;color:#e2e8f0;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= h($eh['subject']) ?></div>
                  <div style="font-size:.68rem;color:#64748b;margin-top:2px;"><?= h($eh['to_email']) ?> · <?= format_dt($eh['sent_at'], 'd M H:i') ?></div>
                </div>
                <span class="badge badge-sm <?= $eh['status']==='sent'?'badge-success':'badge-danger' ?>"><?= $eh['status'] ?></span>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
        <?php endif; ?>

        <?php if ($ai_res && $ai_res['reasoning']): ?>
        <details class="mt-3">
          <summary class="text-muted" style="font-size:.7rem;cursor:pointer;">AI reasoning</summary>
          <div class="text-muted mt-1" style="font-size:.72rem;line-height:1.5;"><?= h($ai_res['reasoning']) ?></div>
        </details>
        <?php endif; ?>

        <?php endif; // ai_on ?>
      </div>
    </div>

    <script>
    (function() {
      var LEAD_ID = <?= (int)$lid ?>;
      var CSRF    = '<?= csrf_token() ?>';
      var HAS_EMAIL = <?= $lead_email ? 'true' : 'false' ?>;

      // Generate smart replies
      window.srGenerate = function() {
        var tone = document.getElementById('srTone').value;
        var mode = document.getElementById('srMode').value;
        var btn  = document.getElementById('srGenerateBtn');

        document.getElementById('srLoading').style.display    = 'block';
        document.getElementById('srList').innerHTML            = '';
        document.getElementById('srAutoResult').style.display = 'none';
        document.getElementById('srModeHint').style.display   = 'none';
        btn.disabled = true;

        var fd = new FormData();
        fd.append('action', 'ai_smart_replies');
        fd.append('_csrf', CSRF);
        fd.append('tone', tone);
        fd.append('mode', mode);

        fetch(window.location.href, { method:'POST', body:fd, credentials:'same-origin' })
          .then(function(r) { return r.json(); })
          .then(function(data) {
            document.getElementById('srLoading').style.display = 'none';
            btn.disabled = false;

            if (!data.ok) {
              document.getElementById('srList').innerHTML =
                '<div style="font-size:.75rem;color:#ef4444;padding:6px 0;">Error: ' + (data.error||'Unknown') + '</div>';
              return;
            }

            // Show auto-send result
            if (data.auto_sent === true) {
              var ab = document.getElementById('srAutoResult');
              ab.style.display = 'block';
              ab.style.background = 'rgba(34,197,94,.12)';
              ab.style.border     = '1px solid rgba(34,197,94,.3)';
              ab.style.color      = '#86efac';
              ab.innerHTML = '✓ Auto-reply sent to <strong>' + (data.auto_sent_to||'') + '</strong>';
            } else if (data.auto_sent === false && data.no_email) {
              var ab = document.getElementById('srAutoResult');
              ab.style.display = 'block';
              ab.style.background = 'rgba(239,68,68,.1)';
              ab.style.border     = '1px solid rgba(239,68,68,.3)';
              ab.style.color      = '#fca5a5';
              ab.innerHTML = '⚠ No email address found for this lead';
            } else if (data.auto_sent === false && data.intent_no_match) {
              var ab = document.getElementById('srAutoResult');
              ab.style.display = 'block';
              ab.style.background = 'rgba(245,158,11,.1)';
              ab.style.border     = '1px solid rgba(245,158,11,.3)';
              ab.style.color      = '#fcd34d';
              ab.innerHTML = 'ℹ Intent did not match auto-reply criteria — replies generated for review';
            }

            // Show mode hint
            var hint = document.getElementById('srModeHint');
            if (mode === 'suggest') {
              hint.textContent = 'Click a reply to edit, then use Send to email the lead.';
              hint.style.display = 'block';
            }

            // Render reply cards
            var list = document.getElementById('srList');
            (data.replies||[]).forEach(function(reply, i) {
              var card = document.createElement('div');
              card.style.cssText = 'background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:8px;padding:10px;';
              card.innerHTML =
                '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">' +
                  '<span style="font-size:.68rem;font-weight:700;color:var(--brand-400);">' + (reply.label||'Option '+(i+1)) + '</span>' +
                  (HAS_EMAIL ?
                    '<button type="button" onclick="srSendReply(this)" data-subject="' + srEsc(reply.subject) + '" data-body="' + srEsc(reply.body) + '" ' +
                    'style="font-size:.68rem;padding:3px 9px;border-radius:6px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.1);color:#e2e8f0;cursor:pointer;">' +
                    '<i class="hgi hgi-stroke hgi-mail-send-01" style="font-size:.75rem;"></i> Send</button>' : '') +
                '</div>' +
                '<div style="font-size:.7rem;color:#94a3b8;margin-bottom:5px;">Subject: ' + srEsc(reply.subject) + '</div>' +
                '<div style="font-size:.78rem;color:#cbd5e1;line-height:1.6;white-space:pre-line;" contenteditable="true" ' +
                  'data-field="body" style="outline:none;border-radius:4px;padding:4px;" ' +
                  'onfocus="this.style.border=\'1px solid rgba(255,255,255,.2)\'" ' +
                  'onblur="this.style.border=\'none\'">' + srEsc(reply.body) + '</div>';
              list.appendChild(card);
            });
          })
          .catch(function(err) {
            document.getElementById('srLoading').style.display = 'none';
            btn.disabled = false;
            alert('Request failed: ' + err.message);
          });
      };

      // Send a specific reply card
      window.srSendReply = function(btn) {
        var card    = btn.closest('div[style]');
        var bodyEl  = card.querySelector('[data-field="body"]');
        var subject = btn.getAttribute('data-subject');
        var body    = bodyEl ? bodyEl.innerText : btn.getAttribute('data-body');

        btn.disabled    = true;
        btn.textContent = 'Sending…';

        var fd = new FormData();
        fd.append('action',     'send_reply');
        fd.append('_csrf', CSRF);
        fd.append('subject',    subject);
        fd.append('body',       body);

        fetch(window.location.href, { method:'POST', body:fd, credentials:'same-origin' })
          .then(function(r) { return r.json(); })
          .then(function(data) {
            if (data.ok) {
              btn.textContent      = '✓ Sent';
              btn.style.color      = '#86efac';
              btn.style.background = 'rgba(34,197,94,.15)';
            } else {
              btn.disabled    = false;
              btn.textContent = 'Send';
              alert('Send failed: ' + (data.error||'Unknown error'));
            }
          })
          .catch(function(err) {
            btn.disabled = false;
            btn.textContent = 'Send';
            alert('Request failed: ' + err.message);
          });
      };

      // Send the legacy email draft
      window.sendDraftEmail = function() {
        <?php if ($email_draft): ?>
        var subject = <?= json_encode($email_draft['subject'] ?? '') ?>;
        var body    = <?= json_encode($email_draft['body']    ?? '') ?>;
        var fd = new FormData();
        fd.append('action', 'send_reply');
        fd.append('_csrf', CSRF);
        fd.append('subject', subject);
        fd.append('body',    body);
        var btn = event.target;
        btn.disabled = true; btn.textContent = 'Sending…';
        fetch(window.location.href, { method:'POST', body:fd, credentials:'same-origin' })
          .then(function(r) { return r.json(); })
          .then(function(data) {
            if (data.ok) { btn.textContent = '✓ Sent'; btn.style.opacity = '.6'; }
            else { btn.disabled = false; btn.textContent = 'Send'; alert('Error: '+(data.error||'')); }
          });
        <?php endif; ?>
      };

      function srEsc(str) {
        return (str||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
      }
    })();
    </script>
    <?php endif; // can ai ?>

        <!-- Smart Duplicate Detection -->
    <?php if (can('leads','merge')): ?>
    <?php
    require_once __DIR__ . '/config/deduplication.php';
    // Use recorded duplicates first (fast), fall back to live scan
    $dup_records = db_fetch_all(
        "SELECT ld.*,
         CASE WHEN ld.lead_id_a = ? THEN ld.lead_id_b ELSE ld.lead_id_a END AS other_id
         FROM lead_duplicates ld
         WHERE (ld.lead_id_a = ? OR ld.lead_id_b = ?) AND ld.resolved = 0",
        'iii', $lid, $lid, $lid
    );
    // Enrich with lead data
    $dup_leads = [];
    foreach ($dup_records as $dr) {
        $other = db_fetch(
            "SELECT l.id, l.reference_no, l.status, l.submitted_at, l.assigned_to,
             CONCAT(u.first_name,' ',u.last_name) AS assigned_name
             FROM leads l LEFT JOIN users u ON u.id = l.assigned_to
             WHERE l.id = ? AND l.is_deleted = 0", 'i', (int)$dr['other_id']
        );
        if ($other) {
            $other['match_type']  = $dr['match_type'];
            $other['match_value'] = $dr['match_value'];
            $dup_leads[] = $other;
        }
    }
    // If table doesn't exist yet, fall back to live email scan
    if (empty($dup_leads)) {
        $live = dedupe_find($lid, $account_id);
        foreach ($live as $m) {
            $dup_leads[] = $m;
        }
    }
    ?>
    <?php if ($dup_leads): ?>
    <div class="card" style="border:1.5px solid #fde68a;">
      <div class="card-header" style="background:#fffbeb;border-radius:10px 10px 0 0;">
        <div style="display:flex;align-items:center;gap:6px;">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#d97706" stroke-width="2.5"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
          <div class="card-title" style="color:#92400e;"><?= count($dup_leads) ?> Possible Duplicate<?= count($dup_leads)>1?'s':'' ?></div>
        </div>
        <span style="font-size:.68rem;color:#b45309;background:#fef3c7;padding:2px 8px;border-radius:99px;">Review &amp; merge or dismiss</span>
      </div>
      <div style="padding:8px 14px;">
        <?php foreach ($dup_leads as $dup):
          $match_label = ['email'=>'Email match','phone'=>'Phone match','name_phone'=>'Name + phone match'][$dup['match_type']??'email'] ?? 'Match';
          $status_col  = ['new'=>'#3b82f6','contacted'=>'#f59e0b','qualified'=>'#8b5cf6','converted'=>'#22c55e','lost'=>'#94a3b8','spam'=>'#ef4444'][$dup['status']] ?? '#94a3b8';
        ?>
        <div style="border:1px solid var(--gray-100);border-radius:8px;padding:10px 12px;margin-bottom:8px;background:var(--gray-50);">
          <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:8px;">
            <div>
              <a href="<?= APP_URL ?>/lead_view.php?id=<?= $dup['id'] ?>" target="_blank"
                 style="font-size:.82rem;font-weight:700;color:var(--brand-500);text-decoration:none;">
                <?= h($dup['reference_no']) ?>
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align:middle;opacity:.5;"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
              </a>
              <div style="display:flex;align-items:center;gap:5px;margin-top:3px;">
                <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:<?= $status_col ?>;"></span>
                <span style="font-size:.72rem;color:var(--gray-500);"><?= ucfirst($dup['status']) ?></span>
                <span style="font-size:.7rem;color:var(--gray-300);">·</span>
                <span style="font-size:.7rem;color:var(--gray-400);"><?= format_dt($dup['submitted_at'], 'd M Y') ?></span>
              </div>
              <div style="margin-top:4px;">
                <span style="font-size:.68rem;background:#fef3c7;color:#b45309;padding:2px 7px;border-radius:99px;"><?= h($match_label) ?></span>
                <?php if (!empty($dup['match_value'])): ?>
                <span style="font-size:.68rem;color:var(--gray-400);margin-left:4px;"><?= h($dup['match_value']) ?></span>
                <?php endif; ?>
              </div>
            </div>
          </div>
          <div style="display:flex;gap:6px;flex-wrap:wrap;">
            <!-- Merge button + notes toggle -->
            <button type="button" onclick="showMerge(<?= $dup['id'] ?>)"
              class="btn btn-primary btn-sm" style="font-size:.72rem;">
              Merge into this lead
            </button>
            <!-- Dismiss -->
            <form method="POST" style="display:inline;">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="dismiss_dupe">
              <input type="hidden" name="dupe_lead_b" value="<?= $dup['id'] ?>">
              <button type="submit" class="btn btn-secondary btn-sm" style="font-size:.72rem;"
                title="Mark as not a duplicate — won't show again">Not a duplicate</button>
            </form>
          </div>
          <!-- Merge confirm panel (hidden) -->
          <div id="mergePanel<?= $dup['id'] ?>" style="display:none;margin-top:10px;padding:10px;background:#eff6ff;border-radius:8px;border:1px solid #bfdbfe;">
            <div style="font-size:.75rem;color:#1d4ed8;font-weight:600;margin-bottom:6px;">
              Merge <?= h($dup['reference_no']) ?> INTO this lead (<?= h($lead['reference_no']) ?>)
            </div>
            <div style="font-size:.72rem;color:#3b82f6;margin-bottom:8px;line-height:1.5;">
              All comments, field data, and activities from the duplicate will be preserved here. The duplicate lead will be archived.
            </div>
            <form method="POST">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="merge">
              <input type="hidden" name="target_lead_id" value="<?= $dup['id'] ?>">
              <textarea name="merge_notes" class="form-control" rows="2"
                placeholder="Optional note about this merge…"
                style="font-size:.78rem;margin-bottom:8px;resize:none;"></textarea>
              <div style="display:flex;gap:6px;">
                <button type="submit" class="btn btn-primary btn-sm" style="font-size:.72rem;">
                  Confirm Merge
                </button>
                <button type="button" onclick="document.getElementById('mergePanel<?= $dup['id'] ?>').style.display='none'"
                  class="btn btn-secondary btn-sm" style="font-size:.72rem;">Cancel</button>
              </div>
            </form>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
    <?php endif; // can merge ?>

    <!-- Lead management actions -->
    <div class="card" style="padding:14px;">
      <div style="font-size:.72rem;font-weight:700;text-transform:uppercase;color:var(--gray-400);letter-spacing:.05em;margin-bottom:10px;">Actions</div>
      <div style="display:flex;flex-direction:column;gap:7px;">

        <?php if (!$lead['archived_at'] && can('leads','archive')): ?>
        <form method="POST">
          <?= csrf_field() ?><input type="hidden" name="action" value="archive">
          <button type="submit" class="btn btn-secondary" style="width:100%;font-size:.78rem;">📦 Archive Lead</button>
        </form>
        <?php elseif ($lead['archived_at'] && can('leads','archive')): ?>
        <div style="font-size:.72rem;color:var(--gray-400);margin-bottom:2px;">Archived <?= format_dt($lead['archived_at'], 'd M Y') ?></div>
        <form method="POST">
          <?= csrf_field() ?><input type="hidden" name="action" value="unarchive">
          <button type="submit" class="btn btn-secondary" style="width:100%;font-size:.78rem;">↩ Unarchive</button>
        </form>
        <?php endif; ?>

        <?php if (!$lead['gdpr_erased_at'] && can('leads','gdpr_erase')): ?>
        <form method="POST" onsubmit="return confirm('GDPR ERASE: This will permanently delete all personal data from this lead. This CANNOT be undone. Continue?')">
          <?= csrf_field() ?><input type="hidden" name="action" value="gdpr_erase">
          <button type="submit" class="btn btn-secondary" style="width:100%;font-size:.78rem;color:var(--warning);">🔒 GDPR Erase PII</button>
        </form>
        <?php elseif ($lead['gdpr_erased_at']): ?>
        <div style="background:#fef2f2;border-radius:7px;padding:8px 10px;font-size:.72rem;color:#b91c1c;">
          🔒 PII erased on <?= format_dt($lead['gdpr_erased_at'], 'd M Y') ?>
        </div>
        <?php endif; ?>

        <?php if (can('leads', 'delete')): ?>
        <form method="POST" onsubmit="return confirm('Delete this lead? It will be moved to trash.')">
          <?= csrf_field() ?><input type="hidden" name="action" value="soft_delete">
          <button type="submit" class="btn btn-danger" style="width:100%;font-size:.78rem;">🗑 Delete Lead</button>
        </form>
        <?php endif; ?>

      </div>
    </div>

  </div>
</div>

<script>
function showMerge(id) {
  var p = document.getElementById('mergePanel' + id);
  if (p) p.style.display = p.style.display === 'none' ? 'block' : 'none';
}
function checkTransferReason(sel) {
  var orig = sel.getAttribute('data-orig') || '<?= (int)$lead['assigned_to'] ?>';
  var grp  = document.getElementById('transferReasonGroup');
  if (grp) grp.style.display = (sel.value !== orig) ? 'block' : 'none';
}
function toggleOwnershipLog() {
  var log   = document.getElementById('ownershipLog');
  var arrow = document.getElementById('ownershipArrow');
  if (!log) return;
  var open = log.style.display !== 'none';
  log.style.display   = open ? 'none' : 'block';
  arrow.style.transform = open ? '' : 'rotate(180deg)';
}
// Store original assigned_to on page load
window.addEventListener('DOMContentLoaded', function() {
  var sel = document.getElementById('assignedSelect');
  if (sel) sel.setAttribute('data-orig', sel.value);
});

// ── Lead reminder helpers ─────────────────────────────────
var _lrem_csrf = '<?= csrf_token() ?>';
function toggleNewReminder() {
  var f = document.getElementById('newReminderForm');
  if (!f) return;
  f.style.display = f.style.display === 'none' ? 'block' : 'none';
  if (f.style.display === 'block') {
    // Pre-fill datetime to tomorrow same time
    var d = new Date(); d.setDate(d.getDate()+1);
    var iso = d.toISOString().slice(0,16);
    document.getElementById('remAtInput').value = iso;
    document.getElementById('remMsgInput').focus();
  }
}
function submitNewReminder() {
  var msg  = document.getElementById('remMsgInput').value.trim();
  var at   = document.getElementById('remAtInput').value;
  var uid  = document.getElementById('remUserInput').value;
  if (!msg || !at) { alert('Please enter a note and time.'); return; }
  fetch(window.location.href, {
    method: 'POST',
    headers: {'Content-Type':'application/x-www-form-urlencoded'},
    body: '_reminder_action=create&reminder_msg='+encodeURIComponent(msg)+'&reminder_at='+encodeURIComponent(at)+'&reminder_user='+uid+'&_csrf='+encodeURIComponent(_lrem_csrf)
  }).then(function() {
    // Reload to show new reminder
    window.location.reload();
  });
}
function lremDone(id) {
  fetch(window.location.href, {
    method: 'POST',
    headers: {'Content-Type':'application/x-www-form-urlencoded'},
    body: '_reminder_action=done&reminder_id='+id+'&_csrf='+encodeURIComponent(_lrem_csrf)
  }).then(function() {
    var el = document.getElementById('lrem_'+id);
    if (el) el.style.opacity = '.3';
    setTimeout(function(){ if (el) el.remove(); }, 400);
  });
}
function lremSnooze(id, mins) {
  fetch(window.location.href, {
    method: 'POST',
    headers: {'Content-Type':'application/x-www-form-urlencoded'},
    body: '_reminder_action=snooze&reminder_id='+id+'&minutes='+mins+'&_csrf='+encodeURIComponent(_lrem_csrf)
  }).then(function() {
    var el = document.getElementById('lrem_'+id);
    if (el) el.style.opacity = '.3';
    setTimeout(function(){ if (el) el.remove(); }, 400);
  });
  lremCloseSnooze();
}
function lremToggleSnooze(id) {
  lremCloseSnooze();
  var m = document.getElementById('lSnooze_'+id);
  if (m) m.style.display = m.style.display === 'none' ? 'block' : 'none';
}
function lremCloseSnooze() {
  document.querySelectorAll('[id^="lSnooze_"]').forEach(function(m){ m.style.display='none'; });
}
document.addEventListener('click', function(e) {
  if (!e.target.closest('[onclick^="lremToggleSnooze"]')) lremCloseSnooze();
});
</script>
<?php include __DIR__ . '/layouts/footer.php'; ?>
