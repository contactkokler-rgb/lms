<?php
require_once __DIR__ . '/config/auth.php';
$user       = require_permission('leads', 'create');
$account_id = (int)($user['account_id'] ?? 0);
$is_super   = is_super_admin();

$page_title = 'Import Leads';
$active_nav = 'leads';

// ── Sample CSV download ──────────────────────────────────────
if (isset($_GET['sample'])) {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="leadpro-import-sample.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Name', 'Email', 'Phone', 'Company', 'Message']);
    fputcsv($out, ['Jane Smith', 'jane@example.com', '+1 555 000 1234', 'Acme Corp', 'Interested in your services']);
    fputcsv($out, ['Bob Jones', 'bob@company.org', '+44 7911 123456', 'Beta Ltd', 'Please contact me']);
    fputcsv($out, ['Maria Garcia', 'maria@biz.com', '', 'Gamma Inc', '']);
    fclose($out);
    exit;
}

// ── Load forms for this account ─────────────────────────────
$forms = $is_super
    ? db_fetch_all('SELECT f.id, f.name, d.domain FROM lead_forms f JOIN domains d ON d.id=f.domain_id WHERE f.is_active=1 ORDER BY f.name')
    : db_fetch_all('SELECT f.id, f.name, d.domain FROM lead_forms f JOIN domains d ON d.id=f.domain_id WHERE f.account_id=? AND f.is_active=1 ORDER BY f.name', 'i', $account_id);

$statuses = ['new','contacted','qualified','converted','lost'];

// ── AJAX: parse CSV and return preview + auto-mapping ───────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'parse_csv') {
    if (!csrf_verify()) { http_response_code(403); echo json_encode(['ok'=>false,'error'=>'CSRF']); exit; }
    header('Content-Type: application/json');

    $form_id = (int)($_POST['form_id'] ?? 0);
    if (!$form_id) { echo json_encode(['ok'=>false,'error'=>'Select a form first.']); exit; }

    // Validate form belongs to account
    $form = $is_super
        ? db_fetch('SELECT f.*, d.domain FROM lead_forms f JOIN domains d ON d.id=f.domain_id WHERE f.id=?', 'i', $form_id)
        : db_fetch('SELECT f.*, d.domain FROM lead_forms f JOIN domains d ON d.id=f.domain_id WHERE f.id=? AND f.account_id=?', 'ii', $form_id, $account_id);
    if (!$form) { echo json_encode(['ok'=>false,'error'=>'Invalid form.']); exit; }

    // Get form fields
    $form_fields = db_fetch_all('SELECT id, field_key, field_label, field_type, is_required FROM form_fields WHERE form_id=? AND is_visible=1 ORDER BY sort_order,id', 'i', $form_id);

    if (empty($_FILES['csv_file']['tmp_name'])) {
        echo json_encode(['ok'=>false,'error'=>'No file uploaded.']); exit;
    }
    $tmp  = $_FILES['csv_file']['tmp_name'];
    $name = $_FILES['csv_file']['name'] ?? 'upload.csv';

    // Read up to 502 rows (1 header + 501 data)
    $fh   = fopen($tmp, 'r');
    if (!$fh) { echo json_encode(['ok'=>false,'error'=>'Cannot read file.']); exit; }

    // Detect delimiter
    $first_line = fgets($fh);
    rewind($fh);
    $delimiters = [','=>0,';'=>0,"\t"=>0,'|'=>0];
    foreach ($delimiters as $d => $_) $delimiters[$d] = substr_count($first_line, $d);
    arsort($delimiters);
    $delimiter = key($delimiters) ?: ',';

    $rows    = [];
    $headers = null;
    $line    = 0;
    while (($row = fgetcsv($fh, 0, $delimiter)) !== false && $line < 502) {
        if ($line === 0) {
            $headers = array_map('trim', $row);
            $line++;
            continue;
        }
        $rows[] = array_map('trim', $row);
        $line++;
    }
    fclose($fh);

    if (!$headers) { echo json_encode(['ok'=>false,'error'=>'Could not read CSV headers.']); exit; }

    // Auto-map: match CSV headers to form field labels/keys
    $mapping = [];
    foreach ($headers as $idx => $hdr) {
        $normalized = strtolower(trim(preg_replace('/[^a-z0-9]+/','_', strtolower($hdr)), '_'));
        $best_field = null;
        $best_score = 0;

        foreach ($form_fields as $ff) {
            $fk = strtolower($ff['field_key']);
            $fl = strtolower($ff['field_label']);
            $fk_norm = preg_replace('/[^a-z0-9]+/','_', $fk);
            $fl_norm = preg_replace('/[^a-z0-9]+/','_', $fl);

            $score = 0;
            if ($normalized === $fk_norm || $normalized === $fl_norm) {
                $score = 100;
            } elseif (strpos($fk_norm, $normalized) !== false || strpos($normalized, $fk_norm) !== false) {
                $score = 80;
            } elseif (strpos($fl_norm, $normalized) !== false || strpos($normalized, $fl_norm) !== false) {
                $score = 70;
            } else {
                // Fuzzy: common aliases
                $aliases = [
                    'email' => ['email','e_mail','mail','email_address'],
                    'phone' => ['phone','mobile','cell','telephone','tel','contact','phone_number','mobile_number'],
                    'name'  => ['name','full_name','fullname','contact_name','customer_name','client_name'],
                    'first_name' => ['first','firstname','fname','given_name'],
                    'last_name'  => ['last','lastname','lname','surname','family_name'],
                    'company'    => ['company','organisation','organization','business','firm'],
                    'message'    => ['message','notes','note','comments','comment','description','inquiry'],
                ];
                foreach ($aliases as $key => $syns) {
                    if (in_array($normalized, $syns) && (strpos($fk, $key) !== false || strpos($fl, $key) !== false)) {
                        $score = 60;
                        break;
                    }
                }
            }

            if ($score > $best_score) {
                $best_score = $score;
                $best_field = $ff;
            }
        }
        $mapping[$idx] = $best_score >= 60 ? ($best_field['id'] ?? '') : '';
    }

    // Preview: first 5 data rows
    $preview = array_slice($rows, 0, 5);

    // Validation preview: check emails + phones in first 50 rows
    $validation_issues = [];
    foreach (array_slice($rows, 0, 50) as $ri => $row) {
        foreach ($headers as $hi => $hdr) {
            $val = $row[$hi] ?? '';
            if (!$val) continue;
            $norm = strtolower(preg_replace('/[^a-z]+/','_',strtolower($hdr)));
            if (strpos($norm,'email') !== false && !filter_var($val, FILTER_VALIDATE_EMAIL))
                $validation_issues[] = "Row " . ($ri+2) . ": '$val' is not a valid email";
        }
        if (count($validation_issues) >= 5) { $validation_issues[] = '...and more'; break; }
    }

    echo json_encode([
        'ok'         => true,
        'headers'    => $headers,
        'mapping'    => $mapping,
        'preview'    => $preview,
        'total_rows' => count($rows),
        'form_fields'=> $form_fields,
        'issues'     => $validation_issues,
        'delimiter'  => $delimiter,
    ]);
    exit;
}

// ── POST: execute import ─────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'execute_import') {
    if (!csrf_verify()) { http_response_code(403); die('CSRF'); }

    $form_id      = (int)($_POST['form_id'] ?? 0);
    $default_status = in_array($_POST['default_status'] ?? '', $statuses) ? $_POST['default_status'] : 'new';
    $dupe_action  = in_array($_POST['dupe_action'] ?? '', ['skip','merge']) ? $_POST['dupe_action'] : 'skip';
    $mapping      = $_POST['mapping'] ?? []; // [csv_col_idx => field_id]
    $delimiter    = in_array($_POST['delimiter'] ?? '', [',',';',"\t",'|']) ? $_POST['delimiter'] : ',';

    // Validate form
    $form = $is_super
        ? db_fetch('SELECT f.*, d.domain, d.id AS domain_id FROM lead_forms f JOIN domains d ON d.id=f.domain_id WHERE f.id=?', 'i', $form_id)
        : db_fetch('SELECT f.*, d.domain, d.id AS domain_id FROM lead_forms f JOIN domains d ON d.id=f.domain_id WHERE f.id=? AND f.account_id=?', 'ii', $form_id, $account_id);
    if (!$form) { $_SESSION['flash']=['type'=>'error','msg'=>'Invalid form.']; header('Location:'.APP_URL.'/import.php'); exit; }

    $form_acct = $is_super ? (int)$form['account_id'] : $account_id;

    if (empty($_FILES['csv_file']['tmp_name'])) {
        $_SESSION['flash']=['type'=>'error','msg'=>'No file uploaded.']; header('Location:'.APP_URL.'/import.php'); exit;
    }

    $tmp      = $_FILES['csv_file']['tmp_name'];
    $filename = basename($_FILES['csv_file']['name'] ?? 'import.csv');

    // Load form fields for validation
    $form_fields_by_id = [];
    foreach (db_fetch_all('SELECT * FROM form_fields WHERE form_id=? AND is_visible=1', 'i', $form_id) as $ff)
        $form_fields_by_id[$ff['id']] = $ff;

    require_once __DIR__ . '/config/deduplication.php';

    // Create import log record
    $import_id = db_insert(
        'INSERT INTO lead_imports (account_id,form_id,imported_by,filename,status,mapping) VALUES (?,?,?,?,?,?)',
        'iiiiss', $form_acct, $form_id, $user['id'], $filename, 'processing', json_encode($mapping)
    );

    // Read CSV
    $fh      = fopen($tmp, 'r');
    $headers = null;
    $total = $imported = $skipped = $merged = $failed = 0;
    $errors  = [];

    while (($row = fgetcsv($fh, 0, $delimiter)) !== false) {
        if (!$headers) { $headers = array_map('trim', $row); continue; }
        $total++;
        if ($total > 5000) { $errors[] = "Row $total: Import limit is 5,000 rows per file."; break; }

        // Build field values from mapping
        $field_values = [];
        foreach ($mapping as $col_idx => $field_id) {
            $field_id = (int)$field_id;
            if (!$field_id || !isset($form_fields_by_id[$field_id])) continue;
            $val = trim($row[(int)$col_idx] ?? '');
            if ($val === '') continue;
            $ff = $form_fields_by_id[$field_id];

            // Validation
            if ($ff['field_type'] === 'email' && !filter_var($val, FILTER_VALIDATE_EMAIL)) {
                $errors[] = "Row $total: invalid email '$val' — skipped field";
                continue;
            }

            $field_values[] = [
                'field_id'    => $ff['id'],
                'field_key'   => $ff['field_key'],
                'field_label' => $ff['field_label'],
                'value'       => substr($val, 0, 1000),
            ];
        }

        if (empty($field_values)) {
            $errors[] = "Row $total: no mapped values — skipped";
            $skipped++;
            continue;
        }

        // Dupe check
        $temp_signals = dedupe_extract_signals($field_values);
        $existing_dupe = null;

        if ($temp_signals['email']) {
            $existing_dupe = db_fetch(
                "SELECT l.id FROM leads l JOIN lead_values lv ON lv.lead_id=l.id
                 WHERE l.account_id=? AND l.form_id=? AND l.is_deleted=0
                 AND (lv.field_key LIKE '%email%' OR lv.field_label LIKE '%email%')
                 AND LOWER(lv.value)=? LIMIT 1",
                'iis', $form_acct, $form_id, strtolower($temp_signals['email'])
            );
        }
        if (!$existing_dupe && $temp_signals['phone']) {
            $existing_dupe = db_fetch(
                "SELECT l.id FROM leads l JOIN lead_values lv ON lv.lead_id=l.id
                 WHERE l.account_id=? AND l.form_id=? AND l.is_deleted=0
                 AND (lv.field_key LIKE '%phone%' OR lv.field_label LIKE '%phone%')
                 AND REGEXP_REPLACE(lv.value,'[^0-9]','')=? LIMIT 1",
                'iis', $form_acct, $form_id, $temp_signals['phone']
            );
        }

        if ($existing_dupe) {
            if ($dupe_action === 'skip') {
                $skipped++;
                continue;
            } elseif ($dupe_action === 'merge') {
                // Update existing lead's field values with any new data
                $existing_id = (int)$existing_dupe['id'];
                $existing_keys = array_column(
                    db_fetch_all('SELECT field_key FROM lead_values WHERE lead_id=?', 'i', $existing_id),
                    'field_key'
                );
                foreach ($field_values as $fv) {
                    if (!in_array($fv['field_key'], $existing_keys)) {
                        db_insert('INSERT INTO lead_values (lead_id,field_id,field_key,field_label,value) VALUES (?,?,?,?,?)',
                            'iisss', $existing_id, $fv['field_id'], $fv['field_key'], $fv['field_label'], $fv['value']);
                    }
                }
                $merged++;
                continue;
            }
        }

        // Insert lead
        $ref      = generate_reference($form_acct);
        $lead_id  = db_insert(
            'INSERT INTO leads (account_id,form_id,domain_id,reference_no,status,utm_source) VALUES (?,?,?,?,?,?)',
            'iiisss', $form_acct, $form_id, (int)$form['domain_id'], $ref, $default_status, 'import'
        );
        if (!$lead_id) { $errors[] = "Row $total: DB insert failed"; $failed++; continue; }

        // Insert field values
        foreach ($field_values as $fv) {
            db_insert('INSERT INTO lead_values (lead_id,field_id,field_key,field_label,value) VALUES (?,?,?,?,?)',
                'iisss', $lead_id, $fv['field_id'], $fv['field_key'], $fv['field_label'], $fv['value']);
        }

        // Run dedup detection
        try {
            $dupes = dedupe_find($lead_id, $form_acct);
            if ($dupes) dedupe_record($lead_id, $form_acct, $dupes);
        } catch (\Throwable $e) { /* ignore */ }

        $imported++;
    }
    fclose($fh);

    // Update import log
    db_query('UPDATE lead_imports SET status=?,total_rows=?,imported=?,skipped=?,merged=?,failed=?,errors=?,finished_at=NOW() WHERE id=?',
        'siiiiiis', 'done', $total, $imported, $skipped, $merged, $failed, json_encode(array_slice($errors,0,100)), $import_id);

    audit('leads.imported', "import:{$import_id}", ['imported'=>$imported,'skipped'=>$skipped,'merged'=>$merged]);

    $_SESSION['flash'] = ['type'=>'success','msg'=>
        "Import complete: $imported imported, $skipped skipped, $merged merged" .
        ($failed ? ", $failed failed" : '') . '.'];
    header('Location: '.APP_URL.'/leads.php'); exit;
}

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);

// Recent imports
$recent_imports = $is_super
    ? db_fetch_all('SELECT li.*, u.first_name, u.last_name, f.name AS form_name FROM lead_imports li JOIN users u ON u.id=li.imported_by JOIN lead_forms f ON f.id=li.form_id ORDER BY li.started_at DESC LIMIT 10')
    : db_fetch_all('SELECT li.*, u.first_name, u.last_name, f.name AS form_name FROM lead_imports li JOIN users u ON u.id=li.imported_by JOIN lead_forms f ON f.id=li.form_id WHERE li.account_id=? ORDER BY li.started_at DESC LIMIT 10', 'i', $account_id);

include __DIR__ . '/layouts/header.php';
?>

<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type'] ?>" data-auto-dismiss><?= h($flash['msg']) ?></div>
<?php endif; ?>

<div class="page-header">
  <div>
    <h1 class="page-title">Import Leads</h1>
    <p class="page-subtitle">Upload a CSV file to bulk-import leads</p>
  </div>
  <a href="<?= APP_URL ?>/leads.php" class="btn btn-secondary">← Back to Leads</a>
</div>

<div style="display:grid;grid-template-columns:1fr 340px;gap:20px;align-items:start;">

  <!-- Left: Upload form -->
  <div>
    <div class="card">
      <div class="card-header"><div class="card-title">Upload CSV</div></div>
      <div class="card-body">

        <?php if (empty($forms)): ?>
        <div class="empty-state">
          <div class="empty-state-title">No active forms</div>
          <div class="empty-state-desc">You need at least one active form to import leads.</div>
          <a href="<?= APP_URL ?>/forms.php" class="btn btn-primary" style="margin-top:12px;">Create a Form</a>
        </div>
        <?php else: ?>

        <!-- Step 1: Select form + upload -->
        <div id="step1">
          <div class="form-group">
            <label class="form-label">Target Form <span style="color:var(--danger);">*</span></label>
            <select id="formSelect" class="form-control" required>
              <option value="">Select a form…</option>
              <?php foreach ($forms as $f): ?>
              <option value="<?= $f['id'] ?>"><?= h($f['name']) ?> — <?= h($f['domain']) ?></option>
              <?php endforeach; ?>
            </select>
            <div style="font-size:.72rem;color:var(--gray-400);margin-top:4px;">CSV columns will be mapped to this form's fields.</div>
          </div>

          <div class="form-group">
            <label class="form-label">CSV File <span style="color:var(--danger);">*</span></label>
            <div id="dropZone" style="border:2px dashed var(--gray-200);border-radius:10px;padding:32px;text-align:center;cursor:pointer;transition:all .2s;"
                 ondragover="this.style.borderColor='var(--brand-500)';event.preventDefault()"
                 ondragleave="this.style.borderColor='var(--gray-200)'"
                 ondrop="handleDrop(event)"
                 onclick="document.getElementById('csvFile').click()">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="var(--gray-300)" stroke-width="1.5" style="margin:0 auto 10px;display:block;"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
              <div style="font-size:.85rem;font-weight:600;color:var(--gray-600);" id="dropLabel">Drop CSV here or click to browse</div>
              <div style="font-size:.75rem;color:var(--gray-400);margin-top:4px;">Max 5,000 rows · CSV format</div>
            </div>
            <input type="file" id="csvFile" accept=".csv,text/csv" style="display:none;" onchange="handleFileSelect(this)">
          </div>

          <button type="button" id="parseBtn" class="btn btn-primary" onclick="parseCsv()" disabled>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
            Preview & Map Columns
          </button>
        </div>

        <!-- Step 2: Mapping + preview (shown after parse) -->
        <div id="step2" style="display:none;">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
            <div style="font-size:.85rem;font-weight:600;color:var(--gray-700);">Column Mapping</div>
            <button type="button" class="btn btn-secondary btn-sm" onclick="resetImport()">← Start Over</button>
          </div>

          <!-- Validation issues -->
          <div id="issuesBox" style="display:none;background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:10px 14px;margin-bottom:14px;">
            <div style="font-size:.75rem;font-weight:700;color:#dc2626;margin-bottom:4px;">Validation Warnings</div>
            <div id="issuesList" style="font-size:.72rem;color:#b91c1c;line-height:1.7;"></div>
          </div>

          <form method="POST" id="importForm" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="execute_import">
            <input type="hidden" name="form_id" id="hiddenFormId">
            <input type="hidden" name="delimiter" id="hiddenDelimiter">
            <!-- Hidden file re-upload handled by JS cloning -->

            <!-- Mapping table -->
            <div style="overflow-x:auto;margin-bottom:16px;">
              <table class="table" id="mappingTable">
                <thead>
                  <tr>
                    <th>CSV Column</th>
                    <th>Sample Data</th>
                    <th>Map to Form Field</th>
                    <th style="width:70px;text-align:center;">Status</th>
                  </tr>
                </thead>
                <tbody id="mappingBody"></tbody>
              </table>
            </div>

            <!-- Import options -->
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px;">
              <div class="form-group" style="margin:0;">
                <label class="form-label" style="font-size:.75rem;">Default Status</label>
                <select name="default_status" class="form-control form-control-sm">
                  <?php foreach($statuses as $s): ?>
                  <option value="<?=$s?>" <?=$s==='new'?'selected':''?>><?=ucfirst($s)?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="form-group" style="margin:0;">
                <label class="form-label" style="font-size:.75rem;">Duplicate Handling</label>
                <select name="dupe_action" class="form-control form-control-sm">
                  <option value="skip">Skip duplicates</option>
                  <option value="merge">Merge (update existing)</option>
                </select>
              </div>
            </div>

            <!-- Preview table -->
            <div style="margin-bottom:16px;">
              <div style="font-size:.78rem;font-weight:600;color:var(--gray-700);margin-bottom:8px;">
                Data Preview <span id="previewCount" style="font-weight:400;color:var(--gray-400);"></span>
              </div>
              <div style="overflow-x:auto;border:1px solid var(--gray-100);border-radius:8px;">
                <table class="table" id="previewTable" style="font-size:.75rem;min-width:600px;">
                  <thead id="previewHead"></thead>
                  <tbody id="previewBody"></tbody>
                </table>
              </div>
            </div>

            <div style="display:flex;align-items:center;gap:10px;">
              <button type="submit" class="btn btn-primary" id="importBtn">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                Import Leads
              </button>
              <span id="rowCountLabel" style="font-size:.78rem;color:var(--gray-400);"></span>
            </div>
          </form>
        </div>

        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Right: Instructions + history -->
  <div>
    <!-- Instructions -->
    <div class="card" style="margin-bottom:16px;">
      <div class="card-header"><div class="card-title">How It Works</div></div>
      <div class="card-body" style="font-size:.8rem;color:var(--gray-600);line-height:1.8;">
        <div style="display:flex;gap:10px;margin-bottom:10px;">
          <span style="font-size:.9rem;">1️⃣</span><div>Select the form whose fields you want to populate, then upload your CSV file.</div>
        </div>
        <div style="display:flex;gap:10px;margin-bottom:10px;">
          <span style="font-size:.9rem;">2️⃣</span><div>Column mapping is detected automatically. Review and adjust any mis-matches.</div>
        </div>
        <div style="display:flex;gap:10px;margin-bottom:10px;">
          <span style="font-size:.9rem;">3️⃣</span><div>Preview your data. Validation issues are flagged before import.</div>
        </div>
        <div style="display:flex;gap:10px;">
          <span style="font-size:.9rem;">4️⃣</span><div>Choose how to handle duplicates — skip or merge with existing records.</div>
        </div>
        <hr style="border:none;border-top:1px solid var(--gray-100);margin:12px 0;">
        <div style="font-size:.72rem;color:var(--gray-400);">
          Supported: CSV (comma, semicolon, tab, or pipe delimited). Max 5,000 rows per import. First row must be column headers.
        </div>
      </div>
    </div>

    <!-- Download sample CSV -->
    <div class="card" style="margin-bottom:16px;">
      <div class="card-header"><div class="card-title">Sample CSV</div></div>
      <div class="card-body">
        <p style="font-size:.78rem;color:var(--gray-500);margin-bottom:10px;">Download a sample CSV template to see the expected format.</p>
        <a href="<?= APP_URL ?>/import.php?sample=1" class="btn btn-secondary btn-sm">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
          Download Template
        </a>
      </div>
    </div>

    <!-- Recent imports -->
    <?php if ($recent_imports): ?>
    <div class="card">
      <div class="card-header"><div class="card-title">Import History</div></div>
      <div style="padding:0 4px;">
        <?php foreach ($recent_imports as $imp): ?>
        <div style="padding:10px 12px;border-bottom:1px solid var(--gray-100);">
          <div style="font-size:.8rem;font-weight:600;color:var(--gray-700);"><?= h($imp['filename']) ?></div>
          <div style="font-size:.72rem;color:var(--gray-400);margin-top:2px;">
            <?= h($imp['form_name']) ?> · <?= format_dt($imp['started_at'], 'd M Y, g:ia') ?>
          </div>
          <div style="font-size:.72rem;color:var(--gray-500);margin-top:4px;display:flex;gap:10px;flex-wrap:wrap;">
            <span style="color:#16a34a;">✓ <?= $imp['imported'] ?> imported</span>
            <?php if ($imp['skipped']): ?><span style="color:var(--gray-400);">⊘ <?= $imp['skipped'] ?> skipped</span><?php endif; ?>
            <?php if ($imp['merged']): ?><span style="color:#2563eb;">⊕ <?= $imp['merged'] ?> merged</span><?php endif; ?>
            <?php if ($imp['failed']): ?><span style="color:#dc2626;">✗ <?= $imp['failed'] ?> failed</span><?php endif; ?>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>

</div>

<script>
var _csvFile   = null;
var _formFields = [];
var _headers   = [];
var _rows      = [];
var _mapping   = {};
var _delimiter = ',';

function handleDrop(e) {
  e.preventDefault();
  document.getElementById('dropZone').style.borderColor = 'var(--gray-200)';
  var files = e.dataTransfer.files;
  if (files.length) { _csvFile = files[0]; updateDropLabel(); checkReady(); }
}
function handleFileSelect(input) {
  if (input.files.length) { _csvFile = input.files[0]; updateDropLabel(); checkReady(); }
}
function updateDropLabel() {
  if (_csvFile) document.getElementById('dropLabel').textContent = _csvFile.name;
}
function checkReady() {
  var ok = _csvFile && document.getElementById('formSelect').value;
  document.getElementById('parseBtn').disabled = !ok;
}
document.getElementById('formSelect').addEventListener('change', checkReady);

function parseCsv() {
  var formId = document.getElementById('formSelect').value;
  if (!formId || !_csvFile) return alert('Select a form and upload a CSV file first.');

  var btn = document.getElementById('parseBtn');
  btn.disabled = true; btn.textContent = 'Analysing…';

  var fd = new FormData();
  fd.append('action', 'parse_csv');
  fd.append('_csrf', '<?= csrf_token() ?>');
  fd.append('form_id', formId);
  fd.append('csv_file', _csvFile);

  fetch(window.location.href, { method:'POST', body:fd })
    .then(function(r){ return r.json(); })
    .then(function(data) {
      btn.disabled = false; btn.textContent = 'Preview & Map Columns';
      if (!data.ok) { alert(data.error || 'Parse error'); return; }
      _formFields = data.form_fields;
      _headers    = data.headers;
      _rows       = data.preview;
      _mapping    = data.mapping;
      _delimiter  = data.delimiter;
      renderStep2(data);
    })
    .catch(function(e){ btn.disabled=false; btn.textContent='Preview & Map Columns'; alert('Error: '+e.message); });
}

function renderStep2(data) {
  document.getElementById('step1').style.display = 'none';
  document.getElementById('step2').style.display = 'block';

  document.getElementById('hiddenFormId').value  = document.getElementById('formSelect').value;
  document.getElementById('hiddenDelimiter').value = data.delimiter;

  // Validation issues
  if (data.issues && data.issues.length) {
    document.getElementById('issuesBox').style.display = 'block';
    document.getElementById('issuesList').innerHTML = data.issues.map(function(i){ return '<div>'+esc(i)+'</div>'; }).join('');
  }

  // Field options for select
  var fieldOptions = '<option value="">— Skip this column —</option>';
  data.form_fields.forEach(function(ff) {
    fieldOptions += '<option value="'+ff.id+'">'+esc(ff.field_label)+(ff.is_required?' *':'')+'</option>';
  });

  // Mapping table
  var tbody = '';
  data.headers.forEach(function(hdr, idx) {
    var mapped    = data.mapping[idx] || '';
    var sample    = (data.preview[0] && data.preview[0][idx]) ? data.preview[0][idx] : '';
    var isMapped  = mapped !== '';
    var statusBadge = isMapped
      ? '<span style="color:#16a34a;font-size:1.1em;">✓</span>'
      : '<span style="color:var(--gray-300);font-size:1.1em;">—</span>';
    tbody += '<tr>'
      + '<td style="font-weight:600;font-size:.8rem;">'+esc(hdr)+'</td>'
      + '<td style="font-size:.75rem;color:var(--gray-500);max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="'+esc(sample)+'">'+esc(sample)+'</td>'
      + '<td><select name="mapping['+idx+']" class="form-control form-control-sm mapping-sel" data-idx="'+idx+'" onchange="updateMappingStatus(this)">'
      + fieldOptions.replace('value="'+mapped+'"','value="'+mapped+'" selected')
      + '</select></td>'
      + '<td style="text-align:center;" id="status_'+idx+'">'+statusBadge+'</td>'
      + '</tr>';
  });
  document.getElementById('mappingBody').innerHTML = tbody;

  // Preview table
  var thead = '<tr>';
  data.headers.forEach(function(h){ thead += '<th>'+esc(h)+'</th>'; });
  thead += '</tr>';
  document.getElementById('previewHead').innerHTML = thead;

  var tbodyPrev = '';
  data.preview.forEach(function(row){
    tbodyPrev += '<tr>';
    data.headers.forEach(function(_,i){ tbodyPrev += '<td>'+esc(row[i]||'')+'</td>'; });
    tbodyPrev += '</tr>';
  });
  document.getElementById('previewBody').innerHTML = tbodyPrev;
  document.getElementById('previewCount').textContent = '(showing first '+Math.min(data.preview.length,5)+' of '+data.total_rows+' rows)';
  document.getElementById('rowCountLabel').textContent = data.total_rows + ' rows to import';

  // Wire file input to hidden form
  var fi = document.createElement('input');
  fi.type='file'; fi.name='csv_file'; fi.style.display='none';
  document.getElementById('importForm').appendChild(fi);
  var dt = new DataTransfer(); dt.items.add(_csvFile);
  fi.files = dt.files;
}

function updateMappingStatus(sel) {
  var idx = sel.dataset.idx;
  var cell = document.getElementById('status_'+idx);
  cell.innerHTML = sel.value ? '<span style="color:#16a34a;font-size:1.1em;">✓</span>' : '<span style="color:var(--gray-300);font-size:1.1em;">—</span>';
}

function resetImport() {
  _csvFile = null; _headers = []; _rows = []; _mapping = {}; _delimiter = ',';
  document.getElementById('dropLabel').textContent = 'Drop CSV here or click to browse';
  document.getElementById('csvFile').value = '';
  document.getElementById('step1').style.display = 'block';
  document.getElementById('step2').style.display = 'none';
  document.getElementById('issuesBox').style.display = 'none';
  document.getElementById('parseBtn').disabled = true;
}

function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

document.getElementById('importForm').addEventListener('submit', function(){
  var btn = document.getElementById('importBtn');
  btn.disabled = true;
  btn.innerHTML = '<span style="display:inline-flex;align-items:center;gap:6px;"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation:spin 1s linear infinite;"><path d="M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0z" opacity=".25"/><path d="M21 12a9 9 0 0 1-9 9"/></svg>Importing…</span>';
});
</script>
<style>@keyframes spin{to{transform:rotate(360deg)}}</style>

<?php include __DIR__ . '/layouts/footer.php'; ?>
