<?php
// embed/debug.php — DELETE THIS FILE AFTER DEBUGGING
// Visit: https://your-domain/embed/debug.php?token=YOUR_TOKEN
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

// Show full form row including domain_id
$full_form = $_GET['token']
    ? db_fetch('SELECT f.*, d.domain, d.is_active AS domain_active FROM lead_forms f LEFT JOIN domains d ON d.id = f.domain_id WHERE f.form_token = ?', 's', $_GET['token'])
    : null;

$form_fields = $_GET['token'] && $full_form
    ? db_fetch_all('SELECT id, field_key, field_label, field_type, is_required, is_visible FROM form_fields WHERE form_id = ? ORDER BY sort_order', 'i', $full_form['id'])
    : [];

echo json_encode([
    'app_url'      => APP_URL,
    'php_version'  => PHP_VERSION,
    'token_given'  => $_GET['token'] ?? null,
    'form'         => $_GET['token']
        ? db_fetch('SELECT id, name, is_active, form_token FROM lead_forms WHERE form_token = ?', 's', $_GET['token'])
        : 'No token provided — add ?token=YOUR_TOKEN to URL',
    'form_full'    => $full_form,
    'form_fields'  => $form_fields,
    'all_forms'    => db_fetch_all('SELECT id, name, is_active, LEFT(form_token,16) AS token_prefix FROM lead_forms LIMIT 10'),
    'all_domains'  => db_fetch_all('SELECT id, domain, is_active, account_id FROM domains LIMIT 10'),
], JSON_PRETTY_PRINT);
