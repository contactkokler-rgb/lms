/**
 * LeadPro Embed Loader v1.5
 *
 * IMPORTANT: Do NOT add the "async" attribute to this script tag.
 *
 * Usage:
 *   <script src="https://YOUR-DOMAIN/embed/loader.js" data-form="TOKEN"></script>
 *
 * What this version fixes:
 *  - UTM params now persist across pages via sessionStorage (so a user
 *    who lands on page-1 with UTMs then converts on page-2 still gets tracked)
 *  - Captures utm_device (gclid device param) automatically
 *  - postMessage is sent both on iframe load AND on a polling loop until
 *    the iframe JS acknowledges receipt — prevents the race condition where
 *    the message fires before the iframe is ready to receive it
 *  - Full source_url (href), referrer, and all UTM params always included
 */
(function () {
  'use strict';

  /* ── 1. Find script tag ─────────────────────────────────── */
  var scripts = document.getElementsByTagName('script');
  var thisScript = null;
  for (var i = scripts.length - 1; i >= 0; i--) {
    if (scripts[i].getAttribute('data-form') || scripts[i].getAttribute('data-token')) {
      thisScript = scripts[i]; break;
    }
  }
  if (!thisScript && document.currentScript) thisScript = document.currentScript;
  if (!thisScript) { console.error('[LeadPro] Script tag not found. Remove async attribute.'); return; }

  var token = thisScript.getAttribute('data-form') || thisScript.getAttribute('data-token');
  if (!token) { console.error('[LeadPro] Missing data-form attribute.'); return; }

  var scriptSrc = thisScript.src || '';
  var baseUrl = scriptSrc.replace(/\/embed\/loader\.js.*$/, '').replace(/\/+$/, '');
  if (!baseUrl) { console.error('[LeadPro] Cannot determine base URL.'); return; }

  /* ── 2. UTM capture — URL params + sessionStorage persistence ── */
  var UTM_KEYS = ['utm_source','utm_medium','utm_campaign','utm_term','utm_content','utm_device'];
  var SESSION_KEY = 'lp_utm_' + token;

  function parseUtmFromUrl() {
    var params = {};
    try {
      var qs = new URLSearchParams(window.location.search);
      UTM_KEYS.forEach(function(k) {
        var v = qs.get(k);
        if (v && v.trim()) params[k] = v.trim();
      });
      // Capture device from Google Ads URL params
      var gdevice = qs.get('device') || qs.get('gad_device');
      if (gdevice && !params['utm_device']) params['utm_device'] = gdevice;
    } catch(e) {}
    return params;
  }

  function loadStoredUtm() {
    try {
      var raw = sessionStorage.getItem(SESSION_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch(e) { return {}; }
  }

  function saveUtm(params) {
    try { sessionStorage.setItem(SESSION_KEY, JSON.stringify(params)); } catch(e) {}
  }

  var storedUtm  = loadStoredUtm();
  var currentUtm = parseUtmFromUrl();
  var utmParams  = {};
  UTM_KEYS.forEach(function(k) {
    utmParams[k] = currentUtm[k] || storedUtm[k] || '';
  });

  if (Object.keys(currentUtm).length > 0) {
    saveUtm(utmParams);
  }

  /* ── 3. Build context payload ───────────────────────────── */
  var context = {
    type:         'leadpro-context',
    source_url:   window.location.href  || '',
    referrer:     document.referrer     || '',
    utm_source:   utmParams.utm_source   || '',
    utm_medium:   utmParams.utm_medium   || '',
    utm_campaign: utmParams.utm_campaign || '',
    utm_term:     utmParams.utm_term     || '',
    utm_content:  utmParams.utm_content  || '',
    utm_device:   utmParams.utm_device   || ''
  };

  /* ── 4. Container / iframe ──────────────────────────────── */
  var containerId = thisScript.getAttribute('data-container') || 'leadpro-form';
  var container = document.getElementById(containerId);
  if (!container) {
    container = document.createElement('div');
    container.id = containerId;
    thisScript.parentNode.insertBefore(container, thisScript);
  }

  var formUrl = baseUrl + '/embed/form.php?token=' + encodeURIComponent(token);
  UTM_KEYS.forEach(function(k) {
    if (utmParams[k]) formUrl += '&' + k + '=' + encodeURIComponent(utmParams[k]);
  });
  formUrl += '&lp_src=' + encodeURIComponent((window.location.href || '').substring(0, 500));

  var iframe = document.createElement('iframe');
  iframe.src           = formUrl;
  iframe.width         = '100%';
  iframe.frameBorder   = '0';
  iframe.scrolling     = 'no';
  iframe.title         = 'Contact Form';
  iframe.setAttribute('loading', 'lazy');
  iframe.style.cssText = 'border:none;width:100%;min-height:300px;display:block;overflow:hidden;';
  container.innerHTML  = '';
  container.appendChild(iframe);

  /* ── 5. Reliable postMessage delivery with polling + ack ── */
  var contextSent = false;
  var pollCount   = 0;
  var pollMax     = 16;
  var pollTimer   = null;

  function sendContext() {
    try {
      if (iframe.contentWindow) {
        iframe.contentWindow.postMessage(context, '*');
      }
    } catch(e) {}
  }

  function startPolling() {
    if (contextSent) return;
    sendContext();
    pollTimer = setInterval(function() {
      if (contextSent || pollCount >= pollMax) {
        clearInterval(pollTimer);
        return;
      }
      sendContext();
      pollCount++;
    }, 300);
  }

  window.addEventListener('message', function(e) {
    try {
      if (!e.data) return;
      if (e.data.type === 'leadpro-resize') {
        var h = parseInt(e.data.height, 10);
        if (h > 0) iframe.style.height = (h + 40) + 'px';
      }
      if (e.data.type === 'leadpro-context-ack') {
        contextSent = true;
        clearInterval(pollTimer);
      }
    } catch(err) {}
  });

  iframe.addEventListener('load', function() {
    setTimeout(startPolling, 100);
  });

  setTimeout(startPolling, 200);

})();
