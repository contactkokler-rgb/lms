<?php
define('NO_SESSION', true);
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
require_once __DIR__ . '/../config/config.php';

header('X-Frame-Options: ALLOWALL'); // Legacy; CSP below takes precedence

// Load form + its registered domain
$token  = trim($_GET['token'] ?? '');
$form   = null;
$fields = [];
$error  = null;

if (!$token) {
    $error = 'No form token provided.';
} else {
    try {
        $form = db_fetch(
            'SELECT f.*, d.domain AS allowed_domain, d.is_active AS domain_active, d.verified_at
             FROM lead_forms f
             JOIN domains d ON d.id = f.domain_id
             WHERE f.form_token = ? AND f.is_active = 1',
            's', $token
        );
        if (!$form) {
            $error = 'Form not found or inactive.';
        } elseif (!$form['domain_active']) {
            $error = 'This form\'s domain has been disabled.';
        } else {
            $fields = db_fetch_all(
                'SELECT * FROM form_fields WHERE form_id = ? AND is_visible = 1 ORDER BY sort_order, id',
                'i', (int)$form['id']
            );
        }
    } catch (Throwable $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
}

// Restrict iframe embedding to the registered domain + our own server
if ($form) {
    $allowed_domain = $form['allowed_domain'];
    $our_host       = parse_url(APP_URL, PHP_URL_HOST) ?? '';
    $our_scheme     = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $allowed_origins = implode(' ', array_filter([
        'https://' . $allowed_domain,
        'http://'  . $allowed_domain,
        'https://www.' . $allowed_domain,
        'http://www.'  . $allowed_domain,
        ($our_host ? $our_scheme . '://' . $our_host : ''),
    ]));
    header("Content-Security-Policy: frame-ancestors 'self' " . $allowed_origins);
} else {
    header("Content-Security-Policy: frame-ancestors 'self'");
}
header('Content-Type: text/html; charset=UTF-8');

$settings = $form ? (json_decode($form['settings'] ?? '{}', true) ?: []) : [];

// UTM from query string (double fallback — loader.js passes these in case postMessage fails)
$utm_keys = ['utm_source','utm_medium','utm_campaign','utm_term','utm_content','utm_device'];
$utm_qs = [];
foreach ($utm_keys as $k) $utm_qs[$k] = trim($_GET[$k] ?? '');
// source_url fallback from query string (loader.js also passes lp_src=)
$src_qs = substr(trim($_GET['lp_src'] ?? ''), 0, 500);

// Root-relative URL: inherits scheme+host from the browser, always same-origin.
// Avoids mixed-content blocks and works in any subfolder install.
// e.g. /embed/form.php -> /submit.php  (root install)
//      /app/embed/form.php -> /app/submit.php  (subfolder)
$_base      = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'] ?? '/embed/x')), '/');
$submit_url = $_base . '/submit.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $form ? htmlspecialchars($form['name']) : 'Form' ?></title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:transparent;padding:8px 2px 20px}
.lp-field{margin-bottom:14px}
.lp-label{display:block;font-size:13px;font-weight:600;color:#1e293b;margin-bottom:5px}
.lp-req{color:#ef4444;margin-left:2px}
.lp-input{width:100%;padding:9px 12px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:14px;color:#0f172a;outline:none;transition:border-color .15s;background:#fff;font-family:inherit}
.lp-input:focus{border-color:#3b82f6;box-shadow:0 0 0 3px rgba(59,130,246,.12)}
textarea.lp-input{resize:vertical;min-height:80px}
.lp-btn{display:block;width:100%;padding:11px 16px;background:#2563eb;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;transition:background .15s;margin-top:4px;font-family:inherit}
.lp-btn:hover{background:#1d4ed8}
.lp-btn:disabled{background:#94a3b8;cursor:not-allowed}
.lp-errors{list-style:none;margin-bottom:10px}
.lp-errors li{font-size:12px;color:#ef4444;padding:4px 0}
.lp-success{padding:28px 16px;text-align:center}
.lp-success svg{display:block;margin:0 auto 12px}
.lp-success-title{font-size:17px;font-weight:700;color:#0f172a;margin-bottom:6px}
.lp-success-msg{font-size:14px;color:#64748b}
.lp-notice{padding:20px 16px;text-align:center;color:#94a3b8;font-size:13px;background:#f8fafc;border-radius:8px}
.lp-trap{position:absolute!important;left:-9999px!important;top:-9999px!important;height:1px!important;width:1px!important;overflow:hidden!important;opacity:0!important;pointer-events:none!important}
</style>
</head>
<body>
<?php if ($error): ?>
<div class="lp-notice"><?= htmlspecialchars($error) ?></div>
<?php elseif (!$fields): ?>
<div class="lp-notice">This form has no fields configured yet.</div>
<?php else: ?>

<div id="successMsg" class="lp-success" style="display:none;">
  <svg width="48" height="48" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="12" fill="#f0fdf4"/><polyline points="7,12 11,16 17,8" stroke="#16a34a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
  <div class="lp-success-title">Thank you!</div>
  <div class="lp-success-msg"><?= htmlspecialchars($settings['success_msg'] ?? 'We will be in touch soon.') ?></div>
</div>

<form class="lp-form" id="lpForm" novalidate>
  <?php foreach ($fields as $f):
    $key   = htmlspecialchars($f['field_key']);
    $label = htmlspecialchars($f['field_label']);
    $ph    = htmlspecialchars($f['placeholder'] ?? '');
    $req   = $f['is_required'] ? 'required' : '';
    $type  = $f['field_type'];
  ?>
  <?php if ($type === 'hidden'): ?>
  <input type="hidden" name="<?= $key ?>" value="<?= htmlspecialchars($f['default_value'] ?? '') ?>">
  <?php elseif ($type === 'textarea'): ?>
  <div class="lp-field">
    <label class="lp-label"><?= $label ?><?php if ($req): ?><span class="lp-req">*</span><?php endif; ?></label>
    <textarea class="lp-input" name="<?= $key ?>" placeholder="<?= $ph ?>" <?= $req ?>></textarea>
  </div>
  <?php elseif ($type === 'select'): ?>
  <div class="lp-field">
    <label class="lp-label"><?= $label ?><?php if ($req): ?><span class="lp-req">*</span><?php endif; ?></label>
    <select class="lp-input" name="<?= $key ?>" <?= $req ?>>
      <option value="">— Select —</option>
      <?php foreach (json_decode($f['options'] ?? '[]', true) ?: [] as $opt): ?>
      <option value="<?= htmlspecialchars($opt) ?>"><?= htmlspecialchars($opt) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <?php elseif ($type === 'radio' || $type === 'checkbox'): ?>
  <div class="lp-field">
    <label class="lp-label"><?= $label ?><?php if ($req): ?><span class="lp-req">*</span><?php endif; ?></label>
    <?php foreach (json_decode($f['options'] ?? '[]', true) ?: [] as $opt): ?>
    <label style="display:flex;align-items:center;gap:8px;margin-bottom:6px;font-size:13px;color:#334155;cursor:pointer;">
      <input type="<?= $type ?>" name="<?= $key ?>" value="<?= htmlspecialchars($opt) ?>" <?= $req ?>>
      <?= htmlspecialchars($opt) ?>
    </label>
    <?php endforeach; ?>
  </div>
  <?php else:
    $map = ['email'=>'email','phone'=>'tel','number'=>'number','url'=>'url','date'=>'date'];
    $input_type = isset($map[$type]) ? $map[$type] : 'text';
  ?>
  <div class="lp-field">
    <label class="lp-label"><?= $label ?><?php if ($req): ?><span class="lp-req">*</span><?php endif; ?></label>
    <input class="lp-input" type="<?= $input_type ?>" name="<?= $key ?>" placeholder="<?= $ph ?>" <?= $req ?>>
  </div>
  <?php endif; ?>
  <?php endforeach; ?>

  <input type="hidden" id="lp_ts" name="_lp_ts" value="">

  <!-- Honeypot trap field -->
  <div class="lp-trap" aria-hidden="true">
    <label for="lp_website">Website</label>
    <input type="text" id="lp_website" name="lp_website" tabindex="-1" autocomplete="off">
  </div>

  <ul class="lp-errors" id="formErrors"></ul>
  <button type="submit" class="lp-btn" id="submitBtn">Submit</button>
</form>

<script>
var SUBMIT_URL = <?= json_encode($submit_url) ?>;
var FORM_TOKEN = <?= json_encode((string)$form['form_token']) ?>;

// Context: pre-populated from query string (fallback if postMessage fails/races)
var context = {
  source_url:   <?= json_encode($src_qs) ?>,
  referrer:     '',
  utm_source:   <?= json_encode($utm_qs['utm_source']) ?>,
  utm_medium:   <?= json_encode($utm_qs['utm_medium']) ?>,
  utm_campaign: <?= json_encode($utm_qs['utm_campaign']) ?>,
  utm_term:     <?= json_encode($utm_qs['utm_term']) ?>,
  utm_content:  <?= json_encode($utm_qs['utm_content']) ?>,
  utm_device:   <?= json_encode($utm_qs['utm_device']) ?>
};
var contextReady = false; // true once postMessage received (overrides QS fallback)

// Receive context from loader.js via postMessage
window.addEventListener('message', function(e) {
  try {
    if (!e.data || e.data.type !== 'leadpro-context') return;
    // Always override with postMessage data (it's fresher / full URL)
    if (e.data.source_url)   context.source_url   = e.data.source_url;
    if (e.data.referrer     !== undefined) context.referrer     = e.data.referrer;
    if (e.data.utm_source   !== undefined) context.utm_source   = e.data.utm_source;
    if (e.data.utm_medium   !== undefined) context.utm_medium   = e.data.utm_medium;
    if (e.data.utm_campaign !== undefined) context.utm_campaign = e.data.utm_campaign;
    if (e.data.utm_term     !== undefined) context.utm_term     = e.data.utm_term;
    if (e.data.utm_content  !== undefined) context.utm_content  = e.data.utm_content;
    if (e.data.utm_device   !== undefined) context.utm_device   = e.data.utm_device;
    contextReady = true;
    // Acknowledge receipt — tells loader.js to stop polling
    window.parent.postMessage({type: 'leadpro-context-ack'}, '*');
  } catch(err) {}
});

function sendHeight() {
  var h = document.body.scrollHeight || document.documentElement.scrollHeight;
  window.parent.postMessage({type:'leadpro-resize', height:h}, '*');
}

document.getElementById('lpForm').addEventListener('submit', function(e) {
  e.preventDefault();
  var btn    = document.getElementById('submitBtn');
  var errBox = document.getElementById('formErrors');

  var trap = document.getElementById('lp_website');
  if (trap && trap.value) {
    document.getElementById('lpForm').style.display = 'none';
    document.getElementById('successMsg').style.display = 'block';
    sendHeight();
    return;
  }

  btn.disabled    = true;
  btn.textContent = 'Submitting…';
  errBox.innerHTML = '';

  var fields = {};
  var data = new FormData(this);
  data.forEach(function(v, k) { if (k !== 'lp_website') fields[k] = v; });

  fetch(SUBMIT_URL, {
    method:  'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      token:        FORM_TOKEN,
      fields:       fields,
      source_url:   context.source_url,
      referrer:     context.referrer,
      utm_source:   context.utm_source,
      utm_medium:   context.utm_medium,
      utm_campaign: context.utm_campaign,
      utm_term:     context.utm_term,
      utm_content:  context.utm_content,
      utm_device:   context.utm_device
    })
  })
  .then(function(res) { return res.json(); })
  .then(function(data) {
    if (data.ok) {
      document.getElementById('lpForm').style.display = 'none';
      document.getElementById('successMsg').style.display = 'block';
      if (data.redirect_url) setTimeout(function() { window.top.location.href = data.redirect_url; }, 1500);
    } else {
      var errs = data.errors || [data.error || 'Submission failed.'];
      errBox.innerHTML = errs.map(function(e) { return '<li>' + e + '</li>'; }).join('');
      btn.disabled = false;
      btn.textContent = 'Submit';
    }
    sendHeight();
  })
  .catch(function(err) {
    // err.message tells us whether this is a CORS block, mixed-content block,
    // network failure, or JSON parse error — useful for debugging.
    var msg = (err && err.message) ? err.message : 'unknown error';
    errBox.innerHTML = '<li>Submission error: ' + msg + '</li>';
    btn.disabled = false;
    btn.textContent = 'Submit';
    sendHeight();
  });
});

document.getElementById('lp_ts').value = Math.floor(Date.now()/1000);
window.addEventListener('load', sendHeight);
setTimeout(sendHeight, 200);
setTimeout(sendHeight, 800);
if (window.ResizeObserver) new ResizeObserver(sendHeight).observe(document.body);
</script>
<?php endif; ?>
</body>
</html>
