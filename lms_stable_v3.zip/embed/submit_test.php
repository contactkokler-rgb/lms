<?php
/**
 * LeadPro — Submit endpoint diagnostic
 * Visit: /embed/submit_test.php?token=YOUR_FORM_TOKEN
 * DELETE THIS FILE after confirming submit.php works.
 */
define('NO_SESSION', true);
require_once __DIR__ . '/../config/config.php';
header('Content-Type: text/html; charset=UTF-8');

$token = trim($_GET['token'] ?? '');
$form  = null;
if ($token) {
    $form = db_fetch(
        'SELECT f.id, f.name, f.form_token, f.is_active, d.domain AS allowed_domain, d.is_active AS domain_active
         FROM lead_forms f JOIN domains d ON d.id = f.domain_id WHERE f.form_token = ?', 's', $token
    );
}

// Detect what columns exist
$db2 = db();
$has_v2  = $db2->query("SHOW COLUMNS FROM leads LIKE 'device_type'")->num_rows > 0;
$has_geo = $db2->query("SHOW COLUMNS FROM leads LIKE 'utm_term'")->num_rows > 0;

$base = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'] ?? '/embed/x')), '/');
$submit_url = $base . '/submit.php';
?>
<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>Submit Test</title>
<style>body{font:14px monospace;padding:20px;background:#111;color:#eee}
.ok{color:#4ade80}.bad{color:#f87171}.warn{color:#fbbf24}
table{border-collapse:collapse;margin:10px 0}td,th{border:1px solid #444;padding:6px 12px;text-align:left}
button{padding:8px 16px;background:#3b82f6;color:#fff;border:none;cursor:pointer;font:inherit;margin-top:10px}
pre{background:#1a1a2e;padding:12px;overflow-x:auto}
</style></head><body>
<h2>LeadPro Submit Diagnostic</h2>
<table>
<tr><th>PHP Version</th><td><?= PHP_VERSION ?></td></tr>
<tr><th>APP_URL</th><td><?= h(APP_URL) ?></td></tr>
<tr><th>SUBMIT_URL (computed)</th><td><?= h($submit_url) ?></td></tr>
<tr><th>leads.device_type exists</th><td class="<?= $has_v2?'ok':'warn' ?>"><?= $has_v2?'YES (migrate_v2.sql run)':'NO (migrate_v2.sql not run — OK, handled)' ?></td></tr>
<tr><th>leads.utm_term exists</th><td class="<?= $has_geo?'ok':'warn' ?>"><?= $has_geo?'YES (migrate_utm_geo.sql run)':'NO (migrate_utm_geo.sql not run — OK, handled)' ?></td></tr>
<tr><th>Form token</th><td><?= $token ? h($token) : '<span class="warn">Not provided — add ?token=YOUR_TOKEN</span>' ?></td></tr>
<?php if ($form): ?>
<tr><th>Form found</th><td class="ok"><?= h($form['name']) ?> (ID <?= $form['id'] ?>)</td></tr>
<tr><th>Form active</th><td class="<?= $form['is_active']?'ok':'bad' ?>"><?= $form['is_active']?'YES':'NO' ?></td></tr>
<tr><th>Domain</th><td><?= h($form['allowed_domain']) ?> (active: <?= $form['domain_active']?'YES':'NO' ?>)</td></tr>
<?php elseif ($token): ?>
<tr><th>Form found</th><td class="bad">NOT FOUND — check token or form is inactive</td></tr>
<?php endif; ?>
</table>

<?php if ($form && $form['is_active'] && $form['domain_active']): ?>
<h3>Live POST test</h3>
<p>Click to POST a test submission directly to submit.php and see the raw response:</p>
<button onclick="runTest()">Run Test POST</button>
<pre id="out">…</pre>
<script>
function runTest() {
  var out = document.getElementById('out');
  out.textContent = 'Posting to <?= $submit_url ?>…';
  fetch(<?= json_encode($submit_url) ?>, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      token: <?= json_encode($token) ?>,
      fields: {_lp_ts: Math.floor(Date.now()/1000) - 5},
      source_url: window.location.href
    })
  })
  .then(function(r) {
    out.textContent = 'HTTP ' + r.status + '\n';
    return r.text();
  })
  .then(function(t) {
    out.textContent += t;
    try { JSON.parse(t); out.textContent += '\n\n✓ Valid JSON'; }
    catch(e) { out.textContent += '\n\n✗ NOT valid JSON: ' + e.message; }
  })
  .catch(function(e) {
    out.textContent = '✗ fetch() rejected: ' + e.message + '\n(CORS block, network failure, or mixed content)';
  });
}
</script>
<?php endif; ?>
</body></html>
